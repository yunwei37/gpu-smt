import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. Given \( n \) is a positive integer greater than or equal to 2.
  2. There exists an integer \( x \) such that \( x^3 = n \).
  3. There exists an integer \( t \) such that \( t^4 = n \).
  We need to prove that \( 4096 \leq n \).
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  have hx' : x ^ 1 ≤ x ^ 3 := by
    apply Nat.one_le_pow
  have ht' : t ^ 1 ≤ t ^ 4 := by
    apply Nat.one_le_pow
  have h : x ^ 3 ≥ 1 := by
    apply Nat.one_le_pow
  have h' : t ^ 4 ≥ 1 := by
    apply Nat.one_le_pow
  simp_all only [pow_one, Nat.mul_one]
  apply Nat.le_of_mul_le_mul_right <;> nlinarith
#print axioms mathd_numbertheory_296
