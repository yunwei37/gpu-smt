import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. Let \( n \) be a positive integer that satisfies \( 2 \leq n \), \( n \) being a perfect cube, and \( n \) being a perfect fourth power. We need to prove that \( 4096 \leq n \).
  1. **Perfect Cube Condition**: Given \( n \) is a perfect cube, we can write \( n = x^3 \) for some integer \( x \).
  2. **Perfect Fourth Power Condition**: Given \( n \) is also a perfect fourth power, we can write \( n = t^4 \) for some integer \( t \).
  Since \( n \) is a perfect cube and a perfect fourth power, we can express \( n \) as both \( x^3 \) and \( t^4 \). We need to find the smallest \( n \) that satisfies both conditions and is greater than or equal to 4096.
  -/
  -- Extract the values of x and t that satisfy the conditions
  cases' h₁ with x hx
  cases' h₂ with t ht
  -- Simplify the conditions to n = x^3 and n = t^4
  simp only [pow_three, pow_succ] at hx ht
  -- Normalize the numbers to ensure they are in the correct form
  norm_cast at hx ht
  -- Use the fact that n is a perfect cube and a perfect fourth power to derive the inequality
  have := h₀
  -- Use the derived inequality to show that n ≥ 4096
  apply Nat.le_of_not_lt
  intro h
  -- If n < 4096, then n cannot be both a perfect cube and a perfect fourth power
  have : t ≤ 15 := by
    -- Use the fact that n is a perfect cube and a perfect fourth power to derive t ≤ 15
    nlinarith [pow_two t, pow_two (t - 1), pow_two (t + 1)]
  have : x ≤ 15 := by
    -- Similarly, derive that x ≤ 15
    nlinarith [pow_two x, pow_two (x - 1), pow_two (x + 1)]
  -- Conclude that n < 4096 leads to a contradiction
  interval_cases t <;> interval_cases x <;> omega
#print axioms mathd_numbertheory_296
