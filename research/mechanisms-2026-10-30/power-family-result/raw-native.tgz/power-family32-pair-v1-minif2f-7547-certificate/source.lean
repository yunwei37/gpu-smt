import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) other than 1 that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. Let \( n \) be a positive integer such that \( n = x^3 \) for some integer \( x \) and \( n = t^4 \) for some integer \( t \). Since \( n \) must be a perfect cube and a perfect fourth power, we equate \( x^3 = t^4 \). This implies that \( t^4 = x^3 \). 
  To find the smallest such \( n \), we need to consider the smallest integers \( x \) and \( t \) such that \( t^4 = x^3 \). We start by checking the smallest values of \( x \) and \( t \).
  1. For \( x = 1 \), \( t^4 = 1^3 = 1 \). This does not satisfy \( t^4 = x^3 \) for any positive integer \( t \).
  2. For \( x = 2 \), \( t^4 = 2^3 = 8 \). The smallest integer \( t \) that satisfies \( t^4 = 8 \) is \( t = 2 \).
  3. For \( x = 3 \), \( t^4 = 3^3 = 27 \). The smallest integer \( t \) that satisfies \( t^4 = 27 \) is \( t = 3 \).
  4. For \( x = 4 \), \( t^4 = 4^3 = 64 \). The smallest integer \( t \) that satisfies \( t^4 = 64 \) is \( t = 4 \).
  5. For \( x = 5 \), \( t^4 = 5^3 = 125 \). The smallest integer \( t \) that satisfies \( t^4 = 125 \) is \( t = 5 \).
  For each \( x \), we check the smallest \( t \) that satisfies \( t^4 = x^3 \). We see that the smallest \( t \) that satisfies \( t^4 = x^3 \) is 1 for \( x = 1 \), 2 for \( x = 2 \), 3 for \( x = 3 \), 4 for \( x = 4 \), and 5 for \( x = 5 \).
  The smallest \( n \) is when \( x = 5 \), \( t = 5 \), so \( n = 5^3 = 125 \). However, we need to check if there is a smaller \( n \) that satisfies both conditions. We find that the smallest \( n \) that satisfies both conditions is 4096, as \( 4096 = 6^3 = 6^4 \).
  Thus, the smallest positive integer other than 1 that is both a perfect cube and a perfect fourth power is 4096.
  -/
  -- Normalize the numbers to simplify the proof.
  norm_num
  -- Extract the values of x and t from the given conditions.
  rcases h₁ with ⟨x, rfl⟩
  rcases h₂ with ⟨t, rfl⟩
  -- Use the fact that x^3 = t^4 to set up the inequality.
  apply le_of_not_lt
  intro h
  -- Use the inequality to show that n must be at least 4096.
  have h₁ : x ≤ 16 := by
    nlinarith [pow_two x, pow_two t]
  have h₂ : t ≤ 16 := by
    nlinarith [pow_two x, pow_two t]
  -- Use interval cases to check the possible values of x and t.
  m_power_cases x <;> m_power_cases t <;> norm_num at h ⊢
  -- Use linarith to conclude the proof.
  <;> linarith
#print axioms mathd_numbertheory_296
