import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. **Existence of \( x \) and \( t \)**:
     - Given \( n \) is a perfect cube, there exists an integer \( x \) such that \( x^3 = n \).
     - Similarly, given \( n \) is a perfect fourth power, there exists an integer \( t \) such that \( t^4 = n \).
  2. **Solving for \( n \)**:
     - From \( x^3 = n \), we know \( n \) must be a cube of an integer.
     - From \( t^4 = n \), we know \( n \) must be a fourth power of an integer.
  3. **Finding the smallest \( n \)**:
     - The smallest positive integer that is both a cube and a fourth power is 4096.
     - This is because \( 4096 = 16^3 \) and \( 4096 = 16^4 \).
  4. **Conclusion**:
     - Since 4096 is the smallest integer that satisfies both conditions, we conclude that \( n \geq 4096 \).
  -/
  -- Extract the integers x and t from the given conditions
  cases' h₁ with x hx
  cases' h₂ with t ht
  -- We know x^3 = n and t^4 = n from the given conditions
  have : x ≥ 2 := by
    -- Since x^3 = n and n ≥ 2, x must be at least 2 to satisfy the equation
    nlinarith [pow_two x, pow_two (x - 1)]
  have : t ≥ 2 := by
    -- Since t^4 = n and n ≥ 2, t must be at least 2 to satisfy the equation
    nlinarith [pow_two t, pow_two (t - 1)]
  -- Use the fact that the smallest n that is both a cube and a fourth power is 4096
  have : n ≥ 4096 := by
    -- Since x ≥ 2 and t ≥ 2, the smallest n that satisfies both conditions is 4096
    nlinarith [pow_two x, pow_two (x - 1), pow_two t, pow_two (t - 1)]
  -- Conclude that n ≥ 4096
  linarith
#print axioms mathd_numbertheory_296
