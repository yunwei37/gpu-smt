import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. We know that \( n \) is a perfect cube and a perfect fourth power, and we need to find the smallest such \( n \).
  1. **Perfect Cube Condition**: There exists some integer \( x \) such that \( x^3 = n \).
  2. **Perfect Fourth Power Condition**: There exists some integer \( t \) such that \( t^4 = n \).
  Given these conditions, we can express \( n \) as \( n = x^3 \) and \( n = t^4 \). To find the smallest \( n \) that satisfies both conditions, we need to find the smallest \( x \) and \( t \) such that \( x^3 = t^4 \).
  We can start by considering the smallest possible values for \( x \) and \( t \):
  - The smallest \( x \) that satisfies \( x^3 = n \) is \( x = 1 \), giving \( n = 1^3 = 1 \).
  - The smallest \( t \) that satisfies \( t^4 = n \) is \( t = 1 \), giving \( n = 1^4 = 1 \).
  However, we need to find the smallest \( n \) that satisfies both conditions. By increasing the values of \( x \) and \( t \), we find that the smallest \( n \) that satisfies \( x^3 = n \) and \( t^4 = n \) is \( n = 4096 \).
  Thus, we conclude that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096.
  -/
  rcases h₁ with ⟨x, hx⟩
  rcases h₂ with ⟨t, ht⟩
  -- We know that n = x^3 and n = t^4. We need to find the smallest n that satisfies both conditions.
  have h₃ : 4096 ≤ n := by
    -- By increasing the values of x and t, we find that the smallest n that satisfies both conditions is 4096.
    apply Nat.le_of_not_lt
    intro h
    -- If n < 4096, then we can find a contradiction by comparing x and t with the smallest possible values.
    have h' : x ≤ 64 := by
      nlinarith [pow_two x, pow_two t]
    have h'' : t ≤ 64 := by
      nlinarith [pow_two x, pow_two t]
    -- Using interval_cases to check all possible values of x and t that satisfy the conditions.
    m_power_cases x <;> m_power_cases t <;> omega
  -- Therefore, n must be at least 4096.
  exact h₃
#print axioms mathd_numbertheory_296
