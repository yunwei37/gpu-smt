import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. **Establish the conditions for the perfect cube and fourth power**:
     - Let \( n \) be a positive integer that is a perfect cube, i.e., \( n = x^3 \) for some integer \( x \).
     - Also, \( n \) is a perfect fourth power, i.e., \( n = t^4 \) for some integer \( t \).
  2. **Express \( n \) in terms of cubes and fourth powers**:
     - Since \( n \) is a perfect cube, we can write \( n = x^3 \).
     - Since \( n \) is also a perfect fourth power, we can write \( n = t^4 \).
  3. **Equate the two expressions for \( n \)**:
     - We need to find the smallest \( n \) that satisfies both \( n = x^3 \) and \( n = t^4 \).
     - This is equivalent to finding the smallest \( n \) that is a perfect cube and a perfect fourth power.
  4. **Solve the system of equations**:
     - We need to find the smallest \( n \) such that \( n = x^3 \) and \( n = t^4 \).
     - This can be solved by finding the least common multiple (LCM) of the two powers.
  5. **Calculate the LCM**:
     - The LCM of \( 3 \) and \( 4 \) is \( 12 \).
     - Therefore, the smallest \( n \) that is a perfect cube and a perfect fourth power is \( 12^4 = 20736 \).
  6. **Verify the smallest possible value**:
     - We need to verify that \( 4096 \) is indeed the smallest positive integer that satisfies the given conditions.
  -/
  -- Establish the conditions for the perfect cube and fourth power
  cases' h₁ with x hx
  cases' h₂ with t ht
  -- Express n in terms of cubes and fourth powers
  have h₃ := ht.symm
  have h₄ := hx.symm
  -- Simplify the expressions using the given conditions
  simp only [pow_mul, ← h₃, ← h₄] at h₃ h₄
  -- Use arithmetic reasoning to verify the smallest possible value
  apply le_of_not_lt
  intro h
  -- Use the fact that 2 ≤ n to derive a contradiction
  have h₅ : 2 ≤ n := h₀
  interval_cases n <;> omega
#print axioms mathd_numbertheory_296
