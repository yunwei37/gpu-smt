import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) other than 1 that is both a perfect cube and a perfect fourth power is 4096, we start by analyzing the given conditions. We know that \( n \) can be expressed as \( x^3 \) and \( t^4 \) for some natural numbers \( x \) and \( t \). We need to find the smallest such \( n \) that satisfies both conditions.
  1. Given \( n = x^3 \), we can express \( x \) in terms of its cube root. Since \( x \) must be a natural number, \( x \) must be an integer.
  2. Given \( n = t^4 \), we can express \( t \) in terms of its fourth root. Since \( t \) must be a natural number, \( t \) must be an integer.
  3. To find the smallest \( n \) that satisfies both conditions, we need to find the smallest integers \( x \) and \( t \) such that \( x^3 \) and \( t^4 \) are both integers and \( n = x^3 = t^4 \).
  4. We need to check if there are any integer solutions for \( x \) and \( t \) that satisfy both conditions. By examining the smallest possible values, we find that \( x = 4096 \) and \( t = 4096 \) satisfy the conditions.
  5. Therefore, the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096.
  -/
  rcases h₁ with ⟨x, hx⟩
  rcases h₂ with ⟨t, ht⟩
  -- We need to show that 4096 ≤ n.
  -- Given n = x^3 and n = t^4, we need to find the smallest x and t such that x^3 = t^4.
  -- By examining the smallest possible values, we find that x = 4096 and t = 4096 satisfy the conditions.
  -- Therefore, the smallest positive integer n that is both a perfect cube and a perfect fourth power is 4096.
  apply Nat.le_of_not_lt
  intro h
  -- If n < 4096, then we can find a contradiction by checking the smallest possible values.
  have hx' : x < 4096 := by
    nlinarith [pow_two x, pow_two (x - 1)]
  have ht' : t < 4096 := by
    nlinarith [pow_two t, pow_two (t - 1)]
  -- Using interval_cases to check the smallest possible values of x and t.
  m_power_cases x <;> m_power_cases t <;> omega
#print axioms mathd_numbertheory_296
