import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. We know that \( n \) can be expressed as \( x^3 \) and \( t^4 \) for some integers \( x \) and \( t \). We need to find the smallest \( n \) that satisfies these conditions.
  Given the constraints, we can start by examining the smallest possible values for \( x \) and \( t \). Since \( n \) must be a perfect cube and a perfect fourth power, we can use the properties of these powers to derive a lower bound.
  First, we note that the smallest perfect cube greater than 2 is \( 2^3 = 8 \). The smallest perfect fourth power greater than 2 is \( 2^4 = 16 \). However, since we need the smallest \( n \) that satisfies both conditions, we need to find the smallest \( n \) that is greater than 2 and is a perfect cube and a perfect fourth power.
  By examining the smallest possible values, we find that the smallest \( n \) that is a perfect cube and a perfect fourth power is \( 4096 \). This value is derived from the smallest perfect cube and perfect fourth power combinations, ensuring that \( n \) is greater than 2 and satisfies both conditions.
  -/
  -- Extract the values of x and t from the given conditions
  cases' h₁ with x hx
  cases' h₂ with t ht
  -- Use the properties of powers and the smallest possible values to derive a lower bound
  apply le_of_not_lt
  intro h
  -- Use the properties of powers and the smallest possible values to derive a lower bound
  have h₃ : n < 4096 := by
    -- Use the fact that n < 4096 to derive a contradiction
    nlinarith [pow_two x, pow_two t, pow_two 4, pow_two 8, pow_two 16, pow_two 64,
      pow_two 256, pow_two 1024, pow_two 2048]
  -- Use the properties of powers and the smallest possible values to derive a lower bound
  nlinarith [pow_two x, pow_two t, pow_two 4, pow_two 8, pow_two 16, pow_two 64,
    pow_two 256, pow_two 1024, pow_two 2048]
#print axioms mathd_numbertheory_296
