import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is at least 4096, we start by considering the given conditions. We have a number \( n \) that is a perfect cube and a perfect fourth power. 
  1. **Perfect Cube Condition**: There exists a natural number \( x \) such that \( x^3 = n \).
  2. **Perfect Fourth Power Condition**: There exists a natural number \( t \) such that \( t^4 = n \).
  Given these conditions, we need to find the smallest \( n \) that satisfies both conditions. By the properties of perfect cubes and perfect fourth powers, we know that the smallest such \( n \) must be a multiple of both 3 and 4.
  To find the smallest such \( n \), we can start by considering the least common multiple (LCM) of 3 and 4, which is 12. We then find the smallest positive integer that is a multiple of 12 and satisfies both conditions.
  -/
  -- Extract the number x such that x^3 = n
  cases' h₁ with x hx
  -- Extract the number t such that t^4 = n
  cases' h₂ with t ht
  -- We need to show that 4096 ≤ n. We start by using the properties of perfect cubes and perfect fourth powers.
  -- The smallest perfect cube is 1^3 = 1 and the smallest perfect fourth power is 1^4 = 1.
  -- Since n is a perfect cube and a perfect fourth power, it must be a multiple of both 3 and 4.
  -- The LCM of 3 and 4 is 12.
  -- We need to find the smallest n that is a multiple of 12 and satisfies both conditions.
  -- The smallest multiple of 12 is 12 itself, but 12 is not the smallest number that satisfies both conditions.
  -- We need to find the smallest n that is a multiple of 12 and satisfies both conditions.
  -- By the properties of perfect cubes and perfect fourth powers, we know that the smallest such n must be a multiple of both 3 and 4.
  -- The smallest multiple of 12 that satisfies both conditions is 4096.
  -- Therefore, we conclude that 4096 ≤ n.
  have : 4096 ≤ n := by
    -- Use the properties of perfect cubes and perfect fourth powers to show that 4096 ≤ n.
    apply Nat.le_of_not_lt
    intro h
    -- If n < 4096, then we can find a contradiction by checking the divisibility conditions.
    -- Specifically, we check that n is not divisible by 12, which contradicts the given conditions.
    have h₁ : x ≤ 4096 := by linarith
    have h₂ : t ≤ 4096 := by linarith
    -- Since n is a perfect cube and a perfect fourth power, it must be a multiple of both 3 and 4.
    -- The smallest multiple of 12 that satisfies both conditions is 4096.
    -- Therefore, we conclude that 4096 ≤ n.
    have h₃ : x ≤ 4096 := by linarith
    have h₄ : t ≤ 4096 := by linarith
    -- Use interval_cases to check the divisibility conditions and find the smallest n.
    m_power_cases x <;> m_power_cases t <;> omega
  -- Finally, we conclude that 4096 ≤ n.
  exact this
#print axioms mathd_numbertheory_296
