import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. Given \( n \) is a positive integer greater than or equal to 2.
  2. There exists an integer \( x \) such that \( x^3 = n \).
  3. There exists an integer \( t \) such that \( t^4 = n \).
  We need to prove that \( n \geq 4096 \).
  -/
  obtain ⟨x, hx⟩ := h₁
  -- We have \( n = x^3 \) for some integer \( x \).
  obtain ⟨t, ht⟩ := h₂
  -- We have \( n = t^4 \) for some integer \( t \).
  have h₃ : x ≥ 2 := by
    -- Since \( n \geq 2 \) and \( n = x^3 \), it follows that \( x^3 \geq 2 \).
    nlinarith [pow_two x, pow_two (x - 1)]
  have h₄ : t ≥ 2 := by
    -- Since \( n \geq 2 \) and \( n = t^4 \), it follows that \( t^4 \geq 2 \).
    nlinarith [pow_two t, pow_two (t - 1)]
  -- Using the fact that \( n = x^3 \) and \( n = t^4 \), we can derive a lower bound for \( n \).
  apply le_of_not_lt
  intro h
  -- If \( n < 4096 \), then we can find a contradiction with the properties of \( x \) and \( t \).
  have h₅ : x < 16 := by
    -- Since \( n < 4096 \), we have \( x^3 < 4096 \).
    nlinarith [pow_two x, pow_two (x - 1)]
  have h₆ : t < 16 := by
    -- Similarly, since \( n < 4096 \), we have \( t^4 < 4096 \).
    nlinarith [pow_two t, pow_two (t - 1)]
  -- Using the fact that \( x < 16 \) and \( t < 16 \), we can derive a contradiction.
  interval_cases x <;> interval_cases t <;> omega
#print axioms mathd_numbertheory_296
