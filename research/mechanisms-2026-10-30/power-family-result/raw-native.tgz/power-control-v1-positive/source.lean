import PowerMethods
set_option maxHeartbeats 200000
theorem positive (n x t : Nat) (hn : 2 ≤ n) (hlt : n < 4096)
 (hx : x^3=n) (ht : t^4=n) : False := by m_power_cases x
#print axioms positive
