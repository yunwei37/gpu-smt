import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. Given \( n \) is a perfect cube, there exists an integer \( x \) such that \( n = x^3 \).
  2. Given \( n \) is also a perfect fourth power, there exists an integer \( t \) such that \( n = t^4 \).
  3. We need to find the smallest \( n \) that satisfies both conditions. By examining the properties of cubes and fourth powers, we can determine the smallest such number.
  4. The smallest number that is both a perfect cube and a perfect fourth power is known to be 4096, which is verified by the given conditions.
  -/
  obtain ⟨x, hx⟩ := h₁
  -- Since n is a perfect cube, we can write n as x^3.
  obtain ⟨t, ht⟩ := h₂
  -- Since n is a perfect fourth power, we can write n as t^4.
  -- We need to find the smallest n that satisfies both conditions.
  apply Nat.le_of_not_lt
  intro h
  -- If n < 4096, then we can find a contradiction by comparing the cubes and fourth powers.
  have hx' : x < 16 := by
    -- Since x^3 < 4096, x must be less than 16.
    nlinarith [pow_two x, pow_two (x + 1)]
  have ht' : t < 16 := by
    -- Since t^4 < 4096, t must be less than 16.
    nlinarith [pow_two t, pow_two (t + 1)]
  -- By comparing the cubes and fourth powers, we find that no smaller number satisfies both conditions.
  interval_cases x <;> interval_cases t <;> linarith
#print axioms mathd_numbertheory_296
