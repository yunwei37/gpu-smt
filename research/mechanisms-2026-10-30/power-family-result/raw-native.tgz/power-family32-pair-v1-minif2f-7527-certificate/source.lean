import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \), other than 1, that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. Let \( n \) be a positive integer such that \( n \geq 2 \). We are given that \( n \) is a perfect cube and a perfect fourth power. This means there exist integers \( x \) and \( t \) such that \( n = x^3 \) and \( n = t^4 \).
  We need to find the smallest \( n \) that satisfies both conditions. By examining the properties of cubes and fourth powers, we know that the smallest number that can be expressed as both a cube and a fourth power is 4096. This is because \( 4096 = 16^3 = 2^24 \), which is the smallest number that can be expressed as both \( 2^a \) and \( 2^b \) where \( a \) and \( b \) are integers.
  Thus, the smallest positive integer \( n \) that satisfies both conditions is 4096.
  -/
  obtain ⟨x, hx⟩ := h₁
  -- We know that n is a perfect cube, so there exists an integer x such that n = x^3.
  obtain ⟨t, ht⟩ := h₂
  -- We also know that n is a perfect fourth power, so there exists an integer t such that n = t^4.
  have : x ≤ 2 ^ 15 := by
    -- Since n = x^3 and n = t^4, we need to show that x ≤ 2^15.
    -- We can use the fact that the smallest number that is both a cube and a fourth power is 4096.
    -- Since 4096 = 16^3 = 2^24, we need to show that x ≤ 2^24.
    nlinarith [pow_two x, pow_two t]
  have : t ≤ 2 ^ 12 := by
    -- Similarly, we need to show that t ≤ 2^12.
    -- We can use the fact that the smallest number that is both a cube and a fourth power is 4096.
    -- Since 4096 = 2^12, we need to show that t ≤ 2^12.
    nlinarith [pow_two x, pow_two t]
  -- Using the inequalities x ≤ 2^15 and t ≤ 2^12, we can conclude that n ≥ 4096.
  nlinarith [pow_two x, pow_two t]
#print axioms mathd_numbertheory_296
