import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. **Identify the perfect cube and fourth power conditions**:
     - Let \( n \) be a positive integer.
     - \( n \) is a perfect cube, so there exists an integer \( x \) such that \( x^3 = n \).
     - \( n \) is also a perfect fourth power, so there exists an integer \( t \) such that \( t^4 = n \).
  2. **Establish the conditions**:
     - From the conditions \( h₁ \) and \( h₂ \), we have:
       \[
       n = x^3 \quad \text{and} \quad n = t^4
       \]
     - This implies:
       \[
       x^3 = t^4
       \]
  3. **Analyze the smallest possible values**:
     - The smallest positive integer \( n \) that satisfies \( n = x^3 \) and \( n = t^4 \) is 4096.
     - Verify that 4096 satisfies both conditions:
       \[
       4096 = 16^3 = 2^8 = t^4
       \]
     - Therefore, \( t = 2 \) and \( n = 4096 \).
  4. **Conclusion**:
     - Since 4096 is the smallest number that satisfies both conditions, it follows that \( 4096 \leq n \).
  -/
  -- Extract the integer x such that x^3 = n from the perfect cube condition
  cases' h₁ with x hx
  -- Extract the integer t such that t^4 = n from the perfect fourth power condition
  cases' h₂ with t ht
  -- Rewrite n using the equalities x^3 = n and t^4 = n
  rw [← hx, ← ht]
  -- Introduce a hypothesis h to show 4096 ≤ 2^8
  have : 4096 ≤ 2 ^ 8 := by norm_num
  -- Use linear arithmetic to conclude 4096 ≤ n
  linarith
#print axioms mathd_numbertheory_296
