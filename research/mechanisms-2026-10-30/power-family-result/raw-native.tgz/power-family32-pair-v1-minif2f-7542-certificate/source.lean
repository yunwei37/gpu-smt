import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is at least 4096, we start by considering the properties of perfect cubes and perfect fourth powers. A perfect cube is of the form \( n = x^3 \), and a perfect fourth power is of the form \( n = t^4 \). We need to find the smallest such \( n \) that satisfies both conditions.
  Given the conditions, we can write:
  \[ n = x^3 \]
  \[ n = t^4 \]
  Since \( n \) must be the same in both cases, we equate the two expressions:
  \[ x^3 = t^4 \]
  This implies that \( t \) must be a power of \( x \). Let \( t = x^a \) for some integer \( a \). Then:
  \[ x^3 = (x^a)^4 \]
  \[ x^3 = x^{4a} \]
  Since \( x \) is a positive integer, we can equate the exponents:
  \[ 3 = 4a \]
  Solving for \( a \):
  \[ a = \frac{3}{4} \]
  However, \( a \) must be an integer, so we need to find the smallest \( n \) that satisfies both conditions. By checking the smallest integers, we find that \( n = 4096 \) is the smallest number that satisfies both conditions.
  -/
  -- Extract the values of x and t from the given conditions
  cases' h₁ with x hx
  cases' h₂ with t ht
  -- We need to show that 4096 is the smallest number that satisfies both conditions
  have h₃ : 4096 ≤ n := by
    -- Use the fact that x^3 = n and t^4 = n to find the smallest n
    apply Nat.le_of_not_lt
    intro h₄
    -- If n < 4096, then we can find a smaller x and t that satisfy the conditions
    have h₅ : x ≤ 4096 := by
      -- Use the fact that x^3 ≤ 4096 to find the smallest x
      nlinarith [pow_two x, pow_two (x - 1)]
    have h₆ : t ≤ 4096 := by
      -- Use the fact that t^4 ≤ 4096 to find the smallest t
      nlinarith [pow_two t, pow_two (t - 1)]
    -- Check all possible values of x and t that satisfy the conditions
    m_power_cases x <;> m_power_cases t <;> omega
  -- Conclude that 4096 is the smallest number that satisfies both conditions
  exact h₃
#print axioms mathd_numbertheory_296
