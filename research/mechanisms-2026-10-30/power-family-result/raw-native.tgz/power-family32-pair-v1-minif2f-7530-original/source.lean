import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. We know that \( n \) is at least 2, and there exist integers \( x \) and \( t \) such that \( x^3 = n \) and \( t^4 = n \). We need to prove that \( n \geq 4096 \).
  First, we note that \( n \) is a common multiple of 3 and 4. Let \( n = 12k \) for some integer \( k \). Since \( n \geq 2 \), we have \( 12k \geq 2 \), which implies \( k \geq \frac{1}{6} \). Since \( k \) is an integer, \( k \geq 1 \).
  Next, we consider the possible values of \( k \) that make \( n \) a perfect cube and a perfect fourth power. We need \( 12k \) to be a perfect cube and a perfect fourth power. This means \( 12k \) must be of the form \( 12m^3 \) and \( 12m^4 \) for some integers \( m \).
  Since \( 12k = 12m^3 \), we have \( k = m^3 \). Similarly, since \( 12k = 12m^4 \), we have \( k = m^4 \). This implies \( m^3 = m^4 \), which simplifies to \( m = 1 \). Thus, \( k = 1 \).
  Substituting \( k = 1 \) into the equation for \( n \), we get \( n = 12 \cdot 1 = 12 \). However, this contradicts the requirement that \( n \) must be at least 4096. Therefore, we need to re-evaluate our approach.
  Given the constraints, we need to find the smallest \( n \) that satisfies both conditions. By the properties of perfect cubes and fourth powers, we can use the fact that \( n \) must be a multiple of both 3 and 4. The smallest such \( n \) that satisfies both conditions is 4096.
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  -- We know that n is a perfect cube and a perfect fourth power, so we can use these facts to derive the inequality.
  apply le_of_not_lt
  intro h
  -- If n < 4096, then we can find a contradiction by comparing the properties of n being a perfect cube and a perfect fourth power.
  have h₃ : x ≤ 4096 := by
    nlinarith [pow_two x, pow_two t, pow_two (x - t)]
  have h₄ : t ≤ 4096 := by
    nlinarith [pow_two x, pow_two t, pow_two (x - t)]
  -- Using interval_cases to check all possible values of x and t that satisfy the conditions.
  interval_cases x <;> interval_cases t <;> omega
#print axioms mathd_numbertheory_296
