import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. Assume \( n \) is a positive integer that is both a perfect cube and a perfect fourth power.
  2. By the given conditions, there exist integers \( x \) and \( t \) such that \( x^3 = n \) and \( t^4 = n \).
  3. We need to show that \( n \geq 4096 \).
  4. Consider the least common multiple (LCM) of \( n \) when divided by 3 and 4. The LCM of 3 and 4 is 12.
  5. Since \( n \) is a perfect cube, it must be a multiple of 3, and since \( n \) is a perfect fourth power, it must be a multiple of 4.
  6. Therefore, \( n \) must be a multiple of 12.
  7. The smallest positive integer that is a multiple of 12 and greater than or equal to 4096 is 4096.
  8. Hence, \( n \geq 4096 \).
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  have h₃ : 0 < n := by linarith
  have h₄ : 0 < x := by
    -- Since x^3 = n and n ≥ 4096, x must be positive to satisfy the equation x^3 = n.
    nlinarith [pow_two x, pow_two t]
  have h₅ : 0 < t := by
    -- Similarly, since t^4 = n and n ≥ 4096, t must be positive to satisfy the equation t^4 = n.
    nlinarith [pow_two x, pow_two t]
  -- Given that n ≥ 4096 and n is a multiple of 12, we conclude that n ≥ 4096.
  nlinarith [pow_two x, pow_two t, pow_two (n - x ^ 3), pow_two (n - t ^ 4)]
#print axioms mathd_numbertheory_296
