import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. **Identify the conditions**: We need \( n \) to be a perfect cube and a perfect fourth power. This implies \( n = x^3 \) and \( n = t^4 \) for some integers \( x \) and \( t \).
  2. **Establish lower bounds**: Since \( n \) is a perfect cube and a perfect fourth power, we can infer that \( n \) must be at least 4096. This is because the smallest perfect cube greater than 1 is 8 (corresponding to \( x = 2 \)), and the smallest perfect fourth power greater than 1 is 16 (corresponding to \( t = 2 \)). Therefore, \( n \) must be at least \( 2^6 = 64 \), but since \( n \) is both a perfect cube and a perfect fourth power, it must be at least 4096.
  3. **Conclusion**: Given the constraints and the need for \( n \) to be at least 4096, we conclude that the smallest such \( n \) is indeed 4096.
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  have hx' : x ≥ 4 := by
    -- We need to show that x ≥ 4 to satisfy the conditions.
    -- Since x^3 is a perfect fourth power, we can infer that x must be at least 4.
    contrapose! hx
    have : x < 4 := by linarith
    interval_cases x <;> simp_all [pow_succ]
  have ht' : t ≥ 4 := by
    -- Similarly, we need to show that t ≥ 4 to satisfy the conditions.
    -- Since t^4 is a perfect cube, we can infer that t must be at least 4.
    contrapose! ht
    have : t < 4 := by linarith
    interval_cases t <;> simp_all [pow_succ]
  have : x ^ 3 ≥ 4 ^ 3 := by gcongr
  have : t ^ 4 ≥ 4 ^ 4 := by gcongr
  linarith
#print axioms mathd_numbertheory_296
