import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power, is 4096, we start by considering the given conditions. Let \( n \) be a positive integer such that \( n \geq 2 \), and \( n \) can be expressed as a perfect cube and a perfect fourth power. We need to show that \( n \geq 4096 \).
  1. From the condition that \( n \) is a perfect cube, we can write \( n = x^3 \) for some integer \( x \).
  2. Similarly, from the condition that \( n \) is a perfect fourth power, we can write \( n = t^4 \) for some integer \( t \).
  3. Equating the two expressions for \( n \), we get \( x^3 = t^4 \).
  4. To find the smallest such \( n \), we need to find the smallest \( n \) that satisfies both conditions.
  5. We use the fact that \( 2 \leq n \) and the smallest integers \( x \) and \( t \) that satisfy \( x^3 = t^4 \).
  6. By solving the equation \( x^3 = t^4 \) for the smallest integers \( x \) and \( t \), we find that the smallest values that satisfy this equation are \( x = 16 \) and \( t = 4 \).
  7. Substituting these values back into the expression for \( n \), we get \( n = 16^3 = 4096 \).
  Thus, the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is indeed 4096.
  -/
  -- We use the fact that n is a perfect cube and a perfect fourth power to set up equations involving x and t.
  cases' h₁ with x hx
  cases' h₂ with t ht
  -- We know that x and t are integers such that n = x^3 and n = t^4.
  -- We need to find the smallest n that satisfies both conditions.
  -- By solving the equation x^3 = t^4 for the smallest integers x and t, we find that the smallest values are x = 16 and t = 4.
  -- Substituting these values back into the expression for n, we get n = 16^3 = 4096.
  have h : n ≥ 4096 := by
    rw [show n = 16 ^ 3 by
      -- Using the fact that n is a perfect cube, we solve for n.
      have : x ≤ 4096 := by
        -- We use the fact that 2 ≤ n and solve for n.
        nlinarith [pow_two x, pow_two (x - 16), pow_two (x + 16)]
      have : t ≤ 4096 := by
        -- We use the fact that n is a perfect fourth power and solve for n.
        nlinarith [pow_two t, pow_two (t - 4), pow_two (t + 4)]
      -- We equate the expressions for n and solve for n.
      nlinarith [pow_two x, pow_two (x - 16), pow_two (x + 16), pow_two t, pow_two (t - 4), pow_two (t + 4)]
    ]
    nlinarith [pow_two x, pow_two (x - 16), pow_two (x + 16), pow_two t, pow_two (t - 4), pow_two (t + 4)]
  nlinarith [pow_two x, pow_two (x - 16), pow_two (x + 16), pow_two t, pow_two (t - 4), pow_two (t + 4)]
#print axioms mathd_numbertheory_296
