import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is at least 4096, we proceed as follows:
  1. Assume \( n \) is the smallest such integer and \( n > 1 \).
  2. By the properties of perfect cubes and perfect fourth powers, \( n \) must be at least 4096.
  3. We use the given conditions \( h₁ \) and \( h₂ \) to show that \( n \) is a perfect cube and a perfect fourth power.
  4. Specifically, we use the existence of \( x \) such that \( x^3 = n \) and \( t \) such that \( t^4 = n \) to establish a lower bound for \( n \).
  5. By simplifying and combining these conditions, we conclude that \( n \geq 4096 \).
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  apply le_of_not_lt
  intro h
  -- We need to show that if n < 4096, then n cannot be both a perfect cube and a perfect fourth power.
  have hx' : x < 4096 := by linarith [pow_two x, pow_two t]
  have ht' : t < 4096 := by linarith [pow_two x, pow_two t]
  -- Using the properties of perfect cubes and perfect fourth powers, we derive a contradiction.
  interval_cases x <;> interval_cases t <;> omega
#print axioms mathd_numbertheory_296
