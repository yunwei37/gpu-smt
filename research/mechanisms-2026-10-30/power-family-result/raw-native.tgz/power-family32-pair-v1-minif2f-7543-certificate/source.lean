import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is at least 4096, we proceed as follows:
  1. Let \( n \) be a positive integer that is a perfect cube and a perfect fourth power.
  2. By the properties of perfect cubes and fourth powers, there exist integers \( x \) and \( t \) such that \( x^3 = n \) and \( t^4 = n \).
  3. We need to show that \( n \geq 4096 \).
  4. Given the conditions \( 2 \leq n \), \( x^3 = n \), and \( t^4 = n \), we can use the fact that the smallest perfect cube and perfect fourth power that are at least 4096 are 4096 itself.
  5. Therefore, \( n \) must be at least 4096.
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  -- We know that x^3 = n and t^4 = n.
  have h₃ := hx
  have h₄ := ht
  -- Since n is a perfect cube, n must be of the form x^3 for some integer x.
  -- Since n is a perfect fourth power, n must be of the form t^4 for some integer t.
  -- Therefore, n must be a multiple of both 3 and 4, which is 12.
  -- The smallest perfect cube multiple of 12 is 4096.
  have h₅ : n ≥ 4096 := by
    calc
      4096 = 16 ^ 3 := by norm_num
      _ ≤ n := by
        -- Since n is a perfect cube and 16 is the smallest perfect cube multiple of 12, n must be at least 4096.
        apply le_of_not_lt
        intro h
        -- If n < 4096, then n is not a perfect cube and not a perfect fourth power, contradicting the given conditions.
        have h₆ : x < 16 := by
          nlinarith [pow_two x, pow_two (x - 1), pow_two (x + 1)]
        have h₇ : t < 16 := by
          nlinarith [pow_two t, pow_two (t - 1), pow_two (t + 1)]
        -- Using the fact that n < 4096, we can find a contradiction with the properties of perfect cubes and perfect fourth powers.
        m_power_cases x <;> m_power_cases t <;> omega
  -- Therefore, n must be at least 4096.
  exact h₅
#print axioms mathd_numbertheory_296
