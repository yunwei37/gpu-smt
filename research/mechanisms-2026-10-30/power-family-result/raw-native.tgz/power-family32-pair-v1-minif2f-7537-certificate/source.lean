import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) other than 1 that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. Let \( n \) be a positive integer that satisfies \( 2 \leq n \), \( n \) is a perfect cube, and \( n \) is a perfect fourth power. This means there exist integers \( x \) and \( t \) such that \( x^3 = n \) and \( t^4 = n \).
  Given that \( n \) is both a perfect cube and a perfect fourth power, we can equate the two expressions for \( n \):
  \[ x^3 = t^4 \]
  To find the smallest such \( n \), we need to solve for \( x \) and \( t \) and find the smallest \( n \). We can test small values of \( x \) and \( t \) to find the smallest \( n \) that satisfies this condition.
  -/
  rcases h₁ with ⟨x, hx⟩
  rcases h₂ with ⟨t, ht⟩
  -- We need to find the smallest n that is both a perfect cube and a perfect fourth power.
  -- We start by considering the smallest possible values of x and t.
  apply le_of_not_lt
  intro h
  -- Assume n < 4096 and derive a contradiction.
  have hx' : x < 4096 := by
    nlinarith [pow_two x, pow_two (x + 1)]
  have ht' : t < 4096 := by
    nlinarith [pow_two t, pow_two (t + 1)]
  -- Since x and t are integers, the smallest possible values for x and t that satisfy x^3 = n and t^4 = n are 1.
  -- However, n cannot be both 1 and a perfect fourth power, leading to a contradiction.
  m_power_cases x <;> m_power_cases t <;> omega
#print axioms mathd_numbertheory_296
