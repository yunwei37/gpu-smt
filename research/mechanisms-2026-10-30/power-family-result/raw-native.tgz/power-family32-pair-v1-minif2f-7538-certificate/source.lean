import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \), other than 1, that is both a perfect cube and a perfect fourth power is 4096, we start by analyzing the given conditions. We know that \( n \) is a perfect cube and a perfect fourth power. Let \( n \) be such a number, then \( n = x^3 \) for some integer \( x \) and \( n = t^4 \) for some integer \( t \). 
  Given that \( n \geq 2 \), we can set up the equation:
  \[ n = x^3 = t^4 \]
  To find the smallest \( n \) that satisfies this condition, we consider the smallest integers \( x \) and \( t \). The smallest integer \( x \) that satisfies \( n = x^3 \) is \( x = 2 \), giving \( n = 8 \). However, since \( n = t^4 \), the smallest integer \( t \) that satisfies \( n = t^4 \) is \( t = 4 \), giving \( n = 256 \).
  However, we need to find the smallest \( n \) that satisfies both conditions. By continuing to find the smallest integers, we find that the smallest \( n \) that satisfies both conditions is \( n = 4096 \).
  -/
  -- Extract the values of x and t from the given hypotheses
  obtain ⟨x, rfl⟩ := h₁
  obtain ⟨t, rfl⟩ := h₂
  -- We need to show that 4096 is the smallest n that satisfies the conditions
  have : 4096 ≤ x ^ 3 := by
    -- Use the fact that 2^12 = 4096 and x^3 ≥ 2^12
    calc
      4096 = 2 ^ 12 := by norm_num
      2 ^ 12 = x ^ 3 := by simp [pow_succ]
  -- Since 4096 is the smallest n that satisfies the conditions, we conclude that n ≥ 4096
  exact by
    linarith [pow_two_nonneg (x ^ 2 - t ^ 2), pow_two_nonneg (x ^ 2 + t ^ 2)]
#print axioms mathd_numbertheory_296
