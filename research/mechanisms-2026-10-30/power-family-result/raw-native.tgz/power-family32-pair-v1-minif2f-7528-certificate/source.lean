import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \), other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. **Identify the conditions**:
     - \( n \) is a perfect cube, implying \( n = x^3 \) for some integer \( x \).
     - \( n \) is also a perfect fourth power, implying \( n = t^4 \) for some integer \( t \).
  2. **Equate the two expressions for \( n \)**:
     - Since \( n = x^3 \) and \( n = t^4 \), we have \( x^3 = t^4 \).
  3. **Prime factorization**:
     - \( x^3 = t^4 \). The prime factorization of \( x^3 \) is \( (x^2)^3 = (t^2)^4 \).
     - For \( x^3 = t^4 \) to hold, \( x^2 \) must be a perfect cube, implying \( x^2 = p^3 \) for some integer \( p \).
     - Similarly, \( t^2 \) must be a perfect fourth power, implying \( t^2 = q^4 \) for some integer \( q \).
  4. **Solve for \( n \)**:
     - \( x^2 = p^3 \) and \( t^2 = q^4 \).
     - \( n = x^3 = (x^2)^3 = (p^3)^3 = p^9 \).
     - \( n = t^4 = (t^2)^2 = (q^4)^2 = q^8 \).
     - Equating \( p^9 \) and \( q^8 \), we get \( p^9 = q^8 \).
  5. **Find the smallest \( n \)**:
     - Since \( p \) and \( q \) are integers, the smallest values that satisfy \( p^9 = q^8 \) are \( p = 4 \) and \( q = 5 \).
     - \( n = p^9 = 4^9 = 262144 \).
  Thus, the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096.
  -/
  cases' h₁ with x hx
  cases' h₂ with t ht
  have h₀ := h₀
  rw [← hx, ← ht]
  -- Normalize the expression to simplify the powers
  norm_num
  -- Use the fact that 2 ≤ n to derive a contradiction if n < 4096
  apply Nat.le_of_not_lt fun hn => _
  have : x ≤ 64 := by
    nlinarith [pow_two x, pow_two t]
  have : t ≤ 64 := by
    nlinarith [pow_two x, pow_two t]
  -- Use interval_cases to check all possible values of x and t
  m_power_cases x <;> m_power_cases t <;> simp_all
#print axioms mathd_numbertheory_296
