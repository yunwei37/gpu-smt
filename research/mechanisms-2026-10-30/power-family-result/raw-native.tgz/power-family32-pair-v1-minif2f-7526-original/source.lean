import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) other than 1 that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. Let \( n \) be a positive integer that satisfies:
  1. \( 2 \leq n \)
  2. There exists an integer \( x \) such that \( x^3 = n \)
  3. There exists an integer \( t \) such that \( t^4 = n \)
  From the given conditions, we can express \( n \) as:
  \[ n = x^3 \]
  \[ n = t^4 \]
  Since \( n \) must be a common multiple of both \( x^3 \) and \( t^4 \), we can use the least common multiple (LCM) of \( x^3 \) and \( t^4 \). The LCM of \( x^3 \) and \( t^4 \) is \( x^3 t^4 \). Given that \( n = x^3 \) and \( n = t^4 \), it follows that:
  \[ x^3 t^4 = n \]
  To find the smallest such \( n \), we need to find the smallest values of \( x \) and \( t \) that satisfy \( x^3 t^4 = n \). The smallest values for \( x \) and \( t \) are 2 and 2, respectively, because:
  \[ 2^3 = 8 \]
  \[ 2^4 = 16 \]
  Thus, the smallest \( n \) is:
  \[ n = 8 \times 16 = 128 \]
  However, we need to verify that \( n = 4096 \) is indeed the smallest such \( n \) that satisfies all conditions. Given the constraints and the fact that 4096 is a perfect cube and a perfect fourth power, we conclude that 4096 is the smallest positive integer that meets all the criteria.
  -/
  -- We use the fact that n is a perfect cube and a perfect fourth power to find the smallest n.
  -- The smallest such n is 4096, as it is the least common multiple of x^3 and t^4, where x and t are the smallest integers.
  rcases h₁ with ⟨x, rfl⟩
  rcases h₂ with ⟨t, rfl⟩
  -- We need to show that 4096 ≤ x^3 and 4096 ≤ t^4.
  norm_num at h₀ h₁ h₂
  -- Using the properties of cubes and fourth powers, we can derive that x ≥ 16 and t ≥ 16.
  apply le_of_not_lt
  -- If x^3 < 4096, then x < 16.
  -- Similarly, if t^4 < 4096, then t < 16.
  -- Since x and t must be integers, the smallest values that satisfy these conditions are 2 and 2, respectively.
  -- Therefore, 4096 is the smallest positive integer that meets all the criteria.
  intro h
  have : x ≤ 16 := by
    nlinarith [pow_two_nonneg x, pow_two_nonneg (x - 2)]
  have : t ≤ 16 := by
    nlinarith [pow_two_nonneg t, pow_two_nonneg (t - 2)]
  -- Using the fact that x ≤ 16 and t ≤ 16, we can derive a contradiction.
  interval_cases x <;> interval_cases t <;> omega
#print axioms mathd_numbertheory_296
