import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096, we start by noting that \( n \) must be a common multiple of 3 and 4. Given the constraints \( 2 \leq n \), we need to find the smallest \( n \) that satisfies both conditions.
  1. **Perfect Cube Condition**: \( n \) must be a perfect cube, meaning there exists an integer \( x \) such that \( n = x^3 \).
  2. **Perfect Fourth Power Condition**: \( n \) must be a perfect fourth power, meaning there exists an integer \( t \) such that \( n = t^4 \).
  Since \( n \) must be a common multiple of 3 and 4, we can express \( n \) as \( 24k \) for some integer \( k \). We need to find the smallest \( k \) such that \( 24k \geq 4096 \).
  Calculating the smallest \( k \):
  \[ 24k \geq 4096 \]
  \[ k \geq \frac{4096}{24} \]
  \[ k \geq 170.6667 \]
  Since \( k \) must be an integer, the smallest \( k \) is 171. Therefore, the smallest \( n \) is:
  \[ n = 24 \times 171 = 4096 \]
  Thus, the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is indeed 4096.
  -/
  -- We know that n is a common multiple of 3 and 4, so it is divisible by 12.
  have : 12 ∣ n := by
    obtain ⟨x, hx⟩ := h₁
    obtain ⟨t, ht⟩ := h₂
    -- Since n is a perfect cube and a perfect fourth power, we can write n = 12k for some k.
    use x ^ 2 * t ^ 3
    linarith [pow_two x, pow_two t, pow_three x, pow_three t]
  -- We need to find the smallest k such that 24k ≥ 4096.
  have : n ≥ 4096 := by
    rcases h₀ with (rfl | h₀)
    · norm_num at h₀
    rcases this with ⟨k, rfl⟩
    -- Using the fact that n = 12k, we need 24k ≥ 4096.
    omega
  -- Therefore, n ≥ 4096.
  assumption
#print axioms mathd_numbertheory_296
