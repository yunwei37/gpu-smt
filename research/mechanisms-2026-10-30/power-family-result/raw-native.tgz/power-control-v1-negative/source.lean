import PowerMethods
set_option maxHeartbeats 200000
theorem wrong_exponent (n x t : Nat) (hn : n=16) (hx : x=4) (ht : t=2)
 (hc : x^2=n) (hf : t^4=n) : False := by
  m_power_cases x
  subst n
  subst t
  norm_num at *
#print axioms wrong_exponent
