import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power is 4096, we proceed as follows:
  1. Assume \( n \) is a positive integer such that \( n \geq 2 \), and \( n \) is a perfect cube (i.e., there exists an integer \( x \) such that \( x^3 = n \)) and a perfect fourth power (i.e., there exists an integer \( t \) such that \( t^4 = n \)).
  2. By the properties of perfect cubes and perfect fourth powers, \( n \) must be a common term of both sequences.
  3. The smallest such \( n \) that satisfies these conditions is found to be 4096.
  4. We verify that 4096 is indeed the smallest number that satisfies the given conditions by checking that it is a perfect cube and a perfect fourth power.
  -/
  -- Extract the integers x and t such that x^3 = n and t^4 = n from the hypotheses h₁ and h₂.
  rcases h₁ with ⟨x, hx⟩
  rcases h₂ with ⟨t, ht⟩
  -- Simplify the expressions involving x and t.
  simp_all only [pow_succ, pow_two, mul_one, mul_assoc]
  -- Use the fact that 4096 is the smallest number that satisfies the given conditions.
  apply Nat.le_of_not_lt
  intro h
  -- If n < 4096, then n cannot be a perfect cube and a perfect fourth power.
  have h₃ : x < 16 := by
    -- Since n < 4096, x must be less than 16 to satisfy x^3 < 4096.
    nlinarith [pow_two x, pow_two (x - 1)]
  have h₄ : t < 16 := by
    -- Similarly, t must be less than 16 to satisfy t^4 < 4096.
    nlinarith [pow_two t, pow_two (t - 1)]
  -- Conclude that n cannot be a perfect cube and a perfect fourth power if n < 4096.
  interval_cases x <;> interval_cases t <;> omega
#print axioms mathd_numbertheory_296
