import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096, we start by noting that \( n \) must be a multiple of both 3 and 4. The least common multiple of 3 and 4 is 12. Therefore, \( n \) must be a multiple of 12.
  Given that \( n \) is a multiple of 12 and \( n \geq 2 \), the smallest such \( n \) is 12. However, we need to find the smallest positive integer that is a perfect cube and a perfect fourth power. This requires finding the smallest \( n \) that satisfies both conditions.
  The smallest perfect cube that is a multiple of 12 is \( 12^3 = 1728 \). The smallest perfect fourth power that is a multiple of 12 is \( 12^4 = 20736 \). Therefore, the smallest positive integer \( n \) that satisfies both conditions is 4096.
  -/
  -- Extract the existence of x such that x^3 = n
  cases' h₁ with x hx
  -- Extract the existence of t such that t^4 = n
  cases' h₂ with t ht
  -- Simplify the equations using the properties of powers
  simp_all only [pow_succ, pow_two]
  -- Use the fact that n must be at least 4096
  apply le_of_not_lt
  -- Assume for contradiction that n < 4096
  intro h
  -- Derive a contradiction by checking the properties of perfect cubes and fourth powers
  have h' : x < 16 := by
    -- Use the fact that x^3 < 4096 to derive a bound on x
    nlinarith [pow_two x, pow_two (x - 1)]
  have h'' : t < 16 := by
    -- Use the fact that t^4 < 4096 to derive a bound on t
    nlinarith [pow_two t, pow_two (t - 1)]
  -- Check all possible values of x and t within the bounds
  m_power_cases x <;> m_power_cases t <;> omega
#print axioms mathd_numbertheory_296
