import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) that is both a perfect cube and a perfect fourth power is 4096, we start by considering the given conditions. Let \( n \) be a positive integer such that \( n \geq 2 \). We are given that \( n \) is a perfect cube and a perfect fourth power, meaning there exist integers \( x \) and \( t \) such that \( n = x^3 \) and \( n = t^4 \).
  We need to find the smallest such \( n \). By equating the two expressions for \( n \), we get \( x^3 = t^4 \). This implies that \( t \) must be a cube root of \( x \). To ensure \( n \) is a perfect cube, \( t \) must be an integer, and \( n \) must be a power of a power.
  Given \( n = x^3 \) and \( n = t^4 \), we can infer that \( n \) must be a common multiple of these two expressions. By calculating the least common multiple (LCM), we find that \( n \) must be a multiple of 4096.
  Thus, the smallest \( n \) that satisfies these conditions is 4096.
  -/
  -- We start by considering the given conditions.
  cases' h₁ with x hx
  cases' h₂ with t ht
  -- We use the fact that x^3 = n and t^4 = n to infer that n must be a multiple of 4096.
  -- This is because the least common multiple (LCM) of 3 and 4 is 12, and the smallest n that is a perfect 12th power is 4096.
  apply le_of_not_lt
  intro h
  -- We use the fact that x^3 = n and t^4 = n to infer that n must be a multiple of 4096.
  -- This is because the least common multiple (LCM) of 3 and 4 is 12, and the smallest n that is a perfect 12th power is 4096.
  have hx' : x ≤ 32 := by
    nlinarith [pow_two x, pow_two (x + 1)]
  have ht' : t ≤ 16 := by
    nlinarith [pow_two t, pow_two (t + 1)]
  -- We use the fact that x^3 = n and t^4 = n to infer that n must be a multiple of 4096.
  -- This is because the least common multiple (LCM) of 3 and 4 is 12, and the smallest n that is a perfect 12th power is 4096.
  m_power_cases x <;> m_power_cases t <;> omega
#print axioms mathd_numbertheory_296
