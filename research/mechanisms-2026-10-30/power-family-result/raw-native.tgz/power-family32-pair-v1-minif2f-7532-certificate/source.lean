import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \), other than 1, that is both a perfect cube and a perfect fourth power is at least 4096, we proceed as follows:
  1. Assume \( n \) is a positive integer such that \( 2 \leq n \).
  2. There exist integers \( x \) and \( t \) such that \( x^3 = n \) and \( t^4 = n \).
  3. By the properties of perfect cubes and fourth powers, \( n \) must be a common multiple of 3 and 4.
  4. The least common multiple (LCM) of 3 and 4 is 12. Therefore, \( n \) must be a multiple of 12.
  5. Given \( 2 \leq n \), the smallest multiple of 12 that satisfies this condition is 4096.
  6. Hence, \( n \geq 4096 \).
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  -- We know that n is a perfect cube and a perfect fourth power.
  -- Since 2 ≤ n, we need to find the smallest such n.
  -- The smallest perfect cube greater than or equal to 2 is 8.
  -- The smallest perfect fourth power greater than or equal to 2 is 16.
  -- We need to find the smallest n that satisfies both conditions.
  -- The LCM of 8 and 16 is 16, so n must be a multiple of 16.
  -- The smallest multiple of 16 greater than or equal to 2 is 4096.
  have h₃ : n ≥ 4096 := by
    apply Nat.le_of_not_lt
    intro h
    -- If n < 4096, then we can find a smaller perfect cube or fourth power that satisfies the conditions.
    -- This would contradict the fact that n is both a perfect cube and a perfect fourth power.
    have h₄ : x ≤ 4096 := by linarith
    have h₅ : t ≤ 4096 := by linarith
    m_power_cases x <;> m_power_cases t <;> omega
  exact h₃
#print axioms mathd_numbertheory_296
