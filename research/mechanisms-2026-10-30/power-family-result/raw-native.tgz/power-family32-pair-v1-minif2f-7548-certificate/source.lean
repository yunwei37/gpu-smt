import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) other than 1 that is both a perfect cube and a perfect fourth power is 4096, we start by analyzing the given conditions. Let \( n \) be such that \( n = x^3 \) and \( n = t^4 \). Since \( n \) is a perfect cube and a perfect fourth power, we need to find the smallest such \( n \) that satisfies both conditions.
  Given \( n \geq 2 \), we can write \( n = x^3 \) and \( n = t^4 \). Equating the two expressions for \( n \), we get \( x^3 = t^4 \). This implies that \( x \) and \( t \) must be such that \( x^3 \) is a perfect fourth power and \( t^4 \) is a perfect cube.
  To find the smallest such \( n \), we consider the smallest possible values for \( x \) and \( t \). The smallest \( x \) and \( t \) that satisfy these conditions are \( x = 2 \) and \( t = 2 \), respectively. Thus, the smallest \( n \) that satisfies both conditions is:
  \[
  n = 2^3 = 8
  \]
  However, we need to verify that 8 is indeed the smallest number satisfying both conditions. We then check the next smallest numbers, which are the perfect cubes and fourth powers. The smallest perfect cube greater than 8 is \( 2^3 = 8 \), and the smallest perfect fourth power greater than 8 is \( 2^4 = 16 \).
  Thus, the smallest positive integer \( n \) that satisfies both conditions is 16. However, we need to verify that 16 is indeed the smallest number satisfying both conditions. We then check the next smallest numbers, which are the perfect cubes and fourth powers. The smallest perfect cube greater than 16 is \( 2^3 = 8 \), and the smallest perfect fourth power greater than 16 is \( 2^4 = 16 \).
  Thus, the smallest positive integer \( n \) that satisfies both conditions is 4096.
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  have : x ≤ t ^ 2 := by
    -- We need to show that x is less than or equal to t^2.
    apply le_of_not_lt
    intro h
    -- If x is greater than t^2, we derive a contradiction.
    have : x ≥ 2 := h₀
    -- We use the fact that x^3 = n and t^4 = n to derive a contradiction.
    calc
      x ^ 3 ≤ t ^ 2 * x := by gcongr; assumption
      _ = t ^ 2 * (x : ℕ) := by rfl
      _ ≤ t ^ 2 * t ^ 2 := by gcongr; assumption
      _ = t ^ 4 := by ring
      _ ≤ n := by assumption
      _ = t ^ 4 := by rfl
  -- Using the above, we conclude that x ≤ t^2.
  nlinarith [pow_two x, pow_two t]
#print axioms mathd_numbertheory_296
