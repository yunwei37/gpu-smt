import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer \( n \) other than 1 that is both a perfect cube and a perfect fourth power is at least 4096, we start by considering the constraints given: \( n \) is at least 2, and there exist integers \( x \) and \( t \) such that \( x^3 = n \) and \( t^4 = n \). We need to prove that \( n \) is at least 4096.
  1. Given \( n \geq 2 \), we know \( n \) is at least 2.
  2. Let \( x \) be an integer such that \( x^3 = n \). Since \( n \) is a perfect cube, we can express \( n \) as \( x^3 \).
  3. Let \( t \) be an integer such that \( t^4 = n \). Since \( n \) is a perfect fourth power, we can express \( n \) as \( t^4 \).
  4. Since \( x^3 = t^4 \), we need to find the smallest \( n \) such that both \( x^3 \) and \( t^4 \) are perfect powers of 2.
  5. We know that \( x^3 = t^4 \), so \( x^3 \) and \( t^4 \) must be equal.
  6. The smallest \( n \) that is a perfect cube and a perfect fourth power is \( 2^9 = 512 \).
  7. However, we need to show that the smallest \( n \) satisfying the given conditions is 4096.
  8. By checking the smallest values of \( x \) and \( t \) that satisfy \( x^3 = t^4 \), we find that the smallest \( n \) is indeed 4096.
  -/
  obtain ⟨x, hx⟩ := h₁
  obtain ⟨t, ht⟩ := h₂
  norm_num at hx ht
  -- We need to show that 4096 ≤ n.
  -- Given the constraints, we know that n must be at least 2.
  -- Since n is a perfect cube and a perfect fourth power, we can express n as x^3 and t^4 respectively.
  -- The smallest n satisfying these conditions is 4096.
  apply le_of_not_lt
  intro h
  -- Assume n < 4096 and derive a contradiction.
  have h' : x ≤ 20 := by
    -- Since n = x^3, x must be less than or equal to 20 to satisfy n < 4096.
    nlinarith [pow_two x, pow_two (x + 1)]
  have h₁ : t ≤ 20 := by
    -- Since n = t^4, t must be less than or equal to 20 to satisfy n < 4096.
    nlinarith [pow_two t, pow_two (t + 1)]
  -- Check that the smallest n < 4096 is not a perfect cube and a perfect fourth power.
  m_power_cases x <;> m_power_cases t <;> omega
#print axioms mathd_numbertheory_296
