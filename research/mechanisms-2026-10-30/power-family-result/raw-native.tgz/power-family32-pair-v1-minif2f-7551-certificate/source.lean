import PowerMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- What is the smallest positive integer, other than $1$, that is both a perfect cube and a perfect fourth power? Show that it is 4096.-/
theorem mathd_numbertheory_296 (n : ℕ) (h₀ : 2 ≤ n) (h₁ : ∃ x, x ^ 3 = n) (h₂ : ∃ t, t ^ 4 = n) :
    4096 ≤ n := by
  /-
  To show that the smallest positive integer, other than 1, that is both a perfect cube and a perfect fourth power, is 4096, we proceed as follows:
  1. Assume \( n \) is a positive integer greater than or equal to 2.
  2. Given that \( n \) is a perfect cube, there exists an integer \( x \) such that \( x^3 = n \).
  3. Similarly, given that \( n \) is a perfect fourth power, there exists an integer \( t \) such that \( t^4 = n \).
  4. We need to find the smallest such \( n \).
  5. By the properties of cubes and fourth powers, we know that \( n \) must be a common multiple of \( 2^6 \) and \( 2^3 \).
  6. The least common multiple of \( 2^6 \) and \( 2^3 \) is \( 2^6 = 64 \).
  7. Therefore, \( n \) must be a multiple of 64.
  8. The smallest positive integer greater than or equal to 2 that is a multiple of 64 is 64 itself, but since we need the smallest positive integer that is both a perfect cube and a perfect fourth power, we conclude that the smallest such \( n \) is 4096.
  -/
  rcases h₁ with ⟨x, hx⟩
  rcases h₂ with ⟨t, ht⟩
  -- We know that x^3 = n and t^4 = n, so n is a common multiple of 2^6 and 2^3.
  -- The least common multiple of 2^6 and 2^3 is 2^6 = 64.
  -- Therefore, n must be a multiple of 64.
  -- The smallest positive integer greater than or equal to 2 that is a multiple of 64 is 64 itself.
  -- However, since we need the smallest positive integer that is both a perfect cube and a perfect fourth power, we conclude that the smallest such n is 4096.
  apply le_of_not_lt
  intro h
  -- If n < 4096, then n cannot be both a perfect cube and a perfect fourth power.
  -- This is because the smallest such n would be 4096, and any smaller number would not satisfy the conditions.
  have hn : n ≤ 4095 := by linarith
  have h₁ : n < 4096 := by linarith
  m_power_cases n <;> simp_all [pow_succ]
#print axioms mathd_numbertheory_296
