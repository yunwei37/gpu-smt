import CertificateProofs
set_option maxHeartbeats 200000
theorem amc12a_2020_p4 (S : Finset Nat)
 (h : ∀ n, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧
 (∀ d ∈ Nat.digits 10 n, Even d) ∧ 5 ∣ n) : S.card=100 :=
 MechanismCertificate.amc12a_2020_p4_certificate S h
#print axioms amc12a_2020_p4
