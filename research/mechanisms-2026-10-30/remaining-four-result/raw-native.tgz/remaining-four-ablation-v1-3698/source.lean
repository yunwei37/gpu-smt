import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many $4$-digit positive integers (i.e., integers between $1000$ and $9999$) have only even digits and are divisible by $5$, we need to analyze the conditions under which a number is divisible by $5$ and has only even digits.
  1. **Divisibility by $5$**: Since the last digit of a number determines its divisibility by $5$, we need to find numbers between $1000$ and $9999$ that end in $0$ or $5$.
  2. **Only even digits**: For a number to be divisible by $5$, its last digit must be $0$ or $5$. However, since the number must have only even digits, the last digit must be $0$.
  3. **Range of numbers**: The numbers range from $1000$ to $9999$, but since the last digit must be $0$, we consider the numbers from $1000$ to $9990$.
  4. **Counting the numbers**: The numbers from $1000$ to $9990$ that have only even digits and are divisible by $5$ can be counted by considering the range of numbers that meet the criteria.
  -/
  have : S = Finset.filter (fun n => 5 ∣ n ∧ ∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) (Finset.Icc 1000 9999) := by
    ext n
    skip
    -- Use the `omega` tactic to solve the linear arithmetic problem
    omega
  rw [this]
  -- The cardinality of the filtered set is 100
  m_digits_rfl
#print axioms amc12a_2020_p4
