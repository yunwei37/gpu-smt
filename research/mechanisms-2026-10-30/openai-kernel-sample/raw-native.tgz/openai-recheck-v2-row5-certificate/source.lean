import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
abbrev currentRow := rows[5]!
abbrev inner (e : Nat × Nat × Int) : Int :=
  (currentRow.2.2.map (fun f => yEntryIntegralFast 17 11 15 currentRow.1 e f)).sum
theorem inner_0 : inner (currentRow.2.2[0]!) = (0 : Int) := by decide +kernel
theorem inner_1 : inner (currentRow.2.2[1]!) = (0 : Int) := by decide +kernel
theorem inner_2 : inner (currentRow.2.2[2]!) = (0 : Int) := by decide +kernel
theorem inner_3 : inner (currentRow.2.2[3]!) = (0 : Int) := by decide +kernel
theorem inner_4 : inner (currentRow.2.2[4]!) = (0 : Int) := by decide +kernel
theorem inner_5 : inner (currentRow.2.2[5]!) = (0 : Int) := by decide +kernel
theorem inner_6 : inner (currentRow.2.2[6]!) = (0 : Int) := by decide +kernel
theorem inner_7 : inner (currentRow.2.2[7]!) = (0 : Int) := by decide +kernel
theorem inner_8 : inner (currentRow.2.2[8]!) = (0 : Int) := by decide +kernel
theorem inner_9 : inner (currentRow.2.2[9]!) = (0 : Int) := by decide +kernel
theorem inner_10 : inner (currentRow.2.2[10]!) = (0 : Int) := by decide +kernel
theorem inner_11 : inner (currentRow.2.2[11]!) = (0 : Int) := by decide +kernel
theorem inner_12 : inner (currentRow.2.2[12]!) = (0 : Int) := by decide +kernel
theorem inner_13 : inner (currentRow.2.2[13]!) = (0 : Int) := by decide +kernel
theorem inner_14 : inner (currentRow.2.2[14]!) = (-256795158365003168637819544503134916688525456097704673280000000000 : Int) := by decide +kernel
theorem inner_15 : inner (currentRow.2.2[15]!) = (0 : Int) := by decide +kernel
theorem inner_16 : inner (currentRow.2.2[16]!) = (0 : Int) := by decide +kernel
theorem inner_17 : inner (currentRow.2.2[17]!) = (204854340508133669106708115831819278742509396992134112870400000000 : Int) := by decide +kernel
theorem inner_18 : inner (currentRow.2.2[18]!) = (0 : Int) := by decide +kernel
theorem inner_19 : inner (currentRow.2.2[19]!) = (0 : Int) := by decide +kernel
theorem inner_20 : inner (currentRow.2.2[20]!) = (0 : Int) := by decide +kernel
theorem inner_21 : inner (currentRow.2.2[21]!) = (0 : Int) := by decide +kernel
theorem inner_22 : inner (currentRow.2.2[22]!) = (251224495506617921141737353871872887020916076385885224960000000000 : Int) := by decide +kernel
theorem inner_23 : inner (currentRow.2.2[23]!) = (0 : Int) := by decide +kernel
theorem inner_24 : inner (currentRow.2.2[24]!) = (0 : Int) := by decide +kernel
theorem inner_25 : inner (currentRow.2.2[25]!) = (0 : Int) := by decide +kernel
theorem inner_26 : inner (currentRow.2.2[26]!) = (-859878103982444907960701165544916709106981374655882854400000000 : Int) := by decide +kernel
theorem list_certificate : currentRow.2.2.map inner = [(0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (-256795158365003168637819544503134916688525456097704673280000000000 : Int), (0 : Int), (0 : Int), (204854340508133669106708115831819278742509396992134112870400000000 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (251224495506617921141737353871872887020916076385885224960000000000 : Int), (0 : Int), (0 : Int), (0 : Int), (-859878103982444907960701165544916709106981374655882854400000000 : Int)] := by
  apply List.ext_getElem
  · rfl
  · intro n hn hm
    simp only [List.length_cons, List.length_nil] at hm
    cases n with
    | zero => exact inner_0
    | succ n =>
      cases n with
      | zero => exact inner_1
      | succ n =>
        cases n with
        | zero => exact inner_2
        | succ n =>
          cases n with
          | zero => exact inner_3
          | succ n =>
            cases n with
            | zero => exact inner_4
            | succ n =>
              cases n with
              | zero => exact inner_5
              | succ n =>
                cases n with
                | zero => exact inner_6
                | succ n =>
                  cases n with
                  | zero => exact inner_7
                  | succ n =>
                    cases n with
                    | zero => exact inner_8
                    | succ n =>
                      cases n with
                      | zero => exact inner_9
                      | succ n =>
                        cases n with
                        | zero => exact inner_10
                        | succ n =>
                          cases n with
                          | zero => exact inner_11
                          | succ n =>
                            cases n with
                            | zero => exact inner_12
                            | succ n =>
                              cases n with
                              | zero => exact inner_13
                              | succ n =>
                                cases n with
                                | zero => exact inner_14
                                | succ n =>
                                  cases n with
                                  | zero => exact inner_15
                                  | succ n =>
                                    cases n with
                                    | zero => exact inner_16
                                    | succ n =>
                                      cases n with
                                      | zero => exact inner_17
                                      | succ n =>
                                        cases n with
                                        | zero => exact inner_18
                                        | succ n =>
                                          cases n with
                                          | zero => exact inner_19
                                          | succ n =>
                                            cases n with
                                            | zero => exact inner_20
                                            | succ n =>
                                              cases n with
                                              | zero => exact inner_21
                                              | succ n =>
                                                cases n with
                                                | zero => exact inner_22
                                                | succ n =>
                                                  cases n with
                                                  | zero => exact inner_23
                                                  | succ n =>
                                                    cases n with
                                                    | zero => exact inner_24
                                                    | succ n =>
                                                      cases n with
                                                      | zero => exact inner_25
                                                      | succ n =>
                                                        cases n with
                                                        | zero => exact inner_26
                                                        | succ n =>
                                                          omega
theorem result : yRowIntegralFast 17 11 15 (rows[5]!) = (198423799545765976702665224035012332365793035905658781696000000000 : Int) := by
  change (currentRow.2.2.map inner).sum = _
  rw [list_certificate]
  decide +kernel
#print axioms result
end MOpenAISample

open Lean Elab Command in
elab "#recheck_fresh_kernel" : command => do
  let env ← getEnv
  let mut count : Nat := 0
  let mut total : Nat := 0
  for (name, ci) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    let .thmInfo value := ci | continue
    let renamed := Name.str `MKernelRecheck name.toString
    let began ← IO.monoNanosNow
    match env.addDeclCore (Core.getMaxHeartbeats (← getOptions)).toUSize (maxRecDepth.get (← getOptions)).toUSize
        (.thmDecl {value with name := renamed, all := [renamed]}) none with
    | .error e => throwError m!"kernel recheck {name}: {e.toMessageData (← getOptions)}"
    | .ok _ => pure ()
    let ended ← IO.monoNanosNow
    total := total + (ended - began)
    count := count + 1
    logInfo m!"M_OPENAI_KERNEL {name} {ended - began}"
  logInfo m!"M_OPENAI_KERNEL_TOTAL {count} {total}"
#recheck_fresh_kernel
