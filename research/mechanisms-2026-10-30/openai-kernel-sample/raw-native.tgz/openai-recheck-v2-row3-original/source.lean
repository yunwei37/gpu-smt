import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
theorem result : yRowIntegralFast 17 11 15 (rows[3]!) = (-851421285462192129596789078827261106272541388110582670950400000000 : Int) := by decide +kernel
#print axioms result
end MOpenAISample

open Lean Elab Command in
elab "#recheck_fresh_kernel" : command => do
  let env ← getEnv
  let mut count : Nat := 0
  let mut total : Nat := 0
  for (name, ci) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    let .thmInfo value := ci | continue
    let renamed := Name.str `MKernelRecheck name.toString
    let began ← IO.monoNanosNow
    match env.addDeclCore (Core.getMaxHeartbeats (← getOptions)).toUSize (maxRecDepth.get (← getOptions)).toUSize
        (.thmDecl {value with name := renamed, all := [renamed]}) none with
    | .error e => throwError m!"kernel recheck {name}: {e.toMessageData (← getOptions)}"
    | .ok _ => pure ()
    let ended ← IO.monoNanosNow
    total := total + (ended - began)
    count := count + 1
    logInfo m!"M_OPENAI_KERNEL {name} {ended - began}"
  logInfo m!"M_OPENAI_KERNEL_TOTAL {count} {total}"
#recheck_fresh_kernel
