import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
abbrev currentRow := rows[2]!
abbrev inner (e : Nat × Nat × Int) : Int :=
  (currentRow.2.2.map (fun f => yEntryIntegralFast 17 11 15 currentRow.1 e f)).sum
theorem inner_0 : inner (currentRow.2.2[0]!) = (0 : Int) := by decide +kernel
theorem inner_1 : inner (currentRow.2.2[1]!) = (0 : Int) := by decide +kernel
theorem inner_2 : inner (currentRow.2.2[2]!) = (0 : Int) := by decide +kernel
theorem inner_3 : inner (currentRow.2.2[3]!) = (0 : Int) := by decide +kernel
theorem inner_4 : inner (currentRow.2.2[4]!) = (0 : Int) := by decide +kernel
theorem inner_5 : inner (currentRow.2.2[5]!) = (0 : Int) := by decide +kernel
theorem inner_6 : inner (currentRow.2.2[6]!) = (0 : Int) := by decide +kernel
theorem inner_7 : inner (currentRow.2.2[7]!) = (1071826838329037124381414155664630650787719590250688597196800000000 : Int) := by decide +kernel
theorem inner_8 : inner (currentRow.2.2[8]!) = (0 : Int) := by decide +kernel
theorem inner_9 : inner (currentRow.2.2[9]!) = (0 : Int) := by decide +kernel
theorem inner_10 : inner (currentRow.2.2[10]!) = (276084959177846622533610686381271117122977061541798897254400000000 : Int) := by decide +kernel
theorem inner_11 : inner (currentRow.2.2[11]!) = (0 : Int) := by decide +kernel
theorem inner_12 : inner (currentRow.2.2[12]!) = (0 : Int) := by decide +kernel
theorem inner_13 : inner (currentRow.2.2[13]!) = (209227474411241144789431009211564465392156548667141835980800000000 : Int) := by decide +kernel
theorem inner_14 : inner (currentRow.2.2[14]!) = (0 : Int) := by decide +kernel
theorem inner_15 : inner (currentRow.2.2[15]!) = (0 : Int) := by decide +kernel
theorem list_certificate : currentRow.2.2.map inner = [(0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (1071826838329037124381414155664630650787719590250688597196800000000 : Int), (0 : Int), (0 : Int), (276084959177846622533610686381271117122977061541798897254400000000 : Int), (0 : Int), (0 : Int), (209227474411241144789431009211564465392156548667141835980800000000 : Int), (0 : Int), (0 : Int)] := by
  apply List.ext_getElem
  · rfl
  · intro n hn hm
    simp only [List.length_cons, List.length_nil] at hm
    cases n with
    | zero => exact inner_0
    | succ n =>
      cases n with
      | zero => exact inner_1
      | succ n =>
        cases n with
        | zero => exact inner_2
        | succ n =>
          cases n with
          | zero => exact inner_3
          | succ n =>
            cases n with
            | zero => exact inner_4
            | succ n =>
              cases n with
              | zero => exact inner_5
              | succ n =>
                cases n with
                | zero => exact inner_6
                | succ n =>
                  cases n with
                  | zero => exact inner_7
                  | succ n =>
                    cases n with
                    | zero => exact inner_8
                    | succ n =>
                      cases n with
                      | zero => exact inner_9
                      | succ n =>
                        cases n with
                        | zero => exact inner_10
                        | succ n =>
                          cases n with
                          | zero => exact inner_11
                          | succ n =>
                            cases n with
                            | zero => exact inner_12
                            | succ n =>
                              cases n with
                              | zero => exact inner_13
                              | succ n =>
                                cases n with
                                | zero => exact inner_14
                                | succ n =>
                                  cases n with
                                  | zero => exact inner_15
                                  | succ n =>
                                    omega
theorem result : yRowIntegralFast 17 11 15 (rows[2]!) = (1557139271918124891704455851257466233302853200459629330432000000000 : Int) := by
  change (currentRow.2.2.map inner).sum = _
  rw [list_certificate]
  decide +kernel
#print axioms result
end MOpenAISample

open Lean Elab Command in
elab "#recheck_fresh_kernel" : command => do
  let env ← getEnv
  let mut count : Nat := 0
  let mut total : Nat := 0
  for (name, ci) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    let .thmInfo value := ci | continue
    let renamed := Name.str `MKernelRecheck name.toString
    let began ← IO.monoNanosNow
    match env.addDeclCore 1000000 1000000
        (.thmDecl {value with name := renamed, all := [renamed]}) none with
    | .error e => throwError "original kernel recheck failed"
    | .ok _ => pure ()
    let ended ← IO.monoNanosNow
    total := total + (ended - began)
    count := count + 1
    logInfo m!"M_OPENAI_KERNEL {name} {ended - began}"
  logInfo m!"M_OPENAI_KERNEL_TOTAL {count} {total}"
#recheck_fresh_kernel
