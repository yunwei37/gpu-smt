import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
theorem result : yRowIntegralFast 17 11 15 (rows[3]!) = (-851421285462192129596789078827261106272541388110582670950400000000 : Int) := by decide +kernel
#print axioms result
end MOpenAISample
