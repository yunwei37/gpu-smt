import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
theorem result : yRowIntegralFast 17 11 15 (rows[1]!) = (889111953967100853219108311928204221408320732742968934400000000 : Int) := by decide +kernel
#print axioms result
end MOpenAISample
