import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
theorem result : yRowIntegralFast 17 11 15 (rows[4]!) = (-145272526275599502019542461687289125013441640791713356185600000000 : Int) := by decide +kernel
#print axioms result
end MOpenAISample
