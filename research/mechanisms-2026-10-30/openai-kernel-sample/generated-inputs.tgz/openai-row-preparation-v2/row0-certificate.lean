import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
abbrev currentRow := rows[0]!
abbrev inner (e : Nat × Nat × Int) : Int :=
  (currentRow.2.2.map (fun f => yEntryIntegralFast 17 11 15 currentRow.1 e f)).sum
theorem inner_0 : inner (currentRow.2.2[0]!) = (0 : Int) := by decide +kernel
theorem inner_1 : inner (currentRow.2.2[1]!) = (0 : Int) := by decide +kernel
theorem inner_2 : inner (currentRow.2.2[2]!) = (0 : Int) := by decide +kernel
theorem inner_3 : inner (currentRow.2.2[3]!) = (0 : Int) := by decide +kernel
theorem inner_4 : inner (currentRow.2.2[4]!) = (0 : Int) := by decide +kernel
theorem inner_5 : inner (currentRow.2.2[5]!) = (0 : Int) := by decide +kernel
theorem inner_6 : inner (currentRow.2.2[6]!) = (0 : Int) := by decide +kernel
theorem inner_7 : inner (currentRow.2.2[7]!) = (0 : Int) := by decide +kernel
theorem inner_8 : inner (currentRow.2.2[8]!) = (0 : Int) := by decide +kernel
theorem inner_9 : inner (currentRow.2.2[9]!) = (0 : Int) := by decide +kernel
theorem inner_10 : inner (currentRow.2.2[10]!) = (0 : Int) := by decide +kernel
theorem inner_11 : inner (currentRow.2.2[11]!) = (0 : Int) := by decide +kernel
theorem list_certificate : currentRow.2.2.map inner = [(0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int)] := by
  apply List.ext_getElem
  · rfl
  · intro n hn hm
    cases n with
    | zero => exact inner_0
    | succ n =>
      cases n with
      | zero => exact inner_1
      | succ n =>
        cases n with
        | zero => exact inner_2
        | succ n =>
          cases n with
          | zero => exact inner_3
          | succ n =>
            cases n with
            | zero => exact inner_4
            | succ n =>
              cases n with
              | zero => exact inner_5
              | succ n =>
                cases n with
                | zero => exact inner_6
                | succ n =>
                  cases n with
                  | zero => exact inner_7
                  | succ n =>
                    cases n with
                    | zero => exact inner_8
                    | succ n =>
                      cases n with
                      | zero => exact inner_9
                      | succ n =>
                        cases n with
                        | zero => exact inner_10
                        | succ n =>
                          cases n with
                          | zero => exact inner_11
                          | succ n =>
                            omega
theorem result : yRowIntegralFast 17 11 15 (rows[0]!) = (0 : Int) := by
  change (currentRow.2.2.map inner).sum = _
  rw [list_certificate]
  decide +kernel
#print axioms result
end MOpenAISample
