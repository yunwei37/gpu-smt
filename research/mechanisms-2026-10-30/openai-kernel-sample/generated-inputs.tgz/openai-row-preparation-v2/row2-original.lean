import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
theorem result : yRowIntegralFast 17 11 15 (rows[2]!) = (1557139271918124891704455851257466233302853200459629330432000000000 : Int) := by decide +kernel
#print axioms result
end MOpenAISample
