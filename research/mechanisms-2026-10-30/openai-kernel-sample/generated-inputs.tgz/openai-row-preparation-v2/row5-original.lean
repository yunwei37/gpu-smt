import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
theorem result : yRowIntegralFast 17 11 15 (rows[5]!) = (198423799545765976702665224035012332365793035905658781696000000000 : Int) := by decide +kernel
#print axioms result
end MOpenAISample
