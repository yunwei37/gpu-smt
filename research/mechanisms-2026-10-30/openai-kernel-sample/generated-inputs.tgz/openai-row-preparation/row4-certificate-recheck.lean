import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
abbrev currentRow := rows[4]!
abbrev inner (e : Nat × Nat × Int) : Int :=
  (currentRow.2.2.map (fun f => yEntryIntegralFast 17 11 15 currentRow.1 e f)).sum
theorem inner_0 : inner (currentRow.2.2[0]!) = (0 : Int) := by decide +kernel
theorem inner_1 : inner (currentRow.2.2[1]!) = (0 : Int) := by decide +kernel
theorem inner_2 : inner (currentRow.2.2[2]!) = (0 : Int) := by decide +kernel
theorem inner_3 : inner (currentRow.2.2[3]!) = (0 : Int) := by decide +kernel
theorem inner_4 : inner (currentRow.2.2[4]!) = (0 : Int) := by decide +kernel
theorem inner_5 : inner (currentRow.2.2[5]!) = (0 : Int) := by decide +kernel
theorem inner_6 : inner (currentRow.2.2[6]!) = (0 : Int) := by decide +kernel
theorem inner_7 : inner (currentRow.2.2[7]!) = (0 : Int) := by decide +kernel
theorem inner_8 : inner (currentRow.2.2[8]!) = (0 : Int) := by decide +kernel
theorem inner_9 : inner (currentRow.2.2[9]!) = (0 : Int) := by decide +kernel
theorem inner_10 : inner (currentRow.2.2[10]!) = (0 : Int) := by decide +kernel
theorem inner_11 : inner (currentRow.2.2[11]!) = (0 : Int) := by decide +kernel
theorem inner_12 : inner (currentRow.2.2[12]!) = (0 : Int) := by decide +kernel
theorem inner_13 : inner (currentRow.2.2[13]!) = (0 : Int) := by decide +kernel
theorem inner_14 : inner (currentRow.2.2[14]!) = (-136980885315682170191314734044300793348545484287624871936000000000 : Int) := by decide +kernel
theorem inner_15 : inner (currentRow.2.2[15]!) = (0 : Int) := by decide +kernel
theorem inner_16 : inner (currentRow.2.2[16]!) = (0 : Int) := by decide +kernel
theorem inner_17 : inner (currentRow.2.2[17]!) = (-152245239236217705795934865939465859594178228402751589580800000000 : Int) := by decide +kernel
theorem inner_18 : inner (currentRow.2.2[18]!) = (0 : Int) := by decide +kernel
theorem inner_19 : inner (currentRow.2.2[19]!) = (0 : Int) := by decide +kernel
theorem inner_20 : inner (currentRow.2.2[20]!) = (0 : Int) := by decide +kernel
theorem inner_21 : inner (currentRow.2.2[21]!) = (0 : Int) := by decide +kernel
theorem inner_22 : inner (currentRow.2.2[22]!) = (-146248325867805043554698485291968774999343244143843344384000000000 : Int) := by decide +kernel
theorem inner_23 : inner (currentRow.2.2[23]!) = (0 : Int) := by decide +kernel
theorem inner_24 : inner (currentRow.2.2[24]!) = (0 : Int) := by decide +kernel
theorem inner_25 : inner (currentRow.2.2[25]!) = (0 : Int) := by decide +kernel
theorem inner_26 : inner (currentRow.2.2[26]!) = (290201924144105417522405623588446302928625316042506449715200000000 : Int) := by decide +kernel
theorem list_certificate : currentRow.2.2.map inner = [(0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (-136980885315682170191314734044300793348545484287624871936000000000 : Int), (0 : Int), (0 : Int), (-152245239236217705795934865939465859594178228402751589580800000000 : Int), (0 : Int), (0 : Int), (0 : Int), (0 : Int), (-146248325867805043554698485291968774999343244143843344384000000000 : Int), (0 : Int), (0 : Int), (0 : Int), (290201924144105417522405623588446302928625316042506449715200000000 : Int)] := by
  apply List.ext_getElem
  · rfl
  · intro n hn hm
      cases n with
      | zero => exact inner_0
      | succ n =>
        cases n with
        | zero => exact inner_1
        | succ n =>
          cases n with
          | zero => exact inner_2
          | succ n =>
            cases n with
            | zero => exact inner_3
            | succ n =>
              cases n with
              | zero => exact inner_4
              | succ n =>
                cases n with
                | zero => exact inner_5
                | succ n =>
                  cases n with
                  | zero => exact inner_6
                  | succ n =>
                    cases n with
                    | zero => exact inner_7
                    | succ n =>
                      cases n with
                      | zero => exact inner_8
                      | succ n =>
                        cases n with
                        | zero => exact inner_9
                        | succ n =>
                          cases n with
                          | zero => exact inner_10
                          | succ n =>
                            cases n with
                            | zero => exact inner_11
                            | succ n =>
                              cases n with
                              | zero => exact inner_12
                              | succ n =>
                                cases n with
                                | zero => exact inner_13
                                | succ n =>
                                  cases n with
                                  | zero => exact inner_14
                                  | succ n =>
                                    cases n with
                                    | zero => exact inner_15
                                    | succ n =>
                                      cases n with
                                      | zero => exact inner_16
                                      | succ n =>
                                        cases n with
                                        | zero => exact inner_17
                                        | succ n =>
                                          cases n with
                                          | zero => exact inner_18
                                          | succ n =>
                                            cases n with
                                            | zero => exact inner_19
                                            | succ n =>
                                              cases n with
                                              | zero => exact inner_20
                                              | succ n =>
                                                cases n with
                                                | zero => exact inner_21
                                                | succ n =>
                                                  cases n with
                                                  | zero => exact inner_22
                                                  | succ n =>
                                                    cases n with
                                                    | zero => exact inner_23
                                                    | succ n =>
                                                      cases n with
                                                      | zero => exact inner_24
                                                      | succ n =>
                                                        cases n with
                                                        | zero => exact inner_25
                                                        | succ n =>
                                                          cases n with
                                                          | zero => exact inner_26
                                                          | succ n =>
                                                            omega
theorem result : yRowIntegralFast 17 11 15 (rows[4]!) = (-145272526275599502019542461687289125013441640791713356185600000000 : Int) := by
  change (currentRow.2.2.map inner).sum = _
  rw [list_certificate]
  decide +kernel
#print axioms result
end MOpenAISample

open Lean Elab Command in
elab "#recheck_fresh_kernel" : command => do
  let env ← getEnv
  let mut count := 0
  let mut total : Nat := 0
  for (name, ci) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    let .thmInfo value := ci | continue
    let renamed := Name.str `MKernelRecheck name.toString
    let began ← IO.monoNanosNow
    match env.addDeclCore 1000000 1000000
        (.thmDecl {value with name := renamed, all := [renamed]}) none with
    | .error e => throwError "original kernel recheck failed: {e}"
    | .ok _ => pure ()
    let ended ← IO.monoNanosNow
    total := total + (ended - began).toNat
    count := count + 1
    logInfo m!"M_OPENAI_KERNEL {name} {ended - began}"
  logInfo m!"M_OPENAI_KERNEL_TOTAL {count} {total}"
#recheck_fresh_kernel
