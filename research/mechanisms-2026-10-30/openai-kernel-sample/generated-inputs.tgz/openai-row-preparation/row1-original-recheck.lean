import OAI.Analysis.Laughlin.FourBody.RowCompute
import Lean
set_option maxHeartbeats 200000
set_option maxRecDepth 10000
open OAI.Laughlin.Certificate.RowCompute
namespace MOpenAISample
theorem result : yRowIntegralFast 17 11 15 (rows[1]!) = (889111953967100853219108311928204221408320732742968934400000000 : Int) := by decide +kernel
#print axioms result
end MOpenAISample

open Lean Elab Command in
elab "#recheck_fresh_kernel" : command => do
  let env ← getEnv
  let mut count := 0
  let mut total : Nat := 0
  for (name, ci) in env.constants.toList do
    if (env.getModuleIdxFor? name).isSome then continue
    let .thmInfo value := ci | continue
    let renamed := Name.str `MKernelRecheck name.toString
    let began ← IO.monoNanosNow
    match env.addDeclCore 1000000 1000000
        (.thmDecl {value with name := renamed, all := [renamed]}) none with
    | .error e => throwError "original kernel recheck failed: {e}"
    | .ok _ => pure ()
    let ended ← IO.monoNanosNow
    total := total + (ended - began).toNat
    count := count + 1
    logInfo m!"M_OPENAI_KERNEL {name} {ended - began}"
  logInfo m!"M_OPENAI_KERNEL_TOTAL {count} {total}"
#recheck_fresh_kernel
