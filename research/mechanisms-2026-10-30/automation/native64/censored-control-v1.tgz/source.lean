import Mathlib
set_option maxHeartbeats 200000
theorem prefix_error (S : Finset Nat) (h :
    ∀ n, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d ∈ Nat.digits 10 n, Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  have impossible : (1 : Nat) = 2 := by decide
  have eqSet : S = (Finset.Icc 1000 9999).filter (fun n =>
      (∀ d ∈ Nat.digits 10 n, Even d) ∧ 5 ∣ n) := by
    ext n
    rw [h, Finset.mem_filter, Finset.mem_Icc]
    tauto
  rw [eqSet]
  rfl

#print axioms prefix_error
