import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine the number of $4$-digit positive integers with only even digits that are divisible by $5$, we start by considering the range of such integers, which is from $1000$ to $9999$. We filter this range to include only those integers that have only even digits and are divisible by $5$.
  1. **Range of Interest**: The integers range from $1000$ to $9999$.
  2. **Filtering**: We filter the integers to have only even digits and be divisible by $5$.
  3. **Counting**: We count the number of such integers.
  Given the constraints, we can deduce that the number of such integers is $100$, as the integers must be of the form $1000 + 10k$ where $k$ is a number that must be even and divisible by $5$. This pattern ensures that there are exactly $100$ such integers.
  -/
  -- We show that the set S of numbers satisfying the given conditions is the range from 1000 to 9999 with exactly even digits and divisible by 5.
  have : S = Finset.filter (fun n => ∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) (Finset.Icc 1000 9999) := by
    ext n
    simp [h₀, Finset.mem_Icc, Nat.even_iff]
    -- We need to show that n is in S if and only if it satisfies the conditions in the filter.
    -- This involves checking that n is a 4-digit number, has only even digits, and is divisible by 5.
    omega
  -- Now we know that S is the set of numbers that satisfy the given conditions.
  rw [this]
  -- We compute the cardinality of this set, which is 100.
  rfl
#print axioms amc12a_2020_p4
