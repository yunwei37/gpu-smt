import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- The product of two positive whole numbers is 2005. If neither number is 1, what is the sum of the two numbers? Show that it is 406.-/
theorem mathd_numbertheory_541 (m n : ℕ) (h₀ : 1 < m) (h₁ : 1 < n) (h₂ : m * n = 2005) :
    m + n = 406 := by
  /-
  Given two positive whole numbers \( m \) and \( n \) such that \( m \times n = 2005 \) and neither \( m \) nor \( n \) is 1, we need to show that the sum \( m + n \) is 406. We start by noting that both \( m \) and \( n \) are greater than 1. We then use the fact that the product \( m \times n = 2005 \) and the constraints on \( m \) and \( n \) to deduce the sum \( m + n \).
  -/
  -- We know that both m and n are greater than 1.
  have : 1 < m := h₀
  have : 1 < n := h₁
  have : m * n = 2005 := h₂
  -- We use the fact that m and n are positive and the product to deduce the sum.
  apply Eq.symm
  -- We use the fact that m and n are positive and the product to deduce the sum.
  nlinarith [mul_pos (Nat.pos_of_ne_zero (by norm_num : (2005 : ℕ) ≠ 0)) (Nat.pos_of_ne_zero (by norm_num : (2005 : ℕ) ≠ 0))]
#print axioms mathd_numbertheory_541
