import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many 4-digit positive integers (i.e., integers between 1000 and 9999, inclusive) have only even digits that are divisible by 5, we need to analyze the conditions under which a 4-digit number has only even digits and is divisible by 5.
  1. **Range and Digits**: The number must be a 4-digit number, so \(1000 \leq n \leq 9999\).
  2. **Even Digits**: All digits of \(n\) must be even. This implies that each digit \(d\) in the number \(n = \overline{d_4 d_3 d_2 d_1 d_0}\) is even.
  3. **Divisibility by 5**: The number \(n\) must be divisible by 5. This means \(d_0\) must be 0 or 5.
  Given these conditions, we can count the possible numbers. Since the number must be divisible by 5 and all digits must be even, the last digit must be 0 or 5. We will show that there are exactly 100 such numbers.
  -/
  have : S = Finset.filter (fun n => 5 ∣ n) (Finset.filter (fun n => ∀ d ∈ Nat.digits 10 n, Even d) (Finset.Icc 1000 9999)) := by
    ext n
    simp [h₀]
    -- We need to show that the conditions in h₀ are equivalent to the conditions in the filter.
    constructor <;> intro h
    -- Case 1: If n satisfies the conditions in h₀, then it satisfies the conditions in the filter.
    {
      constructor
      -- Check that n is a 4-digit number.
      { simpa [Nat.lt_succ_iff] using h.1 }
      constructor
      -- Check that n is divisible by 5.
      { simpa using h.2.2.2 }
      constructor
      -- Check that all digits of n are even.
      { intro d hd
        have : d ∈ Finset.range 10 := by simpa using hd
        rcases this with ⟨d', hd'⟩
        simp [← hd'] at this ⊢
        simpa using h.2.2.1 d' hd' }
      -- Check that n is a 4-digit number.
      { simpa [Nat.lt_succ_iff] using h.1 }
    }
    -- Case 2: If n satisfies the conditions in the filter, then it satisfies the conditions in h₀.
    {
      constructor
      -- Check that n is a 4-digit number.
      { simpa [Nat.lt_succ_iff] using h.1 }
      constructor
      -- Check that n is divisible by 5.
      { simpa using h.2 }
      constructor
      -- Check that all digits of n are even.
      { intro d hd
        have : d ∈ Finset.range 10 := by simpa using hd
        rcases this with ⟨d', hd'⟩
        simp [← hd'] at this ⊢
        simpa using h.2.1 d' hd' }
      -- Check that n is a 4-digit number.
      { simpa [Nat.lt_succ_iff] using h.1 }
    }
  simpa using this
#print axioms amc12a_2020_p4
