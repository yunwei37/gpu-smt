import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine the number of 4-digit positive integers with only even digits that are divisible by 5, we need to identify the conditions for such integers. A 4-digit integer ranges from 1000 to 9999. For an integer to be divisible by 5, its last digit must be either 0 or 5. Given that all digits of the integer must be even, the possible values for each digit are 0, 2, 4, 6, or 8.
  The first digit (thousands place) cannot be 0, so it has 4 choices (2, 4, 6, 8). The second and third digits can each be any even digit (0, 2, 4, 6, 8), giving a total of \(4 \times 5 \times 5 = 100\) possible 4-digit integers with only even digits that are divisible by 5.
  -/
  -- We show that the set S of integers satisfying the given conditions is exactly the set of integers from 1000 to 9999 that meet the criteria.
  have : S = Finset.filter (fun n ↦ n ≥ 1000 ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) (Finset.range 10000) := by
    ext n
    simp [h₀, Nat.lt_succ_iff]
    -- The range function generates all integers from 0 to 9999.
    -- The filter function applies the conditions given in h₀ to each integer in the range.
    omega
  -- We rewrite S using the filtered range, which gives us the set of all 4-digit integers with only even digits and divisible by 5.
  rw [this]
  -- The cardinality of the filtered set is the count of such integers, which is known to be 100.
  m_digits_rfl
#print axioms amc12a_2020_p4
