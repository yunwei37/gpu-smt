import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine the number of $4$-digit positive integers with only even digits that are divisible by $5$, we need to find the range of such integers and count them. A $4$-digit number ranges from $1000$ to $9999$. We need to identify numbers within this range that have only even digits and are divisible by $5$.
  1. **Identify the range of numbers**: The numbers in question are between $1000$ and $9999$.
  2. **Determine divisibility by 5**: For a number to be divisible by $5$, its last digit must be $0$ or $5$.
  3. **Count the valid numbers**:
     - **Range of choices for the first digit**: The first digit (thousands place) can be any digit from $1$ to $9$, giving us 9 choices.
     - **Range of choices for the second digit**: The second digit (hundreds place) can be any digit from $0$ to $9$, giving us 10 choices.
     - **Range of choices for the third digit**: The third digit (tens place) can be any digit from $0$ to $9$, giving us 10 choices.
     - **Range of choices for the fourth digit**: The fourth digit (units place) can only be $0$ or $5$, giving us 2 choices.
  Combining these, the total number of valid numbers is calculated as:
  \[ 9 \text{ (choices for the first digit)} \times 10 \text{ (choices for the second digit)} \times 10 \text{ (choices for the third digit)} \times 2 \text{ (choices for the fourth digit)} = 1800 \]
  However, this calculation seems incorrect. Let's correct it:
  - **Range of choices for the first digit**: The first digit (thousands place) can be any digit from $1$ to $9$, giving us 9 choices.
  - **Range of choices for the second digit**: The second digit (hundreds place) can be any digit from $0$ to $9$, giving us 10 choices.
  - **Range of choices for the third digit**: The third digit (tens place) can be any digit from $0$ to $9$, giving us 10 choices.
  - **Range of choices for the fourth digit**: The fourth digit (units place) can only be $0$ or $5$, giving us 2 choices.
  Thus, the total number of valid numbers is:
  \[ 9 \text{ (choices for the first digit)} \times 10 \text{ (choices for the second digit)} \times 10 \text{ (choices for the third digit)} \times 2 \text{ (choices for the fourth digit)} = 1800 \]
  -/
  have h₁ : S = Finset.filter (fun x : ℕ => 1000 ≤ x ∧ x ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 x → Even d) ∧ 5 ∣ x) (Finset.Icc 1000 9999) := by
    ext n
    simp [h₀, Finset.mem_Icc]
    -- This line uses the given condition to establish the equivalence between membership in S and the filter condition.
    -- The filter condition checks if a number n is within the range [1000, 9999], has only even digits, and is divisible by 5.
    -- The proof simply uses the given condition h₀ to show that the membership in S is equivalent to the filter condition.
    <;> omega
  rw [h₁]
  -- This line rewrites S using the filter condition h₁.
  rfl
#print axioms amc12a_2020_p4
