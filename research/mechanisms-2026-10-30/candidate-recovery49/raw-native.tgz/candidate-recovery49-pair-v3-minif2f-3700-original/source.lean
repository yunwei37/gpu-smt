import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To show that the number of 4-digit positive integers with only even digits and divisible by 5 is 100, we start by defining the set \( S \) of all 4-digit numbers with only even digits and divisible by 5. We then prove that this set \( S \) is equivalent to the set of numbers from 1000 to 9999 with only even digits and divisible by 5. Finally, we count the number of such numbers and verify that the count is indeed 100.
  -/
  -- We show that S is equal to the set of numbers from 1000 to 9999 with only even digits and divisible by 5.
  have : S = Finset.filter (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) (Finset.range 10000) := by
    ext n
    simp [h₀, Nat.lt_succ_iff]
    -- We need to show that n is in S if and only if it satisfies the given conditions.
    -- This is done by simplifying the conditions and using basic arithmetic and logical equivalences.
    omega
  -- We rewrite S using the above equivalence.
  rw [this]
  -- We count the number of elements in the filtered set and verify that it equals 100.
  rfl
#print axioms amc12a_2020_p4
