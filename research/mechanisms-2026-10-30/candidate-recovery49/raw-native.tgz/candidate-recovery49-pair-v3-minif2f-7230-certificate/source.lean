import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- The product of two positive whole numbers is 2005. If neither number is 1, what is the sum of the two numbers? Show that it is 406.-/
theorem mathd_numbertheory_541 (m n : ℕ) (h₀ : 1 < m) (h₁ : 1 < n) (h₂ : m * n = 2005) :
    m + n = 406 := by
  /-
  Given two positive whole numbers \( m \) and \( n \) such that \( m \times n = 2005 \) and neither \( m \) nor \( n \) is 1, we need to show that \( m + n = 406 \).
  1. Since neither \( m \) nor \( n \) is 1, we have \( m \geq 2 \) and \( n \geq 2 \).
  2. We start by considering the product \( m \times n = 2005 \).
  3. To find the sum \( m + n \), we can use the fact that both \( m \) and \( n \) must be positive integers and their product is 2005.
  4. We can list the pairs of positive integers that multiply to 2005:
     - \( 1 \times 2005 = 2005 \)
     - \( 5 \times 401 = 2005 \)
     - \( 401 \times 5 = 2005 \)
     - \( 2005 \times 1 = 2005 \)
  5. Among these pairs, the pairs \( 5 \times 401 \) and \( 401 \times 5 \) are the only pairs where both \( m \) and \( n \) are greater than 1.
  6. Therefore, the sum \( m + n \) is \( 5 + 401 = 406 \).
  -/
  have : 2 ≤ m := by
    -- Since m is not 1, it must be at least 2.
    apply le_of_not_gt
    intro hm
    apply lt_irrefl 1
    linarith
  have : 2 ≤ n := by
    -- Since n is not 1, it must be at least 2.
    apply le_of_not_gt
    intro hn
    apply lt_irrefl 1
    linarith
  -- We use the fact that the product of m and n is 2005 and both m and n are at least 2.
  have : m + n = 406 := by
    -- We list the pairs of positive integers that multiply to 2005 and find that m + n = 406.
    have : m ≤ 401 := by
      nlinarith
    have : n ≤ 401 := by
      nlinarith
    m_interval_cases m <;> m_interval_cases n <;> norm_num at h₂
  exact this
#print axioms mathd_numbertheory_541
