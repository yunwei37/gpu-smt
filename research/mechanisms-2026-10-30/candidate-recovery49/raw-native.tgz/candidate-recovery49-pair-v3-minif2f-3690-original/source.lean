import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To solve the problem of finding the number of $4$-digit positive integers with only even digits that are divisible by 5, we need to follow these steps:
  1. **Identify the range of such integers**: The integers in question are from $1000$ to $9999$, inclusive.
  2. **Determine the number of choices for each digit**: Each digit of a 4-digit number can be any even number from 0 to 9. This gives us 5 choices for each digit (0, 2, 4, 6, 8).
  3. **Calculate the total number of combinations**: Since there are 4 digits, the total number of combinations is \(5^4\).
  4. **Filter out the integers divisible by 5**: Since the last digit must be 0 or 5 to be divisible by 5, and we have only even digits, the only possible last digit is 0. Thus, we exclude the 4 combinations that end in 5 (i.e., 5, 25, 45, 65, 85).
  5. **Count the remaining combinations**: Therefore, the number of valid 4-digit integers is \(5^4 - 4\).
  -/
  -- Show that the set S is exactly the filtered range of numbers from 1000 to 9999 with only even digits and divisible by 5.
  have h₁ : S = Finset.filter
    (fun n => ∀ d : ℕ, d ∈ Nat.digits 10 n → Even d ∧ 5 ∣ n)
    (Finset.Icc 1000 9999) := by
    ext
    simp [h₀, Nat.lt_succ_iff]
    omega
  -- Rewrite the set S using the filter condition.
  rw [h₁]
  -- The cardinality of the filtered set is the cardinality of the set of all 4-digit numbers with only even digits and divisible by 5.
  rfl
#print axioms amc12a_2020_p4
