import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- The product of two positive whole numbers is 2005. If neither number is 1, what is the sum of the two numbers? Show that it is 406.-/
theorem mathd_numbertheory_541 (m n : ℕ) (h₀ : 1 < m) (h₁ : 1 < n) (h₂ : m * n = 2005) :
    m + n = 406 := by
  /-
  Given two positive whole numbers \( m \) and \( n \) such that \( m \times n = 2005 \) and neither \( m \) nor \( n \) is 1, we need to find the sum of \( m \) and \( n \). We show that the sum is 406.
  First, we establish that \( m \) and \( n \) are both greater than 1. Then, we use the fact that the product \( m \times n = 2005 \) to find the possible values of \( m \) and \( n \). By solving the equation and considering the constraints, we determine that \( m + n = 406 \).
  -/
  -- Establish that m and n are both greater than 1.
  have hm : 1 < m := by linarith
  have hn : 1 < n := by linarith
  -- Use the fact that the product m * n = 2005 to find the possible values of m and n.
  have hm1 : m ≤ 2005 := by nlinarith
  have hn1 : n ≤ 2005 := by nlinarith
  -- By solving the equation and considering the constraints, we determine that m + n = 406.
  interval_cases m <;> interval_cases n <;> norm_num at h₂ <;> omega
#print axioms mathd_numbertheory_541
