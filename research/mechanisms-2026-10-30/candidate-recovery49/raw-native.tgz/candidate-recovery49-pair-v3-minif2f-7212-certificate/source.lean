import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- The product of two positive whole numbers is 2005. If neither number is 1, what is the sum of the two numbers? Show that it is 406.-/
theorem mathd_numbertheory_541 (m n : ℕ) (h₀ : 1 < m) (h₁ : 1 < n) (h₂ : m * n = 2005) :
    m + n = 406 := by
  /-
  Given two positive whole numbers \( m \) and \( n \) such that \( m \times n = 2005 \), we need to show that the sum \( m + n \) equals 406. We will consider the possible values of \( m \) and \( n \) that satisfy the given conditions and verify that their sum is indeed 406.
  -/
  have : m + n = 406 := by
    -- Consider the possible values of m and n that satisfy the given conditions.
    -- We know that m and n are both greater than 1 and their product is 2005.
    have : m ≤ 2005 := by nlinarith
    have : n ≤ 2005 := by nlinarith
    -- We use interval_cases to check all possible values of m and n within the range.
    m_interval_cases m <;> m_interval_cases n <;> omega
  -- Finally, we conclude that the sum of m and n is 406.
  exact this
#print axioms mathd_numbertheory_541
