import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To show that there are exactly 100 four-digit positive integers having only even digits and divisible by 5, we need to follow these steps:
  1. **Filter the Set**: We need to filter the set of numbers from 1000 to 9999 that meet the criteria:
     - All digits are even.
     - The number is divisible by 5.
  2. **Count the Elements**: We will count the number of elements in this filtered set.
  Given the constraints, we can directly verify that the number of such numbers is indeed 100.
  -/
  have h₁ : S = Finset.filter (fun n => n ≥ 1000 ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) (Finset.range 10000) := by
    ext
    simp [h₀]
    omega
  rw [h₁]
  m_digits_rfl
#print axioms amc12a_2020_p4
