import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many 4-digit positive integers are divisible by 5 and have only even digits, we start by defining the set \( S \) of such integers. An integer \( n \) is in \( S \) if and only if:
  1. \( n \) is a 4-digit number, i.e., \( 1000 \leq n \leq 9999 \).
  2. All digits of \( n \) are even.
  3. \( n \) is divisible by 5.
  Given these conditions, we need to show that \( S \) has exactly 100 elements. We use the fact that the number of 4-digit even numbers is 500, as the first digit cannot be 0 (since \( n \) is a 4-digit number). The number of such numbers that are also divisible by 5 is 500.
  -/
  -- Define the set S to be the filter of numbers from 1000 to 9999 with even digits and divisible by 5.
  have : S = Finset.filter (fun n : ℕ =>
      n ≥ 1000 ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n)
      (Finset.Icc 1000 9999) := by
    ext n
    simp [h₀, Finset.mem_Icc]
    -- Use the omega tactic to solve the arithmetic conditions.
    omega
  -- Rewrite the set S using the filter function.
  rw [this]
  -- The cardinality of the filtered set is 100.
  rfl
#print axioms amc12a_2020_p4
