import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine the number of 4-digit positive integers that have only even digits and are divisible by 5, we need to count the integers that meet the criteria. The criteria are:
  1. The integer must be between 1000 and 9999, inclusive.
  2. Each digit of the integer must be even.
  3. The integer must be divisible by 5.
  Given these criteria, we can deduce that the number of such integers is 100, as the count is straightforward and can be verified by the properties of even digits and divisibility by 5.
  -/
  -- We show that S is the set of integers from 1000 to 9999 with only even digits and divisible by 5.
  have h₁ : S = Finset.filter (fun n : ℕ => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n)
    (Finset.Icc 1000 9999) := by
    ext n
    -- We use the given condition to show that n is in the set if and only if it satisfies the filter condition.
    simp [h₀, Finset.mem_Icc]
    -- The filter condition checks that n is between 1000 and 9999, has only even digits, and is divisible by 5.
    -- This is sufficient to prove that the count of such integers is 100.
    omega
  -- We rewrite S using the filter condition and the range of integers from 1000 to 9999.
  rw [h₁]
  -- The cardinality of the filtered set is 100, as there are 100 integers in the range [1000, 9999] that meet the criteria.
  m_digits_rfl
#print axioms amc12a_2020_p4
