import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- The product of two positive whole numbers is 2005. If neither number is 1, what is the sum of the two numbers? Show that it is 406.-/
theorem mathd_numbertheory_541 (m n : ℕ) (h₀ : 1 < m) (h₁ : 1 < n) (h₂ : m * n = 2005) :
    m + n = 406 := by
  /-
  Given two positive whole numbers \( m \) and \( n \) such that \( m \times n = 2005 \), we need to show that if neither number is 1, then their sum \( m + n \) is 406. We start by noting that both \( m \) and \( n \) must be greater than 1. The product of \( m \) and \( n \) is given as 2005. We can express \( n \) in terms of \( m \) as \( n = \frac{2005}{m} \). Since \( m \) is a positive integer, \( \frac{2005}{m} \) must also be a positive integer. This implies that \( m \) must be a divisor of 2005.
  To find the possible values of \( m \), we list the divisors of 2005:
  - 1, 5, 401, and 2005
  Since \( m > 1 \), we discard the cases \( m = 1 \) and \( m = 5 \). We then check the remaining cases:
  - If \( m = 401 \), then \( n = \frac{2005}{401} = 5 \).
  - If \( m = 2005 \), then \( n = \frac{2005}{2005} = 1 \).
  Since neither \( m \) nor \( n \) can be 1, we discard the cases \( m = 2005 \) and \( n = 1 \).
  Thus, the only valid solutions are \( m = 401 \) and \( n = 5 \), or \( m = 5 \) and \( n = 401 \). However, since \( m \times n = 2005 \), the only valid pair is \( m = 401 \) and \( n = 5 \).
  Therefore, \( m + n = 401 + 5 = 406 \).
  -/
  have h₀ : m ≤ 2005 := by
    -- We need to show that m is less than or equal to 2005 to apply the equality check.
    apply Nat.le_of_not_lt
    intro h
    -- If m is greater than 2005, then the product m * n would be greater than 2005, contradicting the given equality.
    have : m * n > 2005 := by nlinarith
    linarith
  have h₁ : n ≤ 2005 := by
    -- Similarly, n must be less than or equal to 2005 to apply the equality check.
    apply Nat.le_of_not_lt
    intro h
    -- If n is greater than 2005, then the product m * n would be greater than 2005, contradicting the given equality.
    have : m * n > 2005 := by nlinarith
    linarith
  -- We now check all possible values of m and n that satisfy the conditions.
  interval_cases m <;> interval_cases n <;> norm_num at h₂ ⊢
#print axioms mathd_numbertheory_541
