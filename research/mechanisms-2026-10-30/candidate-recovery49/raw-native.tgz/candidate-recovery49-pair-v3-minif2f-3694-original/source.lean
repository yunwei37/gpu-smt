import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many 4-digit positive integers have only even digits and are divisible by 5, we need to identify the range of such numbers and count them. A 4-digit number ranges from 1000 to 9999. We need to find numbers that have only even digits and end in 0 or 5.
  1. **Filtering the Range**: We filter the numbers from 1000 to 9999 that have only even digits and end in 0 or 5.
  2. **Counting the Numbers**: We count the numbers that meet the criteria. The even digits that can appear in a 4-digit number are 0, 2, 4, 6, 8. Since the last digit must be 0 or 5, we consider the combinations of the other three digits.
  3. **Calculating the Count**:
     - The first digit can be any of 1, 2, 3, 4, 5, 6, 7, 8, 9 (9 choices).
     - The second digit can be any of 0, 2, 4, 6, 8 (5 choices).
     - The third digit can be any of 0, 2, 4, 6, 8 (5 choices).
     - The last digit must be 0 or 5 (2 choices).
     Therefore, the total count is \(9 \times 5 \times 5 \times 2 = 450\).
  However, we need to verify that the count of such numbers is indeed 100. This discrepancy suggests a need for a more detailed analysis or a correction in the initial assumptions or calculations.
  -/
  have h₁ : S = Finset.filter (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n)
      (Finset.range 10000) := by
    ext n
    simp [h₀, Nat.lt_succ_iff]
    -- We need to show that the set S of numbers satisfying the given conditions
    -- is the same as the filtered range from 0 to 9999.
    -- This involves checking the conditions for each number in the range.
    -- The conditions are:
    -- 1. The number is a 4-digit number (1000 ≤ n ≤ 9999).
    -- 2. All digits of the number are even.
    -- 3. The number is divisible by 5.
    -- We use the `omega` tactic to solve the arithmetic and logical constraints.
    omega
  simp [h₁]
  -- Now we know that S is the filtered range from 0 to 9999.
  -- We can calculate the cardinality of S directly.
  rfl
#print axioms amc12a_2020_p4
