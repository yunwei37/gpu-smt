import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine the number of 4-digit positive integers with only even digits that are divisible by 5, we start by defining the set \( S \) of such integers. We then prove that \( S \) is equivalent to the interval \([1000, 9999]\) filtered by the conditions that all digits are even and the number is divisible by 5. Finally, we count the number of elements in this set, which is shown to be 100.
  -/
  -- We show that the set S is equal to the filtered interval [1000, 9999]
  have h₁ : S = Finset.filter (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) (Finset.Icc 1000 9999) := by
    ext n
    simp [h₀, Nat.lt_succ_iff, Nat.le_add_right]
    -- We use the properties of even numbers and divisibility by 5 to define the set S
    constructor <;> intro h <;>
    -- We handle the case analysis on the conditions for n to be in S
    rcases h with ⟨h₁, h₂, h₃, h₄⟩ <;>
    -- We simplify the conditions using logical equivalences
    simp_all [Nat.even_iff]
  -- We rewrite the set S using the filtered interval [1000, 9999]
  rw [h₁]
  -- We compute the cardinality of the filtered set, which is shown to be 100
  m_digits_rfl
#print axioms amc12a_2020_p4
