import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many 4-digit positive integers have only even digits and are divisible by 5, we need to find the number of such integers. An integer \( n \) is considered a 4-digit number if it lies between 1000 and 9999, inclusive. The condition for \( n \) to have only even digits is that each digit in its decimal representation must be even. The even digits are 0, 2, 4, 6, and 8. Since the last digit of \( n \) must be 0 (to ensure divisibility by 5), the other three digits must be chosen from the set {0, 2, 4, 6, 8}.
  Given that the last digit is fixed as 0, we have 4 choices for the first digit, 5 choices for the second digit, and 5 choices for the third digit. Thus, the total number of such integers is calculated as:
  \[ 4 \times 5 \times 5 = 100 \]
  -/
  have : S = Finset.filter (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) (Finset.range 10000) := by
    ext n
    simp [h₀, Nat.lt_succ_iff]
    -- We need to show that the filter of numbers from 0 to 9999 that satisfy the given conditions
    -- is equal to the set of numbers from 1000 to 9999 that satisfy the conditions.
    -- This is done by simplifying the filter operation and using the properties of numbers.
    omega
  rw [this]
  -- We rewrite the set S using the filter operation.
  rfl
#print axioms amc12a_2020_p4
