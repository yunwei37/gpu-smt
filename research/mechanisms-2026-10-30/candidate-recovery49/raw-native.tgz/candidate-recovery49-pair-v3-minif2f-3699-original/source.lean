import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many $4$-digit positive integers have only even digits and are divisible by $5$, we need to count the numbers that meet the criteria. A number is divisible by $5$ if its last digit is $0$ or $5$. Given that the number must have only even digits, the last digit must be $0$ (as the only even digit that can be the last digit is $0$).
  The remaining three digits must also be even. The digits $0, 2, 4, 6, 8$ are the only even digits. Therefore, each of the three remaining digits can be any of these five digits. The total number of ways to choose these digits is calculated as follows:
  - The first digit can be any of $0, 2, 4, 6, 8$ (5 choices).
  - The second digit can be any of $0, 2, 4, 6, 8$ (5 choices).
  - The third digit can be any of $0, 2, 4, 6, 8$ (5 choices).
  Thus, the total number of $4$-digit numbers with only even digits and divisible by $5$ is $5 \times 5 \times 5 = 125$.
  -/
  have : S = Finset.filter (fun n => n % 5 = 0) (Finset.filter (fun n => ∀ d ∈ Nat.digits 10 n, Even d) (Finset.Icc 1000 9999)) := by
    ext n
    simp [h₀, Nat.even_iff]
    -- We need to show that a number is in S if and only if it is a 4-digit number with only even digits and divisible by 5.
    -- This involves checking the conditions for membership in the sets involved.
    -- The filter function will apply the conditions to each number in the range.
    -- The Icc 1000 9999 is the set of all 4-digit numbers.
    -- The filter (fun n => ∀ d ∈ Nat.digits 10 n, Even d) ensures that all digits of the number are even.
    -- The filter (fun n => n % 5 = 0) ensures that the number is divisible by 5.
    -- The final set S is the intersection of these two filters.
    omega
  -- We have shown that S is the set of all numbers that satisfy the given conditions.
  simp [this]
  -- The cardinality of S is the number of elements in the set, which is 100.
  rfl
#print axioms amc12a_2020_p4
