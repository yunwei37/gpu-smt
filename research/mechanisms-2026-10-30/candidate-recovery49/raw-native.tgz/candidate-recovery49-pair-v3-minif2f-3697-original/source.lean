import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many 4-digit positive integers (i.e., integers between 1000 and 9999, inclusive) have only even digits and are divisible by 5, we need to consider the properties of even digits and the divisibility rule for 5.
  1. **Range of 4-digit integers**: These integers range from 1000 to 9999.
  2. **Even digits**: Since the digits must be even, they can only be 0, 2, 4, 6, or 8.
  3. **Divisibility by 5**: For a number to be divisible by 5, its last digit must be 0 or 5.
  Given the constraints, we can analyze the possible values of the digits. The first digit (thousands place) must be an even digit, and the other three digits must also be even and divisible by 5. This means the first digit can be 2, 4, 6, or 8 (4 choices). The last digit can be 0 or 5 (2 choices).
  Thus, the total number of such integers is calculated by considering the choices for the first digit and the last digit:
  \[
  4 \text{ (choices for the first digit)} \times 2 \text{ (choices for the last digit)} = 8
  \]
  However, we need to consider the structure of the problem and the constraints on the digits. The problem states that the number must be divisible by 5, and since the digits must be even, we need to count the valid combinations of digits.
  The correct approach is to consider the valid combinations of digits and their permutations. The number of valid 4-digit integers with only even digits and divisible by 5 can be determined by the combinatorial analysis of the digits.
  -/
  -- We need to show that the set S of numbers satisfying the given conditions has exactly 100 elements.
  have h₁ : S = Finset.filter (fun n => n % 10 = 0 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d)) (Finset.Icc 1000 9999) := by
    ext n
    simp [h₀, ← Nat.lt_succ_iff, Nat.le_of_dvd zero_lt_one]
    -- We need to show that a number n is in S if and only if it satisfies the conditions in h₀.
    -- This involves checking that n % 10 = 0 and all digits of n are even.
    -- We use the properties of the digits and the range of numbers to establish this equivalence.
    omega
  -- Now we know that S is the set of numbers from 1000 to 9999 with only even digits and divisible by 5.
  rw [h₁]
  -- We rewrite S using the established equivalence.
  rfl
  -- The cardinality of the set of numbers satisfying the conditions is 100.
#print axioms amc12a_2020_p4
