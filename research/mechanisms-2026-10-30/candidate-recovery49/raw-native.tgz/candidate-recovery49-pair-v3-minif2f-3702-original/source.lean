import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine the number of 4-digit positive integers with only even digits that are divisible by 5, we need to count the integers \( n \) in the range from 1000 to 9999 that satisfy the following conditions:
  1. All digits of \( n \) are even.
  2. \( n \) is divisible by 5.
  Given that the last digit of \( n \) must be 0 or 5 (since \( n \) must be divisible by 5), we can focus on the digits in the thousands and hundreds place. For each choice of these digits (which can be 0, 2, 4, 6, or 8), we can form a valid number. The thousands and hundreds digits can be any of the 5 even digits (0, 2, 4, 6, 8).
  Thus, the total number of such numbers is calculated as:
  \[ 5 \text{ (choices for the thousands place)} \times 5 \text{ (choices for the hundreds place)} \times 5 \text{ (choices for the tens place)} \times 5 \text{ (choices for the units place)} = 5^4 = 625 \]
  However, this calculation seems incorrect because it does not account for the fact that the number must be divisible by 5. The correct approach is to consider the constraints and the possible values for each digit.
  -/
  have h₁ : S = Finset.filter
    (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n)
    (Finset.range 10000) := by
    ext n
    simp [h₀, Finset.mem_filter, Finset.mem_range]
    omega
  rw [h₁]
  simp only [Finset.card, Finset.filter_eq, Finset.mem_filter, Finset.mem_range, Finset.card_range,
    Nat.div_self (Nat.zero_lt_succ _)]
  rfl
#print axioms amc12a_2020_p4
