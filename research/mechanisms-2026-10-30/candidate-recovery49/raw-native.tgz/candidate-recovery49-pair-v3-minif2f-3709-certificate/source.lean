import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many \(4\)-digit positive integers (i.e., integers between \(1000\) and \(9999\), inclusive) have only even digits and are divisible by \(5\), we need to identify the pattern of such numbers. Numbers with only even digits and divisible by \(5\) must end in \(0\) and have digits that are all even. The smallest such number is \(1000\) and the largest is \(9900\). We can count the number of such numbers by considering the sequence of even numbers from \(0\) to \(99\).
  -/
  -- We define the set S to be the filter of numbers from 1000 to 9999 that have only even digits and are divisible by 5.
  have : S = Finset.filter (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) (Finset.range 10000) := by
    ext n
    simp [h₀, Nat.lt_succ_iff]
    -- We need to show that the number n is in S if and only if it satisfies the conditions in the filter.
    -- This involves checking that n is a 4-digit number, has only even digits, and is divisible by 5.
    -- The filter function will select numbers that satisfy these conditions.
    -- We then use the properties of the filter to show that the cardinality of S is 100.
    omega
  -- We rewrite S using the defined filter.
  rw [this]
  -- The cardinality of the filtered set is 100, as derived from the properties of the numbers involved.
  m_digits_rfl
#print axioms amc12a_2020_p4
