import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many 4-digit positive integers have only even digits and are divisible by 5, we need to find the number of integers \( n \) in the range from 1000 to 9999 that satisfy the conditions:
  1. \( n \) has only even digits.
  2. \( n \) is divisible by 5.
  Given the constraints, we can deduce that the last digit of \( n \) must be 0 or 5. Since \( n \) must be a 4-digit number, the last digit must be 0 (as the number must be divisible by 5).
  Thus, the last digit is fixed as 0. The remaining 3 digits can be any combination of even digits (0, 2, 4, 6, 8) except for the first digit which cannot be 0 (since \( n \) must be a 4-digit number).
  For each choice of the first digit (4 choices: 2, 4, 6, 8), the remaining 3 digits can each be any of the even digits (4 choices: 0, 2, 4, 6, 8). Therefore, the total number of such \( n \) is:
  \[ 4 \times 4 \times 4 \times 4 = 4^4 = 256 \]
  However, since we are only interested in the number of such \( n \) that are divisible by 5, and the last digit must be 0, we only consider the cases where the first digit is 0 or 5, and the remaining 3 digits are even. This gives us:
  \[ 4 \times 4 \times 4 = 64 \]
  Thus, the number of such \( n \) is 64.
  -/
  have h₁ : S = Finset.filter (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n)
      (Finset.range (10000)) := by
    ext n
    simp [h₀, Finset.mem_filter, Finset.mem_range, le_of_lt]
    -- We need to show that the filter condition matches the given conditions.
    -- This involves checking that the number is within the range [1000, 9999],
    -- all digits are even, and the number is divisible by 5.
    -- The first condition is checked by `le_of_lt`.
    -- The second condition is checked by `le_of_lt`.
    -- The third condition is checked by `simp [Nat.lt_succ_iff]`.
    -- The fourth condition is checked by `le_of_lt`.
    omega
  simp_rw [h₁]
  -- Now we need to show that the cardinality of the filtered set is 100.
  -- This involves counting the number of valid numbers that meet the criteria.
  -- The first digit can be any of 4 even digits (2, 4, 6, 8).
  -- The second digit can be any of 5 even digits (0, 2, 4, 6, 8).
  -- The third digit can be any of 5 even digits (0, 2, 4, 6, 8).
  -- The fourth digit can be any of 5 even digits (0, 2, 4, 6, 8).
  -- Therefore, the total number of valid numbers is 4 * 5 * 5 * 5 = 500.
  -- However, since the number must be divisible by 5, the last digit must be 0.
  -- This reduces the count to 4 * 4 * 4 = 64.
  -- Thus, the number of such n is 64.
  m_digits_rfl
#print axioms amc12a_2020_p4
