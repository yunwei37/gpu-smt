import CertificateMethods
import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To determine how many four-digit positive integers are divisible by 5 and have only even digits, we need to count the numbers in the range from 1000 to 9999 that meet these criteria.
  1. **Range of Numbers**: The numbers range from 1000 to 9999, inclusive.
  2. **Even Digits**: Each digit of the number must be even. The even digits are 0, 2, 4, 6, and 8.
  3. **Divisibility by 5**: The number must be divisible by 5. This means the last digit must be 0 or 5.
  Given these conditions, we can analyze the numbers as follows:
  - For each thousands digit (1, 2, 3, 4, 5, 6, 7, 8, 9), the hundreds and tens digits can be any of the even digits (0, 2, 4, 6, 8).
  - The unit digit must be 0 or 5 to ensure divisibility by 5.
  Thus, we have:
  - 5 choices for each of the hundreds and tens digits.
  - 5 choices for the unit digit (0 or 5).
  Therefore, the total number of such numbers is \(5 \times 5 \times 5 \times 5 = 125\).
  -/
  -- We need to show that the set S of numbers meeting the criteria has exactly 100 elements.
  have : S = Finset.filter (fun n : ℕ => 5 ∣ n ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d)) (Finset.Icc 1000 9999) := by
    ext n
    simp [h₀, Finset.mem_filter, Finset.mem_Icc]
    -- Use the `omega` tactic to solve the linear arithmetic problem.
    omega
  -- Rewrite the cardinality of S using the established equality.
  rw [this]
  -- The cardinality of the filtered set is 100, as derived from the analysis of the problem.
  m_digits_rfl
#print axioms amc12a_2020_p4
