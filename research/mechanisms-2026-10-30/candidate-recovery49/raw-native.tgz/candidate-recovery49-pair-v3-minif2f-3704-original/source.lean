import Mathlib
import Aesop

set_option maxHeartbeats 200000

open BigOperators Real Nat Topology Rat

/-- How many $4$-digit positive integers (that is, integers between $1000$ and $9999$, inclusive) having only even digits are divisible by $5?$

$\textbf{(A) } 80 \qquad \textbf{(B) } 100 \qquad \textbf{(C) } 125 \qquad \textbf{(D) } 200 \qquad \textbf{(E) } 500$ Show that it is \textbf{(B) } 100.-/
theorem amc12a_2020_p4 (S : Finset ℕ)
    (h₀ : ∀ n : ℕ, n ∈ S ↔ 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n) :
    S.card = 100 := by
  /-
  To solve the problem, we need to count the number of 4-digit positive integers that have only even digits and are divisible by 5. 
  1. **Range and Constraints**: We are interested in numbers between 1000 and 9999, inclusive.
  2. **Digits and Evenness**: Each digit of the number must be even.
  3. **Divisibility by 5**: The number must be divisible by 5.
  Given these constraints, we can analyze the possible digits that can be used. The digits 0, 2, 4, 6, and 8 are even. Since the number must be divisible by 5, the last digit must be 0 or 5.
  To form a 4-digit number with only even digits, we can choose from the even digits: 0, 2, 4, 6, 8. For each choice of the last digit (0 or 5), we can choose the remaining three digits from the even digits.
  -/
  have h₁ : S = Finset.filter (fun n => 1000 ≤ n ∧ n ≤ 9999 ∧ (∀ d : ℕ, d ∈ Nat.digits 10 n → Even d) ∧ 5 ∣ n)
      (Finset.range 10000) := by
    ext
    simp [h₀, Finset.mem_filter, Finset.mem_range]
    -- We need to show that the set S is the same as the filtered set of numbers from 0 to 9999
    -- that satisfy the given conditions.
    -- The conditions are:
    -- 1. The number is a 4-digit number (1000 ≤ n ≤ 9999).
    -- 2. All digits are even.
    -- 3. The number is divisible by 5.
    -- We will use the fact that the last digit must be 0 or 5 to satisfy the conditions.
    -- The first three digits can be any of the even digits (0, 2, 4, 6, 8).
    -- The last digit must be 0 or 5 to ensure the number is divisible by 5.
    -- Therefore, the number of such numbers is 2 * 5 * 2 * 5 * 5 = 100.
    -- However, we need to filter out the numbers that are not valid.
    -- The filter function will keep only those numbers that satisfy the conditions.
  simp [h₁]
  -- Simplify the expression to show that the cardinality of S is 100.
  rfl
  <;> simp [h₀, Nat.zero_le]
  <;> simp [h₀, Nat.zero_le]
  <;> simp [h₀, Nat.zero_le]
#print axioms amc12a_2020_p4
