import subprocess,json,time
from pathlib import Path
R=Path("/workspaces/repository")
commands=[['/workspaces/.agent-state/gpu-smt-deps/kimina-server-fb2393d/.venv/bin/python', '/workspaces/repository/bench/lean-native/linarith-oracle/run-race.py', '--out', '/tmp/gpu-smt-linarith-oracle-20261017/nat-int-oracle/qualification10-new', '--input', '/workspaces/repository/artifacts/linarith-oracle-2026-10-17/gpu-stage/large-lp-race/nat-int-oracle/input-unsupported10.jsonl', '--limit', '10', '--methods', 'oracle-hint', '--diagnostic', '--reuse-reference', '/tmp/gpu-smt-linarith-oracle-20261017/nat-int-oracle/qualification10-old/rep1-fast-hybrid', '--width', '8', '--affinity', '8', '9', '10', '11', '--native-buckets', '--repl', '/tmp/gpu-smt-goedel427-20261014/repl-bucket-candidate-timing/.lake/build/bin/repl'], ['/workspaces/.agent-state/gpu-smt-deps/kimina-server-fb2393d/.venv/bin/python', '/workspaces/repository/bench/lean-native/linarith-oracle/run-race.py', '--out', '/tmp/gpu-smt-linarith-oracle-20261017/nat-int-oracle/qualification24-real', '--limit', '24', '--methods', 'fast-hybrid', 'oracle-hint', '--width', '8', '--affinity', '8', '9', '10', '11', '--native-buckets', '--repl', '/tmp/gpu-smt-goedel427-20261014/repl-bucket-candidate-timing/.lake/build/bin/repl']]
for i,cmd in enumerate(commands):
 print("BEGIN",i,time.strftime("%FT%TZ",time.gmtime()),flush=True)
 p=subprocess.run(cmd,cwd=R)
 print("END",i,p.returncode,time.strftime("%FT%TZ",time.gmtime()),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
