from pathlib import Path
import json,gzip,math,re,time
import numpy as np
root=Path('/workspaces/repository')
out=root/'artifacts/candidate-scheduling-2026-10-25/source-cost-crossfit-20261026'
started=time.monotonic()
d=json.loads(gzip.decompress((root/'artifacts/engine-resource-pair-2026-10-25/full7808-20261026T004621Z/native/capture.json.gz').read_bytes()))
candidates=d['batch']['candidates'];results=d['results']
assert len(results)==len(candidates)==7808 and all(c['id']==r['id']for c,r in zip(candidates,results))
assert not any(r['cached']or r['coalesced']for r in results)
tasks=sorted({c['task_id']for c in candidates});assert len(tasks)==244
groups={t:[i for i,c in enumerate(candidates)if c['task_id']==t]for t in tasks}
assert all(len(v)==32 for v in groups.values())
tokens=['interval_cases','simp_all','simp','nlinarith','linarith','omega','norm_num','decide','rcases','exact','rfl','aesop']
features=['log1p_utf8_bytes','log1p_newlines','semicolon_fanout']+tokens
X=np.array([[math.log1p(len(c['code'].encode())),math.log1p(c['code'].count('\n')),c['code'].count('<;>')]+[len(re.findall(r'\b'+re.escape(t)+r'\b',c['code']))for t in tokens]for c in candidates],dtype=float)
y=np.array([r['outcome']['status']=='accepted'for r in results],dtype=float)
cost=np.array([sum(a['elapsed_seconds']for a in r['attempts'])for r in results],dtype=float)
assert np.isfinite(X).all()and np.isfinite(cost).all()and(cost>=0).all()
foldof={t:i%5 for i,t in enumerate(tasks)};folds=np.array([foldof[c['task_id']]for c in candidates])
scores=np.full(len(candidates),np.nan);prob=np.full_like(scores,np.nan);predcost=np.full_like(scores,np.nan);models=[]
def sigmoid(z):return 1/(1+np.exp(-np.clip(z,-35,35)))
for fold in range(5):
 train=folds!=fold;test=~train
 mean=X[train].mean(axis=0);scale=X[train].std(axis=0);scale[scale==0]=1
 A=np.column_stack([np.ones(train.sum()),(X[train]-mean)/scale])
 B=np.column_stack([np.ones(test.sum()),(X[test]-mean)/scale])
 penalty=np.eye(A.shape[1]);penalty[0,0]=0
 beta=np.zeros(A.shape[1]);converged=False
 for iteration in range(100):
  p=sigmoid(A@beta);w=np.maximum(p*(1-p),1e-12)
  gradient=A.T@(p-y[train])+penalty@beta
  hessian=A.T@(w[:,None]*A)+penalty
  delta=np.linalg.solve(hessian,gradient);beta-=delta
  if np.max(np.abs(delta))<1e-8:converged=True;break
 assert converged,('logistic did not converge',fold)
 gamma=np.linalg.solve(A.T@A+penalty,A.T@cost[train])
 p=sigmoid(B@beta);seconds=np.maximum(0,B@gamma)
 prob[test]=p;predcost[test]=seconds;scores[test]=p/(1+seconds)
 models.append(dict(fold=fold,train_tasks=int(sum(foldof[t]!=fold for t in tasks)),heldout_tasks=[t for t in tasks if foldof[t]==fold],
  train_sources=int(train.sum()),heldout_sources=int(test.sum()),feature_mean=mean.tolist(),feature_scale=scale.tolist(),
  logistic_coefficients=beta.tolist(),cost_ridge_coefficients=gamma.tolist(),logistic_iterations=iteration+1,converged=converged))
assert np.isfinite(scores).all()
per_task=[]
for task,ids in groups.items():
 accepted=[i for i in ids if y[i]]
 orders=dict(fifo=ids,source_bytes=sorted(ids,key=lambda i:(len(candidates[i]['code'].encode()),i)),
  source_cost_crossfit=sorted(ids,key=lambda i:(-scores[i],i)))
 # Future-outcome-informed cost oracle minimizes serial work for a known solvable task.
 orders['outcome_oracle']=sorted(ids,key=lambda i:(0 if y[i]else 1,cost[i],i))
 row=dict(task_id=task,fold=foldof[task],observed_solvable=bool(accepted),accepted_sources=len(accepted),policies={})
 for policy,order in orders.items():
  work=0;checked=0;winner=None
  for i in order:
   work+=float(cost[i]);checked+=1
   if y[i]:winner=candidates[i]['id'];break
  assert bool(winner)==bool(accepted)
  row['policies'][policy]=dict(frozen_attempt_seconds=work,candidates_checked=checked,first_id=candidates[order[0]]['id'],first_observed_accepted=bool(y[order[0]]),winner=winner)
 per_task.append(row)
summary={}
for policy in ['fifo','source_bytes','source_cost_crossfit','outcome_oracle']:
 allwork=sum(x['policies'][policy]['frozen_attempt_seconds']for x in per_task)
 solved=[x for x in per_task if x['observed_solvable']]
 summary[policy]=dict(tasks=len(per_task),observed_solved_tasks=len(solved),all_task_frozen_work_seconds=allwork,
  solved_task_frozen_work_seconds=sum(x['policies'][policy]['frozen_attempt_seconds']for x in solved),
  unsolved_task_frozen_work_seconds=allwork-sum(x['policies'][policy]['frozen_attempt_seconds']for x in solved),
  candidates_checked=sum(x['policies'][policy]['candidates_checked']for x in per_task),
  first_source_observed_accepted=sum(x['policies'][policy]['first_observed_accepted']for x in per_task))
baseline=summary['fifo']['all_task_frozen_work_seconds']
for v in summary.values():v['fifo_over_policy_frozen_work_ratio']=baseline/v['all_task_frozen_work_seconds']
output=dict(sources=7808,tasks=244,folds=5,features=features,regularization=1,
 target='checked acceptance and observed summed attempt elapsed within existing finite-resource native capture;not theorem truth or unobserved uncensored runtime',
 score='P(checked acceptance)/(1+max(0,ridge predicted observed seconds))',policies=summary,
 analysis_seconds=time.monotonic()-started,native_proof_executions=0,measured_runtime_speedup=None,
 caveat='Frozen serial work only. Originalconcurrency/preemptions/censored timeouts/cleanup are fixed;reordering can change them. No actual admission/cancellation/service latency or parity measurement.')
(out/'result.json').write_text(json.dumps(output,indent=2)+'\n')
(out/'models.json.gz').write_bytes(gzip.compress((json.dumps(dict(features=features,models=models),indent=2)+'\n').encode(),mtime=0))
(out/'per-task.json.gz').write_bytes(gzip.compress((json.dumps(per_task,indent=2)+'\n').encode(),mtime=0))
predictions=[dict(id=c['id'],task_id=c['task_id'],heldout_fold=int(folds[i]),probability=float(prob[i]),predicted_attempt_seconds=float(predcost[i]),score=float(scores[i]),observed_status=results[i]['outcome']['status'],observed_attempt_seconds=float(cost[i]))for i,c in enumerate(candidates)]
(out/'predictions.jsonl.gz').write_bytes(gzip.compress(''.join(json.dumps(x)+'\n'for x in predictions).encode(),mtime=0))
print(json.dumps(output),flush=True)
