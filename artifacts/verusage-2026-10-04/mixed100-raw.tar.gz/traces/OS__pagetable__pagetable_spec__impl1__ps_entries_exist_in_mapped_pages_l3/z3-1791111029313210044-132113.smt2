(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!std_specs.option.impl&%0.is_Some. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.get_Some_0. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.is_None. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.arrow_0. FuelId)
(declare-const fuel%vstd!std_specs.option.is_some. FuelId)
(declare-const fuel%vstd!std_specs.option.is_none. FuelId)
(declare-const fuel%vstd!std_specs.option.spec_unwrap. FuelId)
(declare-const fuel%vstd!array.array_view. FuelId)
(declare-const fuel%vstd!array.impl&%0.view. FuelId)
(declare-const fuel%vstd!array.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!array.lemma_array_index. FuelId)
(declare-const fuel%vstd!array.array_len_matches_n. FuelId)
(declare-const fuel%vstd!array.axiom_array_ext_equal. FuelId)
(declare-const fuel%vstd!array.axiom_array_has_resolved. FuelId)
(declare-const fuel%vstd!array.axiom_array_decreases_to_seq. FuelId)
(declare-const fuel%vstd!array.lemma_array_index_decreases. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.axiom_map_decreases_to_entry. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!pervasive.strictly_cloned. FuelId)
(declare-const fuel%vstd!pervasive.cloned. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%1.arrow_0. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%6.is_init. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%6.value. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!set.lemma_set_empty. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_same. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_different. FuelId)
(declare-const fuel%vstd!simple_pptr.impl&%1.is_init. FuelId)
(declare-const fuel%vstd!simple_pptr.impl&%1.value. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%14.view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%26.view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%vstd!view.impl&%36.view. FuelId)
(declare-const fuel%vstd!view.impl&%46.view. FuelId)
(declare-const fuel%vstd!view.impl&%48.view. FuelId)
(declare-const fuel%vstd!view.impl&%50.view. FuelId)
(declare-const fuel%vstd!view.impl&%52.view. FuelId)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.
 FuelId
)
(declare-const fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!std_specs.option.impl&%0.is_Some. fuel%vstd!std_specs.option.impl&%0.get_Some_0.
  fuel%vstd!std_specs.option.impl&%0.is_None. fuel%vstd!std_specs.option.impl&%0.arrow_0.
  fuel%vstd!std_specs.option.is_some. fuel%vstd!std_specs.option.is_none. fuel%vstd!std_specs.option.spec_unwrap.
  fuel%vstd!array.array_view. fuel%vstd!array.impl&%0.view. fuel%vstd!array.impl&%2.spec_index.
  fuel%vstd!array.lemma_array_index. fuel%vstd!array.array_len_matches_n. fuel%vstd!array.axiom_array_ext_equal.
  fuel%vstd!array.axiom_array_has_resolved. fuel%vstd!array.axiom_array_decreases_to_seq.
  fuel%vstd!array.lemma_array_index_decreases. fuel%vstd!function.axiom_fn_mut_call_requires.
  fuel%vstd!function.axiom_fn_mut_call_ensures. fuel%vstd!iset.lemma_iset_ext_equal.
  fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index. fuel%vstd!map.axiom_map_index_decreases.
  fuel%vstd!map.axiom_map_decreases_to_entry. fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep.
  fuel%vstd!pervasive.strictly_cloned. fuel%vstd!pervasive.cloned. fuel%vstd!raw_ptr.impl&%1.arrow_0.
  fuel%vstd!raw_ptr.impl&%6.is_init. fuel%vstd!raw_ptr.impl&%6.value. fuel%vstd!seq.impl&%2.spec_index.
  fuel%vstd!seq.lemma_seq_index_decreases. fuel%vstd!seq.lemma_seq_new_len. fuel%vstd!seq.lemma_seq_new_index.
  fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep. fuel%vstd!set.Set.contains.
  fuel%vstd!set.axiom_set_ext_equal. fuel%vstd!set.axiom_set_ext_equal_deep. fuel%vstd!set.axiom_set_decreases_to_member.
  fuel%vstd!set.lemma_set_empty. fuel%vstd!set.lemma_set_insert_same. fuel%vstd!set.lemma_set_insert_different.
  fuel%vstd!simple_pptr.impl&%1.is_init. fuel%vstd!simple_pptr.impl&%1.value. fuel%vstd!view.impl&%0.view.
  fuel%vstd!view.impl&%2.view. fuel%vstd!view.impl&%4.view. fuel%vstd!view.impl&%6.view.
  fuel%vstd!view.impl&%14.view. fuel%vstd!view.impl&%16.view. fuel%vstd!view.impl&%18.view.
  fuel%vstd!view.impl&%26.view. fuel%vstd!view.impl&%30.view. fuel%vstd!view.impl&%36.view.
  fuel%vstd!view.impl&%46.view. fuel%vstd!view.impl&%48.view. fuel%vstd!view.impl&%50.view.
  fuel%vstd!view.impl&%52.view. fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.
  fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!array.group_array_axioms.)
  (and
   (fuel_bool_default fuel%vstd!array.array_len_matches_n.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index.)
   (fuel_bool_default fuel%vstd!array.axiom_array_ext_equal.)
   (fuel_bool_default fuel%vstd!array.axiom_array_has_resolved.)
   (fuel_bool_default fuel%vstd!array.axiom_array_decreases_to_seq.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index_decreases.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.axiom_map_decreases_to_entry.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
   (fuel_bool_default fuel%vstd!set.lemma_set_empty.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_same.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_different.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%vstd!array.ArrayAdditionalSpecFns. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%core!clone.Clone. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Copy. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.option.OptionAdditionalFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-sort alloc!alloc.Global. 0)
(declare-sort vstd!map.Map<usize./usize.>. 0)
(declare-sort vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
 0
)
(declare-sort vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
 0
)
(declare-sort vstd!map.Map<usize./tuple%2<usize./usize.>.>. 0)
(declare-sort vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. 0)
(declare-sort vstd!seq.Seq<usize.>. 0)
(declare-sort vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
 0
)
(declare-sort vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
 0
)
(declare-sort vstd!set.Set<usize.>. 0)
(declare-sort vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
 0
)
(declare-datatypes ((core!option.Option. 0) (vstd!raw_ptr.MemContents. 0) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
   0
  ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
   0
  ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
   0
  ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
   0
  ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
   0
  ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
   0
  ) (tuple%0. 0) (tuple%1. 0) (tuple%2. 0) (tuple%3. 0) (tuple%4. 0)
 ) (((core!option.Option./None) (core!option.Option./Some (core!option.Option./Some/?0
     Poly
   ))
  ) ((vstd!raw_ptr.MemContents./Uninit) (vstd!raw_ptr.MemContents./Init (vstd!raw_ptr.MemContents./Init/?0
     Poly
   ))
  ) ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap
    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/?ar
     OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/?spec_seq
     vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
   ))
  ) ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm
    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?present
     Bool
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?ps
     Bool
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?write
     Bool
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?execute_disable
     Bool
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?user
     Bool
   ))
  ) ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry
    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/?addr
     Int
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/?perm
     OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
   ))
  ) ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry
    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/?addr
     Int
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/?write
     Bool
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/?execute_disable
     Bool
   ))
  ) ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable
    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?cr3
     Int
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?pcid
     core!option.Option.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?ioid
     core!option.Option.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?kernel_l4_end
     Int
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l4_table
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l3_rev_map
     vstd!map.Map<usize./usize.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l3_tables
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l2_rev_map
     vstd!map.Map<usize./tuple%2<usize./usize.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l2_tables
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l1_rev_map
     vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l1_tables
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?mapping_4k
     vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?mapping_2m
     vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?mapping_1g
     vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?kernel_entries
     vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?tlb_mapping_4k
     vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?tlb_mapping_2m
     vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?tlb_mapping_1g
     vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
   ))
  ) ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array
    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/?seq
     Poly
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/?ar
     %%Function%%
   ))
  ) ((tuple%0./tuple%0)) ((tuple%1./tuple%1 (tuple%1./tuple%1/?0 Poly))) ((tuple%2./tuple%2
    (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1 Poly)
   )
  ) ((tuple%3./tuple%3 (tuple%3./tuple%3/?0 Poly) (tuple%3./tuple%3/?1 Poly) (tuple%3./tuple%3/?2
     Poly
   ))
  ) ((tuple%4./tuple%4 (tuple%4./tuple%4/?0 Poly) (tuple%4./tuple%4/?1 Poly) (tuple%4./tuple%4/?2
     Poly
    ) (tuple%4./tuple%4/?3 Poly)
))))
(declare-fun core!option.Option./Some/0 (Dcr Type core!option.Option.) Poly)
(declare-fun vstd!raw_ptr.MemContents./Init/0 (Dcr Type vstd!raw_ptr.MemContents.)
 Poly
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
 vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
 Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
 Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
 Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
 Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/user
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
 Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
 Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
 Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/write
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
 Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/execute_disable
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
 Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 core!option.Option.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 core!option.Option.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./usize.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_rev_map
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./tuple%2<usize./usize.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_rev_map
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_4k
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_2m
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_entries
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_4k
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_2m
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_1g
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.)
 Poly
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.)
 %%Function%%
)
(declare-fun tuple%1./tuple%1/0 (tuple%1.) Poly)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-fun tuple%3./tuple%3/0 (tuple%3.) Poly)
(declare-fun tuple%3./tuple%3/1 (tuple%3.) Poly)
(declare-fun tuple%3./tuple%3/2 (tuple%3.) Poly)
(declare-fun tuple%4./tuple%4/0 (tuple%4.) Poly)
(declare-fun tuple%4./tuple%4/1 (tuple%4.) Poly)
(declare-fun tuple%4./tuple%4/2 (tuple%4.) Poly)
(declare-fun tuple%4./tuple%4/3 (tuple%4.) Poly)
(declare-fun TYPE%fun%1. (Dcr Type Dcr Type) Type)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-fun TYPE%core!option.Option. (Dcr Type) Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!raw_ptr.MemContents. (Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-fun TYPE%vstd!simple_pptr.PointsTo. (Dcr Type) Type)
(declare-const TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
 Type
)
(declare-const TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
 Type
)
(declare-const TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
 Type
)
(declare-const TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
 Type
)
(declare-const TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
 Type
)
(declare-fun TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
 (Dcr Type Dcr Type) Type
)
(declare-fun TYPE%tuple%1. (Dcr Type) Type)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%tuple%3. (Dcr Type Dcr Type Dcr Type) Type)
(declare-fun TYPE%tuple%4. (Dcr Type Dcr Type Dcr Type Dcr Type) Type)
(declare-fun FNDEF%core!clone.Clone.clone. (Dcr Type) Type)
(declare-fun Poly%fun%1. (%%Function%%) Poly)
(declare-fun %Poly%fun%1. (Poly) %%Function%%)
(declare-fun Poly%array%. (%%Function%%) Poly)
(declare-fun %Poly%array%. (Poly) %%Function%%)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%vstd!map.Map<usize./usize.>. (vstd!map.Map<usize./usize.>.) Poly)
(declare-fun %Poly%vstd!map.Map<usize./usize.>. (Poly) vstd!map.Map<usize./usize.>.)
(declare-fun Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
 (vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
 (Poly) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
)
(declare-fun Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
 (vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
 (Poly) vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
)
(declare-fun Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>. (vstd!map.Map<usize./tuple%2<usize./usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>. (Poly) vstd!map.Map<usize./tuple%2<usize./usize.>.>.)
(declare-fun Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. (vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. (Poly) vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.)
(declare-fun Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq<usize.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<usize.>. (Poly) vstd!seq.Seq<usize.>.)
(declare-fun Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
 (vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
 (Poly) vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
)
(declare-fun Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
 (vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
 (Poly) vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
)
(declare-fun Poly%vstd!set.Set<usize.>. (vstd!set.Set<usize.>.) Poly)
(declare-fun %Poly%vstd!set.Set<usize.>. (Poly) vstd!set.Set<usize.>.)
(declare-fun Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
 (vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.)
 Poly
)
(declare-fun %Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
 (Poly) vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
)
(declare-fun Poly%core!option.Option. (core!option.Option.) Poly)
(declare-fun %Poly%core!option.Option. (Poly) core!option.Option.)
(declare-fun Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents.) Poly)
(declare-fun %Poly%vstd!raw_ptr.MemContents. (Poly) vstd!raw_ptr.MemContents.)
(declare-fun Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
 Poly
)
(declare-fun %Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
)
(declare-fun Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
 Poly
)
(declare-fun %Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
)
(declare-fun Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
 Poly
)
(declare-fun %Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
)
(declare-fun Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
 Poly
)
(declare-fun %Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
)
(declare-fun Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 Poly
)
(declare-fun %Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
)
(declare-fun Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.)
 Poly
)
(declare-fun %Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%1. (tuple%1.) Poly)
(declare-fun %Poly%tuple%1. (Poly) tuple%1.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(declare-fun Poly%tuple%3. (tuple%3.) Poly)
(declare-fun %Poly%tuple%3. (Poly) tuple%3.)
(declare-fun Poly%tuple%4. (tuple%4.) Poly)
(declare-fun %Poly%tuple%4. (Poly) tuple%4.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%1. (Poly%fun%1. x)))
   :pattern ((Poly%fun%1. x))
   :qid internal_crate__fun__1_box_axiom_definition
   :skolemid skolem_internal_crate__fun__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%fun%1. (%Poly%fun%1. x)))
   )
   :pattern ((has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__1_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x %%Function%%)) (!
   (=>
    (forall ((T%0 Poly)) (!
      (=>
       (has_type T%0 T%0&)
       (has_type (%%apply%%0 x T%0) T%1&)
      )
      :pattern ((has_type (%%apply%%0 x T%0) T%1&))
      :qid internal_crate__fun__1_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__1_constructor_inner_definition
    ))
    (has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_constructor_definition
   :skolemid skolem_internal_crate__fun__1_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (has_type (%%apply%%0 x T%0) T%1&)
   )
   :pattern ((%%apply%%0 x T%0) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&.
      T%1&
   )))
   :qid internal_crate__fun__1_apply_definition
   :skolemid skolem_internal_crate__fun__1_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (height_lt (height (%%apply%%0 x T%0)) (height (fun_from_recursive_field (Poly%fun%1.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0)) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_crate__fun__1_height_apply_definition
   :skolemid skolem_internal_crate__fun__1_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (forall ((T%0 Poly)) (!
       (=>
        (has_type T%0 T%0&)
        (ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1. y) T%0))
       )
       :pattern ((ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1.
           y
          ) T%0
       )))
       :qid internal_crate__fun__1_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__1_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_crate__fun__1_ext_equal_definition
   :skolemid skolem_internal_crate__fun__1_ext_equal_definition
)))
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%array%. (Poly%array%. x)))
   :pattern ((Poly%array%. x))
   :qid internal_crate__array___box_axiom_definition
   :skolemid skolem_internal_crate__array___box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (ARRAY T&. T& N&. N&))
    (= x (Poly%array%. (%Poly%array%. x)))
   )
   :pattern ((has_type x (ARRAY T&. T& N&. N&)))
   :qid internal_crate__array___unbox_axiom_definition
   :skolemid skolem_internal_crate__array___unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./usize.>.)) (!
   (= x (%Poly%vstd!map.Map<usize./usize.>. (Poly%vstd!map.Map<usize./usize.>. x)))
   :pattern ((Poly%vstd!map.Map<usize./usize.>. x))
   :qid internal_vstd__map__Map<usize./usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ USIZE))
    (= x (Poly%vstd!map.Map<usize./usize.>. (%Poly%vstd!map.Map<usize./usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ USIZE)))
   :qid internal_vstd__map__Map<usize./usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./usize.>.)) (!
   (has_type (Poly%vstd!map.Map<usize./usize.>. x) (TYPE%vstd!map.Map. $ USIZE $ USIZE))
   :pattern ((has_type (Poly%vstd!map.Map<usize./usize.>. x) (TYPE%vstd!map.Map. $ USIZE
      $ USIZE
   )))
   :qid internal_vstd__map__Map<usize./usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)))
    (= x (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
      (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
       $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
   ))))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.))
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.))
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
     (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
    (= x (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
      (%Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)))
   :qid internal_vstd__map__Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
   ))
   :qid internal_vstd__map__Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./tuple%2<usize./usize.>.>.)) (!
   (= x (%Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>. (Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>. x))
   :qid internal_vstd__map__Map<usize./tuple__2<usize./usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./tuple__2<usize./usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)))
    (= x (Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>. (%Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))))
   :qid internal_vstd__map__Map<usize./tuple__2<usize./usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./tuple__2<usize./usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./tuple%2<usize./usize.>.>.)) (!
   (has_type (Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>. x) (TYPE%vstd!map.Map.
     $ USIZE (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!map.Map<usize./tuple%2<usize./usize.>.>. x) (TYPE%vstd!map.Map.
      $ USIZE (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   )))
   :qid internal_vstd__map__Map<usize./tuple__2<usize./usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./tuple__2<usize./usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.)) (!
   (= x (%Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. (Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. x))
   :qid internal_vstd__map__Map<usize./tuple__3<usize./usize./usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./tuple__3<usize./usize./usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE (DST $) (TYPE%tuple%3. $ USIZE $ USIZE $ USIZE)))
    (= x (Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. (%Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE (DST $) (TYPE%tuple%3. $ USIZE $ USIZE
       $ USIZE
   ))))
   :qid internal_vstd__map__Map<usize./tuple__3<usize./usize./usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./tuple__3<usize./usize./usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.)) (!
   (has_type (Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. x) (TYPE%vstd!map.Map.
     $ USIZE (DST $) (TYPE%tuple%3. $ USIZE $ USIZE $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>. x) (
      TYPE%vstd!map.Map. $ USIZE (DST $) (TYPE%tuple%3. $ USIZE $ USIZE $ USIZE)
   )))
   :qid internal_vstd__map__Map<usize./tuple__3<usize./usize./usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./tuple__3<usize./usize./usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (= x (%Poly%vstd!seq.Seq<usize.>. (Poly%vstd!seq.Seq<usize.>. x)))
   :pattern ((Poly%vstd!seq.Seq<usize.>. x))
   :qid internal_vstd__seq__Seq<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ USIZE))
    (= x (Poly%vstd!seq.Seq<usize.>. (%Poly%vstd!seq.Seq<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE))
   :pattern ((has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
     (Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
     x
   ))
   :qid internal_vstd__seq__Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)))
    (= x (Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
      (%Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))))
   :qid internal_vstd__seq__Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
     x
    ) (TYPE%vstd!seq.Seq. $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.
      x
     ) (TYPE%vstd!seq.Seq. $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
   ))
   :qid internal_vstd__seq__Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
     (Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
     x
   ))
   :qid internal_vstd__seq__Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.))
    (= x (Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
      (%Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)))
   :qid internal_vstd__seq__Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
     x
    ) (TYPE%vstd!seq.Seq. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
      x
     ) (TYPE%vstd!seq.Seq. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
   ))
   :qid internal_vstd__seq__Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (= x (%Poly%vstd!set.Set<usize.>. (Poly%vstd!set.Set<usize.>. x)))
   :pattern ((Poly%vstd!set.Set<usize.>. x))
   :qid internal_vstd__set__Set<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ USIZE))
    (= x (Poly%vstd!set.Set<usize.>. (%Poly%vstd!set.Set<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE))
   :pattern ((has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.))
  (!
   (= x (%Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
     (Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
      x
   )))
   :pattern ((Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
     x
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>_box_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.))
    (= x (Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
      (%Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)))
   :qid internal_vstd__simple_pptr__PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.))
  (!
   (has_type (Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
     x
    ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
   )
   :pattern ((has_type (Poly%vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.
      x
     ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>_has_type_always_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>_has_type_always_definition
)))
(assert
 (forall ((x core!option.Option.)) (!
   (= x (%Poly%core!option.Option. (Poly%core!option.Option. x)))
   :pattern ((Poly%core!option.Option. x))
   :qid internal_core__option__Option_box_axiom_definition
   :skolemid skolem_internal_core__option__Option_box_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (= x (Poly%core!option.Option. (%Poly%core!option.Option. x)))
   )
   :pattern ((has_type x (TYPE%core!option.Option. V&. V&)))
   :qid internal_core__option__Option_unbox_axiom_definition
   :skolemid skolem_internal_core__option__Option_unbox_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type)) (!
   (has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
     V&. V&
   ))
   :pattern ((has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./None_constructor_definition
   :skolemid skolem_internal_core!option.Option./None_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (_0! Poly)) (!
   (=>
    (has_type _0! V&)
    (has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :pattern ((has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./Some_constructor_definition
   :skolemid skolem_internal_core!option.Option./Some_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (= (core!option.Option./Some/0 V&. V& x) (core!option.Option./Some/?0 x))
   )
   :pattern ((core!option.Option./Some/0 V&. V& x))
   :qid internal_core!option.Option./Some/0_accessor_definition
   :skolemid skolem_internal_core!option.Option./Some/0_accessor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (has_type (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) V&)
   )
   :pattern ((core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) (has_type
     x (TYPE%core!option.Option. V&. V&)
   ))
   :qid internal_core!option.Option./Some/0_invariant_definition
   :skolemid skolem_internal_core!option.Option./Some/0_invariant_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (height_lt (height (core!option.Option./Some/0 V&. V& x)) (height (Poly%core!option.Option.
       x
   ))))
   :pattern ((height (core!option.Option./Some/0 V&. V& x)))
   :qid prelude_datatype_height_core!option.Option./Some/0
   :skolemid skolem_prelude_datatype_height_core!option.Option./Some/0
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./None (%Poly%core!option.Option. x))
     (is-core!option.Option./None (%Poly%core!option.Option. y))
    )
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./None_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./None_ext_equal_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./Some (%Poly%core!option.Option. x))
     (is-core!option.Option./Some (%Poly%core!option.Option. y))
     (ext_eq deep V& (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x))
      (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. y))
    ))
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./Some_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./Some_ext_equal_definition
)))
(assert
 (forall ((x vstd!raw_ptr.MemContents.)) (!
   (= x (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. x)))
   :pattern ((Poly%vstd!raw_ptr.MemContents. x))
   :qid internal_vstd__raw_ptr__MemContents_box_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__MemContents_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (= x (Poly%vstd!raw_ptr.MemContents. (%Poly%vstd!raw_ptr.MemContents. x)))
   )
   :pattern ((has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&)))
   :qid internal_vstd__raw_ptr__MemContents_unbox_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__MemContents_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (has_type (Poly%vstd!raw_ptr.MemContents. vstd!raw_ptr.MemContents./Uninit) (TYPE%vstd!raw_ptr.MemContents.
     T&. T&
   ))
   :pattern ((has_type (Poly%vstd!raw_ptr.MemContents. vstd!raw_ptr.MemContents./Uninit)
     (TYPE%vstd!raw_ptr.MemContents. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.MemContents./Uninit_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Uninit_constructor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T&)
    (has_type (Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents./Init _0!)) (TYPE%vstd!raw_ptr.MemContents.
      T&. T&
   )))
   :pattern ((has_type (Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents./Init _0!))
     (TYPE%vstd!raw_ptr.MemContents. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.MemContents./Init_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init_constructor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x vstd!raw_ptr.MemContents.)) (!
   (=>
    (is-vstd!raw_ptr.MemContents./Init x)
    (= (vstd!raw_ptr.MemContents./Init/0 T&. T& x) (vstd!raw_ptr.MemContents./Init/?0 x))
   )
   :pattern ((vstd!raw_ptr.MemContents./Init/0 T&. T& x))
   :qid internal_vstd!raw_ptr.MemContents./Init/0_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init/0_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (has_type (vstd!raw_ptr.MemContents./Init/0 T&. T& (%Poly%vstd!raw_ptr.MemContents.
       x
      )
     ) T&
   ))
   :pattern ((vstd!raw_ptr.MemContents./Init/0 T&. T& (%Poly%vstd!raw_ptr.MemContents.
      x
     )
    ) (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
   )
   :qid internal_vstd!raw_ptr.MemContents./Init/0_invariant_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init/0_invariant_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x vstd!raw_ptr.MemContents.)) (!
   (=>
    (is-vstd!raw_ptr.MemContents./Init x)
    (height_lt (height (vstd!raw_ptr.MemContents./Init/0 T&. T& x)) (height (Poly%vstd!raw_ptr.MemContents.
       x
   ))))
   :pattern ((height (vstd!raw_ptr.MemContents./Init/0 T&. T& x)))
   :qid prelude_datatype_height_vstd!raw_ptr.MemContents./Init/0
   :skolemid skolem_prelude_datatype_height_vstd!raw_ptr.MemContents./Init/0
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.))
  (!
   (= x (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
     (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
      x
   )))
   :pattern ((Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageMap_box_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageMap_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
    (= x (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
       x
   ))))
   :pattern ((has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageMap_unbox_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageMap_unbox_axiom_definition
)))
(assert
 (forall ((_ar! OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.)
   (_spec_seq! vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.)
  ) (!
   (=>
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      _ar!
     ) (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      $ USIZE $ (CONST_INT 512)
    ))
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap
       _ar! _spec_seq!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
   ))
   :pattern ((has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap
       _ar! _spec_seq!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap_constructor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap_constructor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/?ar
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
        x
      ))
     ) (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      $ USIZE $ (CONST_INT 512)
   )))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
      x
     )
    ) (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
   )
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/?spec_seq
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (= x (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
     (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
      x
   )))
   :pattern ((Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntryPerm_box_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntryPerm_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
    (= x (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
       x
   ))))
   :pattern ((has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntryPerm_unbox_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntryPerm_unbox_axiom_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?present
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?ps
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?write
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?execute_disable
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/user
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/?user
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/user
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/user_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/user_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
     x
    ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
   )
   :pattern ((has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
      x
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntryPerm_has_type_always_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntryPerm_has_type_always_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.))
  (!
   (= x (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
     (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      x
   )))
   :pattern ((Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntry_box_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntry_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
    (= x (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
       x
   ))))
   :pattern ((has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntry_unbox_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageEntry_unbox_axiom_definition
)))
(assert
 (forall ((_addr! Int) (_perm! OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (=>
    (uInv SZ _addr!)
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry
       _addr! _perm!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
   ))
   :pattern ((has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry
       _addr! _perm!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry_constructor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry_constructor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/?addr
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
    (uInv SZ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
       x
   ))))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      x
     )
    ) (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
   )
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/?perm
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
  (!
   (= x (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
     (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
      x
   )))
   :pattern ((Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__MapEntry_box_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__MapEntry_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
    (= x (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
       x
   ))))
   :pattern ((has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__MapEntry_unbox_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__MapEntry_unbox_axiom_definition
)))
(assert
 (forall ((_addr! Int) (_write! Bool) (_execute_disable! Bool)) (!
   (=>
    (uInv SZ _addr!)
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry
       _addr! _write! _execute_disable!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
   ))
   :pattern ((has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry
       _addr! _write! _execute_disable!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry_constructor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry_constructor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/?addr
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
    (uInv SZ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
       x
   ))))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
      x
     )
    ) (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.)
   )
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/write
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/?write
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/write
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/write_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/write_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/execute_disable
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/?execute_disable
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/execute_disable
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/execute_disable_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/execute_disable_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= x (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
     (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      x
   )))
   :pattern ((Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable_box_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
    (= x (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
       x
   ))))
   :pattern ((has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable_unbox_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable_unbox_axiom_definition
)))
(assert
 (forall ((_cr3! Int) (_pcid! core!option.Option.) (_ioid! core!option.Option.) (_kernel_l4_end!
    Int
   ) (_l4_table! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.)
   (_l3_rev_map! vstd!map.Map<usize./usize.>.) (_l3_tables! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.)
   (_l2_rev_map! vstd!map.Map<usize./tuple%2<usize./usize.>.>.) (_l2_tables! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.)
   (_l1_rev_map! vstd!map.Map<usize./tuple%3<usize./usize./usize.>.>.) (_l1_tables! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.)
   (_mapping_4k! vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.)
   (_mapping_2m! vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.)
   (_mapping_1g! vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.)
   (_kernel_entries! vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.)
   (_tlb_mapping_4k! vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.)
   (_tlb_mapping_2m! vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.)
   (_tlb_mapping_1g! vstd!seq.Seq<vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.>.)
  ) (!
   (=>
    (and
     (uInv SZ _cr3!)
     (has_type (Poly%core!option.Option. _pcid!) (TYPE%core!option.Option. $ USIZE))
     (has_type (Poly%core!option.Option. _ioid!) (TYPE%core!option.Option. $ USIZE))
     (uInv SZ _kernel_l4_end!)
    )
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable
       _cr3! _pcid! _ioid! _kernel_l4_end! _l4_table! _l3_rev_map! _l3_tables! _l2_rev_map!
       _l2_tables! _l1_rev_map! _l1_tables! _mapping_4k! _mapping_2m! _mapping_1g! _kernel_entries!
       _tlb_mapping_4k! _tlb_mapping_2m! _tlb_mapping_1g!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
   ))
   :pattern ((has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable
       _cr3! _pcid! _ioid! _kernel_l4_end! _l4_table! _l3_rev_map! _l3_tables! _l2_rev_map!
       _l2_tables! _l1_rev_map! _l1_tables! _mapping_4k! _mapping_2m! _mapping_1g! _kernel_entries!
       _tlb_mapping_4k! _tlb_mapping_2m! _tlb_mapping_1g!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable_constructor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable_constructor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?cr3
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
    (uInv SZ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
       x
   ))))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      x
     )
    ) (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
   )
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?pcid
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
    (has_type (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid
       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
        x
      ))
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      x
     )
    ) (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
   )
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/pcid_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?ioid
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
    (has_type (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid
       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
        x
      ))
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      x
     )
    ) (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
   )
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/ioid_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?kernel_l4_end
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
    (uInv SZ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
       x
   ))))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
      x
     )
    ) (has_type x TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
   )
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l4_table
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l3_rev_map
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l3_tables
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_rev_map
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l2_rev_map
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_rev_map
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_rev_map_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_rev_map_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l2_tables
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_rev_map
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l1_rev_map
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_rev_map
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_rev_map_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_rev_map_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?l1_tables
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_4k
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?mapping_4k
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_4k
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_4k_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_4k_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_2m
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?mapping_2m
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_2m
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_2m_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_2m_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?mapping_1g
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_entries
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?kernel_entries
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_entries
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_entries_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_entries_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_4k
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?tlb_mapping_4k
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_4k
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_4k_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_4k_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_2m
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?tlb_mapping_2m
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_2m
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_2m_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_2m_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_1g
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/?tlb_mapping_1g
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_1g
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_1g_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/tlb_mapping_1g_accessor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.))
  (!
   (= x (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
     (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      x
   )))
   :pattern ((Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__Array_box_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__Array_box_axiom_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
    ))
    (= x (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
       x
   ))))
   :pattern ((has_type x (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__Array_unbox_axiom_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__Array_unbox_axiom_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (_seq! Poly) (_ar! %%Function%%))
  (!
   (=>
    (and
     (has_type _seq! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type (Poly%array%. _ar!) (ARRAY A&. A& N&. N&))
    )
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array
       _seq! _ar!
      )
     ) (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
   )))
   :pattern ((has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array
       _seq! _ar!
      )
     ) (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array_constructor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array_constructor_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/?seq
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq_accessor_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
    ))
    (has_type (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
       x
      )
     ) (TYPE%vstd!seq.Seq. A&. A&)
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      x
     )
    ) (has_type x (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.))
  (!
   (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
     x
    ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/?ar
     x
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
     x
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar_accessor_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar_accessor_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
    ))
    (has_type (Poly%array%. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
        x
      ))
     ) (ARRAY A&. A& N&. N&)
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      x
     )
    ) (has_type x (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar_invariant_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar_invariant_definition
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.))
  (!
   (=>
    (is-OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array
     x
    )
    (height_lt (height (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
       x
      )
     ) (height (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
       x
   ))))
   :pattern ((height (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
      x
   )))
   :qid prelude_datatype_height_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
   :skolemid skolem_prelude_datatype_height_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
)))
(assert
 (forall ((x OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.))
  (!
   (=>
    (is-OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array
     x
    )
    (height_lt (height (Poly%array%. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
        x
      ))
     ) (height (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
       x
   ))))
   :pattern ((height (Poly%array%. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
       x
   ))))
   :qid prelude_datatype_height_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
   :skolemid skolem_prelude_datatype_height_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/ar
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= x (%Poly%tuple%1. (Poly%tuple%1. x)))
   :pattern ((Poly%tuple%1. x))
   :qid internal_crate__tuple__1_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (= x (Poly%tuple%1. (%Poly%tuple%1. x)))
   )
   :pattern ((has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__tuple__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T%0&)
    (has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1_constructor_definition
   :skolemid skolem_internal_tuple__1./tuple__1_constructor_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= (tuple%1./tuple%1/0 x) (tuple%1./tuple%1/?0 x))
   :pattern ((tuple%1./tuple%1/0 x))
   :qid internal_tuple__1./tuple__1/0_accessor_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (has_type (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) T%0&)
   )
   :pattern ((tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1/0_invariant_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_invariant_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (=>
    (is-tuple%1./tuple%1 x)
    (height_lt (height (tuple%1./tuple%1/0 x)) (height (Poly%tuple%1. x)))
   )
   :pattern ((height (tuple%1./tuple%1/0 x)))
   :qid prelude_datatype_height_tuple%1./tuple%1/0
   :skolemid skolem_prelude_datatype_height_tuple%1./tuple%1/0
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%tuple%1. T%0&. T%0&))
     (has_type y (TYPE%tuple%1. T%0&. T%0&))
     (ext_eq deep T%0& (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (tuple%1./tuple%1/0 (%Poly%tuple%1.
        y
    ))))
    (ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y))
   :qid internal_tuple__1./tuple__1_ext_equal_definition
   :skolemid skolem_internal_tuple__1./tuple__1_ext_equal_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= x (%Poly%tuple%3. (Poly%tuple%3. x)))
   :pattern ((Poly%tuple%3. x))
   :qid internal_crate__tuple__3_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__3_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (= x (Poly%tuple%3. (%Poly%tuple%3. x)))
   )
   :pattern ((has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&)))
   :qid internal_crate__tuple__3_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__3_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (_0!
    Poly
   ) (_1! Poly) (_2! Poly)
  ) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
     (has_type _2! T%2&)
    )
    (has_type (Poly%tuple%3. (tuple%3./tuple%3 _0! _1! _2!)) (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :pattern ((has_type (Poly%tuple%3. (tuple%3./tuple%3 _0! _1! _2!)) (TYPE%tuple%3. T%0&.
      T%0& T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3_constructor_definition
   :skolemid skolem_internal_tuple__3./tuple__3_constructor_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= (tuple%3./tuple%3/0 x) (tuple%3./tuple%3/?0 x))
   :pattern ((tuple%3./tuple%3/0 x))
   :qid internal_tuple__3./tuple__3/0_accessor_definition
   :skolemid skolem_internal_tuple__3./tuple__3/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (has_type (tuple%3./tuple%3/0 (%Poly%tuple%3. x)) T%0&)
   )
   :pattern ((tuple%3./tuple%3/0 (%Poly%tuple%3. x)) (has_type x (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3/0_invariant_definition
   :skolemid skolem_internal_tuple__3./tuple__3/0_invariant_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= (tuple%3./tuple%3/1 x) (tuple%3./tuple%3/?1 x))
   :pattern ((tuple%3./tuple%3/1 x))
   :qid internal_tuple__3./tuple__3/1_accessor_definition
   :skolemid skolem_internal_tuple__3./tuple__3/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (has_type (tuple%3./tuple%3/1 (%Poly%tuple%3. x)) T%1&)
   )
   :pattern ((tuple%3./tuple%3/1 (%Poly%tuple%3. x)) (has_type x (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3/1_invariant_definition
   :skolemid skolem_internal_tuple__3./tuple__3/1_invariant_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (= (tuple%3./tuple%3/2 x) (tuple%3./tuple%3/?2 x))
   :pattern ((tuple%3./tuple%3/2 x))
   :qid internal_tuple__3./tuple__3/2_accessor_definition
   :skolemid skolem_internal_tuple__3./tuple__3/2_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (has_type (tuple%3./tuple%3/2 (%Poly%tuple%3. x)) T%2&)
   )
   :pattern ((tuple%3./tuple%3/2 (%Poly%tuple%3. x)) (has_type x (TYPE%tuple%3. T%0&. T%0&
      T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_tuple__3./tuple__3/2_invariant_definition
   :skolemid skolem_internal_tuple__3./tuple__3/2_invariant_definition
)))
(assert
 (forall ((x tuple%3.)) (!
   (=>
    (is-tuple%3./tuple%3 x)
    (height_lt (height (tuple%3./tuple%3/0 x)) (height (Poly%tuple%3. x)))
   )
   :pattern ((height (tuple%3./tuple%3/0 x)))
   :qid prelude_datatype_height_tuple%3./tuple%3/0
   :skolemid skolem_prelude_datatype_height_tuple%3./tuple%3/0
)))
(assert
 (forall ((x tuple%3.)) (!
   (=>
    (is-tuple%3./tuple%3 x)
    (height_lt (height (tuple%3./tuple%3/1 x)) (height (Poly%tuple%3. x)))
   )
   :pattern ((height (tuple%3./tuple%3/1 x)))
   :qid prelude_datatype_height_tuple%3./tuple%3/1
   :skolemid skolem_prelude_datatype_height_tuple%3./tuple%3/1
)))
(assert
 (forall ((x tuple%3.)) (!
   (=>
    (is-tuple%3./tuple%3 x)
    (height_lt (height (tuple%3./tuple%3/2 x)) (height (Poly%tuple%3. x)))
   )
   :pattern ((height (tuple%3./tuple%3/2 x)))
   :qid prelude_datatype_height_tuple%3./tuple%3/2
   :skolemid skolem_prelude_datatype_height_tuple%3./tuple%3/2
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (deep
    Bool
   ) (x Poly) (y Poly)
  ) (!
   (=>
    (and
     (has_type x (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type y (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (ext_eq deep T%0& (tuple%3./tuple%3/0 (%Poly%tuple%3. x)) (tuple%3./tuple%3/0 (%Poly%tuple%3.
        y
     )))
     (ext_eq deep T%1& (tuple%3./tuple%3/1 (%Poly%tuple%3. x)) (tuple%3./tuple%3/1 (%Poly%tuple%3.
        y
     )))
     (ext_eq deep T%2& (tuple%3./tuple%3/2 (%Poly%tuple%3. x)) (tuple%3./tuple%3/2 (%Poly%tuple%3.
        y
    ))))
    (ext_eq deep (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y))
   :qid internal_tuple__3./tuple__3_ext_equal_definition
   :skolemid skolem_internal_tuple__3./tuple__3_ext_equal_definition
)))
(assert
 (forall ((x tuple%4.)) (!
   (= x (%Poly%tuple%4. (Poly%tuple%4. x)))
   :pattern ((Poly%tuple%4. x))
   :qid internal_crate__tuple__4_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__4_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type) (x Poly)
  ) (!
   (=>
    (has_type x (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&))
    (= x (Poly%tuple%4. (%Poly%tuple%4. x)))
   )
   :pattern ((has_type x (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&)))
   :qid internal_crate__tuple__4_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__4_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type) (_0! Poly) (_1! Poly) (_2! Poly) (_3! Poly)
  ) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
     (has_type _2! T%2&)
     (has_type _3! T%3&)
    )
    (has_type (Poly%tuple%4. (tuple%4./tuple%4 _0! _1! _2! _3!)) (TYPE%tuple%4. T%0&. T%0&
      T%1&. T%1& T%2&. T%2& T%3&. T%3&
   )))
   :pattern ((has_type (Poly%tuple%4. (tuple%4./tuple%4 _0! _1! _2! _3!)) (TYPE%tuple%4.
      T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_tuple__4./tuple__4_constructor_definition
   :skolemid skolem_internal_tuple__4./tuple__4_constructor_definition
)))
(assert
 (forall ((x tuple%4.)) (!
   (= (tuple%4./tuple%4/0 x) (tuple%4./tuple%4/?0 x))
   :pattern ((tuple%4./tuple%4/0 x))
   :qid internal_tuple__4./tuple__4/0_accessor_definition
   :skolemid skolem_internal_tuple__4./tuple__4/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type) (x Poly)
  ) (!
   (=>
    (has_type x (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&))
    (has_type (tuple%4./tuple%4/0 (%Poly%tuple%4. x)) T%0&)
   )
   :pattern ((tuple%4./tuple%4/0 (%Poly%tuple%4. x)) (has_type x (TYPE%tuple%4. T%0&. T%0&
      T%1&. T%1& T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_tuple__4./tuple__4/0_invariant_definition
   :skolemid skolem_internal_tuple__4./tuple__4/0_invariant_definition
)))
(assert
 (forall ((x tuple%4.)) (!
   (= (tuple%4./tuple%4/1 x) (tuple%4./tuple%4/?1 x))
   :pattern ((tuple%4./tuple%4/1 x))
   :qid internal_tuple__4./tuple__4/1_accessor_definition
   :skolemid skolem_internal_tuple__4./tuple__4/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type) (x Poly)
  ) (!
   (=>
    (has_type x (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&))
    (has_type (tuple%4./tuple%4/1 (%Poly%tuple%4. x)) T%1&)
   )
   :pattern ((tuple%4./tuple%4/1 (%Poly%tuple%4. x)) (has_type x (TYPE%tuple%4. T%0&. T%0&
      T%1&. T%1& T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_tuple__4./tuple__4/1_invariant_definition
   :skolemid skolem_internal_tuple__4./tuple__4/1_invariant_definition
)))
(assert
 (forall ((x tuple%4.)) (!
   (= (tuple%4./tuple%4/2 x) (tuple%4./tuple%4/?2 x))
   :pattern ((tuple%4./tuple%4/2 x))
   :qid internal_tuple__4./tuple__4/2_accessor_definition
   :skolemid skolem_internal_tuple__4./tuple__4/2_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type) (x Poly)
  ) (!
   (=>
    (has_type x (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&))
    (has_type (tuple%4./tuple%4/2 (%Poly%tuple%4. x)) T%2&)
   )
   :pattern ((tuple%4./tuple%4/2 (%Poly%tuple%4. x)) (has_type x (TYPE%tuple%4. T%0&. T%0&
      T%1&. T%1& T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_tuple__4./tuple__4/2_invariant_definition
   :skolemid skolem_internal_tuple__4./tuple__4/2_invariant_definition
)))
(assert
 (forall ((x tuple%4.)) (!
   (= (tuple%4./tuple%4/3 x) (tuple%4./tuple%4/?3 x))
   :pattern ((tuple%4./tuple%4/3 x))
   :qid internal_tuple__4./tuple__4/3_accessor_definition
   :skolemid skolem_internal_tuple__4./tuple__4/3_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type) (x Poly)
  ) (!
   (=>
    (has_type x (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&))
    (has_type (tuple%4./tuple%4/3 (%Poly%tuple%4. x)) T%3&)
   )
   :pattern ((tuple%4./tuple%4/3 (%Poly%tuple%4. x)) (has_type x (TYPE%tuple%4. T%0&. T%0&
      T%1&. T%1& T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_tuple__4./tuple__4/3_invariant_definition
   :skolemid skolem_internal_tuple__4./tuple__4/3_invariant_definition
)))
(assert
 (forall ((x tuple%4.)) (!
   (=>
    (is-tuple%4./tuple%4 x)
    (height_lt (height (tuple%4./tuple%4/0 x)) (height (Poly%tuple%4. x)))
   )
   :pattern ((height (tuple%4./tuple%4/0 x)))
   :qid prelude_datatype_height_tuple%4./tuple%4/0
   :skolemid skolem_prelude_datatype_height_tuple%4./tuple%4/0
)))
(assert
 (forall ((x tuple%4.)) (!
   (=>
    (is-tuple%4./tuple%4 x)
    (height_lt (height (tuple%4./tuple%4/1 x)) (height (Poly%tuple%4. x)))
   )
   :pattern ((height (tuple%4./tuple%4/1 x)))
   :qid prelude_datatype_height_tuple%4./tuple%4/1
   :skolemid skolem_prelude_datatype_height_tuple%4./tuple%4/1
)))
(assert
 (forall ((x tuple%4.)) (!
   (=>
    (is-tuple%4./tuple%4 x)
    (height_lt (height (tuple%4./tuple%4/2 x)) (height (Poly%tuple%4. x)))
   )
   :pattern ((height (tuple%4./tuple%4/2 x)))
   :qid prelude_datatype_height_tuple%4./tuple%4/2
   :skolemid skolem_prelude_datatype_height_tuple%4./tuple%4/2
)))
(assert
 (forall ((x tuple%4.)) (!
   (=>
    (is-tuple%4./tuple%4 x)
    (height_lt (height (tuple%4./tuple%4/3 x)) (height (Poly%tuple%4. x)))
   )
   :pattern ((height (tuple%4./tuple%4/3 x)))
   :qid prelude_datatype_height_tuple%4./tuple%4/3
   :skolemid skolem_prelude_datatype_height_tuple%4./tuple%4/3
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type) (deep Bool) (x Poly) (y Poly)
  ) (!
   (=>
    (and
     (has_type x (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&))
     (has_type y (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&))
     (ext_eq deep T%0& (tuple%4./tuple%4/0 (%Poly%tuple%4. x)) (tuple%4./tuple%4/0 (%Poly%tuple%4.
        y
     )))
     (ext_eq deep T%1& (tuple%4./tuple%4/1 (%Poly%tuple%4. x)) (tuple%4./tuple%4/1 (%Poly%tuple%4.
        y
     )))
     (ext_eq deep T%2& (tuple%4./tuple%4/2 (%Poly%tuple%4. x)) (tuple%4./tuple%4/2 (%Poly%tuple%4.
        y
     )))
     (ext_eq deep T%3& (tuple%4./tuple%4/3 (%Poly%tuple%4. x)) (tuple%4./tuple%4/3 (%Poly%tuple%4.
        y
    ))))
    (ext_eq deep (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&. T%2& T%3&. T%3&)
     x y
   ))
   :qid internal_tuple__4./tuple__4_ext_equal_definition
   :skolemid skolem_internal_tuple__4./tuple__4_ext_equal_definition
)))
(declare-fun array_new (Dcr Type Int %%Function%%) Poly)
(declare-fun array_index (Dcr Type Dcr Type %%Function%% Poly) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (= (array_new Tdcr T N Fn) (Poly%array%. Fn))
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_array_new
   :skolemid skolem_prelude_array_new
)))
(declare-fun %%apply%%1 (%%Function%% Int) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (=>
    (forall ((i Int)) (!
      (=>
       (and
        (<= 0 i)
        (< i N)
       )
       (has_type (%%apply%%1 Fn i) T)
      )
      :pattern ((has_type (%%apply%%1 Fn i) T))
      :qid prelude_has_type_array_elts
      :skolemid skolem_prelude_has_type_array_elts
    ))
    (has_type (array_new Tdcr T N Fn) (ARRAY Tdcr T $ (CONST_INT N)))
   )
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_has_type_array_new
   :skolemid skolem_prelude_has_type_array_new
)))
(assert
 (forall ((Tdcr Dcr) (T Type) (Nd Dcr) (Ndcr Dcr) (N Type) (Fn %%Function%%) (i Poly))
  (!
   (=>
    (and
     (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr N))
     (has_type i INT)
    )
    (has_type (array_index Tdcr T Nd N Fn i) T)
   )
   :pattern ((array_index Tdcr T Nd N Fn i) (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr
      N
   )))
   :qid prelude_has_type_array_index
   :skolemid skolem_prelude_has_type_array_index
)))
(assert
 (!
  (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%) (i Int)) (!
    (= (array_index Tdcr T $ (CONST_INT N) Fn (I i)) (%%apply%%1 Fn i))
    :pattern ((array_new Tdcr T N Fn) (%%apply%%1 Fn i))
    :qid prelude_array_index_trigger
    :skolemid skolem_prelude_array_index_trigger
  ))
  :named
  prelude_axiom_array_index
))
(assert
 (forall ((x fndef) (Self%&. Dcr) (Self%& Type)) (!
   (has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&))
   :pattern ((has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&)))
   :qid prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
   :skolemid skolem_prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%core!clone.Clone. Self%&. Self%&))
   :qid internal_core__clone__Clone_trait_type_bounds_definition
   :skolemid skolem_internal_core__clone__Clone_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. Self%&. Self%&)
    (tr_bound%core!clone.Clone. Self%&. Self%&)
   )
   :pattern ((tr_bound%core!marker.Copy. Self%&. Self%&))
   :qid internal_core__marker__Copy_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Copy_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&)
    (and
     (sized Self%&.)
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) (TYPE%core!option.Option.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 64)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 64)) (UINT 64))
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 32)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 32)) (SINT 32))
)
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (DST (proj%%vstd!view.View./V
       A0&. A0&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (TYPE%tuple%1. (proj%%vstd!view.View./V
       A0&. A0&
      ) (proj%vstd!view.View./V A0&. A0&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST (proj%%vstd!view.View./V
       A1&. A1&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&) (proj%%vstd!view.View./V
       A1&. A1&
      ) (proj%vstd!view.View./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
    )
    (= (proj%%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
     (DST (proj%%vstd!view.View./V A2&. A2&))
   ))
   :pattern ((proj%%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&.
      A2&
   )))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
    )
    (= (proj%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
     (TYPE%tuple%3. (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&)
      (proj%%vstd!view.View./V A1&. A1&) (proj%vstd!view.View./V A1&. A1&) (proj%%vstd!view.View./V
       A2&. A2&
      ) (proj%vstd!view.View./V A2&. A2&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__50_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type) (A3&. Dcr)
   (A3& Type)
  ) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (sized A3&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
     (tr_bound%vstd!view.View. A3&. A3&)
    )
    (= (proj%%vstd!view.View./V (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&. A2& A3&.
       A3&
      )
     ) (DST (proj%%vstd!view.View./V A3&. A3&))
   ))
   :pattern ((proj%%vstd!view.View./V (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&.
      A2& A3&. A3&
   )))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__52_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__52_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type) (A3&. Dcr)
   (A3& Type)
  ) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (sized A3&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
     (tr_bound%vstd!view.View. A3&. A3&)
    )
    (= (proj%vstd!view.View./V (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&. A2& A3&.
       A3&
      )
     ) (TYPE%tuple%4. (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&)
      (proj%%vstd!view.View./V A1&. A1&) (proj%vstd!view.View./V A1&. A1&) (proj%%vstd!view.View./V
       A2&. A2&
      ) (proj%vstd!view.View./V A2&. A2&) (proj%%vstd!view.View./V A3&. A3&) (proj%vstd!view.View./V
       A3&. A3&
   ))))
   :pattern ((proj%vstd!view.View./V (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&. A2&
      A3&. A3&
   )))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__52_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__52_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
  ) (SINT 32)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
  ) (UINT 64)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) USIZE
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
       Self%&
      ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&.
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
      (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) BOOL
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) (REF T&.)
   )
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       REF T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) T&
   )
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF
       T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (ARRAY
        T&. T& N&. N&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (ARRAY T&. T& N&. N&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&.
        T& N&. N&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
     ) (ARRAY T&. T& N&. N&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (ARRAY T&. T& N&. N&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
        T&.
       ) T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) (TRACKED T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       TRACKED T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
       T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) (GHOST T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       GHOST T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%core!option.Option. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
     ) (TYPE%core!option.Option. T&. T&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%core!option.Option. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&.
        A& T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) (BOX A&. A& T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       BOX A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
        T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX
       A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.Seq.new.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!set.Set.empty.? (Dcr Type) Poly)
(declare-fun vstd!set.Set.insert.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)
(declare-fun vstd!array.array_view.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type Poly
  Poly
 ) Poly
)
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index%default%.? (Dcr Type Dcr
  Type Poly Poly
 ) Poly
)
(declare-fun vstd!pervasive.strictly_cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!pervasive.cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_Some.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_Some%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.get_Some_0%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_None.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_None%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.is_some.? (Dcr Type Poly) Bool)
(declare-fun vstd!std_specs.option.is_none.? (Dcr Type Poly) Bool)
(declare-fun vstd!std_specs.option.spec_unwrap.? (Dcr Type Poly) Poly)
(declare-fun vstd!simple_pptr.impl&%1.addr.? (Dcr Type Poly) Int)
(declare-fun vstd!simple_pptr.impl&%1.mem_contents.? (Dcr Type Poly) vstd!raw_ptr.MemContents.)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.?
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?
 (Poly) Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
 (Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.?
 (Poly) Bool
)
(declare-fun vstd!raw_ptr.impl&%1.arrow_0.? (Dcr Type Poly) Poly)
(declare-fun vstd!raw_ptr.impl&%6.is_init.? (Dcr Type Poly) Bool)
(declare-fun vstd!raw_ptr.impl&%6.value.? (Dcr Type Poly) Poly)
(declare-fun vstd!simple_pptr.impl&%1.is_init.? (Dcr Type Poly) Bool)
(declare-fun vstd!simple_pptr.impl&%1.value.? (Dcr Type Poly) Poly)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.?
 (Dcr Type Dcr Type Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
 (Poly Poly) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.?
 (Poly) vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.?
 (Poly) vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
 (Poly) vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.?
 (Poly Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
 (Poly Poly) core!option.Option.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
 (Poly Poly Poly) core!option.Option.
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
 (Poly) Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.?
 () Int
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.?
 (Poly) Bool
)
(declare-fun OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.?
 (Poly) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
   (=>
    (and
     (has_type len! NAT)
     (has_type f! (TYPE%fun%1. $ INT A&. A&))
    )
    (has_type (vstd!seq.Seq.new.? A&. A& len! f!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.new.? A&. A& len! f!))
   :qid internal_vstd!seq.Seq.new.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.new.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_len.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)) (%I len!))
    ))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)))
    :qid user_vstd__seq__lemma_seq_new_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_index.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (%I len!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!) (%%apply%%0
        (%Poly%fun%1. f!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!))
    :qid user_vstd__seq__lemma_seq_new_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%2
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%3
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_decreases_to_entry.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
           K& V&. V& m! key!
        )))
       ) (height m!)
    )))
    :pattern ((height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
         K& V&. V& m! key!
    )))))
    :qid user_vstd__map__axiom_map_decreases_to_entry_0
    :skolemid skolem_user_vstd__map__axiom_map_decreases_to_entry_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!set.Set.empty.? A&. A&) (TYPE%vstd!set.Set. A&. A&))
   :pattern ((vstd!set.Set.empty.? A&. A&))
   :qid internal_vstd!set.Set.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.Set.empty.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_empty.)
  (forall ((A&. Dcr) (A& Type) (a! Poly)) (!
    (=>
     (has_type a! A&)
     (=>
      (sized A&.)
      (not (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.empty.?
          A&. A&
         )
        ) a!
    ))))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.empty.?
        A&. A&
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_empty_0
    :skolemid skolem_user_vstd__set__lemma_set_empty_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!set.Set. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!set.Set.insert.? A&. A& self! a!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!set.Set.insert.? A&. A& self! a!))
   :qid internal_vstd!set.Set.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.Set.insert.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
         A&. A& s! a!
        )
       ) a!
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a!
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_insert_same_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a1! A&)
      (has_type a2! A&)
     )
     (=>
      (and
       (sized A&.)
       (not (= a1! a2!))
      )
      (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
          A&. A& s! a2!
         )
        ) a1!
       ) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a1!)
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a2!
       )
      ) a1!
    ))
    :qid user_vstd__set__lemma_set_insert_different_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.array_view.)
)
(declare-fun %%lambda%%0 (Dcr Type Dcr Type %%Function%%) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (%%hole%%4
    %%Function%%
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (array_index %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 i$)
   )
   :pattern ((%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (= (vstd!array.array_view.? T&. T& N&. N& a!) (vstd!seq.Seq.new.? T&. T& (I (const_int
        N&
       )
      ) (Poly%fun%1. (mk_fun (%%lambda%%0 T&. T& N&. N& (%Poly%array%. a!))))
    ))
    :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
    :qid internal_vstd!array.array_view.?_definition
    :skolemid skolem_internal_vstd!array.array_view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
   (=>
    (has_type a! (ARRAY T&. T& N&. N&))
    (has_type (vstd!array.array_view.? T&. T& N&. N& a!) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
   :qid internal_vstd!array.array_view.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.array_view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%0.view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!) (vstd!array.array_view.? T&.
       T& N&. N& self!
    )))
    :pattern ((vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))
    :qid internal_vstd!array.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!array.impl&__0.view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&)))
   :qid internal_vstd__array__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__0_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_len_matches_n.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (ar! Poly)) (!
    (=>
     (has_type ar! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) ar!))
       (const_int N&)
    )))
    :pattern ((vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
       ar!
    )))
    :qid user_vstd__array__array_len_matches_n_0
    :skolemid skolem_user_vstd__array__array_len_matches_n_0
))))
(declare-fun req%vstd!array.ArrayAdditionalSpecFns.spec_index. (Dcr Type Dcr Type Poly
  Poly
 ) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self! i!)
    (=>
     %%global_location_label%%4
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T&
     self! i!
   ))
   :qid internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
      i!
     ) T&
   ))
   :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
     i!
   ))
   :qid internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%2.spec_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&. T& self!
       i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!)
       i!
    )))
    :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&.
      T& self! i!
    ))
    :qid internal_vstd!array.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!array.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&. T&)
   )
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&.
     T&
   ))
   :qid internal_vstd__array__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__2_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)
        i!
       ) (vstd!seq.Seq.index.? T&. T& (vstd!array.array_view.? T&. T& N&. N& a!) i!)
    )))
    :pattern ((array_index T&. T& N&. N& (%Poly%array%. a!) i!))
    :qid user_vstd__array__lemma_array_index_0
    :skolemid skolem_user_vstd__array__lemma_array_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_ext_equal.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type a1! (ARRAY T&. T& N&. N&))
      (has_type a2! (ARRAY T&. T& N&. N&))
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (ext_eq false (ARRAY T&. T& N&. N&) a1! a2!) (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a1!)
             i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a2!)
             i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a1!
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a2!
           ) i$
         ))
         :qid user_vstd__array__axiom_array_ext_equal_0
         :skolemid skolem_user_vstd__array__axiom_array_ext_equal_0
    )))))
    :pattern ((ext_eq false (ARRAY T&. T& N&. N&) a1! a2!))
    :qid user_vstd__array__axiom_array_ext_equal_1
    :skolemid skolem_user_vstd__array__axiom_array_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (array! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type array! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (ARRAY T&. T& N&. N&) array!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&.
            T& N&. N&
           ) array!
          ) i!
    ))))))
    :pattern ((has_resolved $ (ARRAY T&. T& N&. N&) array!) (vstd!seq.Seq.index.? T&. T&
      (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) array!) i!
    ))
    :qid user_vstd__array__axiom_array_has_resolved_0
    :skolemid skolem_user_vstd__array__axiom_array_has_resolved_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_decreases_to_seq.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (=>
     (has_type a! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (height_lt (height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)) (height a!))
    ))
    :pattern ((height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)))
    :qid user_vstd__array__axiom_array_decreases_to_seq_0
    :skolemid skolem_user_vstd__array__axiom_array_decreases_to_seq_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index_decreases.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
           N&. N&
          ) a!
         ) i!
        )
       ) (height a!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
         N&. N&
        ) a!
       ) i!
    )))
    :qid user_vstd__array__lemma_array_index_decreases_0
    :skolemid skolem_user_vstd__array__lemma_array_index_decreases_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(declare-fun ens%core!clone.Clone.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (%return! Poly)) (!
   (= (ens%core!clone.Clone.clone. Self%&. Self%& self! %return!) (has_type %return! Self%&))
   :pattern ((ens%core!clone.Clone.clone. Self%&. Self%& self! %return!))
   :qid internal_ens__core!clone.Clone.clone._definition
   :skolemid skolem_internal_ens__core!clone.Clone.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (Self%&. Dcr) (Self%& Type)) (!
   (=>
    (has_type closure%$ (TYPE%tuple%1. (REF Self%&.) Self%&))
    (=>
     (let
      ((self$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      true
     )
     (closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.)) (TYPE%tuple%1.
       (REF Self%&.) Self%&
      ) (F fndef_singleton) closure%$
   )))
   :pattern ((closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.))
     (TYPE%tuple%1. (REF Self%&.) Self%&) (F fndef_singleton) closure%$
   ))
   :qid user_core__clone__Clone__clone_0
   :skolemid skolem_user_core__clone__Clone__clone_0
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%tuple%0.)
)
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Tuple1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. T%0&. T%0&)
    (tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Clone1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. T%0&. T%0&)
    (tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Copy1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
    )
    (tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Clone2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
    )
    (tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Copy2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type))
  (!
   (tr_bound%core!marker.Tuple. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&.
     T%2&
   ))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1&
      T%2&. T%2&
   )))
   :qid internal_crate__impl_tuple&__Tuple3_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple3_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type))
  (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
     (tr_bound%core!clone.Clone. T%2&. T%2&)
    )
    (tr_bound%core!clone.Clone. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :pattern ((tr_bound%core!clone.Clone. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1&
      T%2&. T%2&
   )))
   :qid internal_crate__impl_tuple&__Clone3_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone3_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type))
  (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
     (tr_bound%core!marker.Copy. T%2&. T%2&)
    )
    (tr_bound%core!marker.Copy. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :pattern ((tr_bound%core!marker.Copy. (DST T%2&.) (TYPE%tuple%3. T%0&. T%0& T%1&. T%1&
      T%2&. T%2&
   )))
   :qid internal_crate__impl_tuple&__Copy3_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy3_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type)
  ) (!
   (tr_bound%core!marker.Tuple. (DST T%3&.) (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&.
     T%2& T%3&. T%3&
   ))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%3&.) (TYPE%tuple%4. T%0&. T%0& T%1&. T%1&
      T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_crate__impl_tuple&__Tuple4_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple4_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type)
  ) (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
     (tr_bound%core!clone.Clone. T%2&. T%2&)
     (tr_bound%core!clone.Clone. T%3&. T%3&)
    )
    (tr_bound%core!clone.Clone. (DST T%3&.) (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&.
      T%2& T%3&. T%3&
   )))
   :pattern ((tr_bound%core!clone.Clone. (DST T%3&.) (TYPE%tuple%4. T%0&. T%0& T%1&. T%1&
      T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_crate__impl_tuple&__Clone4_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone4_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%3&.
    Dcr
   ) (T%3& Type)
  ) (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
     (tr_bound%core!marker.Copy. T%2&. T%2&)
     (tr_bound%core!marker.Copy. T%3&. T%3&)
    )
    (tr_bound%core!marker.Copy. (DST T%3&.) (TYPE%tuple%4. T%0&. T%0& T%1&. T%1& T%2&.
      T%2& T%3&. T%3&
   )))
   :pattern ((tr_bound%core!marker.Copy. (DST T%3&.) (TYPE%tuple%4. T%0&. T%0& T%1&. T%1&
      T%2&. T%2& T%3&. T%3&
   )))
   :qid internal_crate__impl_tuple&__Copy4_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy4_trait_impl_definition
)))
(declare-fun ens%core!clone.impls.impl&%28.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%28.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (SINT 32) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%28.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__28.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__28.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (SINT 32)))
     (has_type res$ (SINT 32))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (SINT 32)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (SINT 32)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%28__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%28__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%18.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%18.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 64) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%18.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__18.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__18.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 64)))
     (has_type res$ (UINT 64))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 64)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 64)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%18__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%18__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%10.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%10.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ USIZE x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%10.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__10.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__10.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) USIZE))
     (has_type res$ USIZE)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1. (
        REF $
       ) USIZE
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1.
      (REF $) USIZE
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%10__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%10__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%42.clone. (Poly Poly) Bool)
(assert
 (forall ((b! Poly) (%return! Poly)) (!
   (= (ens%core!clone.impls.impl&%42.clone. b! %return!) (and
     (ens%core!clone.Clone.clone. $ BOOL b! %return!)
     (= %return! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%42.clone. b! %return!))
   :qid internal_ens__core!clone.impls.impl&__42.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__42.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) BOOL))
     (has_type %return$ BOOL)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1. (REF
        $
       ) BOOL
      ) (F fndef_singleton) closure%$ %return$
     )
     (let
      ((b$ (%B (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%B %return$) b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1.
      (REF $) BOOL
     ) (F fndef_singleton) closure%$ %return$
   ))
   :qid user_core__clone__impls__impl&%42__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%42__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%6.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (REF T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%6.clone. T&. T& b! res!))
   :qid internal_ens__core!clone.impls.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (REF T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.))) (TYPE%tuple%1.
       (REF (REF T&.)) T&
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.)))
     (TYPE%tuple%1. (REF (REF T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%6__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%6__clone_0
)))
(assert
 (fuel_bool_default fuel%vstd!pervasive.strictly_cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.strictly_cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.strictly_cloned.? T&. T& a! b!) (closure_ens (FNDEF%core!clone.Clone.clone.
       T&. T&
      ) (DST (REF T&.)) (TYPE%tuple%1. (REF T&.) T&) (F fndef_singleton) (Poly%tuple%1.
       (tuple%1./tuple%1 a!)
      ) b!
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.strictly_cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.strictly_cloned.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!pervasive.cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.cloned.? T&. T& a! b!) (or
      (vstd!pervasive.strictly_cloned.? T&. T& a! b!)
      (= a! b!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.cloned.?_definition
))))
(declare-fun ens%core!array.impl&%20.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (res! Poly)) (!
   (= (ens%core!array.impl&%20.clone. T&. T& N&. N& a! res!) (and
     (ens%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&) a! res!)
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (const_int N&)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
            $ (ARRAY T&. T& N&. N&) a!
           ) i$
          ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
           i$
       ))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
          a!
         ) i$
       ))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
          res!
         ) i$
       ))
       :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
           $ (ARRAY T&. T& N&. N&) a!
          ) i$
         ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
          i$
       )))
       :qid user_core__array__impl&%20__clone_0
       :skolemid skolem_user_core__array__impl&%20__clone_0
     ))
     (=>
      (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (ARRAY T&. T& N&.
         N&
        ) a!
       ) (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
      )
      (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!) (vstd!view.View.view.? $ (ARRAY
         T&. T& N&. N&
        ) res!
   )))))
   :pattern ((ens%core!array.impl&%20.clone. T&. T& N&. N& a! res!))
   :qid internal_ens__core!array.impl&__20.clone._definition
   :skolemid skolem_internal_ens__core!array.impl&__20.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)))
     (has_type res$ (ARRAY T&. T& N&. N&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&)) (DST (REF $))
      (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)) (F fndef_singleton) closure%$ res$
     )
     (let
      ((a$ (%Poly%array%. (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (and
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
              $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)
             ) i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
             i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            (Poly%array%. a$)
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            res$
           ) i$
         ))
         :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
             $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)
            ) i$
           ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
            i$
         )))
         :qid user_core__array__impl&%20__clone_1
         :skolemid skolem_user_core__array__impl&%20__clone_1
       ))
       (=>
        (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (ARRAY T&. T& N&.
           N&
          ) (Poly%array%. a$)
         ) (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
        )
        (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)) (vstd!view.View.view.?
          $ (ARRAY T&. T& N&. N&) res$
   )))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&)) (DST
      (REF $)
     ) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__array__impl&%20__clone_2
   :skolemid skolem_user_core__array__impl&%20__clone_2
)))
(declare-fun ens%verus_builtin!impl&%9.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%9.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (TRACKED T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%9.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__9.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__9.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (TRACKED T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED T&.)))
      (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED
        T&.
      ))
     ) (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%9__clone_0
   :skolemid skolem_user_verus_builtin__impl&%9__clone_0
)))
(declare-fun ens%verus_builtin!impl&%7.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%7.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (GHOST T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%7.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__7.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__7.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (GHOST T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST T&.)))
      (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST
        T&.
      ))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%7__clone_0
   :skolemid skolem_user_verus_builtin__impl&%7__clone_0
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.is_Some.? Self%&. Self%& T&. T&
      self!
     ) BOOL
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_Some.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.is_Some.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.is_Some.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? Self%&. Self%& T&.
      T& self!
     ) T&
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? Self%&. Self%& T&.
     T& self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.get_Some_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.get_Some_0.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.is_None.? Self%&. Self%& T&. T&
      self!
     ) BOOL
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_None.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.is_None.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.is_None.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
      self!
     ) T&
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.is_some.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.is_some.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.is_some.? T&. T& option!) (is-core!option.Option./Some (%Poly%core!option.Option.
       option!
    )))
    :pattern ((vstd!std_specs.option.is_some.? T&. T& option!))
    :qid internal_vstd!std_specs.option.is_some.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.is_some.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.is_none.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.is_none.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.is_none.? T&. T& option!) (is-core!option.Option./None (%Poly%core!option.Option.
       option!
    )))
    :pattern ((vstd!std_specs.option.is_none.? T&. T& option!))
    :qid internal_vstd!std_specs.option.is_none.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.is_none.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.arrow_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.arrow_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. self!))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.is_Some.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.is_Some.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.is_Some.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (B (is-core!option.Option./Some (%Poly%core!option.Option. self!)))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_Some.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.is_Some.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.is_Some.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.get_Some_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.get_Some_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. self!))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.get_Some_0.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.get_Some_0.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.is_None.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.is_None.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.is_None.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (B (is-core!option.Option./None (%Poly%core!option.Option. self!)))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_None.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.is_None.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.is_None.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option. T&.
      T&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option.
      T&. T&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__option__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__option__impl&__0_trait_impl_definition
)))
(declare-fun req%vstd!std_specs.option.spec_unwrap. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (= (req%vstd!std_specs.option.spec_unwrap. T&. T& option!) (=>
     %%global_location_label%%5
     (is-core!option.Option./Some (%Poly%core!option.Option. option!))
   ))
   :pattern ((req%vstd!std_specs.option.spec_unwrap. T&. T& option!))
   :qid internal_req__vstd!std_specs.option.spec_unwrap._definition
   :skolemid skolem_internal_req__vstd!std_specs.option.spec_unwrap._definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.spec_unwrap.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.spec_unwrap.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.spec_unwrap.? T&. T& option!) (core!option.Option./Some/0
      T&. T& (%Poly%core!option.Option. option!)
    ))
    :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
    :qid internal_vstd!std_specs.option.spec_unwrap.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (=>
    (has_type option! (TYPE%core!option.Option. T&. T&))
    (has_type (vstd!std_specs.option.spec_unwrap.? T&. T& option!) T&)
   )
   :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
   :qid internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
)))
(declare-fun ens%core!option.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (opt! Poly) (res! Poly)) (!
   (= (ens%core!option.impl&%6.clone. T&. T& opt! res!) (and
     (ens%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&. T&) opt! res!)
     (=>
      (is-core!option.Option./None (%Poly%core!option.Option. opt!))
      (is-core!option.Option./None (%Poly%core!option.Option. res!))
     )
     (=>
      (is-core!option.Option./Some (%Poly%core!option.Option. opt!))
      (and
       (is-core!option.Option./Some (%Poly%core!option.Option. res!))
       (vstd!pervasive.cloned.? T&. T& (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option.
          opt!
         )
        ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. res!))
   )))))
   :pattern ((ens%core!option.impl&%6.clone. T&. T& opt! res!))
   :qid internal_ens__core!option.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!option.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)))
     (has_type res$ (TYPE%core!option.Option. T&. T&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&. T&)) (
       DST (REF $)
      ) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)) (F fndef_singleton) closure%$
      res$
     )
     (let
      ((opt$ (%Poly%core!option.Option. (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (and
       (=>
        (is-core!option.Option./None opt$)
        (is-core!option.Option./None (%Poly%core!option.Option. res$))
       )
       (=>
        (is-core!option.Option./Some opt$)
        (and
         (is-core!option.Option./Some (%Poly%core!option.Option. res$))
         (vstd!pervasive.cloned.? T&. T& (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option.
            (Poly%core!option.Option. opt$)
           )
          ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. res$))
   )))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&.
       T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)) (F fndef_singleton)
     closure%$ res$
   ))
   :qid user_core__option__impl&%6__clone_0
   :skolemid skolem_user_core__option__impl&%6__clone_0
)))
(declare-fun ens%alloc!boxed.impl&%15.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (b! Poly) (res! Poly)) (!
   (= (ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!) (and
     (ens%core!clone.Clone.clone. (BOX A&. A& T&.) T& b! res!)
     (vstd!pervasive.cloned.? T&. T& b! res!)
   ))
   :pattern ((ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!))
   :qid internal_ens__alloc!boxed.impl&__15.clone._definition
   :skolemid skolem_internal_ens__alloc!boxed.impl&__15.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF (BOX A&. A&
         T&.
       ))
      ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (vstd!pervasive.cloned.? T&. T& b$ res$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF
       (BOX A&. A& T&.)
      )
     ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_alloc__boxed__impl&%15__clone_0
   :skolemid skolem_user_alloc__boxed__impl&%15__clone_0
)))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (uInv SZ (vstd!simple_pptr.impl&%1.addr.? V&. V& self!))
   )
   :pattern ((vstd!simple_pptr.impl&%1.addr.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.addr.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.addr.?_pre_post_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (has_type (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? V&.
       V& self!
      )
     ) (TYPE%vstd!raw_ptr.MemContents. V&. V&)
   ))
   :pattern ((vstd!simple_pptr.impl&%1.mem_contents.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.mem_contents.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.mem_contents.?_pre_post_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.?
   1
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.?
      v!
     ) (not (= (uClip SZ (bitand (I (%I v!)) (I (uClip SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PRESENT_MASK.?))))
       0
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.?
   7
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (and
    (<= 0 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.?)
    (< OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.?
     64
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.?
   (uClip 64 (bitshl (I 1) (I OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_SHIFT.?)))
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.?
      v!
     ) (not (= (uClip SZ (bitand (I (%I v!)) (I (uClip SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_PS_MASK.?))))
       0
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.?
   1
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (and
    (<= 0 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.?)
    (< OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.?
     64
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.?
   (uClip 64 (bitshl (I 1) (I OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_SHIFT.?)))
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.?
      v!
     ) (not (= (uClip SZ (bitand (I (%I v!)) (I (uClip SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_WRITE_MASK.?))))
       0
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.?
   63
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (and
    (<= 0 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.?)
    (< OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.?
     64
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.?
   (uClip 64 (bitshl (I 1) (I OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_SHIFT.?)))
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.?
      v!
     ) (not (= (uClip SZ (bitand (I (%I v!)) (I (uClip SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_EXECUTE_MASK.?))))
       0
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.?
   2
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (and
    (<= 0 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.?)
    (< OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.?
     64
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.?
   (uClip 64 (bitshl (I 1) (I OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_SHIFT.?)))
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.?
      v!
     ) (not (= (uClip SZ (bitand (I (%I v!)) (I (uClip SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PAGE_ENTRY_USER_MASK.?))))
       0
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.?
      v!
     ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm
      (%B (B (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2present.?
         v!
       ))
      ) (%B (B (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2ps.?
         v!
       ))
      ) (%B (B (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2write.?
         v!
       ))
      ) (%B (B (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2execute_disable.?
         v!
       ))
      ) (%B (B (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2user.?
         v!
    )))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.?_definition
))))
(declare-fun ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry_perm.
 (Int OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
 Bool
)
(assert
 (forall ((v! Int) (ret! OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.))
  (!
   (= (ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry_perm.
     v! ret!
    ) (and
     (ext_eq false TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
      (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
       ret!
      ) (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.?
        (I v!)
     )))
     (=>
      (= v! 0)
      (and
       (and
        (and
         (and
          (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              ret!
            ))
           ) false
          )
          (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              ret!
            ))
           ) false
         ))
         (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             ret!
           ))
          ) false
        ))
        (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            ret!
          ))
         ) false
       ))
       (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/user
         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           ret!
         ))
        ) false
   )))))
   :pattern ((ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry_perm.
     v! ret!
   ))
   :qid internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry_perm._definition
   :skolemid skolem_internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry_perm._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.?
   281474976706560
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?
      v!
     ) (uClip SZ (bitand (I (%I v!)) (I (uClip SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.?))))
    )
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?_definition
))))
(assert
 (forall ((v! Poly)) (!
   (=>
    (has_type v! USIZE)
    (uInv SZ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?
      v!
   )))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?
     v!
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?_pre_post_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
      v!
     ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry
      (%I (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?
         v!
       ))
      ) (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
       (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry_perm.?
         v!
    )))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?_definition
))))
(assert
 (forall ((v! Poly)) (!
   (=>
    (has_type v! USIZE)
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
       v!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
     v!
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?_pre_post_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?_pre_post_definition
)))
(declare-fun ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry.
 (Int OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
 Bool
)
(assert
 (forall ((v! Int) (ret! OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.))
  (!
   (= (ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry.
     v! ret!
    ) (and
     (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
       ret!
      ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
     )
     (ext_eq false TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
       ret!
      ) (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
        (I v!)
     )))
     (=>
      (= v! 0)
      (and
       (and
        (and
         (and
          (and
           (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               ret!
             ))
            ) 0
           )
           (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  ret!
             )))))
            ) false
          ))
          (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 ret!
            )))))
           ) false
         ))
         (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                ret!
           )))))
          ) false
        ))
        (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               ret!
          )))))
         ) false
       ))
       (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/user
         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              ret!
         )))))
        ) false
   )))))
   :pattern ((ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry.
     v! ret!
   ))
   :qid internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry._definition
   :skolemid skolem_internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2page_entry._definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.)
  (forall ((v! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.?
      v!
     ) (= (uClip SZ (bitand (I (%I v!)) (I (uClip SZ (uClip 64 (bitnot (I OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_MASK.?)))))))
      0
    ))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.?
      v!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.?_definition
))))
(declare-fun ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2pa.
 (Int Int) Bool
)
(assert
 (forall ((v! Int) (ret! Int)) (!
   (= (ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2pa.
     v! ret!
    ) (and
     (uInv SZ ret!)
     (ext_eq false USIZE (I ret!) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2pa.?
        (I v!)
     )))
     (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_valid.?
      (I ret!)
   )))
   :pattern ((ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2pa.
     v! ret!
   ))
   :qid internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2pa._definition
   :skolemid skolem_internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!usize2pa._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.?
   281474974613504
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.?
   1
)))
(assert
 (uInv SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.)
  (forall ((va! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?
      va!
     ) (and
      (= (uClip SZ (bitand (I (%I va!)) (I (uClip SZ (uClip 64 (bitnot (I OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_2m_MASK.?)))))))
       0
      )
      (>= (uClip 64 (bitand (I (uClip 64 (bitshr (I (uClip 64 (%I va!))) (I 39)))) (I 511)))
       (uClip 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.?)
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?
      va!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?_definition
))))
(declare-fun ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_2m_valid.
 (Int Bool) Bool
)
(assert
 (forall ((va! Int) (ret! Bool)) (!
   (= (ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_2m_valid.
     va! ret!
    ) (= ret! (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?
      (I va!)
   )))
   :pattern ((ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_2m_valid.
     va! ret!
   ))
   :qid internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_2m_valid._definition
   :skolemid skolem_internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_2m_valid._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.?
   281457796841472
)))
(assert
 (uInv 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.)
  (forall ((va! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.?
      va!
     ) (and
      (= (uClip SZ (bitand (I (%I va!)) (I (uClip SZ (uClip 64 (bitnot (I OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MEM_1g_MASK.?)))))))
       0
      )
      (>= (uClip 64 (bitand (I (uClip 64 (bitshr (I (uClip 64 (%I va!))) (I 39)))) (I 511)))
       (uClip 64 OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!KERNEL_MEM_END_L4INDEX.?)
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.?
      va!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.?_definition
))))
(declare-fun ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_1g_valid.
 (Int Bool) Bool
)
(assert
 (forall ((va! Int) (ret! Bool)) (!
   (= (ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_1g_valid.
     va! ret!
    ) (= ret! (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_1g_valid.?
      (I va!)
   )))
   :pattern ((ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_1g_valid.
     va! ret!
   ))
   :qid internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_1g_valid._definition
   :skolemid skolem_internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!va_1g_valid._definition
)))
(declare-fun req%vstd!raw_ptr.impl&%1.arrow_0. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (= (req%vstd!raw_ptr.impl&%1.arrow_0. T&. T& self!) (=>
     %%global_location_label%%6
     (is-vstd!raw_ptr.MemContents./Init (%Poly%vstd!raw_ptr.MemContents. self!))
   ))
   :pattern ((req%vstd!raw_ptr.impl&%1.arrow_0. T&. T& self!))
   :qid internal_req__vstd!raw_ptr.impl&__1.arrow_0._definition
   :skolemid skolem_internal_req__vstd!raw_ptr.impl&__1.arrow_0._definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%1.arrow_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%1.arrow_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!) (vstd!raw_ptr.MemContents./Init/0
      T&. T& (%Poly%vstd!raw_ptr.MemContents. self!)
    ))
    :pattern ((vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!))
    :qid internal_vstd!raw_ptr.impl&__1.arrow_0.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__1.arrow_0.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (has_type (vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!) T&)
   )
   :pattern ((vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!))
   :qid internal_vstd!raw_ptr.impl&__1.arrow_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.impl&__1.arrow_0.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%6.is_init.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%6.is_init.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!raw_ptr.impl&%6.is_init.? T&. T& self!) (is-vstd!raw_ptr.MemContents./Init
      (%Poly%vstd!raw_ptr.MemContents. self!)
    ))
    :pattern ((vstd!raw_ptr.impl&%6.is_init.? T&. T& self!))
    :qid internal_vstd!raw_ptr.impl&__6.is_init.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__6.is_init.?_definition
))))
(declare-fun req%vstd!raw_ptr.impl&%6.value. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (= (req%vstd!raw_ptr.impl&%6.value. T&. T& self!) (=>
     %%global_location_label%%7
     (is-vstd!raw_ptr.MemContents./Init (%Poly%vstd!raw_ptr.MemContents. self!))
   ))
   :pattern ((req%vstd!raw_ptr.impl&%6.value. T&. T& self!))
   :qid internal_req__vstd!raw_ptr.impl&__6.value._definition
   :skolemid skolem_internal_req__vstd!raw_ptr.impl&__6.value._definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%6.value.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%6.value.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!raw_ptr.impl&%6.value.? T&. T& self!) (vstd!raw_ptr.MemContents./Init/0 T&.
      T& (%Poly%vstd!raw_ptr.MemContents. self!)
    ))
    :pattern ((vstd!raw_ptr.impl&%6.value.? T&. T& self!))
    :qid internal_vstd!raw_ptr.impl&__6.value.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__6.value.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (has_type (vstd!raw_ptr.impl&%6.value.? T&. T& self!) T&)
   )
   :pattern ((vstd!raw_ptr.impl&%6.value.? T&. T& self!))
   :qid internal_vstd!raw_ptr.impl&__6.value.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.impl&__6.value.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!simple_pptr.impl&%1.is_init.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!simple_pptr.impl&%1.is_init.)
  (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
    (= (vstd!simple_pptr.impl&%1.is_init.? V&. V& self!) (is-vstd!raw_ptr.MemContents./Init
      (vstd!simple_pptr.impl&%1.mem_contents.? V&. V& self!)
    ))
    :pattern ((vstd!simple_pptr.impl&%1.is_init.? V&. V& self!))
    :qid internal_vstd!simple_pptr.impl&__1.is_init.?_definition
    :skolemid skolem_internal_vstd!simple_pptr.impl&__1.is_init.?_definition
))))
(declare-fun req%vstd!simple_pptr.impl&%1.value. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (= (req%vstd!simple_pptr.impl&%1.value. V&. V& self!) (=>
     %%global_location_label%%8
     (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? V&. V&
       self!
   ))))
   :pattern ((req%vstd!simple_pptr.impl&%1.value. V&. V& self!))
   :qid internal_req__vstd!simple_pptr.impl&__1.value._definition
   :skolemid skolem_internal_req__vstd!simple_pptr.impl&__1.value._definition
)))
(assert
 (fuel_bool_default fuel%vstd!simple_pptr.impl&%1.value.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!simple_pptr.impl&%1.value.)
  (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
    (= (vstd!simple_pptr.impl&%1.value.? V&. V& self!) (vstd!raw_ptr.MemContents./Init/0
      V&. V& (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
         V&. V& self!
    )))))
    :pattern ((vstd!simple_pptr.impl&%1.value.? V&. V& self!))
    :qid internal_vstd!simple_pptr.impl&__1.value.?_definition
    :skolemid skolem_internal_vstd!simple_pptr.impl&__1.value.?_definition
))))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (has_type (vstd!simple_pptr.impl&%1.value.? V&. V& self!) V&)
   )
   :pattern ((vstd!simple_pptr.impl&%1.value.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.value.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.value.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%14.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%14.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!) self!)
    )
    :pattern ((vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!))
    :qid internal_vstd!view.impl&__14.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__14.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%26.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%26.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 64) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 64) self!))
    :qid internal_vstd!view.impl&__26.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__26.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%36.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%36.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 32) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 32) self!))
    :qid internal_vstd!view.impl&__36.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__36.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%46.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%46.view.)
  (forall ((A0&. Dcr) (A0& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (tr_bound%vstd!view.View. A0&. A0&)
     )
     (= (vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!) (Poly%tuple%1.
       (tuple%1./tuple%1 (vstd!view.View.view.? A0&. A0& (tuple%1./tuple%1/0 (%Poly%tuple%1.
           self!
    )))))))
    :pattern ((vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!))
    :qid internal_vstd!view.impl&__46.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__46.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%48.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%48.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
     )
     (= (vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!) (Poly%tuple%2.
       (tuple%2./tuple%2 (vstd!view.View.view.? A0&. A0& (tuple%2./tuple%2/0 (%Poly%tuple%2.
           self!
         ))
        ) (vstd!view.View.view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!))
    :qid internal_vstd!view.impl&__48.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__48.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%50.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%50.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type) (self! Poly))
   (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (sized A2&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
      (tr_bound%vstd!view.View. A2&. A2&)
     )
     (= (vstd!view.View.view.? (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&) self!)
      (Poly%tuple%3. (tuple%3./tuple%3 (vstd!view.View.view.? A0&. A0& (tuple%3./tuple%3/0
          (%Poly%tuple%3. self!)
         )
        ) (vstd!view.View.view.? A1&. A1& (tuple%3./tuple%3/1 (%Poly%tuple%3. self!))) (vstd!view.View.view.?
         A2&. A2& (tuple%3./tuple%3/2 (%Poly%tuple%3. self!))
    )))))
    :pattern ((vstd!view.View.view.? (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&)
      self!
    ))
    :qid internal_vstd!view.impl&__50.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__50.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%52.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%52.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type) (A3&. Dcr)
    (A3& Type) (self! Poly)
   ) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (sized A2&.)
      (sized A3&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
      (tr_bound%vstd!view.View. A2&. A2&)
      (tr_bound%vstd!view.View. A3&. A3&)
     )
     (= (vstd!view.View.view.? (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&. A2& A3&.
        A3&
       ) self!
      ) (Poly%tuple%4. (tuple%4./tuple%4 (vstd!view.View.view.? A0&. A0& (tuple%4./tuple%4/0
          (%Poly%tuple%4. self!)
         )
        ) (vstd!view.View.view.? A1&. A1& (tuple%4./tuple%4/1 (%Poly%tuple%4. self!))) (vstd!view.View.view.?
         A2&. A2& (tuple%4./tuple%4/2 (%Poly%tuple%4. self!))
        ) (vstd!view.View.view.? A3&. A3& (tuple%4./tuple%4/3 (%Poly%tuple%4. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&. A2&
       A3&. A3&
      ) self!
    ))
    :qid internal_vstd!view.impl&__52.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__52.view.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.)
  (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.?
      A&. A& N&. N& self!
     ) (= (vstd!seq.Seq.len.? A&. A& (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
         self!
       ))
      ) (const_int N&)
    ))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.?
      A&. A& N&. N& self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__7.wf.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__7.wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.)
  (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.?
      A&. A& N&. N& self!
     ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
       self!
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.?
      A&. A& N&. N& self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__7.view.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__7.view.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
      A&. A& N&. N&
    ))
    (has_type (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.?
      A&. A& N&. N& self!
     ) (TYPE%vstd!seq.Seq. A&. A&)
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.view.?
     A&. A& N&. N& self!
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__7.view.?_pre_post_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__7.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.)
  (forall ((self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.?
      self!
     ) (and
      (and
       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%7.wf.?
        $ USIZE $ (CONST_INT 512) (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
         (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
           self!
       ))))
       (= (vstd!seq.Seq.len.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
         (Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
            self!
         )))
        ) 512
      ))
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ INT)
         (=>
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I i$)))
            (let
             ((tmp%%$2 512))
             (and
              (<= tmp%%$ tmp%%$1)
              (< tmp%%$1 tmp%%$2)
          ))))
          (ext_eq false TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
             (vstd!seq.Seq.index.? $ USIZE (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   self!
               ))))
              ) i$
            ))
           ) (vstd!seq.Seq.index.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
            (Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               self!
             ))
            ) i$
        ))))
        :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_usize2page_entry.?
          (vstd!seq.Seq.index.? $ USIZE (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array./Array/seq
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!Array.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/ar
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                self!
            ))))
           ) i$
        )))
        :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageMap__wf_0
        :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageMap__wf_0
    ))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.?
      self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.wf.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.wf.?_definition
))))
(declare-fun req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((self! Poly) (index! Poly)) (!
   (= (req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.
     self! index!
    ) (=>
     %%global_location_label%%9
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I index!)))
       (let
        ((tmp%%$2 512))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.
     self! index!
   ))
   :qid internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.spec_index._definition
   :skolemid skolem_internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.)
  (forall ((self! Poly) (index! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
      self! index!
     ) (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      (vstd!seq.Seq.index.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
       (Poly%vstd!seq.Seq<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.>.
        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap./PageMap/spec_seq
         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
          self!
        ))
       ) index!
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
      self! index!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.spec_index.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.spec_index.?_definition
))))
(assert
 (forall ((self! Poly) (index! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
     (has_type index! USIZE)
    )
    (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
       self! index!
      )
     ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
     self! index!
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.)
  (forall ((self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.?
      self!
     ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_4k
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
       self!
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.?
      self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.mapping_4k.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.mapping_4k.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.)
  (forall ((self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.?
      self!
     ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_2m
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
       self!
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.?
      self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.mapping_2m.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.mapping_2m.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.)
  (forall ((self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
      self!
     ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
       self!
    )))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
      self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.mapping_1g.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.mapping_1g.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.)
  (forall ((self! Poly) (pa! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.?
      self! pa!
     ) (and
      (and
       (forall ((va$ Poly)) (!
         (=>
          (has_type va$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
              (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.?
                self!
             )))
            ) va$
           )
           (not (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
               (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.?
                  self!
                 )
                ) va$
              ))
             ) (%I pa!)
         ))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.?
               self!
            )))
           ) va$
          ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
            (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_4k.?
               self!
              )
             ) va$
         ))))
         :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__page_not_mapped_0
         :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__page_not_mapped_0
       ))
       (forall ((va$ Poly)) (!
         (=>
          (has_type va$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
              (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.?
                self!
             )))
            ) va$
           )
           (not (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
               (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.?
                  self!
                 )
                ) va$
              ))
             ) (%I pa!)
         ))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.?
               self!
            )))
           ) va$
          ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
            (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_2m.?
               self!
              )
             ) va$
         ))))
         :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__page_not_mapped_1
         :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__page_not_mapped_1
      )))
      (forall ((va$ Poly)) (!
        (=>
         (has_type va$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
               self!
            )))
           ) va$
          )
          (not (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
              (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
               (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
                 self!
                )
               ) va$
             ))
            ) (%I pa!)
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
            (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
              self!
           )))
          ) va$
         ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
           (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
            (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
              self!
             )
            ) va$
        ))))
        :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__page_not_mapped_2
        :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__page_not_mapped_2
    ))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.?
      self! pa!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.page_not_mapped.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.page_not_mapped.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.)
  (forall ((self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.?
      self!
     ) (and
      (and
       (and
        (and
         (and
          (and
           (and
            (ext_eq false (TYPE%vstd!set.Set. $ USIZE) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
               $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
              ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
              )))
             ) (vstd!set.Set.insert.? $ USIZE (vstd!set.Set.empty.? $ USIZE) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
            )))))
            (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
               self!
              )
             ) (vstd!simple_pptr.impl&%1.addr.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
                ))
               ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
           )))))))
           (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
             (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
               ))
              ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
          )))))))
          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.?
           (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
            (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
               $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
                 ))
                ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
         ))))))))))
         (forall ((i$ Poly)) (!
           (=>
            (has_type i$ USIZE)
            (=>
             (and
              (let
               ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
               ))))
               (let
                ((tmp%%$1 (%I i$)))
                (let
                 ((tmp%%$2 512))
                 (and
                  (<= tmp%%$ tmp%%$1)
                  (< tmp%%$1 tmp%%$2)
              ))))
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                     (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                         $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                         (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                          (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                           (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                             self!
                           ))
                          ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                             self!
                      )))))))
                     ) i$
             ))))))))
             (and
              (and
               (= (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      self!
                  ))))
                 ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                    (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                     (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                      (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                       (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                          $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                              self!
                            ))
                           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                              self!
                       )))))))
                      ) i$
                 )))))
                ) false
               )
               (= (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      self!
                  ))))
                 ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                    (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                     (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                      (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                       (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                          $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                              self!
                            ))
                           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                              self!
                       )))))))
                      ) i$
                 )))))
                ) false
              ))
              (not (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
                 )
                ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                          ))
                         ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                     )))))))
                    ) i$
           )))))))))
           :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
             ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                        ))
                       ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                   )))))))
                  ) i$
           )))))))
           :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
             ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                        ))
                       ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                   )))))))
                  ) i$
           )))))))
           :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_0
           :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_0
        )))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ USIZE)
           (=>
            (and
             (let
              ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
              (let
               ((tmp%%$4 (%I i$)))
               (let
                ((tmp%%$5 512))
                (and
                 (<= tmp%%$ tmp%%$4)
                 (< tmp%%$4 tmp%%$5)
             ))))
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                          ))
                         ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                     )))))))
                    ) i$
            ))))))))
            (not (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
               )
              ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                        ))
                       ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                   )))))))
                  ) i$
          ))))))))
          :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
               (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                   $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                     (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       self!
                     ))
                    ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       self!
                )))))))
               ) i$
          )))))
          :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_1
          :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_1
       )))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ USIZE)
          (=>
           (and
            (and
             (let
              ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
              (let
               ((tmp%%$7 (%I i$)))
               (let
                ((tmp%%$8 512))
                (and
                 (<= tmp%%$ tmp%%$7)
                 (< tmp%%$7 tmp%%$8)
             ))))
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                          ))
                         ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                     )))))))
                    ) i$
            ))))))))
            (not (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                          ))
                         ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                     )))))))
                    ) i$
           )))))))))
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
             ))))
            ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                       ))
                      ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                  )))))))
                 ) i$
         ))))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                 )))))))
                ) i$
         )))))))
         :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_2
         :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_2
      )))
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ USIZE)
         (=>
          (and
           (let
            ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
            (let
             ((tmp%%$10 (%I i$)))
             (let
              ((tmp%%$11 512))
              (and
               (<= tmp%%$ tmp%%$10)
               (< tmp%%$10 tmp%%$11)
           ))))
           (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                        ))
                       ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                   )))))))
                  ) i$
          ))))))))
          (not (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                        ))
                       ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                   )))))))
                  ) i$
        ))))))))))
        :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                 )))))))
                ) i$
        ))))))))
        :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_3
        :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l4_3
    ))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.?
      self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.wf_l4.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.wf_l4.?_definition
))))
(declare-fun req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((self! Poly) (l4i! Poly)) (!
   (= (req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.
     self! l4i!
    ) (=>
     %%global_location_label%%10
     (let
      ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
          self!
      ))))
      (let
       ((tmp%%$1 (%I l4i!)))
       (let
        ((tmp%%$2 512))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.
     self! l4i!
   ))
   :qid internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_l4._definition
   :skolemid skolem_internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_l4._definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.)
  (forall ((self! Poly) (l4i! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
      self! l4i!
     ) (ite
      (or
       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
         (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      self!
                    ))
                   ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      self!
               )))))))
              ) l4i!
       )))))))
       (< (%I l4i!) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
          self!
      ))))
      (core!option.Option./Some (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
         (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
          (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
             $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
             (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l4_table
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
               ))
              ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
          )))))))
         ) l4i!
      )))
      core!option.Option./None
    ))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
      self! l4i!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_l4.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_l4.?_definition
))))
(assert
 (forall ((self! Poly) (l4i! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
     (has_type l4i! USIZE)
    )
    (has_type (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
       self! l4i!
      )
     ) (TYPE%core!option.Option. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
     self! l4i!
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_l4.?_pre_post_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_l4.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.)
  (forall ((self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.?
      self!
     ) (and
      (and
       (and
        (and
         (and
          (forall ((p$ Poly)) (!
            (=>
             (has_type p$ USIZE)
             (=>
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                ))))
               ) p$
              )
              (= (vstd!simple_pptr.impl&%1.addr.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                  ))
                 ) p$
                )
               ) (%I p$)
            )))
            :pattern ((vstd!simple_pptr.impl&%1.addr.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
                ))
               ) p$
            )))
            :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_0
            :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_0
          ))
          (forall ((p$ Poly)) (!
            (=>
             (has_type p$ USIZE)
             (=>
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                ))))
               ) p$
              )
              (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                  ))
                 ) p$
            )))))
            :pattern ((is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.?
               $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
                 ))
                ) p$
            ))))
            :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_1
            :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_1
         )))
         (forall ((p$ Poly)) (!
           (=>
            (has_type p$ USIZE)
            (=>
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
               ))))
              ) p$
             )
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.?
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      self!
                    ))
                   ) p$
           ))))))))
           :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.wf.?
             (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
              (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                    (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                     self!
                   ))
                  ) p$
           )))))))
           :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_2
           :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_2
        )))
        (forall ((p$ Poly)) (!
          (=>
           (has_type p$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
             ) p$
            )
            (and
             (and
              (and
               (let
                ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                ))))
                (let
                 ((tmp%%$1 (%I (vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) p$
                 ))))
                 (let
                  ((tmp%%$2 512))
                  (and
                   (<= tmp%%$ tmp%%$1)
                   (< tmp%%$1 tmp%%$2)
               ))))
               (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                    (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                     self!
                 ))))
                ) p$
              ))
              (is-core!option.Option./Some (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
                self! (vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                  ))
                 ) p$
             ))))
             (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
                    self! (vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) p$
               ))))))
              ) (%I p$)
          ))))
          :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
             ))))
            ) p$
          ))
          :pattern ((vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
               self!
             ))
            ) p$
          ))
          :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_3
          :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_3
       )))
       (forall ((p$ Poly) (i$ Poly)) (!
         (=>
          (and
           (has_type p$ USIZE)
           (has_type i$ USIZE)
          )
          (=>
           (and
            (and
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
               ))))
              ) p$
             )
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$4 (%I i$)))
               (let
                ((tmp%%$5 512))
                (and
                 (<= tmp%%$ tmp%%$4)
                 (< tmp%%$4 tmp%%$5)
            )))))
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                   (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                       $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                         (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           self!
                         ))
                        ) p$
                    ))))
                   ) i$
           ))))))))
           (and
            (and
             (= (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                ))))
               ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                          ))
                         ) p$
                     ))))
                    ) i$
               )))))
              ) false
             )
             (= (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                ))))
               ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                          ))
                         ) p$
                     ))))
                    ) i$
               )))))
              ) false
            ))
            (not (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/cr3
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
               )
              ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                        ))
                       ) p$
                   ))))
                  ) i$
         )))))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) p$
          ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                       ))
                      ) p$
                  ))))
                 ) i$
           ))))))
          ) (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) p$
                 ))))
                ) i$
         )))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) p$
          ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                       ))
                      ) p$
                  ))))
                 ) i$
           ))))))
          ) (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l1_tables
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) p$
                 ))))
                ) i$
         )))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) p$
          ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                       ))
                      ) p$
                  ))))
                 ) i$
           ))))))
          ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      self!
                    ))
                   ) p$
               ))))
              ) i$
         )))))
         :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_4
         :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_4
      )))
      (forall ((p$ Poly) (i$ Poly)) (!
        (=>
         (and
          (has_type p$ USIZE)
          (has_type i$ USIZE)
         )
         (=>
          (and
           (and
            (and
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
               ))))
              ) p$
             )
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$7 (%I i$)))
               (let
                ((tmp%%$8 512))
                (and
                 (<= tmp%%$ tmp%%$7)
                 (< tmp%%$7 tmp%%$8)
            )))))
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                   (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                       $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                         (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           self!
                         ))
                        ) p$
                    ))))
                   ) i$
           ))))))))
           (not (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                   (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                       $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                         (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           self!
                         ))
                        ) p$
                    ))))
                   ) i$
          )))))))))
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) p$
                 ))))
                ) i$
        ))))))))
        :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) p$
                 ))))
                ) i$
          ))))))
         ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) p$
                 ))))
                ) i$
          ))))))
         ) (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
               self!
           ))))
          ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
               (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                   $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                     (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       self!
                     ))
                    ) p$
                ))))
               ) i$
        )))))))
        :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_5
        :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_l3_5
    ))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.?
      self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.wf_l3.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.wf_l3.?_definition
))))
(declare-fun req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.
 (Poly Poly Poly) Bool
)
(declare-const %%global_location_label%%11 Bool)
(declare-const %%global_location_label%%12 Bool)
(assert
 (forall ((self! Poly) (l4i! Poly) (l3i! Poly)) (!
   (= (req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.
     self! l4i! l3i!
    ) (and
     (=>
      %%global_location_label%%11
      (let
       ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
           self!
       ))))
       (let
        ((tmp%%$1 (%I l4i!)))
        (let
         ((tmp%%$2 512))
         (and
          (<= tmp%%$ tmp%%$1)
          (< tmp%%$1 tmp%%$2)
     )))))
     (=>
      %%global_location_label%%12
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 (%I l3i!)))
        (let
         ((tmp%%$2 512))
         (and
          (<= tmp%%$ tmp%%$1)
          (< tmp%%$1 tmp%%$2)
   )))))))
   :pattern ((req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.
     self! l4i! l3i!
   ))
   :qid internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_1g_l3._definition
   :skolemid skolem_internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_1g_l3._definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.)
  (forall ((self! Poly) (l4i! Poly) (l3i! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
      self! l4i! l3i!
     ) (ite
      (is-core!option.Option./None (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
        self! l4i!
      ))
      core!option.Option./None
      (ite
       (or
        (not (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                        (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                         (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
                            self! l4i!
                 )))))))))))
                ) l3i!
        ))))))))
        (not (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                      ))
                     ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                        (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                         (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
                            self! l4i!
                 )))))))))))
                ) l3i!
       )))))))))
       core!option.Option./None
       (core!option.Option./Some (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
         (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
          (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
           (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
              $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
                ))
               ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_l4.?
                      self! l4i!
           )))))))))))
          ) l3i!
    ))))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
      self! l4i! l3i!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_1g_l3.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_1g_l3.?_definition
))))
(assert
 (forall ((self! Poly) (l4i! Poly) (l3i! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
     (has_type l4i! USIZE)
     (has_type l3i! USIZE)
    )
    (has_type (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
       self! l4i! l3i!
      )
     ) (TYPE%core!option.Option. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
   ))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
     self! l4i! l3i!
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_1g_l3.?_pre_post_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.spec_resolve_mapping_1g_l3.?_pre_post_definition
)))
(declare-fun req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.
 (Poly) Bool
)
(declare-const %%global_location_label%%13 Bool)
(declare-const %%global_location_label%%14 Bool)
(declare-const %%global_location_label%%15 Bool)
(declare-const %%global_location_label%%16 Bool)
(assert
 (forall ((i! Poly)) (!
   (= (req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.
     i!
    ) (and
     (=>
      %%global_location_label%%13
      (<= (%I (tuple%4./tuple%4/0 (%Poly%tuple%4. i!))) 511)
     )
     (=>
      %%global_location_label%%14
      (<= (%I (tuple%4./tuple%4/1 (%Poly%tuple%4. i!))) 511)
     )
     (=>
      %%global_location_label%%15
      (<= (%I (tuple%4./tuple%4/2 (%Poly%tuple%4. i!))) 511)
     )
     (=>
      %%global_location_label%%16
      (<= (%I (tuple%4./tuple%4/3 (%Poly%tuple%4. i!))) 511)
   )))
   :pattern ((req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.
     i!
   ))
   :qid internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va._definition
   :skolemid skolem_internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va._definition
)))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.)
  (forall ((i! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
      i!
     ) (uClip SZ (bitand (I (uClip SZ (bitand (I (uClip SZ (bitand (I (uClip SZ (bitshl (I (uClip SZ
                  (%I (tuple%4./tuple%4/0 (%Poly%tuple%4. i!)))
                 )
                ) (I 39)
              ))
             ) (I (uClip SZ (bitshl (I (uClip SZ (%I (tuple%4./tuple%4/1 (%Poly%tuple%4. i!)))))
                (I 30)
           )))))
          ) (I (uClip SZ (bitshl (I (uClip SZ (%I (tuple%4./tuple%4/2 (%Poly%tuple%4. i!)))))
             (I 21)
        )))))
       ) (I (uClip SZ (bitshl (I (uClip SZ (%I (tuple%4./tuple%4/3 (%Poly%tuple%4. i!)))))
          (I 12)
    ))))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
      i!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?_definition
))))
(assert
 (forall ((i! Poly)) (!
   (=>
    (has_type i! (TYPE%tuple%4. $ USIZE $ USIZE $ USIZE $ USIZE))
    (uInv SZ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
      i!
   )))
   :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
     i!
   ))
   :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?_pre_post_definition
   :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?_pre_post_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (and
   (=>
    %%location_label%%0
    (uInv SZ (Mul 2 1024))
   )
   (=>
    (uInv SZ (Mul 2 1024))
    (=>
     %%location_label%%1
     (uInv SZ (Mul (uClip SZ (Mul 2 1024)) 1024))
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.)
  (= OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.?
   (uClip SZ (Mul (uClip SZ (Mul 2 1024)) 1024))
)))
(assert
 (uInv SZ OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.?)
)
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.)
  (forall ((ptr! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.?
      ptr!
     ) (and
      (= (EucMod (%I ptr!) 1073741824) 0)
      (< (EucDiv (%I ptr!) 4096) OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!NUM_PAGES.?)
    ))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.?
      ptr!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.)
)
(assert
 (=>
  (fuel_bool fuel%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.)
  (forall ((self! Poly)) (!
    (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.?
      self!
     ) (and
      (and
       (and
        (forall ((va$ Poly)) (!
          (=>
           (has_type va$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
               (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
             ) va$
            )
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?
             va$
          )))
          :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_va_2m_valid.?
            va$
           ) (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
              (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
             ))))
            ) va$
          ))
          :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_0
          :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_0
        ))
        (forall ((l4i$ Poly) (l3i$ Poly)) (!
          (=>
           (and
            (has_type l4i$ USIZE)
            (has_type l3i$ USIZE)
           )
           (=>
            (and
             (let
              ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
              (let
               ((tmp%%$1 (%I l4i$)))
               (let
                ((tmp%%$2 512))
                (and
                 (<= tmp%%$ tmp%%$1)
                 (< tmp%%$1 tmp%%$2)
             ))))
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$4 (%I l3i$)))
               (let
                ((tmp%%$5 512))
                (and
                 (<= tmp%%$ tmp%%$4)
                 (< tmp%%$4 tmp%%$5)
            )))))
            (= (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
               ))))
              ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
                (Poly%tuple%4. (tuple%4./tuple%4 l4i$ l3i$ (I 0) (I 0)))
              ))
             ) (is-core!option.Option./Some (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
               self! l4i$ l3i$
          )))))
          :pattern ((vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
            (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
               self!
             ))
            ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
              (Poly%tuple%4. (tuple%4./tuple%4 l4i$ l3i$ (I 0) (I 0)))
          ))))
          :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
            self! l4i$ l3i$
          ))
          :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_1
          :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_1
       )))
       (forall ((l4i$ Poly) (l3i$ Poly)) (!
         (=>
          (and
           (has_type l4i$ USIZE)
           (has_type l3i$ USIZE)
          )
          (=>
           (and
            (and
             (let
              ((tmp%%$ (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/kernel_l4_end
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
              ))))
              (let
               ((tmp%%$7 (%I l4i$)))
               (let
                ((tmp%%$8 512))
                (and
                 (<= tmp%%$ tmp%%$7)
                 (< tmp%%$7 tmp%%$8)
             ))))
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$10 (%I l3i$)))
               (let
                ((tmp%%$11 512))
                (and
                 (<= tmp%%$ tmp%%$10)
                 (< tmp%%$10 tmp%%$11)
            )))))
            (is-core!option.Option./Some (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
              self! l4i$ l3i$
           )))
           (and
            (and
             (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                 (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                  ))
                 ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
                   (Poly%tuple%4. (tuple%4./tuple%4 l4i$ l3i$ (I 0) (I 0)))
               ))))
              ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
                    self! l4i$ l3i$
             )))))))
             (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/write
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                 (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                  ))
                 ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
                   (Poly%tuple%4. (tuple%4./tuple%4 l4i$ l3i$ (I 0) (I 0)))
               ))))
              ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/write
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                    (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
                       self! l4i$ l3i$
            )))))))))))
            (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/execute_disable
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
               (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
                (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
                 ))
                ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
                  (Poly%tuple%4. (tuple%4./tuple%4 l4i$ l3i$ (I 0) (I 0)))
              ))))
             ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/execute_disable
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
                      self! l4i$ l3i$
         )))))))))))))
         :pattern ((vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
           (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
              self!
            ))
           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
             (Poly%tuple%4. (tuple%4./tuple%4 l4i$ l3i$ (I 0) (I 0)))
         ))))
         :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
           self! l4i$ l3i$
         ))
         :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_2
         :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_2
      )))
      (forall ((va$ Poly)) (!
        (=>
         (has_type va$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
            ))))
           ) va$
          )
          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.?
           (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
              (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
               (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
                ))
               ) va$
        )))))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
            (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
               self!
           ))))
          ) va$
         ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!page_ptr_1g_valid.?
          (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
              (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
               ))
              ) va$
        ))))))
        :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_3
        :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__wf_mapping_1g_3
    ))))
    :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.?
      self!
    ))
    :qid internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.wf_mapping_1g.?_definition
    :skolemid skolem_internal_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__5.wf_mapping_1g.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_vstd__view__impl&__14_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__14_trait_impl_definition
)))
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 64))
)
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 32))
)
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_vstd__view__impl&__46_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__46_trait_impl_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__48_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__48_trait_impl_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
    )
    (tr_bound%vstd!view.View. (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&. A2&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A2&.) (TYPE%tuple%3. A0&. A0& A1&. A1& A2&.
      A2&
   )))
   :qid internal_vstd__view__impl&__50_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__50_trait_impl_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (A2&. Dcr) (A2& Type) (A3&. Dcr)
   (A3& Type)
  ) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (sized A2&.)
     (sized A3&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
     (tr_bound%vstd!view.View. A2&. A2&)
     (tr_bound%vstd!view.View. A3&. A3&)
    )
    (tr_bound%vstd!view.View. (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&. A2& A3&.
      A3&
   )))
   :pattern ((tr_bound%vstd!view.View. (DST A3&.) (TYPE%tuple%4. A0&. A0& A1&. A1& A2&.
      A2& A3&. A3&
   )))
   :qid internal_vstd__view__impl&__52_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__52_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__15_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ USIZE)
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 64))
)
(assert
 (tr_bound%core!clone.Clone. $ (SINT 32))
)
(assert
 (tr_bound%core!clone.Clone. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (REF T&.) T&)
   :pattern ((tr_bound%core!clone.Clone. (REF T&.) T&))
   :qid internal_core__clone__impls__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__impl&__20_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__35_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__35_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__32_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!clone.Clone. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__7_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!clone.Clone. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__9_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ INT)
)
(assert
 (tr_bound%core!clone.Clone. $ NAT)
)
(assert
 (tr_bound%core!marker.Copy. $ USIZE)
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 64))
)
(assert
 (tr_bound%core!marker.Copy. $ (SINT 32))
)
(assert
 (tr_bound%core!marker.Copy. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (REF T&.) T&)
   :pattern ((tr_bound%core!marker.Copy. (REF T&.) T&))
   :qid internal_core__marker__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__4_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!marker.Copy. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!marker.Copy. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__impl&__19_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__19_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!marker.Copy. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!marker.Copy. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__54_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__54_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!marker.Copy. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__8_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__8_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!marker.Copy. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__10_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__10_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ INT)
)
(assert
 (tr_bound%core!marker.Copy. $ NAT)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(declare-const tmp%1 Poly)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(declare-const tmp%4 Poly)
(declare-const tmp%5 Poly)
(declare-const tmp%6 Poly)
(declare-const tmp%7 Poly)
(declare-const tmp%8 Poly)
(declare-const tmp%9 Poly)
(declare-const tmp%10 Poly)
(declare-const tmp%11 Poly)
(declare-const tmp%12 Poly)
(declare-const tmp%13 Poly)
(declare-const tmp%14 Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(declare-const tmp%1 Poly)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(declare-const tmp%4 Poly)
(declare-const tmp%5 Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.)
)
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (
      DST (REF Self%&.)
     ) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $))
  (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST
     (REF (REF T&.))
    ) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&.
       N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&.
       T& N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_core__array__impl&__20__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T&
       N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY
       T&. T& N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_core__array__impl&__20__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T&
       N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY
       T&. T& N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_core__array__impl&__20__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (
      DST (REF (GHOST T&.))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
      T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_core__option__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_core__option__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_core__option__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&)
     (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
       T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(declare-fun req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%6.ps_entries_exist_in_mapped_pages_l3.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 Bool
)
(declare-const %%global_location_label%%17 Bool)
(declare-const %%global_location_label%%18 Bool)
(declare-const %%global_location_label%%19 Bool)
(assert
 (forall ((self! OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%6.ps_entries_exist_in_mapped_pages_l3.
     self!
    ) (and
     (=>
      %%global_location_label%%17
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.?
       (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
        self!
     )))
     (=>
      %%global_location_label%%18
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.?
       (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
        self!
     )))
     (=>
      %%global_location_label%%19
      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.?
       (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
        self!
   )))))
   :pattern ((req%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%6.ps_entries_exist_in_mapped_pages_l3.
     self!
   ))
   :qid internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__6.ps_entries_exist_in_mapped_pages_l3._definition
   :skolemid skolem_internal_req__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__6.ps_entries_exist_in_mapped_pages_l3._definition
)))
(declare-fun ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%6.ps_entries_exist_in_mapped_pages_l3.
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
 Bool
)
(assert
 (forall ((self! OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.))
  (!
   (= (ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%6.ps_entries_exist_in_mapped_pages_l3.
     self!
    ) (and
     (forall ((p$ Poly) (i$ Poly)) (!
       (=>
        (and
         (has_type p$ USIZE)
         (has_type i$ USIZE)
        )
        (=>
         (and
          (and
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
              )))))
             ) p$
            )
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 512))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
           )))))
           (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           self!
                        )))
                       ) p$
                   ))))
                  ) i$
          ))))))))
          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                       )))
                      ) p$
                  ))))
                 ) i$
         ))))))))
         (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.?
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
            self!
           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                      )))
                     ) p$
                 ))))
                ) i$
           )))))
          ) false
       )))
       :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
           (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
            (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
             (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                     self!
                  )))
                 ) p$
             ))))
            ) i$
       )))))
       :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_0
       :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_0
     ))
     (forall ((p$ Poly) (i$ Poly)) (!
       (=>
        (and
         (has_type p$ USIZE)
         (has_type i$ USIZE)
        )
        (=>
         (and
          (and
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
              )))))
             ) p$
            )
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 512))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
           )))))
           (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           self!
                        )))
                       ) p$
                   ))))
                  ) i$
          ))))))))
          (not (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           self!
                        )))
                       ) p$
                   ))))
                  ) i$
         )))))))))
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
           )))))
          ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
            (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
               (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                   $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                     (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                      (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        self!
                     )))
                    ) p$
                ))))
               ) i$
       ))))))))
       :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
           (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
            (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
             (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                     self!
                  )))
                 ) p$
             ))))
            ) i$
       )))))
       :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_1
       :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_1
   ))))
   :pattern ((ens%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%6.ps_entries_exist_in_mapped_pages_l3.
     self!
   ))
   :qid internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__6.ps_entries_exist_in_mapped_pages_l3._definition
   :skolemid skolem_internal_ens__OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&__6.ps_entries_exist_in_mapped_pages_l3._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.)
(declare-const tmp%1 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
   self!
  ) TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
))
(assert
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l4.?
  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
   self!
)))
(assert
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_l3.?
  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
   self!
)))
(assert
 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.wf_mapping_1g.?
  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
   self!
)))
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(assert
 (not (=>
   (= tmp%1 (forall ((p$ Poly) (i$ Poly)) (!
      (=>
       (and
        (has_type p$ USIZE)
        (has_type i$ USIZE)
       )
       (=>
        (and
         (and
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
             )))))
            ) p$
           )
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 512))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
          )))))
          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                       )))
                      ) p$
                  ))))
                 ) i$
         ))))))))
         (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                      )))
                     ) p$
                 ))))
                ) i$
        ))))))))
        (and
         (and
          (and
           (is-core!option.Option./Some (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
              self!
             ) (vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
               )))
              ) p$
             ) i$
           ))
           (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (core!option.Option./Some/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (%Poly%core!option.Option. (Poly%core!option.Option. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.spec_resolve_mapping_1g_l3.?
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   self!
                  ) (vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>. (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       self!
                    )))
                   ) p$
                  ) i$
             )))))
            ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                      (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                       (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                        (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         self!
                      )))
                     ) p$
                 ))))
                ) i$
          ))))))
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/mapping_1g
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 self!
            )))))
           ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
             (Poly%tuple%4. (tuple%4./tuple%4 (vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                 )))
                ) p$
               ) i$ (I 0) (I 0)
         ))))))
         (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry./MapEntry/addr
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
            (vstd!map.impl&%0.index.? $ USIZE $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.
             (Poly%vstd!map.Map<usize./OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!MapEntry.>.
              (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.mapping_1g.?
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                self!
              ))
             ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!spec_index2va.?
               (Poly%tuple%4. (tuple%4./tuple%4 (vstd!map.impl&%0.index.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_rev_map
                    (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                     (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      self!
                   )))
                  ) p$
                 ) i$ (I 0) (I 0)
           ))))))
          ) (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       self!
                    )))
                   ) p$
               ))))
              ) i$
      ))))))))
      :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
         (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
           (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
            (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
               $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                  (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                   (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    self!
                 )))
                ) p$
            ))))
           ) i$
      )))))
      :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_4
      :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_4
   )))
   (and
    (=>
     %%location_label%%0
     tmp%1
    )
    (=>
     tmp%1
     (and
      (=>
       %%location_label%%1
       (forall ((p$ Poly) (i$ Poly)) (!
         (=>
          (and
           (has_type p$ USIZE)
           (has_type i$ USIZE)
          )
          (=>
           (and
            (and
             (and
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                     self!
                )))))
               ) p$
              )
              (let
               ((tmp%%$ 0))
               (let
                ((tmp%%$1 (%I i$)))
                (let
                 ((tmp%%$2 512))
                 (and
                  (<= tmp%%$ tmp%%$1)
                  (< tmp%%$1 tmp%%$2)
             )))))
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                             self!
                          )))
                         ) p$
                     ))))
                    ) i$
            ))))))))
            (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
             (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
              (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                   (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                    (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                       $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                         (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                          (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            self!
                         )))
                        ) p$
                    ))))
                   ) i$
           ))))))))
           (= (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%5.page_not_mapped.?
             (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
              self!
             ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
               (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                 (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                        (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                         (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                           self!
                        )))
                       ) p$
                   ))))
                  ) i$
             )))))
            ) false
         )))
         :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       self!
                    )))
                   ) p$
               ))))
              ) i$
         )))))
         :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_2
         :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_2
      )))
      (=>
       %%location_label%%2
       (forall ((p$ Poly) (i$ Poly)) (!
         (=>
          (and
           (has_type p$ USIZE)
           (has_type i$ USIZE)
          )
          (=>
           (and
            (and
             (and
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                  (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                   (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                    (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                     self!
                )))))
               ) p$
              )
              (let
               ((tmp%%$ 0))
               (let
                ((tmp%%$1 (%I i$)))
                (let
                 ((tmp%%$2 512))
                 (and
                  (<= tmp%%$ tmp%%$1)
                  (< tmp%%$1 tmp%%$2)
             )))))
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/present
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                             self!
                          )))
                         ) p$
                     ))))
                    ) i$
            ))))))))
            (not (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm./PageEntryPerm/ps
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntryPerm.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/perm
                 (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                  (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                   (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                    (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                        $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                          (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                             self!
                          )))
                         ) p$
                     ))))
                    ) i$
           )))))))))
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
               (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l2_tables
                (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                 (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                  self!
             )))))
            ) (I (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
              (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
               (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
                (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                       (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                        (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                         (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                          self!
                       )))
                      ) p$
                  ))))
                 ) i$
         ))))))))
         :pattern ((OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry./PageEntry/addr
           (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
            (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageEntry.
             (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!impl&%0.spec_index.?
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageMap.>.>.
                    (OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable./PageTable/l3_tables
                     (%Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                      (Poly%OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3!PageTable.
                       self!
                    )))
                   ) p$
               ))))
              ) i$
         )))))
         :qid user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_3
         :skolemid skolem_user_OS__pagetable__pagetable_spec__impl1__ps_entries_exist_in_mapped_pages_l3__PageTable__ps_entries_exist_in_mapped_pages_l3_3
)))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
