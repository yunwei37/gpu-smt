(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const va! (_ BitVec 64))
(assert
 true
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (bvule (bvand (bvlshr va! ((_ zero_extend 58) (_ bv39 6))) ((_ zero_extend 55) (_ bv511
       9
     ))
    ) ((_ zero_extend 55) (_ bv511 9))
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
