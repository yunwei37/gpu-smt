(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.lemma_map_insert_domain. FuelId)
(declare-const fuel%vstd!map.lemma_map_insert_same. FuelId)
(declare-const fuel%vstd!map.axiom_map_insert_different. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map_lib.impl&%0.contains_key. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_same. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_different. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.contains. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_same. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_different. FuelId)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.
 FuelId
)
(declare-const fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!function.axiom_fn_mut_call_requires. fuel%vstd!function.axiom_fn_mut_call_ensures.
  fuel%vstd!iset.lemma_iset_ext_equal. fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index.
  fuel%vstd!map.axiom_map_index_decreases. fuel%vstd!map.lemma_map_insert_domain. fuel%vstd!map.lemma_map_insert_same.
  fuel%vstd!map.axiom_map_insert_different. fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep.
  fuel%vstd!map_lib.impl&%0.contains_key. fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.lemma_seq_index_decreases.
  fuel%vstd!seq.lemma_seq_push_len. fuel%vstd!seq.lemma_seq_push_index_same. fuel%vstd!seq.lemma_seq_push_index_different.
  fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep. fuel%vstd!seq_lib.impl&%0.contains.
  fuel%vstd!set.Set.contains. fuel%vstd!set.axiom_set_ext_equal. fuel%vstd!set.axiom_set_ext_equal_deep.
  fuel%vstd!set.axiom_set_decreases_to_member. fuel%vstd!set.lemma_set_insert_same.
  fuel%vstd!set.lemma_set_insert_different. fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.
  fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue. fuel%vstd!array.group_array_axioms.
  fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas. fuel%vstd!iset.group_iset_lemmas.
  fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq. fuel%vstd!laws_eq.u8_laws.group_laws_eq.
  fuel%vstd!laws_eq.i8_laws.group_laws_eq. fuel%vstd!laws_eq.u16_laws.group_laws_eq.
  fuel%vstd!laws_eq.i16_laws.group_laws_eq. fuel%vstd!laws_eq.u32_laws.group_laws_eq.
  fuel%vstd!laws_eq.i32_laws.group_laws_eq. fuel%vstd!laws_eq.u64_laws.group_laws_eq.
  fuel%vstd!laws_eq.i64_laws.group_laws_eq. fuel%vstd!laws_eq.u128_laws.group_laws_eq.
  fuel%vstd!laws_eq.i128_laws.group_laws_eq. fuel%vstd!laws_eq.usize_laws.group_laws_eq.
  fuel%vstd!laws_eq.isize_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties.
  fuel%vstd!layout.group_layout_axioms. fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms.
  fuel%vstd!mut_ref.group_mut_ref_axioms. fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas.
  fuel%vstd!seq_lib.group_filter_ensures. fuel%vstd!seq_lib.group_seq_lib_default.
  fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default. fuel%vstd!slice.group_slice_axioms.
  fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.lemma_map_insert_domain.)
   (fuel_bool_default fuel%vstd!map.lemma_map_insert_same.)
   (fuel_bool_default fuel%vstd!map.axiom_map_insert_different.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_same.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_different.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_same.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_different.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch.
 (Dcr Type) Bool
)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-fun proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./ReadOperation
 (Dcr Type) Dcr
)
(declare-fun proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./ReadOperation
 (Dcr Type) Type
)
(declare-fun proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
 (Dcr Type) Dcr
)
(declare-fun proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
 (Dcr Type) Type
)
(declare-fun proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response
 (Dcr Type) Dcr
)
(declare-fun proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response
 (Dcr Type) Type
)
(declare-fun proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./View
 (Dcr Type) Dcr
)
(declare-fun proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./View
 (Dcr Type) Type
)
(declare-sort vstd!seq.Seq<nat.>. 0)
(declare-datatypes ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
   0
  ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. 0) (tuple%0.
   0
  )
 ) (((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/?op
     Poly
    ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/?node_id
     Int
   ))
  ) ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/?op
     Poly
    )
   ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/?op
     Poly
    ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/?idx Int)
   ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/?ret
     Poly
    ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/?idx
     Int
    )
   ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/?ret
     Poly
    ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/?idx Int)
   )
  ) ((tuple%0./tuple%0))
))
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op
 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.) Int
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op
 (Dcr Type NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op
 (Dcr Type NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx
 (Dcr Type NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Int
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret
 (Dcr Type NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx
 (Dcr Type NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Int
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret
 (Dcr Type NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx
 (Dcr Type NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Int
)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-fun TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (
  Dcr Type
 ) Type
)
(declare-fun TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
 (Dcr Type) Type
)
(declare-fun Poly%vstd!seq.Seq<nat.>. (vstd!seq.Seq<nat.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<nat.>. (Poly) vstd!seq.Seq<nat.>.)
(declare-fun Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (
  NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
 ) Poly
)
(declare-fun %Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
 (Poly) NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
)
(declare-fun Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.) Poly
)
(declare-fun %Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
 (Poly) NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(assert
 (forall ((x vstd!seq.Seq<nat.>.)) (!
   (= x (%Poly%vstd!seq.Seq<nat.>. (Poly%vstd!seq.Seq<nat.>. x)))
   :pattern ((Poly%vstd!seq.Seq<nat.>. x))
   :qid internal_vstd__seq__Seq<nat.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<nat.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ NAT))
    (= x (Poly%vstd!seq.Seq<nat.>. (%Poly%vstd!seq.Seq<nat.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ NAT)))
   :qid internal_vstd__seq__Seq<nat.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<nat.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<nat.>.)) (!
   (has_type (Poly%vstd!seq.Seq<nat.>. x) (TYPE%vstd!seq.Seq. $ NAT))
   :pattern ((has_type (Poly%vstd!seq.Seq<nat.>. x) (TYPE%vstd!seq.Seq. $ NAT)))
   :qid internal_vstd__seq__Seq<nat.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<nat.>_has_type_always_definition
)))
(assert
 (forall ((x NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)) (!
   (= x (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
      x
   )))
   :pattern ((Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. x))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogEntry_box_axiom_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogEntry_box_axiom_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
      DT&
    ))
    (= x (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
       x
   ))))
   :pattern ((has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogEntry_unbox_axiom_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogEntry_unbox_axiom_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (_op! Poly) (_node_id! Int)) (!
   (=>
    (and
     (has_type _op! (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
       DT&. DT&
     ))
     (<= 0 _node_id!)
    )
    (has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry
       _op! _node_id!
      )
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&. DT&)
   ))
   :pattern ((has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry _op! _node_id!)
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&. DT&)
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry_constructor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry_constructor_definition
)))
(assert
 (forall ((x NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)) (!
   (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op x)
    (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/?op x)
   )
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op
     x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
      DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op
      (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. x)
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
      DT&. DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op
     (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. x)
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op_invariant_definition
)))
(assert
 (forall ((x NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)) (!
   (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
     x
    ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/?node_id
     x
   ))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
     x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
      DT&
    ))
    (<= 0 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
      (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. x)
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
     (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. x)
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id_invariant_definition
)))
(assert
 (forall ((x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.)) (!
   (= x (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
   )))
   :pattern ((Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. x))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__UpdateState_box_axiom_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__UpdateState_box_axiom_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (= x (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       x
   ))))
   :pattern ((has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__UpdateState_unbox_axiom_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__UpdateState_unbox_axiom_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (_op! Poly)) (!
   (=>
    (has_type _op! (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
      DT&. DT&
    ))
    (has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (
       NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init _op!
      )
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :pattern ((has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init _op!)
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init_constructor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init_constructor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.))
  (!
   (=>
    (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init x)
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op DT&.
      DT& x
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/?op x)
   ))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op
     DT&. DT& x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op
      DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       x
      )
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
      DT&. DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op
     DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
     )
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op_invariant_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (_op! Poly) (_idx! Int)) (!
   (=>
    (and
     (has_type _op! (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
       DT&. DT&
     ))
     (<= 0 _idx!)
    )
    (has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (
       NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed _op! _idx!
      )
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :pattern ((has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed _op! _idx!)
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed_constructor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed_constructor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.))
  (!
   (=>
    (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed x)
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op DT&.
      DT& x
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/?op x)
   ))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op
     DT&. DT& x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op
      DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       x
      )
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
      DT&. DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op
     DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
     )
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op_invariant_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.))
  (!
   (=>
    (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed x)
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx DT&.
      DT& x
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/?idx x)
   ))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx
     DT&. DT& x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (<= 0 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx
      DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       x
   ))))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx
     DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
     )
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx_invariant_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (_ret! Poly) (_idx! Int)) (!
   (=>
    (and
     (has_type _ret! (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response
       DT&. DT&
     ))
     (<= 0 _idx!)
    )
    (has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (
       NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied _ret! _idx!
      )
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :pattern ((has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied _ret! _idx!)
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied_constructor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied_constructor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.))
  (!
   (=>
    (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied x)
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret DT&.
      DT& x
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/?ret
      x
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret
     DT&. DT& x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret
      DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       x
      )
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response DT&.
      DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret
     DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
     )
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret_invariant_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.))
  (!
   (=>
    (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied x)
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx DT&.
      DT& x
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/?idx
      x
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx
     DT&. DT& x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (<= 0 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx
      DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       x
   ))))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx
     DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
     )
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx_invariant_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (_ret! Poly) (_idx! Int)) (!
   (=>
    (and
     (has_type _ret! (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response
       DT&. DT&
     ))
     (<= 0 _idx!)
    )
    (has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (
       NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done _ret! _idx!
      )
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :pattern ((has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done _ret! _idx!)
     ) (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&. DT&)
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done_constructor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done_constructor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.))
  (!
   (=>
    (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done x)
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret DT&.
      DT& x
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/?ret x)
   ))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret
     DT&. DT& x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret
      DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       x
      )
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response DT&.
      DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret
     DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
     )
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret_invariant_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.))
  (!
   (=>
    (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done x)
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx DT&.
      DT& x
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/?idx x)
   ))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx
     DT&. DT& x
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx_accessor_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx_accessor_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (<= 0 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. x)
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx
     DT&. DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      x
     )
    ) (has_type x (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx_invariant_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx_invariant_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch. Self%&. Self%&)
    (and
     (sized Self%&.)
     (sized (proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./ReadOperation
       Self%&. Self%&
     ))
     (sized (proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
       Self%&. Self%&
     ))
     (sized (proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response
       Self%&. Self%&
     ))
     (sized (proj%%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./View Self%&.
       Self%&
   ))))
   :pattern ((tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch.
     Self%&. Self%&
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__Dispatch_trait_type_bounds_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append__Dispatch_trait_type_bounds_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.Seq.push.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.insert.? (Dcr Type Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!set.Set.insert.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!map_lib.impl&%0.contains_key.? (Dcr Type Dcr Type Poly Poly) Bool)
(declare-fun vstd!seq_lib.impl&%0.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.?
 (Dcr Type Poly) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.?
 (Dcr Type Poly) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.?
 (Dcr Type Poly) Int
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.?
 (Dcr Type Poly) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.?
 (Dcr Type Poly) Int
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.?
 (Dcr Type Poly) Poly
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.?
 (Dcr Type Poly) Int
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.?
 (Dcr Type Poly Poly) Bool
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?
 (Dcr Type Poly Poly Poly Poly Poly Poly Poly) Bool
)
(declare-fun NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.?
 (Dcr Type Poly Poly Poly Poly Poly Poly Poly Fuel) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!seq.Seq.push.? A&. A& self! a!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.push.? A&. A& self! a!))
   :qid internal_vstd!seq.Seq.push.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.push.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)) (nClip (Add (vstd!seq.Seq.len.?
          A&. A& s!
         ) 1
    )))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)))
    :qid user_vstd__seq__lemma_seq_push_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (= (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) a!)
    ))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_same_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (< (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) (vstd!seq.Seq.index.?
        A&. A& s! i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_different_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%2
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%3
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly) (value! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
     (has_type value! V&)
    )
    (has_type (vstd!map.impl&%0.insert.? K&. K& V&. V& self! key! value!) (TYPE%vstd!map.Map.
      K&. K& V&. V&
   )))
   :pattern ((vstd!map.impl&%0.insert.? K&. K& V&. V& self! key! value!))
   :qid internal_vstd!map.impl&__0.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.insert.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!set.Set. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!set.Set.insert.? A&. A& self! a!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!set.Set.insert.? A&. A& self! a!))
   :qid internal_vstd!set.Set.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.Set.insert.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_insert_domain.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly) (value! Poly))
   (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V& m!
         key! value!
        )
       ) (vstd!set.Set.insert.? K&. K& (vstd!map.impl&%0.dom.? K&. K& V&. V& m!) key!)
    )))
    :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&.
       V& m! key! value!
    )))
    :qid user_vstd__map__lemma_map_insert_domain_0
    :skolemid skolem_user_vstd__map__lemma_map_insert_domain_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_insert_same.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly) (value! Poly))
   (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V&
         m! key! value!
        ) key!
       ) value!
    )))
    :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K&
       V&. V& m! key! value!
      ) key!
    ))
    :qid user_vstd__map__lemma_map_insert_same_0
    :skolemid skolem_user_vstd__map__lemma_map_insert_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_insert_different.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key1! Poly) (key2! Poly)
    (value! Poly)
   ) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key1! K&)
      (has_type key2! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (not (= key1! key2!))
      )
      (= (vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V&
         m! key2! value!
        ) key1!
       ) (vstd!map.impl&%0.index.? K&. K& V&. V& m! key1!)
    )))
    :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K&
       V&. V& m! key2! value!
      ) key1!
    ))
    :qid user_vstd__map__axiom_map_insert_different_0
    :skolemid skolem_user_vstd__map__axiom_map_insert_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
         A&. A& s! a!
        )
       ) a!
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a!
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_insert_same_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a1! A&)
      (has_type a2! A&)
     )
     (=>
      (and
       (sized A&.)
       (not (= a1! a2!))
      )
      (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
          A&. A& s! a2!
         )
        ) a1!
       ) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a1!)
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a2!
       )
      ) a1!
    ))
    :qid user_vstd__set__lemma_set_insert_different_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(assert
 (fuel_bool_default fuel%vstd!map_lib.impl&%0.contains_key.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map_lib.impl&%0.contains_key.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (k! Poly)) (!
    (= (vstd!map_lib.impl&%0.contains_key.? K&. K& V&. V& self! k!) (vstd!iset.ISet.contains.?
      K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
      k!
    ))
    :pattern ((vstd!map_lib.impl&%0.contains_key.? K&. K& V&. V& self! k!))
    :qid internal_vstd!map_lib.impl&__0.contains_key.?_definition
    :skolemid skolem_internal_vstd!map_lib.impl&__0.contains_key.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (needle! Poly)) (!
    (= (vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!) (exists ((i$ Poly)) (!
       (and
        (has_type i$ INT)
        (and
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? A&. A& self! i$) needle!)
       ))
       :pattern ((vstd!seq.Seq.index.? A&. A& self! i$))
       :qid user_vstd__seq_lib__impl&%0__contains_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__contains_0
    )))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!))
    :qid internal_vstd!seq_lib.impl&__0.contains.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.contains.?_definition
))))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.
     DT&. DT& self!
    ) (=>
     %%global_location_label%%4
     (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       self!
   ))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.
     DT&. DT& self!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Init_op._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Init_op._definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.)
  (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.? DT&.
      DT& self!
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Init/op DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. self!)
    ))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.?
      DT&. DT& self!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Init_op.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Init_op.?_definition
))))
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.?
      DT&. DT& self!
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
      DT&. DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Init_op.?
     DT&. DT& self!
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Init_op.?_pre_post_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Init_op.?_pre_post_definition
)))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.
     DT&. DT& self!
    ) (=>
     %%global_location_label%%5
     (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       self!
   ))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.
     DT&. DT& self!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_op._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_op._definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.)
  (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.?
      DT&. DT& self!
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/op DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. self!)
    ))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.?
      DT&. DT& self!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_op.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_op.?_definition
))))
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.?
      DT&. DT& self!
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./WriteOperation
      DT&. DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_op.?
     DT&. DT& self!
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_op.?_pre_post_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_op.?_pre_post_definition
)))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.
     DT&. DT& self!
    ) (=>
     %%global_location_label%%6
     (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       self!
   ))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.
     DT&. DT& self!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_idx._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_idx._definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.)
  (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.?
      DT&. DT& self!
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. self!)
    ))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.?
      DT&. DT& self!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_idx.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_idx.?_definition
))))
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (<= 0 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.?
      DT&. DT& self!
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Placed_idx.?
     DT&. DT& self!
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_idx.?_pre_post_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Placed_idx.?_pre_post_definition
)))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.
     DT&. DT& self!
    ) (=>
     %%global_location_label%%7
     (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       self!
   ))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.
     DT&. DT& self!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_ret._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_ret._definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.)
  (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.?
      DT&. DT& self!
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/ret DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. self!)
    ))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.?
      DT&. DT& self!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_ret.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_ret.?_definition
))))
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.?
      DT&. DT& self!
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response DT&.
      DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_ret.?
     DT&. DT& self!
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_ret.?_pre_post_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_ret.?_pre_post_definition
)))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.
     DT&. DT& self!
    ) (=>
     %%global_location_label%%8
     (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       self!
   ))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.
     DT&. DT& self!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_idx._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_idx._definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.)
  (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.?
      DT&. DT& self!
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Applied/idx DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. self!)
    ))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.?
      DT&. DT& self!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_idx.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_idx.?_definition
))))
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (<= 0 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.?
      DT&. DT& self!
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Applied_idx.?
     DT&. DT& self!
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_idx.?_pre_post_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Applied_idx.?_pre_post_definition
)))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.
     DT&. DT& self!
    ) (=>
     %%global_location_label%%9
     (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       self!
   ))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.
     DT&. DT& self!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_ret._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_ret._definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.)
  (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.? DT&.
      DT& self!
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/ret DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. self!)
    ))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.?
      DT&. DT& self!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_ret.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_ret.?_definition
))))
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (has_type (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.?
      DT&. DT& self!
     ) (proj%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch./Response DT&.
      DT&
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_ret.?
     DT&. DT& self!
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_ret.?_pre_post_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_ret.?_pre_post_definition
)))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.
     DT&. DT& self!
    ) (=>
     %%global_location_label%%10
     (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
       self!
   ))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.
     DT&. DT& self!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_idx._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_idx._definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.)
  (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.? DT&.
      DT& self!
     ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Done/idx DT&.
      DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. self!)
    ))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.?
      DT&. DT& self!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_idx.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_idx.?_definition
))))
(assert
 (forall ((DT&. Dcr) (DT& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
      DT&. DT&
    ))
    (<= 0 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.?
      DT&. DT& self!
   )))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&%0.arrow_Done_idx.?
     DT&. DT& self!
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_idx.?_pre_post_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!impl&__0.arrow_Done_idx.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.)
)
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.)
  (forall ((DT&. Dcr) (DT& Type) (log! Poly) (end! Poly)) (!
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.?
      DT&. DT& log! end!
     ) (forall ((i$ Poly)) (!
       (=>
        (has_type i$ NAT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (%I end!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
            $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
             DT&
            ) log!
           )
          ) i$
       )))
       :pattern ((vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
           $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
            DT&
           ) log!
          )
         ) i$
       ))
       :qid user_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogContainsEntriesUpToHere_0
       :skolemid skolem_user_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogContainsEntriesUpToHere_0
    )))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.?
      DT&. DT& log! end!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.?_definition
))))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.
 (Dcr Type Poly Poly Poly Poly Poly Poly Poly) Bool
)
(declare-const %%global_location_label%%11 Bool)
(declare-const %%global_location_label%%12 Bool)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (queue! Poly) (log! Poly) (queueIndex! Poly) (logIndexLower!
    Poly
   ) (logIndexUpper! Poly) (nodeId! Poly) (updates! Poly)
  ) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.
     DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates!
    ) (and
     (=>
      %%global_location_label%%11
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 (%I queueIndex!)))
        (let
         ((tmp%%$2 (vstd!seq.Seq.len.? $ NAT queue!)))
         (and
          (<= tmp%%$ tmp%%$1)
          (<= tmp%%$1 tmp%%$2)
     )))))
     (=>
      %%global_location_label%%12
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogContainsEntriesUpToHere.?
       DT&. DT& log! logIndexUpper!
     ))
     (=>
      %%global_location_label%%13
      (<= (%I logIndexLower!) (%I logIndexUpper!))
   )))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.
     DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const DT&. Dcr)
(declare-const DT& Type)
(declare-const queue! Poly)
(declare-const log! Poly)
(declare-const queueIndex! Poly)
(declare-const logIndexLower! Poly)
(declare-const logIndexUpper! Poly)
(declare-const nodeId! Poly)
(declare-const updates! Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(declare-const tmp%4 Bool)
(declare-const tmp%5 Bool)
(declare-const tmp%6 Bool)
(declare-const tmp%7 Bool)
(declare-const tmp%8 Poly)
(declare-const tmp%9 Bool)
(declare-const tmp%10 Bool)
(declare-const tmp%11 Bool)
(declare-const tmp%12 Bool)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(assert
 (sized DT&.)
)
(assert
 (tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch. DT&. DT&)
)
(assert
 (has_type queue! (TYPE%vstd!seq.Seq. $ NAT))
)
(assert
 (has_type log! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
    DT&. DT&
))))
(assert
 (has_type queueIndex! NAT)
)
(assert
 (has_type logIndexLower! NAT)
)
(assert
 (has_type logIndexUpper! NAT)
)
(assert
 (has_type nodeId! NAT)
)
(assert
 (has_type updates! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
    DT&. DT&
))))
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%switch_label%%2 Bool)
(declare-const %%switch_label%%3 Bool)
(declare-const %%switch_label%%4 Bool)
(declare-const %%switch_label%%5 Bool)
(declare-const %%switch_label%%6 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (=>
   (= decrease%init0 (Sub (%I logIndexUpper!) (%I logIndexLower!)))
   (=>
    (sized DT&.)
    (=>
     (tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch. DT&. DT&)
     (=>
      (<= (%I logIndexLower!) (%I logIndexUpper!))
      (or
       (and
        (=>
         (=>
          (= logIndexLower! logIndexUpper!)
          (= (%I queueIndex!) (vstd!seq.Seq.len.? $ NAT queue!))
         )
         (or
          (and
           (=>
            (< (%I logIndexLower!) (%I logIndexUpper!))
            (or
             (and
              (=>
               (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                  $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                   DT&
                  ) log!
                 )
                ) logIndexLower!
               )
               (or
                (and
                 (=>
                  (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                    (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                      $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                       DT&
                      ) log! logIndexLower!
                    ))
                   ) (%I nodeId!)
                  )
                  (or
                   (and
                    (=>
                     (and
                      (and
                       (and
                        (< (%I queueIndex!) (vstd!seq.Seq.len.? $ NAT queue!))
                        (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                           $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
                            DT&
                           ) updates!
                          )
                         ) (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
                       ))
                       (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
                         (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
                           DT&. DT&
                          ) updates! (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
                      ))))
                      (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx DT&.
                        DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (vstd!map.impl&%0.index.?
                          $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
                           DT&
                          ) updates! (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
                        ))
                       ) (%I logIndexLower!)
                     ))
                     (=>
                      (= tmp%2 (I (nClip (Add (%I queueIndex!) 1))))
                      (=>
                       (= tmp%3 (I (nClip (Add (%I logIndexLower!) 1))))
                       (and
                        (=>
                         %%location_label%%0
                         (check_decrease_height (I (let
                            ((queue!$0 (%Poly%vstd!seq.Seq<nat.>. queue!)) (log!$1 log!) (queueIndex!$2 (%I tmp%2))
                             (logIndexLower!$3 (%I tmp%3)) (logIndexUpper!$4 (%I logIndexUpper!)) (nodeId!$5 (%I
                               nodeId!
                              )
                             ) (updates!$6 updates!)
                            )
                            (Sub logIndexUpper!$4 logIndexLower!$3)
                           )
                          ) (I decrease%init0) false
                        ))
                        (=>
                         (= tmp%1 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?
                           DT&. DT& queue! log! (I (nClip (Add (%I queueIndex!) 1))) (I (nClip (Add (%I logIndexLower!)
                              1
                            ))
                           ) logIndexUpper! nodeId! updates!
                         ))
                         (=>
                          (= tmp%4 tmp%1)
                          %%switch_label%%6
                    ))))))
                    (=>
                     (not (and
                       (and
                        (and
                         (< (%I queueIndex!) (vstd!seq.Seq.len.? $ NAT queue!))
                         (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                            $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
                             DT&
                            ) updates!
                           )
                          ) (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
                        ))
                        (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
                          (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
                            DT&. DT&
                           ) updates! (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
                       ))))
                       (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx DT&.
                         DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (vstd!map.impl&%0.index.?
                           $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
                            DT&
                           ) updates! (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
                         ))
                        ) (%I logIndexLower!)
                     )))
                     (=>
                      (= tmp%4 false)
                      %%switch_label%%6
                   )))
                   (and
                    (not %%switch_label%%6)
                    (=>
                     (= tmp%5 tmp%4)
                     %%switch_label%%5
                 ))))
                 (=>
                  (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                     (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                       $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                        DT&
                       ) log! logIndexLower!
                     ))
                    ) (%I nodeId!)
                  ))
                  (=>
                   (= tmp%5 true)
                   %%switch_label%%5
                )))
                (and
                 (not %%switch_label%%5)
                 (=>
                  (= tmp%6 tmp%5)
                  %%switch_label%%4
              ))))
              (=>
               (not (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                   $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                    DT&
                   ) log!
                  )
                 ) logIndexLower!
               ))
               (=>
                (= tmp%6 false)
                %%switch_label%%4
             )))
             (and
              (not %%switch_label%%4)
              (or
               (and
                (=>
                 tmp%6
                 (or
                  (and
                   (=>
                    (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                       (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                         $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                          DT&
                         ) log! logIndexLower!
                       ))
                      ) (%I nodeId!)
                    ))
                    (=>
                     (= tmp%8 (I (nClip (Add (%I logIndexLower!) 1))))
                     (and
                      (=>
                       %%location_label%%1
                       (check_decrease_height (I (let
                          ((queue!$0 (%Poly%vstd!seq.Seq<nat.>. queue!)) (log!$1 log!) (queueIndex!$2 (%I queueIndex!))
                           (logIndexLower!$3 (%I tmp%8)) (logIndexUpper!$4 (%I logIndexUpper!)) (nodeId!$5 (%I
                             nodeId!
                            )
                           ) (updates!$6 updates!)
                          )
                          (Sub logIndexUpper!$4 logIndexLower!$3)
                         )
                        ) (I decrease%init0) false
                      ))
                      (=>
                       (= tmp%7 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?
                         DT&. DT& queue! log! queueIndex! (I (nClip (Add (%I logIndexLower!) 1))) logIndexUpper!
                         nodeId! updates!
                       ))
                       (=>
                        (= tmp%9 tmp%7)
                        %%switch_label%%3
                   )))))
                   (=>
                    (not (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                        (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                          $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                           DT&
                          ) log! logIndexLower!
                        ))
                       ) (%I nodeId!)
                    )))
                    (=>
                     (= tmp%9 true)
                     %%switch_label%%3
                  )))
                  (and
                   (not %%switch_label%%3)
                   (=>
                    (= tmp%10 tmp%9)
                    %%switch_label%%2
                ))))
                (=>
                 (not tmp%6)
                 (=>
                  (= tmp%10 false)
                  %%switch_label%%2
               )))
               (and
                (not %%switch_label%%2)
                (=>
                 (= tmp%11 tmp%10)
                 %%switch_label%%1
           ))))))
           (=>
            (not (< (%I logIndexLower!) (%I logIndexUpper!)))
            (=>
             (= tmp%11 true)
             %%switch_label%%1
          )))
          (and
           (not %%switch_label%%1)
           (=>
            (= tmp%12 tmp%11)
            %%switch_label%%0
        ))))
        (=>
         (not (=>
           (= logIndexLower! logIndexUpper!)
           (= (%I queueIndex!) (vstd!seq.Seq.len.? $ NAT queue!))
         ))
         (=>
          (= tmp%12 false)
          %%switch_label%%0
       )))
       (not %%switch_label%%0)
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.)
)
(declare-const fuel_nat%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.
 Fuel
)
(assert
 (forall ((DT&. Dcr) (DT& Type) (queue! Poly) (log! Poly) (queueIndex! Poly) (logIndexLower!
    Poly
   ) (logIndexUpper! Poly) (nodeId! Poly) (updates! Poly) (fuel% Fuel)
  ) (!
   (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.?
     DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates! fuel%
    ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.?
     DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates! zero
   ))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.?
     DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates! fuel%
   ))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue._fuel_to_zero_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue._fuel_to_zero_definition
)))
(assert
 (forall ((DT&. Dcr) (DT& Type) (queue! Poly) (log! Poly) (queueIndex! Poly) (logIndexLower!
    Poly
   ) (logIndexUpper! Poly) (nodeId! Poly) (updates! Poly) (fuel% Fuel)
  ) (!
   (=>
    (and
     (sized DT&.)
     (tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch. DT&. DT&)
     (has_type queue! (TYPE%vstd!seq.Seq. $ NAT))
     (has_type log! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
        DT&. DT&
     )))
     (has_type queueIndex! NAT)
     (has_type logIndexLower! NAT)
     (has_type logIndexUpper! NAT)
     (has_type nodeId! NAT)
     (has_type updates! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
        DT&. DT&
     )))
     (<= (%I logIndexLower!) (%I logIndexUpper!))
    )
    (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.?
      DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates! (
       succ fuel%
      )
     ) (and
      (=>
       (= logIndexLower! logIndexUpper!)
       (= (%I queueIndex!) (vstd!seq.Seq.len.? $ NAT queue!))
      )
      (=>
       (< (%I logIndexLower!) (%I logIndexUpper!))
       (and
        (and
         (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
            $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
             DT&
            ) log!
           )
          ) logIndexLower!
         )
         (=>
          (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
            (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
              $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
               DT&
              ) log! logIndexLower!
            ))
           ) (%I nodeId!)
          )
          (and
           (and
            (and
             (and
              (< (%I queueIndex!) (vstd!seq.Seq.len.? $ NAT queue!))
              (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                 $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
                  DT&
                 ) updates!
                )
               ) (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
             ))
             (is-NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
               (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
                 DT&. DT&
                ) updates! (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
            ))))
            (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed/idx DT&.
              DT& (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (vstd!map.impl&%0.index.?
                $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
                 DT&
                ) updates! (vstd!seq.Seq.index.? $ NAT queue! queueIndex!)
              ))
             ) (%I logIndexLower!)
           ))
           (NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.? DT&.
            DT& queue! log! (I (nClip (Add (%I queueIndex!) 1))) (I (nClip (Add (%I logIndexLower!)
               1
             ))
            ) logIndexUpper! nodeId! updates! fuel%
        ))))
        (=>
         (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
            (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
              $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
               DT&
              ) log! logIndexLower!
            ))
           ) (%I nodeId!)
         ))
         (NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.? DT&.
          DT& queue! log! queueIndex! (I (nClip (Add (%I logIndexLower!) 1))) logIndexUpper!
          nodeId! updates! fuel%
   )))))))
   :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.?
     DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates! (
      succ fuel%
   )))
   :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue._fuel_to_body_definition
   :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.)
  (forall ((DT&. Dcr) (DT& Type) (queue! Poly) (log! Poly) (queueIndex! Poly) (logIndexLower!
     Poly
    ) (logIndexUpper! Poly) (nodeId! Poly) (updates! Poly)
   ) (!
    (=>
     (and
      (sized DT&.)
      (tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch. DT&. DT&)
      (has_type queue! (TYPE%vstd!seq.Seq. $ NAT))
      (has_type log! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
         DT&. DT&
      )))
      (has_type queueIndex! NAT)
      (has_type logIndexLower! NAT)
      (has_type logIndexUpper! NAT)
      (has_type nodeId! NAT)
      (has_type updates! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
         DT&. DT&
      )))
      (<= (%I logIndexLower!) (%I logIndexUpper!))
     )
     (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.? DT&.
       DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates!
      ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!rec%LogRangeMatchesQueue.?
       DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates! (
        succ fuel_nat%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.
    ))))
    :pattern ((NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?
      DT&. DT& queue! log! queueIndex! logIndexLower! logIndexUpper! nodeId! updates!
    ))
    :qid internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?_definition
    :skolemid skolem_internal_NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(declare-fun req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
 (Dcr Type vstd!seq.Seq<nat.>. Poly Poly Int Int Int Int Poly Poly Int NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)
 Bool
)
(declare-const %%global_location_label%%14 Bool)
(declare-const %%global_location_label%%15 Bool)
(declare-const %%global_location_label%%16 Bool)
(declare-const %%global_location_label%%17 Bool)
(declare-const %%global_location_label%%18 Bool)
(declare-const %%global_location_label%%19 Bool)
(declare-const %%global_location_label%%20 Bool)
(declare-const %%global_location_label%%21 Bool)
(declare-const %%global_location_label%%22 Bool)
(assert
 (forall ((DT&. Dcr) (DT& Type) (queue! vstd!seq.Seq<nat.>.) (log! Poly) (new_log! Poly)
   (queueIndex! Int) (logIndexLower! Int) (logIndexUpper! Int) (node_id! Int) (updates!
    Poly
   ) (new_updates! Poly) (new_rid! Int) (log_entry! NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)
  ) (!
   (= (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
     DT&. DT& queue! log! new_log! queueIndex! logIndexLower! logIndexUpper! node_id!
     updates! new_updates! new_rid! log_entry!
    ) (and
     (=>
      %%global_location_label%%14
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 queueIndex!))
        (let
         ((tmp%%$2 (vstd!seq.Seq.len.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!))))
         (and
          (<= tmp%%$ tmp%%$1)
          (<= tmp%%$1 tmp%%$2)
     )))))
     (=>
      %%global_location_label%%15
      (<= logIndexLower! logIndexUpper!)
     )
     (=>
      %%global_location_label%%16
      (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
        (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
          log_entry!
        ))
       ) node_id!
     ))
     (=>
      %%global_location_label%%17
      (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
         $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
          DT&
         ) new_updates!
        )
       ) (I new_rid!)
     ))
     (=>
      %%global_location_label%%18
      (= (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (vstd!map.impl&%0.index.?
         $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
          DT&
         ) new_updates! (I new_rid!)
        )
       ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op
         (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
           log_entry!
         ))
        ) (%I (I logIndexUpper!))
     )))
     (=>
      %%global_location_label%%19
      (not (vstd!seq_lib.impl&%0.contains.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!) (I new_rid!)))
     )
     (=>
      %%global_location_label%%20
      (forall ((rid$ Poly)) (!
        (=>
         (has_type rid$ NAT)
         (=>
          (and
           (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
              $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
               DT&
              ) updates!
             )
            ) rid$
           )
           (not (= (%I rid$) new_rid!))
          )
          (and
           (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
              $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
               DT&
              ) new_updates!
             )
            ) rid$
           )
           (= (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
              DT&. DT&
             ) new_updates! rid$
            ) (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
              DT&. DT&
             ) updates! rid$
        )))))
        :pattern ((vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
            $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
             DT&
            ) updates!
           )
          ) rid$
        ))
        :qid user_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogRangeMatchesQueue_append_0
        :skolemid skolem_user_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogRangeMatchesQueue_append_0
     )))
     (=>
      %%global_location_label%%21
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.? DT&.
       DT& (Poly%vstd!seq.Seq<nat.>. queue!) log! (I queueIndex!) (I logIndexLower!) (I logIndexUpper!)
       (I node_id!) updates!
     ))
     (=>
      %%global_location_label%%22
      (= new_log! (vstd!map.impl&%0.insert.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
         DT&. DT&
        ) log! (I logIndexUpper!) (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
         log_entry!
   ))))))
   :pattern ((req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
     DT&. DT& queue! log! new_log! queueIndex! logIndexLower! logIndexUpper! node_id!
     updates! new_updates! new_rid! log_entry!
   ))
   :qid internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append._definition
   :skolemid skolem_internal_req__NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append._definition
)))
(declare-fun ens%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
 (Dcr Type vstd!seq.Seq<nat.>. Poly Poly Int Int Int Int Poly Poly Int NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)
 Bool
)
(assert
 (forall ((DT&. Dcr) (DT& Type) (queue! vstd!seq.Seq<nat.>.) (log! Poly) (new_log! Poly)
   (queueIndex! Int) (logIndexLower! Int) (logIndexUpper! Int) (node_id! Int) (updates!
    Poly
   ) (new_updates! Poly) (new_rid! Int) (log_entry! NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)
  ) (!
   (= (ens%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
     DT&. DT& queue! log! new_log! queueIndex! logIndexLower! logIndexUpper! node_id!
     updates! new_updates! new_rid! log_entry!
    ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.? DT&.
     DT& (vstd!seq.Seq.push.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!) (I new_rid!)) new_log!
     (I queueIndex!) (I logIndexLower!) (I (nClip (Add logIndexUpper! 1))) (I node_id!)
     new_updates!
   ))
   :pattern ((ens%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
     DT&. DT& queue! log! new_log! queueIndex! logIndexLower! logIndexUpper! node_id!
     updates! new_updates! new_rid! log_entry!
   ))
   :qid internal_ens__NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append._definition
   :skolemid skolem_internal_ens__NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const DT&. Dcr)
(declare-const DT& Type)
(declare-const queue! vstd!seq.Seq<nat.>.)
(declare-const log! Poly)
(declare-const new_log! Poly)
(declare-const queueIndex! Int)
(declare-const logIndexLower! Int)
(declare-const logIndexUpper! Int)
(declare-const node_id! Int)
(declare-const updates! Poly)
(declare-const new_updates! Poly)
(declare-const new_rid! Int)
(declare-const log_entry! NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Bool)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Bool)
(declare-const tmp%5 Int)
(declare-const tmp%6 Int)
(declare-const tmp%7 Bool)
(declare-const tmp%8 Int)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(assert
 (sized DT&.)
)
(assert
 (tr_bound%NO__spec__unbounded_log__LogRangeMatchesQueue_append!Dispatch. DT&. DT&)
)
(assert
 (has_type log! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
    DT&. DT&
))))
(assert
 (has_type new_log! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
    DT&. DT&
))))
(assert
 (<= 0 queueIndex!)
)
(assert
 (<= 0 logIndexLower!)
)
(assert
 (<= 0 logIndexUpper!)
)
(assert
 (<= 0 node_id!)
)
(assert
 (has_type updates! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
    DT&. DT&
))))
(assert
 (has_type new_updates! (TYPE%vstd!map.Map. $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
    DT&. DT&
))))
(assert
 (<= 0 new_rid!)
)
(assert
 (has_type (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. log_entry!)
  (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&. DT&)
))
(assert
 (let
  ((tmp%%$ 0))
  (let
   ((tmp%%$1 queueIndex!))
   (let
    ((tmp%%$2 (vstd!seq.Seq.len.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!))))
    (and
     (<= tmp%%$ tmp%%$1)
     (<= tmp%%$1 tmp%%$2)
)))))
(assert
 (<= logIndexLower! logIndexUpper!)
)
(assert
 (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
   (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
     log_entry!
   ))
  ) node_id!
))
(assert
 (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
    $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
     DT&
    ) new_updates!
   )
  ) (I new_rid!)
))
(assert
 (= (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. (vstd!map.impl&%0.index.?
    $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
     DT&
    ) new_updates! (I new_rid!)
   )
  ) (NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState./Placed (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/op
    (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
      log_entry!
    ))
   ) (%I (I logIndexUpper!))
)))
(assert
 (not (vstd!seq_lib.impl&%0.contains.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!) (I new_rid!)))
)
(assert
 (forall ((rid$ Poly)) (!
   (=>
    (has_type rid$ NAT)
    (=>
     (and
      (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
         $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
          DT&
         ) updates!
        )
       ) rid$
      )
      (not (= (%I rid$) new_rid!))
     )
     (and
      (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
         $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
          DT&
         ) new_updates!
        )
       ) rid$
      )
      (= (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
         DT&. DT&
        ) new_updates! rid$
       ) (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState.
         DT&. DT&
        ) updates! rid$
   )))))
   :pattern ((vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
       $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!UpdateState. DT&.
        DT&
       ) updates!
      )
     ) rid$
   ))
   :qid user_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogRangeMatchesQueue_append_1
   :skolemid skolem_user_NO__spec__unbounded_log__LogRangeMatchesQueue_append__LogRangeMatchesQueue_append_1
)))
(assert
 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.? DT&.
  DT& (Poly%vstd!seq.Seq<nat.>. queue!) log! (I queueIndex!) (I logIndexLower!) (I logIndexUpper!)
  (I node_id!) updates!
))
(assert
 (= new_log! (vstd!map.impl&%0.insert.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
    DT&. DT&
   ) log! (I logIndexUpper!) (Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
    log_entry!
))))
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%switch_label%%2 Bool)
(declare-const %%switch_label%%3 Bool)
(declare-const %%switch_label%%4 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(declare-const %%location_label%%5 Bool)
(declare-const %%location_label%%6 Bool)
(declare-const %%location_label%%7 Bool)
(declare-const %%location_label%%8 Bool)
(declare-const %%location_label%%9 Bool)
(assert
 (not (=>
   (= decrease%init0 (Sub logIndexUpper! logIndexLower!))
   (or
    (and
     (=>
      (= logIndexLower! (nClip (Add logIndexUpper! 1)))
      %%switch_label%%0
     )
     (=>
      (not (= logIndexLower! (nClip (Add logIndexUpper! 1))))
      (or
       (and
        (=>
         (= logIndexLower! logIndexUpper!)
         (=>
          (= tmp%1 (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
              $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
               DT&
              ) new_log!
             )
            ) (I logIndexLower!)
          ))
          (and
           (=>
            %%location_label%%0
            tmp%1
           )
           (=>
            tmp%1
            (or
             (and
              (=>
               (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                 (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                   $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                    DT&
                   ) new_log! (I logIndexLower!)
                 ))
                ) node_id!
               )
               (=>
                (= tmp%2 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?
                  DT&. DT& (vstd!seq.Seq.push.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!) (I new_rid!))
                  new_log! (I (nClip (Add queueIndex! 1))) (I (nClip (Add logIndexLower! 1))) (I (nClip
                    (Add logIndexUpper! 1)
                   )
                  ) (I node_id!) new_updates!
                ))
                (and
                 (=>
                  %%location_label%%1
                  tmp%2
                 )
                 (=>
                  tmp%2
                  %%switch_label%%3
              ))))
              (=>
               (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                  (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                    $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                     DT&
                    ) new_log! (I logIndexLower!)
                  ))
                 ) node_id!
               ))
               %%switch_label%%3
             ))
             (and
              (not %%switch_label%%3)
              (or
               (and
                (=>
                 (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                    (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                      $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                       DT&
                      ) new_log! (I logIndexLower!)
                    ))
                   ) node_id!
                 ))
                 (=>
                  (= tmp%3 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?
                    DT&. DT& (vstd!seq.Seq.push.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!) (I new_rid!))
                    new_log! (I queueIndex!) (I (nClip (Add logIndexLower! 1))) (I (nClip (Add logIndexUpper!
                       1
                     ))
                    ) (I node_id!) new_updates!
                  ))
                  (and
                   (=>
                    %%location_label%%2
                    tmp%3
                   )
                   (=>
                    tmp%3
                    %%switch_label%%2
                ))))
                (=>
                 (not (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                     (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                       $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                        DT&
                       ) new_log! (I logIndexLower!)
                     ))
                    ) node_id!
                 )))
                 %%switch_label%%2
               ))
               (and
                (not %%switch_label%%2)
                %%switch_label%%1
        ))))))))
        (=>
         (not (= logIndexLower! logIndexUpper!))
         (=>
          (= tmp%4 (= (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
              DT&. DT&
             ) new_log! (I logIndexLower!)
            ) (vstd!map.impl&%0.index.? $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry.
              DT&. DT&
             ) log! (I logIndexLower!)
          )))
          (and
           (=>
            %%location_label%%3
            tmp%4
           )
           (=>
            tmp%4
            (or
             (and
              (=>
               (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                 (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                   $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                    DT&
                   ) new_log! (I logIndexLower!)
                 ))
                ) node_id!
               )
               (=>
                (= tmp%5 (nClip (Add queueIndex! 1)))
                (=>
                 (= tmp%6 (nClip (Add logIndexLower! 1)))
                 (and
                  (=>
                   %%location_label%%4
                   (check_decrease_height (I (let
                      ((queue!$0 queue!) (log!$1 log!) (new_log!$2 new_log!) (queueIndex!$3 tmp%5) (logIndexLower!$4
                        tmp%6
                       ) (logIndexUpper!$5 logIndexUpper!) (node_id!$6 node_id!) (updates!$7 updates!) (
                        new_updates!$8 new_updates!
                       ) (new_rid!$9 new_rid!) (log_entry!$10 log_entry!)
                      )
                      (Sub logIndexUpper!$5 logIndexLower!$4)
                     )
                    ) (I decrease%init0) false
                  ))
                  (and
                   (=>
                    %%location_label%%5
                    (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
                     DT&. DT& queue! log! new_log! tmp%5 tmp%6 logIndexUpper! node_id! updates! new_updates!
                     new_rid! log_entry!
                   ))
                   (=>
                    (ens%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
                     DT&. DT& queue! log! new_log! tmp%5 tmp%6 logIndexUpper! node_id! updates! new_updates!
                     new_rid! log_entry!
                    )
                    (=>
                     (= tmp%7 (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.?
                       DT&. DT& (vstd!seq.Seq.push.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!) (I new_rid!))
                       new_log! (I queueIndex!) (I logIndexLower!) (I (nClip (Add logIndexUpper! 1))) (I
                        node_id!
                       ) new_updates!
                     ))
                     (and
                      (=>
                       %%location_label%%6
                       tmp%7
                      )
                      (=>
                       tmp%7
                       %%switch_label%%4
              )))))))))
              (=>
               (not (= (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry./LogEntry/node_id
                  (%Poly%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. (vstd!map.impl&%0.index.?
                    $ NAT $ (TYPE%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogEntry. DT&.
                     DT&
                    ) new_log! (I logIndexLower!)
                  ))
                 ) node_id!
               ))
               (=>
                (= tmp%8 (nClip (Add logIndexLower! 1)))
                (and
                 (=>
                  %%location_label%%7
                  (check_decrease_height (I (let
                     ((queue!$0 queue!) (log!$1 log!) (new_log!$2 new_log!) (queueIndex!$3 queueIndex!)
                      (logIndexLower!$4 tmp%8) (logIndexUpper!$5 logIndexUpper!) (node_id!$6 node_id!)
                      (updates!$7 updates!) (new_updates!$8 new_updates!) (new_rid!$9 new_rid!) (log_entry!$10
                       log_entry!
                     ))
                     (Sub logIndexUpper!$5 logIndexLower!$4)
                    )
                   ) (I decrease%init0) false
                 ))
                 (and
                  (=>
                   %%location_label%%8
                   (req%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
                    DT&. DT& queue! log! new_log! queueIndex! tmp%8 logIndexUpper! node_id! updates!
                    new_updates! new_rid! log_entry!
                  ))
                  (=>
                   (ens%NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue_append.
                    DT&. DT& queue! log! new_log! queueIndex! tmp%8 logIndexUpper! node_id! updates!
                    new_updates! new_rid! log_entry!
                   )
                   %%switch_label%%4
             ))))))
             (and
              (not %%switch_label%%4)
              %%switch_label%%1
       )))))))
       (and
        (not %%switch_label%%1)
        %%switch_label%%0
    ))))
    (and
     (not %%switch_label%%0)
     (=>
      %%location_label%%9
      (NO__spec__unbounded_log__LogRangeMatchesQueue_append!LogRangeMatchesQueue.? DT&.
       DT& (vstd!seq.Seq.push.? $ NAT (Poly%vstd!seq.Seq<nat.>. queue!) (I new_rid!)) new_log!
       (I queueIndex!) (I logIndexLower!) (I (nClip (Add logIndexUpper! 1))) (I node_id!)
       new_updates!
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
