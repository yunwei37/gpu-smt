(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const addr@ (_ BitVec 64))
(declare-const max_width@ (_ BitVec 64))
(declare-const tmp$$$$bitvectmp1 (_ BitVec 64))
(declare-const mask_dir_addr@ (_ BitVec 64))
(assert
 (bvule addr@ (bvsub (bvshl ((_ zero_extend 63) (_ bv1 1)) max_width@) ((_ zero_extend
     63
    ) (_ bv1 1)
))))
(assert
 (= (let
   ((tmp$$$$bitvectmp0 (_ bv4096 13)))
   (ite
    (= tmp$$$$bitvectmp0 (_ bv0 13))
    tmp$$$$bitvectmp1
    (bvurem addr@ ((_ zero_extend 51) tmp$$$$bitvectmp0))
   )
  ) ((_ zero_extend 63) (_ bv0 1))
))
(assert
 (= mask_dir_addr@ (bvshl (bvnot (bvshl (_ bv18446744073709551615 64) (bvsub (bvadd (bvsub
        max_width@ ((_ zero_extend 63) (_ bv1 1))
       ) ((_ zero_extend 63) (_ bv1 1))
      ) ((_ zero_extend 60) (_ bv12 4))
    ))
   ) ((_ zero_extend 60) (_ bv12 4))
)))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (bvand addr@ mask_dir_addr@) addr@)
)))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
