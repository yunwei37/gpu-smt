(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(assert
 true
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (forall ((m$ (_ BitVec 64)) (n$ (_ BitVec 64))) (!
     (=>
      (and
       (bvult n$ m$)
       (bvult m$ ((_ zero_extend 57) (_ bv64 7)))
      )
      (bvult (bvshl ((_ zero_extend 63) (_ bv1 1)) n$) (bvshl ((_ zero_extend 63) (_ bv1 1))
        m$
     )))
     :qid user_NR__impl_u__l2_impl__lemma_page_aligned_implies_mask_dir_addr_is_identity__MAX_PHYADDR_1
     :skolemid skolem_user_NR__impl_u__l2_impl__lemma_page_aligned_implies_mask_dir_addr_is_identity__MAX_PHYADDR_1
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
