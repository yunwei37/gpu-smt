(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!std_specs.bits.axiom_u64_leading_zeros. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%MA__bin_sizes__result_sbin!pow2. FuelId)
(declare-const fuel%MA__bin_sizes__result_sbin!valid_sbin_idx. FuelId)
(declare-const fuel%MA__bin_sizes__result_sbin!size_of_sbin. FuelId)
(declare-const fuel%MA__bin_sizes__result_sbin!smallest_sbin_fitting_size. FuelId)
(declare-const fuel%MA__bin_sizes__result_sbin!property_sbin. FuelId)
(declare-const fuel%MA__bin_sizes__result_sbin!check_sbin. FuelId)
(declare-const fuel%MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX. FuelId)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!std_specs.bits.axiom_u64_leading_zeros. fuel%vstd!function.axiom_fn_mut_call_requires.
  fuel%vstd!function.axiom_fn_mut_call_ensures. fuel%MA__bin_sizes__result_sbin!pow2.
  fuel%MA__bin_sizes__result_sbin!valid_sbin_idx. fuel%MA__bin_sizes__result_sbin!size_of_sbin.
  fuel%MA__bin_sizes__result_sbin!smallest_sbin_fitting_size. fuel%MA__bin_sizes__result_sbin!property_sbin.
  fuel%MA__bin_sizes__result_sbin!check_sbin. fuel%MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
  (fuel_bool_default fuel%vstd!std_specs.bits.axiom_u64_leading_zeros.)
))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-datatypes ((tuple%0. 0)) (((tuple%0./tuple%0))))
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(declare-fun vstd!std_specs.bits.u64_leading_zeros.? (Poly) Int)
(declare-fun MA__bin_sizes__result_sbin!pow2.? (Poly) Int)
(declare-fun MA__bin_sizes__result_sbin!rec%pow2.? (Poly Fuel) Int)
(declare-fun MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX.? () Int)
(declare-fun MA__bin_sizes__result_sbin!valid_sbin_idx.? (Poly) Bool)
(declare-fun MA__bin_sizes__result_sbin!size_of_sbin.? (Poly) Int)
(declare-fun MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.? (Poly) Int)
(declare-fun MA__bin_sizes__result_sbin!property_sbin.? (Poly) Bool)
(declare-fun MA__bin_sizes__result_sbin!check_sbin.? (Poly Poly) Bool)
(declare-fun MA__bin_sizes__result_sbin!rec%check_sbin.? (Poly Poly Fuel) Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.bits.axiom_u64_leading_zeros.)
  (forall ((i! Poly)) (!
    (=>
     (has_type i! (UINT 64))
     (and
      (and
       (and
        (and
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (vstd!std_specs.bits.u64_leading_zeros.? i!)))
           (let
            ((tmp%%$2 64))
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
         ))))
         (= (= (%I i!) 0) (= (vstd!std_specs.bits.u64_leading_zeros.? i!) 64))
        )
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$4 (vstd!std_specs.bits.u64_leading_zeros.? i!)))
           (let
            ((tmp%%$5 64))
            (and
             (<= tmp%%$ tmp%%$4)
             (< tmp%%$4 tmp%%$5)
         ))))
         (not (= (uClip 64 (bitand (I (uClip 64 (bitshr (I (%I i!)) (I (uClip 64 (Sub 63 (uClip 64 (vstd!std_specs.bits.u64_leading_zeros.?
                     i!
              )))))))
             ) (I 1)
            )
           ) 0
       ))))
       (= (uClip 64 (bitshr (I (%I i!)) (I (uClip 64 (Sub 64 (uClip 64 (vstd!std_specs.bits.u64_leading_zeros.?
               i!
         ))))))
        ) 0
      ))
      (forall ((j$ Poly)) (!
        (=>
         (has_type j$ (UINT 64))
         (=>
          (let
           ((tmp%%$ (Sub 64 (vstd!std_specs.bits.u64_leading_zeros.? i!))))
           (let
            ((tmp%%$7 (%I j$)))
            (let
             ((tmp%%$8 64))
             (and
              (<= tmp%%$ tmp%%$7)
              (< tmp%%$7 tmp%%$8)
          ))))
          (= (uClip 64 (bitand (I (uClip 64 (bitshr (I (%I i!)) (I (%I j$))))) (I 1))) 0)
        ))
        :pattern ((uClip 64 (bitshr (I (%I i!)) (I (%I j$)))))
        :qid user_vstd__std_specs__bits__axiom_u64_leading_zeros_0
        :skolemid skolem_user_vstd__std_specs__bits__axiom_u64_leading_zeros_0
    ))))
    :pattern ((vstd!std_specs.bits.u64_leading_zeros.? i!))
    :qid user_vstd__std_specs__bits__axiom_u64_leading_zeros_1
    :skolemid skolem_user_vstd__std_specs__bits__axiom_u64_leading_zeros_1
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const i! Poly)
(declare-const tmp%1 Int)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Int)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(assert
 (has_type i! INT)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= decrease%init0 (%I i!))
   (or
    (and
     (=>
      (<= (%I i!) 0)
      (=>
       (= tmp%3 1)
       %%switch_label%%0
     ))
     (=>
      (not (<= (%I i!) 0))
      (=>
       (= tmp%2 (I (Sub (%I i!) 1)))
       (and
        (=>
         %%location_label%%0
         (check_decrease_height (I (let
            ((i!$0 (%I tmp%2)))
            i!$0
           )
          ) (I decrease%init0) false
        ))
        (=>
         (<= 0 tmp%1)
         (=>
          (= tmp%1 (MA__bin_sizes__result_sbin!pow2.? (I (Sub (%I i!) 1))))
          (=>
           (= tmp%3 (nClip (Mul tmp%1 2)))
           %%switch_label%%0
    )))))))
    (not %%switch_label%%0)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%MA__bin_sizes__result_sbin!pow2.)
)
(declare-const fuel_nat%MA__bin_sizes__result_sbin!pow2. Fuel)
(assert
 (forall ((i! Poly) (fuel% Fuel)) (!
   (= (MA__bin_sizes__result_sbin!rec%pow2.? i! fuel%) (MA__bin_sizes__result_sbin!rec%pow2.?
     i! zero
   ))
   :pattern ((MA__bin_sizes__result_sbin!rec%pow2.? i! fuel%))
   :qid internal_MA__bin_sizes__result_sbin!pow2._fuel_to_zero_definition
   :skolemid skolem_internal_MA__bin_sizes__result_sbin!pow2._fuel_to_zero_definition
)))
(assert
 (forall ((i! Poly) (fuel% Fuel)) (!
   (=>
    (has_type i! INT)
    (= (MA__bin_sizes__result_sbin!rec%pow2.? i! (succ fuel%)) (ite
      (<= (%I i!) 0)
      1
      (nClip (Mul (MA__bin_sizes__result_sbin!rec%pow2.? (I (Sub (%I i!) 1)) fuel%) 2))
   )))
   :pattern ((MA__bin_sizes__result_sbin!rec%pow2.? i! (succ fuel%)))
   :qid internal_MA__bin_sizes__result_sbin!pow2._fuel_to_body_definition
   :skolemid skolem_internal_MA__bin_sizes__result_sbin!pow2._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%MA__bin_sizes__result_sbin!pow2.)
  (forall ((i! Poly)) (!
    (=>
     (has_type i! INT)
     (= (MA__bin_sizes__result_sbin!pow2.? i!) (MA__bin_sizes__result_sbin!rec%pow2.? i!
       (succ fuel_nat%MA__bin_sizes__result_sbin!pow2.)
    )))
    :pattern ((MA__bin_sizes__result_sbin!pow2.? i!))
    :qid internal_MA__bin_sizes__result_sbin!pow2.?_definition
    :skolemid skolem_internal_MA__bin_sizes__result_sbin!pow2.?_definition
))))
(assert
 (forall ((i! Poly)) (!
   (=>
    (has_type i! INT)
    (<= 0 (MA__bin_sizes__result_sbin!pow2.? i!))
   )
   :pattern ((MA__bin_sizes__result_sbin!pow2.? i!))
   :qid internal_MA__bin_sizes__result_sbin!pow2.?_pre_post_definition
   :skolemid skolem_internal_MA__bin_sizes__result_sbin!pow2.?_pre_post_definition
)))
(assert
 (forall ((i! Poly) (fuel% Fuel)) (!
   (=>
    (has_type i! INT)
    (<= 0 (MA__bin_sizes__result_sbin!rec%pow2.? i! fuel%))
   )
   :pattern ((MA__bin_sizes__result_sbin!rec%pow2.? i! fuel%))
   :qid internal_MA__bin_sizes__result_sbin!rec__pow2.?_pre_post_rec_definition
   :skolemid skolem_internal_MA__bin_sizes__result_sbin!rec__pow2.?_pre_post_rec_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX.)
)
(assert
 (=>
  (fuel_bool fuel%MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX.)
  (= MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX.? 31)
))
(assert
 (uInv SZ MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX.?)
)
(assert
 (fuel_bool_default fuel%MA__bin_sizes__result_sbin!valid_sbin_idx.)
)
(assert
 (=>
  (fuel_bool fuel%MA__bin_sizes__result_sbin!valid_sbin_idx.)
  (forall ((sbin_idx! Poly)) (!
    (= (MA__bin_sizes__result_sbin!valid_sbin_idx.? sbin_idx!) (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I sbin_idx!)))
       (let
        ((tmp%%$2 MA__bin_sizes__result_sbin!SEGMENT_BIN_MAX.?))
        (and
         (<= tmp%%$ tmp%%$1)
         (<= tmp%%$1 tmp%%$2)
    )))))
    :pattern ((MA__bin_sizes__result_sbin!valid_sbin_idx.? sbin_idx!))
    :qid internal_MA__bin_sizes__result_sbin!valid_sbin_idx.?_definition
    :skolemid skolem_internal_MA__bin_sizes__result_sbin!valid_sbin_idx.?_definition
))))
(declare-fun req%MA__bin_sizes__result_sbin!size_of_sbin. (Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((sbin_idx! Poly)) (!
   (= (req%MA__bin_sizes__result_sbin!size_of_sbin. sbin_idx!) (=>
     %%global_location_label%%0
     (MA__bin_sizes__result_sbin!valid_sbin_idx.? sbin_idx!)
   ))
   :pattern ((req%MA__bin_sizes__result_sbin!size_of_sbin. sbin_idx!))
   :qid internal_req__MA__bin_sizes__result_sbin!size_of_sbin._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!size_of_sbin._definition
)))
(assert
 (fuel_bool_default fuel%MA__bin_sizes__result_sbin!size_of_sbin.)
)
(assert
 (=>
  (fuel_bool fuel%MA__bin_sizes__result_sbin!size_of_sbin.)
  (forall ((sbin_idx! Poly)) (!
    (= (MA__bin_sizes__result_sbin!size_of_sbin.? sbin_idx!) (ite
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 (%I sbin_idx!)))
        (let
         ((tmp%%$2 7))
         (and
          (<= tmp%%$ tmp%%$1)
          (<= tmp%%$1 tmp%%$2)
      ))))
      (nClip (%I sbin_idx!))
      (ite
       (= (%I sbin_idx!) 8)
       10
       (let
        ((group$ (EucDiv (Sub (%I sbin_idx!) 8) 4)))
        (let
         ((inner$ (EucMod (Sub (%I sbin_idx!) 8) 4)))
         (nClip (Mul (Add inner$ 5) (MA__bin_sizes__result_sbin!pow2.? (I (Add group$ 1)))))
    )))))
    :pattern ((MA__bin_sizes__result_sbin!size_of_sbin.? sbin_idx!))
    :qid internal_MA__bin_sizes__result_sbin!size_of_sbin.?_definition
    :skolemid skolem_internal_MA__bin_sizes__result_sbin!size_of_sbin.?_definition
))))
(assert
 (forall ((sbin_idx! Poly)) (!
   (=>
    (has_type sbin_idx! INT)
    (<= 0 (MA__bin_sizes__result_sbin!size_of_sbin.? sbin_idx!))
   )
   :pattern ((MA__bin_sizes__result_sbin!size_of_sbin.? sbin_idx!))
   :qid internal_MA__bin_sizes__result_sbin!size_of_sbin.?_pre_post_definition
   :skolemid skolem_internal_MA__bin_sizes__result_sbin!size_of_sbin.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.)
)
(assert
 (=>
  (fuel_bool fuel%MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.)
  (forall ((i! Poly)) (!
    (= (MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.? i!) (ite
      (<= (%I i!) 8)
      (%I i!)
      (let
       ((w$ (uClip 64 (Sub (%I i!) 1))))
       (let
        ((lz$ (vstd!std_specs.bits.u64_leading_zeros.? (I w$))))
        (let
         ((b$ (uClip 8 (Sub (Sub SZ 1) lz$))))
         (let
          ((sbin_idx$ (Sub (uClip 64 (bitor (I (uClip 64 (uClip 8 (bitshl (I b$) (I 2))))) (I (uClip
                 64 (bitand (I (uClip 64 (bitshr (I w$) (I (uClip 64 (Sub (uClip 64 b$) 2)))))) (I 3))
              )))
             ) 4
          )))
          sbin_idx$
    ))))))
    :pattern ((MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.? i!))
    :qid internal_MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.?_definition
    :skolemid skolem_internal_MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.?_definition
))))
(assert
 (fuel_bool_default fuel%MA__bin_sizes__result_sbin!property_sbin.)
)
(assert
 (=>
  (fuel_bool fuel%MA__bin_sizes__result_sbin!property_sbin.)
  (forall ((slice_count! Poly)) (!
    (= (MA__bin_sizes__result_sbin!property_sbin.? slice_count!) (let
      ((sbin_idx$ (MA__bin_sizes__result_sbin!smallest_sbin_fitting_size.? slice_count!)))
      (and
       (MA__bin_sizes__result_sbin!valid_sbin_idx.? (I sbin_idx$))
       (>= (MA__bin_sizes__result_sbin!size_of_sbin.? (I sbin_idx$)) (%I slice_count!))
    )))
    :pattern ((MA__bin_sizes__result_sbin!property_sbin.? slice_count!))
    :qid internal_MA__bin_sizes__result_sbin!property_sbin.?_definition
    :skolemid skolem_internal_MA__bin_sizes__result_sbin!property_sbin.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const size_start! Poly)
(declare-const size_end! Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Bool)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(assert
 (has_type size_start! INT)
)
(assert
 (has_type size_end! INT)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= decrease%init0 (Sub (%I size_end!) (%I size_start!)))
   (or
    (and
     (=>
      (>= (%I size_start!) (%I size_end!))
      (=>
       (= tmp%4 true)
       %%switch_label%%0
     ))
     (=>
      (not (>= (%I size_start!) (%I size_end!)))
      (or
       (and
        (=>
         (MA__bin_sizes__result_sbin!property_sbin.? size_start!)
         (=>
          (= tmp%2 (I (Add (%I size_start!) 1)))
          (and
           (=>
            %%location_label%%0
            (check_decrease_height (I (let
               ((size_start!$0 (%I tmp%2)) (size_end!$1 (%I size_end!)))
               (Sub size_end!$1 size_start!$0)
              )
             ) (I decrease%init0) false
           ))
           (=>
            (= tmp%1 (MA__bin_sizes__result_sbin!check_sbin.? (I (Add (%I size_start!) 1)) size_end!))
            (=>
             (= tmp%3 tmp%1)
             %%switch_label%%1
        )))))
        (=>
         (not (MA__bin_sizes__result_sbin!property_sbin.? size_start!))
         (=>
          (= tmp%3 false)
          %%switch_label%%1
       )))
       (and
        (not %%switch_label%%1)
        (=>
         (= tmp%4 tmp%3)
         %%switch_label%%0
    )))))
    (not %%switch_label%%0)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%MA__bin_sizes__result_sbin!check_sbin.)
)
(declare-const fuel_nat%MA__bin_sizes__result_sbin!check_sbin. Fuel)
(assert
 (forall ((size_start! Poly) (size_end! Poly) (fuel% Fuel)) (!
   (= (MA__bin_sizes__result_sbin!rec%check_sbin.? size_start! size_end! fuel%) (MA__bin_sizes__result_sbin!rec%check_sbin.?
     size_start! size_end! zero
   ))
   :pattern ((MA__bin_sizes__result_sbin!rec%check_sbin.? size_start! size_end! fuel%))
   :qid internal_MA__bin_sizes__result_sbin!check_sbin._fuel_to_zero_definition
   :skolemid skolem_internal_MA__bin_sizes__result_sbin!check_sbin._fuel_to_zero_definition
)))
(assert
 (forall ((size_start! Poly) (size_end! Poly) (fuel% Fuel)) (!
   (=>
    (and
     (has_type size_start! INT)
     (has_type size_end! INT)
    )
    (= (MA__bin_sizes__result_sbin!rec%check_sbin.? size_start! size_end! (succ fuel%))
     (=>
      (not (>= (%I size_start!) (%I size_end!)))
      (and
       (MA__bin_sizes__result_sbin!property_sbin.? size_start!)
       (MA__bin_sizes__result_sbin!rec%check_sbin.? (I (Add (%I size_start!) 1)) size_end!
        fuel%
   )))))
   :pattern ((MA__bin_sizes__result_sbin!rec%check_sbin.? size_start! size_end! (succ fuel%)))
   :qid internal_MA__bin_sizes__result_sbin!check_sbin._fuel_to_body_definition
   :skolemid skolem_internal_MA__bin_sizes__result_sbin!check_sbin._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%MA__bin_sizes__result_sbin!check_sbin.)
  (forall ((size_start! Poly) (size_end! Poly)) (!
    (=>
     (and
      (has_type size_start! INT)
      (has_type size_end! INT)
     )
     (= (MA__bin_sizes__result_sbin!check_sbin.? size_start! size_end!) (MA__bin_sizes__result_sbin!rec%check_sbin.?
       size_start! size_end! (succ fuel_nat%MA__bin_sizes__result_sbin!check_sbin.)
    )))
    :pattern ((MA__bin_sizes__result_sbin!check_sbin.? size_start! size_end!))
    :qid internal_MA__bin_sizes__result_sbin!check_sbin.?_definition
    :skolemid skolem_internal_MA__bin_sizes__result_sbin!check_sbin.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(declare-fun req%MA__bin_sizes__result_sbin!mod8. (Int Int) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((x! Int) (y! Int)) (!
   (= (req%MA__bin_sizes__result_sbin!mod8. x! y!) (=>
     %%global_location_label%%1
     (= x! (Mul 8 y!))
   ))
   :pattern ((req%MA__bin_sizes__result_sbin!mod8. x! y!))
   :qid internal_req__MA__bin_sizes__result_sbin!mod8._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!mod8._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!mod8. (Int Int) Bool)
(assert
 (forall ((x! Int) (y! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!mod8. x! y!) (= (EucMod x! 8) 0))
   :pattern ((ens%MA__bin_sizes__result_sbin!mod8. x! y!))
   :qid internal_ens__MA__bin_sizes__result_sbin!mod8._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!mod8._definition
)))
(declare-fun req%MA__bin_sizes__result_sbin!div2. (Int Int) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((x! Int) (y! Int)) (!
   (= (req%MA__bin_sizes__result_sbin!div2. x! y!) (=>
     %%global_location_label%%2
     (> y! 0)
   ))
   :pattern ((req%MA__bin_sizes__result_sbin!div2. x! y!))
   :qid internal_req__MA__bin_sizes__result_sbin!div2._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!div2._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!div2. (Int Int) Bool)
(assert
 (forall ((x! Int) (y! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!div2. x! y!) (= (EucDiv x! (Mul y! 2)) (EucDiv (EucDiv
       x! y!
      ) 2
   )))
   :pattern ((ens%MA__bin_sizes__result_sbin!div2. x! y!))
   :qid internal_ens__MA__bin_sizes__result_sbin!div2._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!div2._definition
)))
(declare-fun req%MA__bin_sizes__result_sbin!lemma_div_is_ordered. (Int Int Int) Bool)
(declare-const %%global_location_label%%3 Bool)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((x! Int) (y! Int) (z! Int)) (!
   (= (req%MA__bin_sizes__result_sbin!lemma_div_is_ordered. x! y! z!) (and
     (=>
      %%global_location_label%%3
      (<= x! y!)
     )
     (=>
      %%global_location_label%%4
      (< 0 z!)
   )))
   :pattern ((req%MA__bin_sizes__result_sbin!lemma_div_is_ordered. x! y! z!))
   :qid internal_req__MA__bin_sizes__result_sbin!lemma_div_is_ordered._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!lemma_div_is_ordered._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!lemma_div_is_ordered. (Int Int Int) Bool)
(assert
 (forall ((x! Int) (y! Int) (z! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!lemma_div_is_ordered. x! y! z!) (<= (EucDiv x! z!)
     (EucDiv y! z!)
   ))
   :pattern ((ens%MA__bin_sizes__result_sbin!lemma_div_is_ordered. x! y! z!))
   :qid internal_ens__MA__bin_sizes__result_sbin!lemma_div_is_ordered._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!lemma_div_is_ordered._definition
)))
(declare-fun req%MA__bin_sizes__result_sbin!lemma_div_by_multiple. (Int Int) Bool)
(declare-const %%global_location_label%%5 Bool)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((b! Int) (d! Int)) (!
   (= (req%MA__bin_sizes__result_sbin!lemma_div_by_multiple. b! d!) (and
     (=>
      %%global_location_label%%5
      (<= 0 b!)
     )
     (=>
      %%global_location_label%%6
      (< 0 d!)
   )))
   :pattern ((req%MA__bin_sizes__result_sbin!lemma_div_by_multiple. b! d!))
   :qid internal_req__MA__bin_sizes__result_sbin!lemma_div_by_multiple._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!lemma_div_by_multiple._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!lemma_div_by_multiple. (Int Int) Bool)
(assert
 (forall ((b! Int) (d! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!lemma_div_by_multiple. b! d!) (= (EucDiv (Mul b! d!)
      d!
     ) b!
   ))
   :pattern ((ens%MA__bin_sizes__result_sbin!lemma_div_by_multiple. b! d!))
   :qid internal_ens__MA__bin_sizes__result_sbin!lemma_div_by_multiple._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!lemma_div_by_multiple._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!mul_assoc. (Int Int Int) Bool)
(assert
 (forall ((x! Int) (y! Int) (z! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!mul_assoc. x! y! z!) (= (nClip (Mul (nClip (Mul x! y!))
       z!
      )
     ) (nClip (Mul y! (nClip (Mul x! z!))))
   ))
   :pattern ((ens%MA__bin_sizes__result_sbin!mul_assoc. x! y! z!))
   :qid internal_ens__MA__bin_sizes__result_sbin!mul_assoc._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!mul_assoc._definition
)))
(declare-fun req%MA__bin_sizes__result_sbin!mul_ordering. (Int Int Int) Bool)
(declare-const %%global_location_label%%7 Bool)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((x! Int) (y! Int) (z! Int)) (!
   (= (req%MA__bin_sizes__result_sbin!mul_ordering. x! y! z!) (and
     (=>
      %%global_location_label%%7
      (and
       (and
        (< 0 x!)
        (< 1 y!)
       )
       (< 0 z!)
     ))
     (=>
      %%global_location_label%%8
      (= (nClip (Mul x! y!)) z!)
   )))
   :pattern ((req%MA__bin_sizes__result_sbin!mul_ordering. x! y! z!))
   :qid internal_req__MA__bin_sizes__result_sbin!mul_ordering._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!mul_ordering._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!mul_ordering. (Int Int Int) Bool)
(assert
 (forall ((x! Int) (y! Int) (z! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!mul_ordering. x! y! z!) (< x! z!))
   :pattern ((ens%MA__bin_sizes__result_sbin!mul_ordering. x! y! z!))
   :qid internal_ens__MA__bin_sizes__result_sbin!mul_ordering._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!mul_ordering._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!pow2_positive. (Int) Bool)
(assert
 (forall ((e! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!pow2_positive. e!) (> (MA__bin_sizes__result_sbin!pow2.?
      (I e!)
     ) 0
   ))
   :pattern ((ens%MA__bin_sizes__result_sbin!pow2_positive. e!))
   :qid internal_ens__MA__bin_sizes__result_sbin!pow2_positive._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!pow2_positive._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const e! Int)
(declare-const tmp%1 Int)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (=>
   (= decrease%init0 e!)
   (or
    (and
     (=>
      (<= e! 0)
      %%switch_label%%0
     )
     (=>
      (not (<= e! 0))
      (=>
       (= tmp%1 (Sub e! 1))
       (and
        (=>
         %%location_label%%0
         (check_decrease_height (I (let
            ((e!$0 tmp%1))
            e!$0
           )
          ) (I decrease%init0) false
        ))
        (=>
         (ens%MA__bin_sizes__result_sbin!pow2_positive. tmp%1)
         %%switch_label%%0
    )))))
    (and
     (not %%switch_label%%0)
     (=>
      %%location_label%%1
      (> (MA__bin_sizes__result_sbin!pow2.? (I e!)) 0)
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(declare-fun ens%MA__bin_sizes__result_sbin!pow2_adds. (Int Int) Bool)
(assert
 (forall ((e1! Int) (e2! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!pow2_adds. e1! e2!) (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.?
        (I e1!)
       ) (MA__bin_sizes__result_sbin!pow2.? (I e2!))
      )
     ) (MA__bin_sizes__result_sbin!pow2.? (I (nClip (Add e1! e2!))))
   ))
   :pattern ((ens%MA__bin_sizes__result_sbin!pow2_adds. e1! e2!))
   :qid internal_ens__MA__bin_sizes__result_sbin!pow2_adds._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!pow2_adds._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const e1! Int)
(declare-const e2! Int)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Int)
(declare-const tmp%3 Int)
(declare-const tmp%4 Int)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(assert
 (<= 0 e1!)
)
(assert
 (<= 0 e2!)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(declare-const %%location_label%%5 Bool)
(declare-const %%location_label%%6 Bool)
(declare-const %%location_label%%7 Bool)
(assert
 (not (=>
   (= decrease%init0 e1!)
   (or
    (and
     (=>
      (= e1! 0)
      (=>
       (= tmp%1 (= (MA__bin_sizes__result_sbin!pow2.? (I e1!)) 1))
       (and
        (=>
         %%location_label%%0
         tmp%1
        )
        (=>
         tmp%1
         %%switch_label%%0
     ))))
     (=>
      (not (= e1! 0))
      (and
       (and
        (=>
         %%location_label%%1
         (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1!)) (MA__bin_sizes__result_sbin!pow2.?
             (I e2!)
           ))
          ) (nClip (Mul (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) 2)) (
             MA__bin_sizes__result_sbin!pow2.? (I e2!)
        )))))
        (=>
         (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1!)) (MA__bin_sizes__result_sbin!pow2.?
             (I e2!)
           ))
          ) (nClip (Mul (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) 2)) (
             MA__bin_sizes__result_sbin!pow2.? (I e2!)
         ))))
         (and
          (=>
           (= tmp%2 (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))))
           (=>
            (= tmp%3 (MA__bin_sizes__result_sbin!pow2.? (I e2!)))
            (=>
             (ens%MA__bin_sizes__result_sbin!mul_assoc. tmp%2 2 tmp%3)
             (=>
              %%location_label%%2
              (= (nClip (Mul (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) 2)) (
                  MA__bin_sizes__result_sbin!pow2.? (I e2!)
                ))
               ) (nClip (Mul 2 (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) (MA__bin_sizes__result_sbin!pow2.?
                    (I e2!)
          ))))))))))
          (=>
           (= (nClip (Mul (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) 2)) (
               MA__bin_sizes__result_sbin!pow2.? (I e2!)
             ))
            ) (nClip (Mul 2 (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) (MA__bin_sizes__result_sbin!pow2.?
                 (I e2!)
           ))))))
           (and
            (=>
             (= tmp%4 (nClip (Sub e1! 1)))
             (and
              (=>
               %%location_label%%3
               (check_decrease_height (I (let
                  ((e1!$0 tmp%4) (e2!$1 e2!))
                  e1!$0
                 )
                ) (I decrease%init0) false
              ))
              (=>
               (ens%MA__bin_sizes__result_sbin!pow2_adds. tmp%4 e2!)
               (=>
                %%location_label%%4
                (= (nClip (Mul 2 (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) (MA__bin_sizes__result_sbin!pow2.?
                      (I e2!)
                  ))))
                 ) (nClip (Mul 2 (MA__bin_sizes__result_sbin!pow2.? (I (Add (Sub e1! 1) e2!)))))
            )))))
            (=>
             (= (nClip (Mul 2 (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e1! 1))) (MA__bin_sizes__result_sbin!pow2.?
                   (I e2!)
               ))))
              ) (nClip (Mul 2 (MA__bin_sizes__result_sbin!pow2.? (I (Add (Sub e1! 1) e2!)))))
             )
             (and
              (=>
               %%location_label%%5
               (= (nClip (Mul 2 (MA__bin_sizes__result_sbin!pow2.? (I (Add (Sub e1! 1) e2!))))) (
                 MA__bin_sizes__result_sbin!pow2.? (I (nClip (Add e1! e2!)))
              )))
              (=>
               (= (nClip (Mul 2 (MA__bin_sizes__result_sbin!pow2.? (I (Add (Sub e1! 1) e2!))))) (
                 MA__bin_sizes__result_sbin!pow2.? (I (nClip (Add e1! e2!)))
               ))
               (=>
                %%location_label%%6
                (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1!)) (MA__bin_sizes__result_sbin!pow2.?
                    (I e2!)
                  ))
                 ) (MA__bin_sizes__result_sbin!pow2.? (I (nClip (Add e1! e2!))))
       ))))))))))
       (=>
        (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1!)) (MA__bin_sizes__result_sbin!pow2.?
            (I e2!)
          ))
         ) (MA__bin_sizes__result_sbin!pow2.? (I (nClip (Add e1! e2!))))
        )
        %%switch_label%%0
    ))))
    (and
     (not %%switch_label%%0)
     (=>
      %%location_label%%7
      (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1!)) (MA__bin_sizes__result_sbin!pow2.?
          (I e2!)
        ))
       ) (MA__bin_sizes__result_sbin!pow2.? (I (nClip (Add e1! e2!))))
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :reason-unknown)

(echo "<<DONE>>")
(get-model)

(echo "<<DONE>>")
(assert
 (not %%location_label%%7)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(pop)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const e1! Int)
(declare-const e2! Int)
(declare-const tmp%1 Int)
(declare-const tmp%2 Int)
(declare-const tmp%3 Int)
(assert
 fuel_defaults
)
(assert
 (<= 0 e1!)
)
(assert
 (<= 0 e2!)
)
(declare-const %%switch_label%%0 Bool)
(assert
 (not (or
   (and
    (=>
     (= e1! 0)
     (=>
      (= (MA__bin_sizes__result_sbin!pow2.? (I e1!)) 1)
      %%switch_label%%0
    ))
    (=>
     (not (= e1! 0))
     (=>
      (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1!)) (MA__bin_sizes__result_sbin!pow2.?
          (I e2!)
        ))
       ) (MA__bin_sizes__result_sbin!pow2.? (I (nClip (Add e1! e2!))))
      )
      %%switch_label%%0
   )))
   (not %%switch_label%%0)
)))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(declare-fun req%MA__bin_sizes__result_sbin!pow2_subtracts. (Int Int) Bool)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((e1! Int) (e2! Int)) (!
   (= (req%MA__bin_sizes__result_sbin!pow2_subtracts. e1! e2!) (=>
     %%global_location_label%%9
     (<= e1! e2!)
   ))
   :pattern ((req%MA__bin_sizes__result_sbin!pow2_subtracts. e1! e2!))
   :qid internal_req__MA__bin_sizes__result_sbin!pow2_subtracts._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!pow2_subtracts._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!pow2_subtracts. (Int Int) Bool)
(assert
 (forall ((e1! Int) (e2! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!pow2_subtracts. e1! e2!) (= (EucDiv (MA__bin_sizes__result_sbin!pow2.?
       (I e2!)
      ) (MA__bin_sizes__result_sbin!pow2.? (I e1!))
     ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!)))
   ))
   :pattern ((ens%MA__bin_sizes__result_sbin!pow2_subtracts. e1! e2!))
   :qid internal_ens__MA__bin_sizes__result_sbin!pow2_subtracts._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!pow2_subtracts._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const e1! Int)
(declare-const e2! Int)
(declare-const tmp%1 Int)
(declare-const tmp%2 Int)
(declare-const tmp%3 Int)
(assert
 fuel_defaults
)
(assert
 (<= 0 e1!)
)
(assert
 (<= 0 e2!)
)
(assert
 (<= e1! e2!)
)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(assert
 (not (and
   (and
    (=>
     (= tmp%1 (nClip (Sub e2! e1!)))
     (=>
      (ens%MA__bin_sizes__result_sbin!pow2_adds. tmp%1 e1!)
      (=>
       %%location_label%%0
       (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2!)) (MA__bin_sizes__result_sbin!pow2.?
          (I e1!)
         )
        ) (EucDiv (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!))) (MA__bin_sizes__result_sbin!pow2.?
            (I e1!)
          ))
         ) (MA__bin_sizes__result_sbin!pow2.? (I e1!))
    )))))
    (=>
     (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2!)) (MA__bin_sizes__result_sbin!pow2.?
        (I e1!)
       )
      ) (EucDiv (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!))) (MA__bin_sizes__result_sbin!pow2.?
          (I e1!)
        ))
       ) (MA__bin_sizes__result_sbin!pow2.? (I e1!))
     ))
     (and
      (=>
       (ens%MA__bin_sizes__result_sbin!pow2_positive. e1!)
       (=>
        (= tmp%2 (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!))))
        (=>
         (= tmp%3 (MA__bin_sizes__result_sbin!pow2.? (I e1!)))
         (and
          (=>
           %%location_label%%1
           (req%MA__bin_sizes__result_sbin!lemma_div_by_multiple. tmp%2 tmp%3)
          )
          (=>
           (ens%MA__bin_sizes__result_sbin!lemma_div_by_multiple. tmp%2 tmp%3)
           (=>
            %%location_label%%2
            (= (EucDiv (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!))) (MA__bin_sizes__result_sbin!pow2.?
                 (I e1!)
               ))
              ) (MA__bin_sizes__result_sbin!pow2.? (I e1!))
             ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!)))
      )))))))
      (=>
       (= (EucDiv (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!))) (MA__bin_sizes__result_sbin!pow2.?
            (I e1!)
          ))
         ) (MA__bin_sizes__result_sbin!pow2.? (I e1!))
        ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!)))
       )
       (=>
        %%location_label%%3
        (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2!)) (MA__bin_sizes__result_sbin!pow2.?
           (I e1!)
          )
         ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!)))
   ))))))
   (=>
    (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2!)) (MA__bin_sizes__result_sbin!pow2.?
       (I e1!)
      )
     ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!)))
    )
    (=>
     %%location_label%%4
     (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2!)) (MA__bin_sizes__result_sbin!pow2.?
        (I e1!)
       )
      ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2! e1!)))
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(declare-fun ens%MA__bin_sizes__result_sbin!pow2_properties. (Int) Bool)
(assert
 (forall ((no%param Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!pow2_properties. no%param) (and
     (forall ((e$ Poly)) (!
       (=>
        (has_type e$ INT)
        (> (MA__bin_sizes__result_sbin!pow2.? e$) 0)
       )
       :pattern ((MA__bin_sizes__result_sbin!pow2.? e$))
       :qid user_MA__bin_sizes__result_sbin__pow2_properties_0
       :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_0
     ))
     (forall ((e$ Poly)) (!
       (=>
        (has_type e$ INT)
        (=>
         (> (%I e$) 0)
         (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? e$) 2) (MA__bin_sizes__result_sbin!pow2.?
           (I (Sub (%I e$) 1))
       ))))
       :pattern ((MA__bin_sizes__result_sbin!pow2.? e$))
       :qid user_MA__bin_sizes__result_sbin__pow2_properties_1
       :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_1
     ))
     (forall ((e1$ Poly) (e2$ Poly)) (!
       (=>
        (and
         (has_type e1$ INT)
         (has_type e2$ INT)
        )
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I e1$)))
           (let
            ((tmp%%$2 (%I e2$)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (< (MA__bin_sizes__result_sbin!pow2.? e1$) (MA__bin_sizes__result_sbin!pow2.? e2$))
       ))
       :pattern ((MA__bin_sizes__result_sbin!pow2.? e1$) (MA__bin_sizes__result_sbin!pow2.?
         e2$
       ))
       :qid user_MA__bin_sizes__result_sbin__pow2_properties_2
       :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_2
     ))
     (forall ((e1$ Int) (e2$ Int)) (!
       (=>
        (and
         (<= 0 e1$)
         (<= 0 e2$)
        )
        (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1$)) (MA__bin_sizes__result_sbin!pow2.?
            (I e2$)
          ))
         ) (MA__bin_sizes__result_sbin!pow2.? (I (Add e1$ e2$)))
       ))
       :pattern ((MA__bin_sizes__result_sbin!pow2.? (I (Add e1$ e2$))))
       :qid user_MA__bin_sizes__result_sbin__pow2_properties_3
       :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_3
     ))
     (forall ((e1$ Int) (e2$ Int)) (!
       (=>
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 e1$))
          (let
           ((tmp%%$2 e2$))
           (and
            (<= tmp%%$ tmp%%$1)
            (<= tmp%%$1 tmp%%$2)
        ))))
        (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2$)) (MA__bin_sizes__result_sbin!pow2.?
           (I e1$)
          )
         ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2$ e1$)))
       ))
       :pattern ((MA__bin_sizes__result_sbin!pow2.? (I (Sub e2$ e1$))))
       :qid user_MA__bin_sizes__result_sbin__pow2_properties_4
       :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_4
   ))))
   :pattern ((ens%MA__bin_sizes__result_sbin!pow2_properties. no%param))
   :qid internal_ens__MA__bin_sizes__result_sbin!pow2_properties._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!pow2_properties._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const no%param Int)
(declare-const e@ Poly)
(declare-const e$1@ Poly)
(declare-const e1@ Poly)
(declare-const e2@ Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Int)
(declare-const tmp%3 Int)
(declare-const tmp%4 Int)
(declare-const diff@ Int)
(declare-const e1$1@ Int)
(declare-const e2$1@ Int)
(declare-const e1$2@ Int)
(declare-const e2$2@ Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(declare-const %%location_label%%5 Bool)
(declare-const %%location_label%%6 Bool)
(declare-const %%location_label%%7 Bool)
(declare-const %%location_label%%8 Bool)
(declare-const %%location_label%%9 Bool)
(declare-const %%location_label%%10 Bool)
(declare-const %%location_label%%11 Bool)
(declare-const %%location_label%%12 Bool)
(declare-const %%location_label%%13 Bool)
(declare-const %%location_label%%14 Bool)
(assert
 (not (and
   (=>
    (has_type e@ INT)
    (=>
     (ens%MA__bin_sizes__result_sbin!pow2_positive. (%I e@))
     (=>
      %%location_label%%0
      (> (MA__bin_sizes__result_sbin!pow2.? e@) 0)
   )))
   (=>
    (forall ((e$ Poly)) (!
      (=>
       (has_type e$ INT)
       (> (MA__bin_sizes__result_sbin!pow2.? e$) 0)
      )
      :pattern ((MA__bin_sizes__result_sbin!pow2.? e$))
      :qid user_MA__bin_sizes__result_sbin__pow2_properties_10
      :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_10
    ))
    (and
     (=>
      (has_type e$1@ INT)
      (=>
       (> (%I e$1@) 0)
       (=>
        (= (MA__bin_sizes__result_sbin!pow2.? (I 1)) 2)
        (and
         (=>
          %%location_label%%1
          (req%MA__bin_sizes__result_sbin!pow2_subtracts. 1 (nClip (%I e$1@)))
         )
         (=>
          (ens%MA__bin_sizes__result_sbin!pow2_subtracts. 1 (nClip (%I e$1@)))
          (=>
           %%location_label%%2
           (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? e$1@) 2) (MA__bin_sizes__result_sbin!pow2.?
             (I (Sub (%I e$1@) 1))
     ))))))))
     (=>
      (forall ((e$ Poly)) (!
        (=>
         (has_type e$ INT)
         (=>
          (> (%I e$) 0)
          (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? e$) 2) (MA__bin_sizes__result_sbin!pow2.?
            (I (Sub (%I e$) 1))
        ))))
        :pattern ((MA__bin_sizes__result_sbin!pow2.? e$))
        :qid user_MA__bin_sizes__result_sbin__pow2_properties_11
        :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_11
      ))
      (and
       (=>
        (has_type e1@ INT)
        (=>
         (has_type e2@ INT)
         (=>
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I e1@)))
            (let
             ((tmp%%$2 (%I e2@)))
             (and
              (<= tmp%%$ tmp%%$1)
              (< tmp%%$1 tmp%%$2)
          ))))
          (=>
           (= diff@ (Sub (%I e2@) (%I e1@)))
           (=>
            (= tmp%1 (> (MA__bin_sizes__result_sbin!pow2.? (I diff@)) 1))
            (and
             (=>
              %%location_label%%3
              tmp%1
             )
             (=>
              tmp%1
              (=>
               (ens%MA__bin_sizes__result_sbin!pow2_positive. diff@)
               (=>
                (ens%MA__bin_sizes__result_sbin!pow2_positive. (%I e1@))
                (=>
                 (ens%MA__bin_sizes__result_sbin!pow2_positive. (%I e2@))
                 (and
                  (=>
                   (ens%MA__bin_sizes__result_sbin!pow2_adds. (nClip (%I e1@)) (nClip diff@))
                   (=>
                    %%location_label%%4
                    (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? e1@) (MA__bin_sizes__result_sbin!pow2.?
                        (I diff@)
                      ))
                     ) (MA__bin_sizes__result_sbin!pow2.? e2@)
                  )))
                  (=>
                   (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? e1@) (MA__bin_sizes__result_sbin!pow2.?
                       (I diff@)
                     ))
                    ) (MA__bin_sizes__result_sbin!pow2.? e2@)
                   )
                   (=>
                    (= tmp%2 (MA__bin_sizes__result_sbin!pow2.? e1@))
                    (=>
                     (= tmp%3 (MA__bin_sizes__result_sbin!pow2.? (I diff@)))
                     (=>
                      (= tmp%4 (MA__bin_sizes__result_sbin!pow2.? e2@))
                      (and
                       (=>
                        %%location_label%%5
                        (req%MA__bin_sizes__result_sbin!mul_ordering. tmp%2 tmp%3 tmp%4)
                       )
                       (=>
                        (ens%MA__bin_sizes__result_sbin!mul_ordering. tmp%2 tmp%3 tmp%4)
                        (=>
                         %%location_label%%6
                         (< (MA__bin_sizes__result_sbin!pow2.? e1@) (MA__bin_sizes__result_sbin!pow2.? e2@))
       ))))))))))))))))))
       (=>
        (forall ((e1$ Poly) (e2$ Poly)) (!
          (=>
           (and
            (has_type e1$ INT)
            (has_type e2$ INT)
           )
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$4 (%I e1$)))
              (let
               ((tmp%%$5 (%I e2$)))
               (and
                (<= tmp%%$ tmp%%$4)
                (< tmp%%$4 tmp%%$5)
            ))))
            (< (MA__bin_sizes__result_sbin!pow2.? e1$) (MA__bin_sizes__result_sbin!pow2.? e2$))
          ))
          :pattern ((MA__bin_sizes__result_sbin!pow2.? e1$) (MA__bin_sizes__result_sbin!pow2.?
            e2$
          ))
          :qid user_MA__bin_sizes__result_sbin__pow2_properties_13
          :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_13
        ))
        (and
         (=>
          (and
           (<= 0 e1$1@)
           (<= 0 e2$1@)
          )
          (=>
           (ens%MA__bin_sizes__result_sbin!pow2_adds. (nClip e1$1@) (nClip e2$1@))
           (=>
            %%location_label%%7
            (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1$1@)) (MA__bin_sizes__result_sbin!pow2.?
                (I e2$1@)
              ))
             ) (MA__bin_sizes__result_sbin!pow2.? (I (Add e1$1@ e2$1@)))
         ))))
         (=>
          (forall ((e1$ Int) (e2$ Int)) (!
            (=>
             (and
              (<= 0 e1$)
              (<= 0 e2$)
             )
             (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1$)) (MA__bin_sizes__result_sbin!pow2.?
                 (I e2$)
               ))
              ) (MA__bin_sizes__result_sbin!pow2.? (I (Add e1$ e2$)))
            ))
            :pattern ((MA__bin_sizes__result_sbin!pow2.? (I (Add e1$ e2$))))
            :qid user_MA__bin_sizes__result_sbin__pow2_properties_14
            :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_14
          ))
          (and
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$7 e1$2@))
              (let
               ((tmp%%$8 e2$2@))
               (and
                (<= tmp%%$ tmp%%$7)
                (<= tmp%%$7 tmp%%$8)
            ))))
            (and
             (=>
              %%location_label%%8
              (req%MA__bin_sizes__result_sbin!pow2_subtracts. (nClip e1$2@) (nClip e2$2@))
             )
             (=>
              (ens%MA__bin_sizes__result_sbin!pow2_subtracts. (nClip e1$2@) (nClip e2$2@))
              (=>
               %%location_label%%9
               (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2$2@)) (MA__bin_sizes__result_sbin!pow2.?
                  (I e1$2@)
                 )
                ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2$2@ e1$2@)))
           )))))
           (=>
            (forall ((e1$ Int) (e2$ Int)) (!
              (=>
               (let
                ((tmp%%$ 0))
                (let
                 ((tmp%%$10 e1$))
                 (let
                  ((tmp%%$11 e2$))
                  (and
                   (<= tmp%%$ tmp%%$10)
                   (<= tmp%%$10 tmp%%$11)
               ))))
               (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2$)) (MA__bin_sizes__result_sbin!pow2.?
                  (I e1$)
                 )
                ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2$ e1$)))
              ))
              :pattern ((MA__bin_sizes__result_sbin!pow2.? (I (Sub e2$ e1$))))
              :qid user_MA__bin_sizes__result_sbin__pow2_properties_15
              :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_15
            ))
            (and
             (=>
              %%location_label%%10
              (forall ((e$ Poly)) (!
                (=>
                 (has_type e$ INT)
                 (> (MA__bin_sizes__result_sbin!pow2.? e$) 0)
                )
                :pattern ((MA__bin_sizes__result_sbin!pow2.? e$))
                :qid user_MA__bin_sizes__result_sbin__pow2_properties_5
                :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_5
             )))
             (and
              (=>
               %%location_label%%11
               (forall ((e$ Poly)) (!
                 (=>
                  (has_type e$ INT)
                  (=>
                   (> (%I e$) 0)
                   (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? e$) 2) (MA__bin_sizes__result_sbin!pow2.?
                     (I (Sub (%I e$) 1))
                 ))))
                 :pattern ((MA__bin_sizes__result_sbin!pow2.? e$))
                 :qid user_MA__bin_sizes__result_sbin__pow2_properties_6
                 :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_6
              )))
              (and
               (=>
                %%location_label%%12
                (forall ((e1$ Poly) (e2$ Poly)) (!
                  (=>
                   (and
                    (has_type e1$ INT)
                    (has_type e2$ INT)
                   )
                   (=>
                    (let
                     ((tmp%%$ 0))
                     (let
                      ((tmp%%$1 (%I e1$)))
                      (let
                       ((tmp%%$2 (%I e2$)))
                       (and
                        (<= tmp%%$ tmp%%$1)
                        (< tmp%%$1 tmp%%$2)
                    ))))
                    (< (MA__bin_sizes__result_sbin!pow2.? e1$) (MA__bin_sizes__result_sbin!pow2.? e2$))
                  ))
                  :pattern ((MA__bin_sizes__result_sbin!pow2.? e1$) (MA__bin_sizes__result_sbin!pow2.?
                    e2$
                  ))
                  :qid user_MA__bin_sizes__result_sbin__pow2_properties_7
                  :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_7
               )))
               (and
                (=>
                 %%location_label%%13
                 (forall ((e1$ Int) (e2$ Int)) (!
                   (=>
                    (and
                     (<= 0 e1$)
                     (<= 0 e2$)
                    )
                    (= (nClip (Mul (MA__bin_sizes__result_sbin!pow2.? (I e1$)) (MA__bin_sizes__result_sbin!pow2.?
                        (I e2$)
                      ))
                     ) (MA__bin_sizes__result_sbin!pow2.? (I (Add e1$ e2$)))
                   ))
                   :pattern ((MA__bin_sizes__result_sbin!pow2.? (I (Add e1$ e2$))))
                   :qid user_MA__bin_sizes__result_sbin__pow2_properties_8
                   :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_8
                )))
                (=>
                 %%location_label%%14
                 (forall ((e1$ Int) (e2$ Int)) (!
                   (=>
                    (let
                     ((tmp%%$ 0))
                     (let
                      ((tmp%%$1 e1$))
                      (let
                       ((tmp%%$2 e2$))
                       (and
                        (<= tmp%%$ tmp%%$1)
                        (<= tmp%%$1 tmp%%$2)
                    ))))
                    (= (EucDiv (MA__bin_sizes__result_sbin!pow2.? (I e2$)) (MA__bin_sizes__result_sbin!pow2.?
                       (I e1$)
                      )
                     ) (MA__bin_sizes__result_sbin!pow2.? (I (Sub e2$ e1$)))
                   ))
                   :pattern ((MA__bin_sizes__result_sbin!pow2.? (I (Sub e2$ e1$))))
                   :qid user_MA__bin_sizes__result_sbin__pow2_properties_9
                   :skolemid skolem_user_MA__bin_sizes__result_sbin__pow2_properties_9
)))))))))))))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(declare-fun req%MA__bin_sizes__result_sbin!shift_is_div. (Int Int) Bool)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((x! Int) (shift! Int)) (!
   (= (req%MA__bin_sizes__result_sbin!shift_is_div. x! shift!) (=>
     %%global_location_label%%10
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 shift!))
       (let
        ((tmp%%$2 64))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%MA__bin_sizes__result_sbin!shift_is_div. x! shift!))
   :qid internal_req__MA__bin_sizes__result_sbin!shift_is_div._definition
   :skolemid skolem_internal_req__MA__bin_sizes__result_sbin!shift_is_div._definition
)))
(declare-fun ens%MA__bin_sizes__result_sbin!shift_is_div. (Int Int) Bool)
(assert
 (forall ((x! Int) (shift! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!shift_is_div. x! shift!) (= (uClip 64 (bitshr (I x!)
       (I shift!)
      )
     ) (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I shift!)))
   ))
   :pattern ((ens%MA__bin_sizes__result_sbin!shift_is_div. x! shift!))
   :qid internal_ens__MA__bin_sizes__result_sbin!shift_is_div._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!shift_is_div._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const x! Int)
(declare-const shift! Int)
(declare-const tmp%1 Int)
(declare-const tmp%2 Int)
(declare-const tmp%3 Int)
(declare-const tmp%4 Int)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(assert
 (uInv 64 x!)
)
(assert
 (uInv 64 shift!)
)
(assert
 (let
  ((tmp%%$ 0))
  (let
   ((tmp%%$1 shift!))
   (let
    ((tmp%%$2 64))
    (and
     (<= tmp%%$ tmp%%$1)
     (< tmp%%$1 tmp%%$2)
)))))
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(declare-const %%location_label%%5 Bool)
(declare-const %%location_label%%6 Bool)
(declare-const %%location_label%%7 Bool)
(declare-const %%location_label%%8 Bool)
(declare-const %%location_label%%9 Bool)
(declare-const %%location_label%%10 Bool)
(declare-const %%location_label%%11 Bool)
(assert
 (not (=>
   (= decrease%init0 shift!)
   (or
    (and
     (=>
      (= shift! 0)
      (and
       (=>
        %%location_label%%0
        true
       )
       (=>
        (= (uClip 64 (bitshr (I x!) (I 0))) x!)
        (=>
         (= (MA__bin_sizes__result_sbin!pow2.? (I 0)) 1)
         %%switch_label%%0
     ))))
     (=>
      (not (= shift! 0))
      (and
       (=>
        %%location_label%%1
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$4 shift!))
          (let
           ((tmp%%$5 64))
           (and
            (< tmp%%$ tmp%%$4)
            (< tmp%%$4 tmp%%$5)
       )))))
       (=>
        (= (uClip 64 (bitshr (I x!) (I shift!))) (EucDiv (uClip 64 (bitshr (I x!) (I (uClip 64
              (uClip 64 (Sub shift! 1))
           )))
          ) 2
        ))
        (and
         (=>
          (= tmp%1 (nClip (Sub shift! 1)))
          (=>
           (ens%MA__bin_sizes__result_sbin!pow2_adds. tmp%1 1)
           (=>
            %%location_label%%2
            (= (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I shift!))) (EucDiv x! (nClip (Mul
                (MA__bin_sizes__result_sbin!pow2.? (I (Sub shift! 1))) (MA__bin_sizes__result_sbin!pow2.?
                 (I 1)
         ))))))))
         (=>
          (= (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I shift!))) (EucDiv x! (nClip (Mul
              (MA__bin_sizes__result_sbin!pow2.? (I (Sub shift! 1))) (MA__bin_sizes__result_sbin!pow2.?
               (I 1)
          )))))
          (and
           (=>
            (= tmp%2 (Sub shift! 1))
            (=>
             (ens%MA__bin_sizes__result_sbin!pow2_positive. tmp%2)
             (=>
              (= tmp%3 (MA__bin_sizes__result_sbin!pow2.? (I (Sub shift! 1))))
              (and
               (=>
                %%location_label%%3
                (req%MA__bin_sizes__result_sbin!div2. x! tmp%3)
               )
               (=>
                (ens%MA__bin_sizes__result_sbin!div2. x! tmp%3)
                (=>
                 %%location_label%%4
                 (= (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I shift!))) (EucDiv (EucDiv x! (MA__bin_sizes__result_sbin!pow2.?
                     (I (Sub shift! 1))
                    )
                   ) 2
           ))))))))
           (=>
            (= (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I shift!))) (EucDiv (EucDiv x! (MA__bin_sizes__result_sbin!pow2.?
                (I (Sub shift! 1))
               )
              ) 2
            ))
            (and
             (and
              (=>
               %%location_label%%5
               (= (uClip 64 (bitshr (I x!) (I shift!))) (EucDiv (uClip 64 (bitshr (I x!) (I (uClip 64
                     (uClip 64 (Sub shift! 1))
                  )))
                 ) 2
              )))
              (=>
               (= (uClip 64 (bitshr (I x!) (I shift!))) (EucDiv (uClip 64 (bitshr (I x!) (I (uClip 64
                     (uClip 64 (Sub shift! 1))
                  )))
                 ) 2
               ))
               (and
                (=>
                 (= tmp%4 (uClip 64 (Sub shift! 1)))
                 (and
                  (=>
                   %%location_label%%6
                   (check_decrease_height (I (let
                      ((x!$0 x!) (shift!$1 tmp%4))
                      shift!$1
                     )
                    ) (I decrease%init0) false
                  ))
                  (and
                   (=>
                    %%location_label%%7
                    (req%MA__bin_sizes__result_sbin!shift_is_div. x! tmp%4)
                   )
                   (=>
                    (ens%MA__bin_sizes__result_sbin!shift_is_div. x! tmp%4)
                    (=>
                     %%location_label%%8
                     (= (EucDiv (uClip 64 (bitshr (I x!) (I (uClip 64 (uClip 64 (Sub shift! 1)))))) 2)
                      (EucDiv (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I (Sub shift! 1)))) 2)
                ))))))
                (=>
                 (= (EucDiv (uClip 64 (bitshr (I x!) (I (uClip 64 (uClip 64 (Sub shift! 1)))))) 2)
                  (EucDiv (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I (Sub shift! 1)))) 2)
                 )
                 (and
                  (=>
                   %%location_label%%9
                   (= (EucDiv (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I (Sub shift! 1)))) 2) (
                     EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I shift!))
                  )))
                  (=>
                   (= (EucDiv (EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I (Sub shift! 1)))) 2) (
                     EucDiv x! (MA__bin_sizes__result_sbin!pow2.? (I shift!))
                   ))
                   (=>
                    %%location_label%%10
                    (= (uClip 64 (bitshr (I x!) (I shift!))) (EucDiv x! (MA__bin_sizes__result_sbin!pow2.?
                       (I shift!)
             ))))))))))
             (=>
              (= (uClip 64 (bitshr (I x!) (I shift!))) (EucDiv x! (MA__bin_sizes__result_sbin!pow2.?
                 (I shift!)
              )))
              %%switch_label%%0
    ))))))))))
    (and
     (not %%switch_label%%0)
     (=>
      %%location_label%%11
      (= (uClip 64 (bitshr (I x!) (I shift!))) (EucDiv x! (MA__bin_sizes__result_sbin!pow2.?
         (I shift!)
)))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(declare-fun ens%MA__bin_sizes__result_sbin!result_sbin. (Int Int) Bool)
(assert
 (forall ((size_start! Int) (size_end! Int)) (!
   (= (ens%MA__bin_sizes__result_sbin!result_sbin. size_start! size_end!) (=>
     (MA__bin_sizes__result_sbin!check_sbin.? (I size_start!) (I size_end!))
     (forall ((size$ Poly)) (!
       (=>
        (has_type size$ INT)
        (=>
         (let
          ((tmp%%$ size_start!))
          (let
           ((tmp%%$1 (%I size$)))
           (let
            ((tmp%%$2 size_end!))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (MA__bin_sizes__result_sbin!property_sbin.? size$)
       ))
       :pattern ((MA__bin_sizes__result_sbin!property_sbin.? size$))
       :qid user_MA__bin_sizes__result_sbin__result_sbin_0
       :skolemid skolem_user_MA__bin_sizes__result_sbin__result_sbin_0
   ))))
   :pattern ((ens%MA__bin_sizes__result_sbin!result_sbin. size_start! size_end!))
   :qid internal_ens__MA__bin_sizes__result_sbin!result_sbin._definition
   :skolemid skolem_internal_ens__MA__bin_sizes__result_sbin!result_sbin._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const size_start! Int)
(declare-const size_end! Int)
(declare-const tmp%1 Int)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (=>
   (= decrease%init0 (Sub size_end! size_start!))
   (or
    (and
     (=>
      (>= size_start! size_end!)
      %%switch_label%%0
     )
     (=>
      (not (>= size_start! size_end!))
      (=>
       (= tmp%1 (Add size_start! 1))
       (and
        (=>
         %%location_label%%0
         (check_decrease_height (I (let
            ((size_start!$0 tmp%1) (size_end!$1 size_end!))
            (Sub size_end!$1 size_start!$0)
           )
          ) (I decrease%init0) false
        ))
        (=>
         (ens%MA__bin_sizes__result_sbin!result_sbin. tmp%1 size_end!)
         %%switch_label%%0
    )))))
    (and
     (not %%switch_label%%0)
     (=>
      %%location_label%%1
      (=>
       (MA__bin_sizes__result_sbin!check_sbin.? (I size_start!) (I size_end!))
       (forall ((size$ Poly)) (!
         (=>
          (has_type size$ INT)
          (=>
           (let
            ((tmp%%$ size_start!))
            (let
             ((tmp%%$1 (%I size$)))
             (let
              ((tmp%%$2 size_end!))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (MA__bin_sizes__result_sbin!property_sbin.? size$)
         ))
         :pattern ((MA__bin_sizes__result_sbin!property_sbin.? size$))
         :qid user_MA__bin_sizes__result_sbin__result_sbin_1
         :skolemid skolem_user_MA__bin_sizes__result_sbin__result_sbin_1
)))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
