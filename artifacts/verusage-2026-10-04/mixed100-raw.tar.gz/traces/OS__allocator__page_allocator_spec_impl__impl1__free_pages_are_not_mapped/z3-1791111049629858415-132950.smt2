(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!std_specs.option.impl&%0.is_Some. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.arrow_0. FuelId)
(declare-const fuel%vstd!std_specs.option.is_some. FuelId)
(declare-const fuel%vstd!std_specs.option.is_none. FuelId)
(declare-const fuel%vstd!std_specs.option.spec_unwrap. FuelId)
(declare-const fuel%vstd!array.array_view. FuelId)
(declare-const fuel%vstd!array.impl&%0.view. FuelId)
(declare-const fuel%vstd!array.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!array.lemma_array_index. FuelId)
(declare-const fuel%vstd!array.array_len_matches_n. FuelId)
(declare-const fuel%vstd!array.axiom_array_ext_equal. FuelId)
(declare-const fuel%vstd!array.axiom_array_has_resolved. FuelId)
(declare-const fuel%vstd!array.axiom_array_decreases_to_seq. FuelId)
(declare-const fuel%vstd!array.lemma_array_index_decreases. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.axiom_map_decreases_to_entry. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!pervasive.strictly_cloned. FuelId)
(declare-const fuel%vstd!pervasive.cloned. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%6.is_init. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.contains. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.to_set_ensures. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.Set.subset_of. FuelId)
(declare-const fuel%vstd!set.impl&%0.spec_add. FuelId)
(declare-const fuel%vstd!set.impl&%0.finite. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!set.lemma_set_union. FuelId)
(declare-const fuel%vstd!set.lemma_set_contains_len. FuelId)
(declare-const fuel%vstd!simple_pptr.impl&%1.is_init. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%14.view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%20.view. FuelId)
(declare-const fuel%vstd!view.impl&%26.view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%vstd!view.impl&%36.view. FuelId)
(declare-const fuel%vstd!view.impl&%46.view. FuelId)
(declare-const fuel%vstd!view.impl&%48.view. FuelId)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_4k.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_2m.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_1g.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.
 FuelId
)
(declare-const fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!std_specs.option.impl&%0.is_Some. fuel%vstd!std_specs.option.impl&%0.arrow_0.
  fuel%vstd!std_specs.option.is_some. fuel%vstd!std_specs.option.is_none. fuel%vstd!std_specs.option.spec_unwrap.
  fuel%vstd!array.array_view. fuel%vstd!array.impl&%0.view. fuel%vstd!array.impl&%2.spec_index.
  fuel%vstd!array.lemma_array_index. fuel%vstd!array.array_len_matches_n. fuel%vstd!array.axiom_array_ext_equal.
  fuel%vstd!array.axiom_array_has_resolved. fuel%vstd!array.axiom_array_decreases_to_seq.
  fuel%vstd!array.lemma_array_index_decreases. fuel%vstd!function.axiom_fn_mut_call_requires.
  fuel%vstd!function.axiom_fn_mut_call_ensures. fuel%vstd!iset.lemma_iset_ext_equal.
  fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index. fuel%vstd!map.axiom_map_index_decreases.
  fuel%vstd!map.axiom_map_decreases_to_entry. fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep.
  fuel%vstd!pervasive.strictly_cloned. fuel%vstd!pervasive.cloned. fuel%vstd!raw_ptr.impl&%6.is_init.
  fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.lemma_seq_index_decreases. fuel%vstd!seq.lemma_seq_new_len.
  fuel%vstd!seq.lemma_seq_new_index. fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep.
  fuel%vstd!seq_lib.impl&%0.contains. fuel%vstd!seq_lib.impl&%0.to_set_ensures. fuel%vstd!set.Set.contains.
  fuel%vstd!set.Set.subset_of. fuel%vstd!set.impl&%0.spec_add. fuel%vstd!set.impl&%0.finite.
  fuel%vstd!set.axiom_set_ext_equal. fuel%vstd!set.axiom_set_ext_equal_deep. fuel%vstd!set.axiom_set_decreases_to_member.
  fuel%vstd!set.lemma_set_union. fuel%vstd!set.lemma_set_contains_len. fuel%vstd!simple_pptr.impl&%1.is_init.
  fuel%vstd!view.impl&%0.view. fuel%vstd!view.impl&%2.view. fuel%vstd!view.impl&%4.view.
  fuel%vstd!view.impl&%6.view. fuel%vstd!view.impl&%14.view. fuel%vstd!view.impl&%16.view.
  fuel%vstd!view.impl&%18.view. fuel%vstd!view.impl&%20.view. fuel%vstd!view.impl&%26.view.
  fuel%vstd!view.impl&%30.view. fuel%vstd!view.impl&%36.view. fuel%vstd!view.impl&%46.view.
  fuel%vstd!view.impl&%48.view. fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_4k.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_2m.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_1g.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.
  fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!array.group_array_axioms.)
  (and
   (fuel_bool_default fuel%vstd!array.array_len_matches_n.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index.)
   (fuel_bool_default fuel%vstd!array.axiom_array_ext_equal.)
   (fuel_bool_default fuel%vstd!array.axiom_array_has_resolved.)
   (fuel_bool_default fuel%vstd!array.axiom_array_decreases_to_seq.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index_decreases.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.axiom_map_decreases_to_entry.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.to_set_ensures.)
   (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
   (fuel_bool_default fuel%vstd!set.lemma_set_union.)
   (fuel_bool_default fuel%vstd!set.lemma_set_contains_len.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%vstd!array.ArrayAdditionalSpecFns. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%core!clone.Clone. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Copy. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.option.OptionAdditionalFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-sort alloc!alloc.Global. 0)
(declare-sort vstd!map.Map<usize./vstd!set.Set<usize.>.>. 0)
(declare-sort vstd!seq.Seq<i32.>. 0)
(declare-sort vstd!seq.Seq<usize.>. 0)
(declare-sort vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
 0
)
(declare-sort vstd!set.Set<usize.>. 0)
(declare-sort vstd!set.Set<tuple%2<usize./usize.>.>. 0)
(declare-datatypes ((core!option.Option. 0) (vstd!raw_ptr.MemContents. 0) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
   0
  ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
   0
  ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
   0
  ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
   0
  ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
   0
  ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
   0
  ) (tuple%0. 0) (tuple%1. 0) (tuple%2. 0)
 ) (((core!option.Option./None) (core!option.Option./Some (core!option.Option./Some/?0
     Poly
   ))
  ) ((vstd!raw_ptr.MemContents./Uninit) (vstd!raw_ptr.MemContents./Init (vstd!raw_ptr.MemContents./Init/?0
     Poly
   ))
  ) ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node
    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/?value
     core!option.Option.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/?next
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/?prev
     Int
   ))
  ) ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList
    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?ar
     %%Function%%
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?spec_seq
     Poly
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list
     vstd!seq.Seq<i32.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list_head
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list_tail
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list_len
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list
     vstd!seq.Seq<i32.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list_head
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list_tail
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list_len
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?size
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?arr_seq
     Poly
   ))
  ) ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page
    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?addr
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?state
     OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?is_io_page
     Bool
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?rev_pointer
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?ref_count
     Int
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?owning_container
     core!option.Option.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?mappings
     vstd!set.Set<tuple%2<usize./usize.>.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?io_mappings
     vstd!set.Set<tuple%2<usize./usize.>.>.
   ))
  ) ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator
    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_array
     OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?free_pages_4k
     OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?free_pages_2m
     OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?free_pages_1g
     OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?allocated_pages_4k
     vstd!set.Set<usize.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?allocated_pages_2m
     vstd!set.Set<usize.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?allocated_pages_1g
     vstd!set.Set<usize.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?mapped_pages_4k
     vstd!set.Set<usize.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?mapped_pages_2m
     vstd!set.Set<usize.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?mapped_pages_1g
     vstd!set.Set<usize.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_perms_4k
     Poly
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_perms_2m
     Poly
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_perms_1g
     Poly
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?container_map_4k
     vstd!map.Map<usize./vstd!set.Set<usize.>.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?container_map_2m
     vstd!map.Map<usize./vstd!set.Set<usize.>.>.
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?container_map_1g
     vstd!map.Map<usize./vstd!set.Set<usize.>.>.
   ))
  ) ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Unavailable4k)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Unavailable2m)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Unavailable1g)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Pagetable)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated4k)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated2m)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated1g)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free4k)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free2m)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free1g)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Merged2m)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Merged1g)
   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Io)
  ) ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array
    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/?seq
     Poly
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/?ar
     %%Function%%
   ))
  ) ((tuple%0./tuple%0)) ((tuple%1./tuple%1 (tuple%1./tuple%1/?0 Poly))) ((tuple%2./tuple%2
    (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1 Poly)
))))
(declare-fun core!option.Option./Some/0 (Dcr Type core!option.Option.) Poly)
(declare-fun vstd!raw_ptr.MemContents./Init/0 (Dcr Type vstd!raw_ptr.MemContents.)
 Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.)
 core!option.Option.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 %%Function%%
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 vstd!seq.Seq<i32.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 vstd!seq.Seq<i32.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 core!option.Option.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 vstd!set.Set<tuple%2<usize./usize.>.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 vstd!set.Set<tuple%2<usize./usize.>.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!map.Map<usize./vstd!set.Set<usize.>.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!map.Map<usize./vstd!set.Set<usize.>.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 vstd!map.Map<usize./vstd!set.Set<usize.>.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.)
 Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.)
 %%Function%%
)
(declare-fun tuple%1./tuple%1/0 (tuple%1.) Poly)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-fun TYPE%fun%1. (Dcr Type Dcr Type) Type)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-fun TYPE%core!option.Option. (Dcr Type) Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!raw_ptr.MemContents. (Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-fun TYPE%vstd!simple_pptr.PointsTo. (Dcr Type) Type)
(declare-fun TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
 (Dcr Type) Type
)
(declare-fun TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
 (Dcr Type Dcr Type) Type
)
(declare-const TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
 Type
)
(declare-const TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
 Type
)
(declare-const TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
 Type
)
(declare-fun TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
 (Dcr Type Dcr Type) Type
)
(declare-fun TYPE%tuple%1. (Dcr Type) Type)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-fun FNDEF%core!clone.Clone.clone. (Dcr Type) Type)
(declare-fun Poly%fun%1. (%%Function%%) Poly)
(declare-fun %Poly%fun%1. (Poly) %%Function%%)
(declare-fun Poly%array%. (%%Function%%) Poly)
(declare-fun %Poly%array%. (Poly) %%Function%%)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. (vstd!map.Map<usize./vstd!set.Set<usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. (Poly) vstd!map.Map<usize./vstd!set.Set<usize.>.>.)
(declare-fun Poly%vstd!seq.Seq<i32.>. (vstd!seq.Seq<i32.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<i32.>. (Poly) vstd!seq.Seq<i32.>.)
(declare-fun Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq<usize.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<usize.>. (Poly) vstd!seq.Seq<usize.>.)
(declare-fun Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
 (vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
 (Poly) vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
)
(declare-fun Poly%vstd!set.Set<usize.>. (vstd!set.Set<usize.>.) Poly)
(declare-fun %Poly%vstd!set.Set<usize.>. (Poly) vstd!set.Set<usize.>.)
(declare-fun Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (vstd!set.Set<tuple%2<usize./usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (Poly) vstd!set.Set<tuple%2<usize./usize.>.>.)
(declare-fun Poly%core!option.Option. (core!option.Option.) Poly)
(declare-fun %Poly%core!option.Option. (Poly) core!option.Option.)
(declare-fun Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents.) Poly)
(declare-fun %Poly%vstd!raw_ptr.MemContents. (Poly) vstd!raw_ptr.MemContents.)
(declare-fun Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.)
 Poly
)
(declare-fun %Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
 (Poly) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
)
(declare-fun Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
 Poly
)
(declare-fun %Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
 (Poly) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
)
(declare-fun Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
 Poly
)
(declare-fun %Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
 (Poly) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
)
(declare-fun Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 Poly
)
(declare-fun %Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
 (Poly) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
)
(declare-fun Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
 Poly
)
(declare-fun %Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
 (Poly) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
)
(declare-fun Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.)
 Poly
)
(declare-fun %Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
 (Poly) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%1. (tuple%1.) Poly)
(declare-fun %Poly%tuple%1. (Poly) tuple%1.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%1. (Poly%fun%1. x)))
   :pattern ((Poly%fun%1. x))
   :qid internal_crate__fun__1_box_axiom_definition
   :skolemid skolem_internal_crate__fun__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%fun%1. (%Poly%fun%1. x)))
   )
   :pattern ((has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__1_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x %%Function%%)) (!
   (=>
    (forall ((T%0 Poly)) (!
      (=>
       (has_type T%0 T%0&)
       (has_type (%%apply%%0 x T%0) T%1&)
      )
      :pattern ((has_type (%%apply%%0 x T%0) T%1&))
      :qid internal_crate__fun__1_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__1_constructor_inner_definition
    ))
    (has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_constructor_definition
   :skolemid skolem_internal_crate__fun__1_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (has_type (%%apply%%0 x T%0) T%1&)
   )
   :pattern ((%%apply%%0 x T%0) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&.
      T%1&
   )))
   :qid internal_crate__fun__1_apply_definition
   :skolemid skolem_internal_crate__fun__1_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (height_lt (height (%%apply%%0 x T%0)) (height (fun_from_recursive_field (Poly%fun%1.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0)) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_crate__fun__1_height_apply_definition
   :skolemid skolem_internal_crate__fun__1_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (forall ((T%0 Poly)) (!
       (=>
        (has_type T%0 T%0&)
        (ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1. y) T%0))
       )
       :pattern ((ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1.
           y
          ) T%0
       )))
       :qid internal_crate__fun__1_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__1_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_crate__fun__1_ext_equal_definition
   :skolemid skolem_internal_crate__fun__1_ext_equal_definition
)))
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%array%. (Poly%array%. x)))
   :pattern ((Poly%array%. x))
   :qid internal_crate__array___box_axiom_definition
   :skolemid skolem_internal_crate__array___box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (ARRAY T&. T& N&. N&))
    (= x (Poly%array%. (%Poly%array%. x)))
   )
   :pattern ((has_type x (ARRAY T&. T& N&. N&)))
   :qid internal_crate__array___unbox_axiom_definition
   :skolemid skolem_internal_crate__array___unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!set.Set<usize.>.>.)) (!
   (= x (%Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. x))
   :qid internal_vstd__map__Map<usize./vstd!set.Set<usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!set.Set<usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!set.Set. $ USIZE)))
    (= x (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. (%Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!set.Set. $ USIZE))))
   :qid internal_vstd__map__Map<usize./vstd!set.Set<usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!set.Set<usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!set.Set<usize.>.>.)) (!
   (has_type (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. x) (TYPE%vstd!map.Map.
     $ USIZE $ (TYPE%vstd!set.Set. $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. x) (TYPE%vstd!map.Map.
      $ USIZE $ (TYPE%vstd!set.Set. $ USIZE)
   )))
   :qid internal_vstd__map__Map<usize./vstd!set.Set<usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!set.Set<usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<i32.>.)) (!
   (= x (%Poly%vstd!seq.Seq<i32.>. (Poly%vstd!seq.Seq<i32.>. x)))
   :pattern ((Poly%vstd!seq.Seq<i32.>. x))
   :qid internal_vstd__seq__Seq<i32.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<i32.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (SINT 32)))
    (= x (Poly%vstd!seq.Seq<i32.>. (%Poly%vstd!seq.Seq<i32.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (SINT 32))))
   :qid internal_vstd__seq__Seq<i32.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<i32.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<i32.>.)) (!
   (has_type (Poly%vstd!seq.Seq<i32.>. x) (TYPE%vstd!seq.Seq. $ (SINT 32)))
   :pattern ((has_type (Poly%vstd!seq.Seq<i32.>. x) (TYPE%vstd!seq.Seq. $ (SINT 32))))
   :qid internal_vstd__seq__Seq<i32.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<i32.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (= x (%Poly%vstd!seq.Seq<usize.>. (Poly%vstd!seq.Seq<usize.>. x)))
   :pattern ((Poly%vstd!seq.Seq<usize.>. x))
   :qid internal_vstd__seq__Seq<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ USIZE))
    (= x (Poly%vstd!seq.Seq<usize.>. (%Poly%vstd!seq.Seq<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE))
   :pattern ((has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
     (Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
     x
   ))
   :qid internal_vstd__seq__Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
    (= x (Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
      (%Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)))
   :qid internal_vstd__seq__Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
     x
    ) (TYPE%vstd!seq.Seq. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>.
      x
     ) (TYPE%vstd!seq.Seq. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   ))
   :qid internal_vstd__seq__Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (= x (%Poly%vstd!set.Set<usize.>. (Poly%vstd!set.Set<usize.>. x)))
   :pattern ((Poly%vstd!set.Set<usize.>. x))
   :qid internal_vstd__set__Set<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ USIZE))
    (= x (Poly%vstd!set.Set<usize.>. (%Poly%vstd!set.Set<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE))
   :pattern ((has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<tuple%2<usize./usize.>.>.)) (!
   (= x (%Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!set.Set<tuple%2<usize./usize.>.>. x))
   :qid internal_vstd__set__Set<tuple__2<usize./usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<tuple__2<usize./usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)))
    (= x (Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (%Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!set.Set. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))))
   :qid internal_vstd__set__Set<tuple__2<usize./usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<tuple__2<usize./usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<tuple%2<usize./usize.>.>.)) (!
   (has_type (Poly%vstd!set.Set<tuple%2<usize./usize.>.>. x) (TYPE%vstd!set.Set. (DST $)
     (TYPE%tuple%2. $ USIZE $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!set.Set<tuple%2<usize./usize.>.>. x) (TYPE%vstd!set.Set.
      (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   )))
   :qid internal_vstd__set__Set<tuple__2<usize./usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<tuple__2<usize./usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x core!option.Option.)) (!
   (= x (%Poly%core!option.Option. (Poly%core!option.Option. x)))
   :pattern ((Poly%core!option.Option. x))
   :qid internal_core__option__Option_box_axiom_definition
   :skolemid skolem_internal_core__option__Option_box_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (= x (Poly%core!option.Option. (%Poly%core!option.Option. x)))
   )
   :pattern ((has_type x (TYPE%core!option.Option. V&. V&)))
   :qid internal_core__option__Option_unbox_axiom_definition
   :skolemid skolem_internal_core__option__Option_unbox_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type)) (!
   (has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
     V&. V&
   ))
   :pattern ((has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./None_constructor_definition
   :skolemid skolem_internal_core!option.Option./None_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (_0! Poly)) (!
   (=>
    (has_type _0! V&)
    (has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :pattern ((has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./Some_constructor_definition
   :skolemid skolem_internal_core!option.Option./Some_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (= (core!option.Option./Some/0 V&. V& x) (core!option.Option./Some/?0 x))
   )
   :pattern ((core!option.Option./Some/0 V&. V& x))
   :qid internal_core!option.Option./Some/0_accessor_definition
   :skolemid skolem_internal_core!option.Option./Some/0_accessor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (has_type (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) V&)
   )
   :pattern ((core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) (has_type
     x (TYPE%core!option.Option. V&. V&)
   ))
   :qid internal_core!option.Option./Some/0_invariant_definition
   :skolemid skolem_internal_core!option.Option./Some/0_invariant_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (height_lt (height (core!option.Option./Some/0 V&. V& x)) (height (Poly%core!option.Option.
       x
   ))))
   :pattern ((height (core!option.Option./Some/0 V&. V& x)))
   :qid prelude_datatype_height_core!option.Option./Some/0
   :skolemid skolem_prelude_datatype_height_core!option.Option./Some/0
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./None (%Poly%core!option.Option. x))
     (is-core!option.Option./None (%Poly%core!option.Option. y))
    )
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./None_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./None_ext_equal_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./Some (%Poly%core!option.Option. x))
     (is-core!option.Option./Some (%Poly%core!option.Option. y))
     (ext_eq deep V& (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x))
      (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. y))
    ))
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./Some_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./Some_ext_equal_definition
)))
(assert
 (forall ((x vstd!raw_ptr.MemContents.)) (!
   (= x (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. x)))
   :pattern ((Poly%vstd!raw_ptr.MemContents. x))
   :qid internal_vstd__raw_ptr__MemContents_box_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__MemContents_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (= x (Poly%vstd!raw_ptr.MemContents. (%Poly%vstd!raw_ptr.MemContents. x)))
   )
   :pattern ((has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&)))
   :qid internal_vstd__raw_ptr__MemContents_unbox_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__MemContents_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (has_type (Poly%vstd!raw_ptr.MemContents. vstd!raw_ptr.MemContents./Uninit) (TYPE%vstd!raw_ptr.MemContents.
     T&. T&
   ))
   :pattern ((has_type (Poly%vstd!raw_ptr.MemContents. vstd!raw_ptr.MemContents./Uninit)
     (TYPE%vstd!raw_ptr.MemContents. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.MemContents./Uninit_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Uninit_constructor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T&)
    (has_type (Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents./Init _0!)) (TYPE%vstd!raw_ptr.MemContents.
      T&. T&
   )))
   :pattern ((has_type (Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents./Init _0!))
     (TYPE%vstd!raw_ptr.MemContents. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.MemContents./Init_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init_constructor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x vstd!raw_ptr.MemContents.)) (!
   (=>
    (is-vstd!raw_ptr.MemContents./Init x)
    (= (vstd!raw_ptr.MemContents./Init/0 T&. T& x) (vstd!raw_ptr.MemContents./Init/?0 x))
   )
   :pattern ((vstd!raw_ptr.MemContents./Init/0 T&. T& x))
   :qid internal_vstd!raw_ptr.MemContents./Init/0_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init/0_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (has_type (vstd!raw_ptr.MemContents./Init/0 T&. T& (%Poly%vstd!raw_ptr.MemContents.
       x
      )
     ) T&
   ))
   :pattern ((vstd!raw_ptr.MemContents./Init/0 T&. T& (%Poly%vstd!raw_ptr.MemContents.
      x
     )
    ) (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
   )
   :qid internal_vstd!raw_ptr.MemContents./Init/0_invariant_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init/0_invariant_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x vstd!raw_ptr.MemContents.)) (!
   (=>
    (is-vstd!raw_ptr.MemContents./Init x)
    (height_lt (height (vstd!raw_ptr.MemContents./Init/0 T&. T& x)) (height (Poly%vstd!raw_ptr.MemContents.
       x
   ))))
   :pattern ((height (vstd!raw_ptr.MemContents./Init/0 T&. T& x)))
   :qid prelude_datatype_height_vstd!raw_ptr.MemContents./Init/0
   :skolemid skolem_prelude_datatype_height_vstd!raw_ptr.MemContents./Init/0
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.))
  (!
   (= x (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      x
   )))
   :pattern ((Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Node_box_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Node_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
    ))
    (= x (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
       x
   ))))
   :pattern ((has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Node_unbox_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Node_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_value! core!option.Option.) (_next! Int) (_prev! Int))
  (!
   (=>
    (and
     (has_type (Poly%core!option.Option. _value!) (TYPE%core!option.Option. T&. T&))
     (iInv 32 _next!)
     (iInv 32 _prev!)
    )
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node
       _value! _next! _prev!
      )
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
   )))
   :pattern ((has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node
       _value! _next! _prev!
      )
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node_constructor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node_constructor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/?value
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
    ))
    (has_type (Poly%core!option.Option. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
        x
      ))
     ) (TYPE%core!option.Option. T&. T&)
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/?next
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
    ))
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/next_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/?prev
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
    ))
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
      T&. T&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/prev_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.))
  (!
   (=>
    (is-OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node
     x
    )
    (height_lt (height (Poly%core!option.Option. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
        x
      ))
     ) (height (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
       x
   ))))
   :pattern ((height (Poly%core!option.Option. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
       x
   ))))
   :qid prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
   :skolemid skolem_prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node./Node/value
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= x (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
   )))
   :pattern ((Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__StaticLinkedList_box_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__StaticLinkedList_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (= x (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__StaticLinkedList_unbox_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__StaticLinkedList_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (_ar! %%Function%%) (_spec_seq! Poly)
   (_value_list! vstd!seq.Seq<i32.>.) (_value_list_head! Int) (_value_list_tail! Int)
   (_value_list_len! Int) (_free_list! vstd!seq.Seq<i32.>.) (_free_list_head! Int) (
    _free_list_tail! Int
   ) (_free_list_len! Int) (_size! Int) (_arr_seq! Poly)
  ) (!
   (=>
    (and
     (has_type (Poly%array%. _ar!) (ARRAY $ (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
        T&. T&
       ) N&. N&
     ))
     (has_type _spec_seq! (TYPE%vstd!seq.Seq. T&. T&))
     (iInv 32 _value_list_head!)
     (iInv 32 _value_list_tail!)
     (uInv SZ _value_list_len!)
     (iInv 32 _free_list_head!)
     (iInv 32 _free_list_tail!)
     (uInv SZ _free_list_len!)
     (uInv SZ _size!)
     (has_type _arr_seq! (TYPE%vstd!seq.Seq. $ (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
        T&. T&
    ))))
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList
       _ar! _spec_seq! _value_list! _value_list_head! _value_list_tail! _value_list_len!
       _free_list! _free_list_head! _free_list_tail! _free_list_len! _size! _arr_seq!
      )
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :pattern ((has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList
       _ar! _spec_seq! _value_list! _value_list_head! _value_list_tail! _value_list_len!
       _free_list! _free_list_head! _free_list_tail! _free_list_len! _size! _arr_seq!
      )
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList_constructor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList_constructor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?ar
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (Poly%array%. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
        x
      ))
     ) (ARRAY $ (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
       T&. T&
      ) N&. N&
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?spec_seq
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
      )
     ) (TYPE%vstd!seq.Seq. T&. T&)
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list_head
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_head_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list_tail
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_tail_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?value_list_len
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list_head
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_head_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list_tail
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_tail_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?free_list_len
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/free_list_len_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?size
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/size_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/?arr_seq
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
      )
     ) (TYPE%vstd!seq.Seq. $ (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Node.
       T&. T&
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (=>
    (is-OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList
     x
    )
    (height_lt (height (Poly%array%. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
        x
      ))
     ) (height (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((height (Poly%array%. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
       x
   ))))
   :qid prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
   :skolemid skolem_prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/ar
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (=>
    (is-OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList
     x
    )
    (height_lt (height (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
       x
      )
     ) (height (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((height (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
      x
   )))
   :qid prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
   :skolemid skolem_prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.))
  (!
   (=>
    (is-OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList
     x
    )
    (height_lt (height (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
       x
      )
     ) (height (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       x
   ))))
   :pattern ((height (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
      x
   )))
   :qid prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
   :skolemid skolem_prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/arr_seq
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= x (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      x
   )))
   :pattern ((Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Page_box_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Page_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
    (= x (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
       x
   ))))
   :pattern ((has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Page_unbox_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Page_unbox_axiom_definition
)))
(assert
 (forall ((_addr! Int) (_state! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
   (_is_io_page! Bool) (_rev_pointer! Int) (_ref_count! Int) (_owning_container! core!option.Option.)
   (_mappings! vstd!set.Set<tuple%2<usize./usize.>.>.) (_io_mappings! vstd!set.Set<tuple%2<usize./usize.>.>.)
  ) (!
   (=>
    (and
     (uInv SZ _addr!)
     (iInv 32 _rev_pointer!)
     (uInv SZ _ref_count!)
     (has_type (Poly%core!option.Option. _owning_container!) (TYPE%core!option.Option. $
       USIZE
    )))
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page
       _addr! _state! _is_io_page! _rev_pointer! _ref_count! _owning_container! _mappings!
       _io_mappings!
      )
     ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
   ))
   :pattern ((has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page
       _addr! _state! _is_io_page! _rev_pointer! _ref_count! _owning_container! _mappings!
       _io_mappings!
      )
     ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page_constructor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page_constructor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?addr
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?state
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?is_io_page
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?rev_pointer
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?ref_count
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
       x
   ))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?owning_container
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
    (has_type (Poly%core!option.Option. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
        x
      ))
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?mappings
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/?io_mappings
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= x (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
   )))
   :pattern ((Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator_box_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (= x (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       x
   ))))
   :pattern ((has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator_unbox_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator_unbox_axiom_definition
)))
(assert
 (forall ((_page_array! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.)
   (_free_pages_4k! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
   (_free_pages_2m! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
   (_free_pages_1g! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
   (_allocated_pages_4k! vstd!set.Set<usize.>.) (_allocated_pages_2m! vstd!set.Set<usize.>.)
   (_allocated_pages_1g! vstd!set.Set<usize.>.) (_mapped_pages_4k! vstd!set.Set<usize.>.)
   (_mapped_pages_2m! vstd!set.Set<usize.>.) (_mapped_pages_1g! vstd!set.Set<usize.>.)
   (_page_perms_4k! Poly) (_page_perms_2m! Poly) (_page_perms_1g! Poly) (_container_map_4k!
    vstd!map.Map<usize./vstd!set.Set<usize.>.>.
   ) (_container_map_2m! vstd!map.Map<usize./vstd!set.Set<usize.>.>.) (_container_map_1g!
    vstd!map.Map<usize./vstd!set.Set<usize.>.>.
   )
  ) (!
   (=>
    (and
     (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
       _page_array!
      ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
       $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
       $ (CONST_INT 2097152)
     ))
     (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       _free_pages_4k!
      ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       $ USIZE $ (CONST_INT 2097152)
     ))
     (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       _free_pages_2m!
      ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       $ USIZE $ (CONST_INT 2097152)
     ))
     (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       _free_pages_1g!
      ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       $ USIZE $ (CONST_INT 2097152)
     ))
     (has_type _page_perms_4k! (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
        $ (ARRAY $ (UINT 8) $ (CONST_INT 4096))
     )))
     (has_type _page_perms_2m! (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
        $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152))
     )))
     (has_type _page_perms_1g! (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
        $ (ARRAY $ (UINT 8) $ (CONST_INT 1073741824))
    ))))
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator
       _page_array! _free_pages_4k! _free_pages_2m! _free_pages_1g! _allocated_pages_4k!
       _allocated_pages_2m! _allocated_pages_1g! _mapped_pages_4k! _mapped_pages_2m! _mapped_pages_1g!
       _page_perms_4k! _page_perms_2m! _page_perms_1g! _container_map_4k! _container_map_2m!
       _container_map_1g!
      )
     ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
   ))
   :pattern ((has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator
       _page_array! _free_pages_4k! _free_pages_2m! _free_pages_1g! _allocated_pages_4k!
       _allocated_pages_2m! _allocated_pages_1g! _mapped_pages_4k! _mapped_pages_2m! _mapped_pages_1g!
       _page_perms_4k! _page_perms_2m! _page_perms_1g! _container_map_4k! _container_map_2m!
       _container_map_1g!
      )
     ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator_constructor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator_constructor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_array
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
        x
      ))
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      $ (CONST_INT 2097152)
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?free_pages_4k
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
        x
      ))
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      $ USIZE $ (CONST_INT 2097152)
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?free_pages_2m
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
        x
      ))
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      $ USIZE $ (CONST_INT 2097152)
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?free_pages_1g
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
        x
      ))
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      $ USIZE $ (CONST_INT 2097152)
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?allocated_pages_4k
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?allocated_pages_2m
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?allocated_pages_1g
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?mapped_pages_4k
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?mapped_pages_2m
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?mapped_pages_1g
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_perms_4k
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       x
      )
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8)
        $ (CONST_INT 4096)
   )))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_perms_2m
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       x
      )
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8)
        $ (CONST_INT 2097152)
   )))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?page_perms_1g
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       x
      )
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8)
        $ (CONST_INT 1073741824)
   )))))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
      x
     )
    ) (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
   )
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?container_map_4k
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?container_map_2m
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/?container_map_1g
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g_accessor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.))
  (!
   (= x (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
      x
   )))
   :pattern ((Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState_box_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
    (= x (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
       x
   ))))
   :pattern ((has_type x TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState_unbox_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState_unbox_axiom_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.))
  (!
   (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
     x
    ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
   )
   :pattern ((has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
      x
     ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState_has_type_always_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState_has_type_always_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.))
  (!
   (= x (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      x
   )))
   :pattern ((Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Array_box_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Array_box_axiom_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
    ))
    (= x (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
       x
   ))))
   :pattern ((has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Array_unbox_axiom_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Array_unbox_axiom_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (_seq! Poly) (_ar! %%Function%%))
  (!
   (=>
    (and
     (has_type _seq! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type (Poly%array%. _ar!) (ARRAY A&. A& N&. N&))
    )
    (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array
       _seq! _ar!
      )
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
   )))
   :pattern ((has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array
       _seq! _ar!
      )
     ) (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array_constructor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array_constructor_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/?seq
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq_accessor_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
    ))
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
       x
      )
     ) (TYPE%vstd!seq.Seq. A&. A&)
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.))
  (!
   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
     x
    ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/?ar
     x
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
     x
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar_accessor_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar_accessor_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
    ))
    (has_type (Poly%array%. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
        x
      ))
     ) (ARRAY A&. A& N&. N&)
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      x
     )
    ) (has_type x (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar_invariant_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar_invariant_definition
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.))
  (!
   (=>
    (is-OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array
     x
    )
    (height_lt (height (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
       x
      )
     ) (height (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
       x
   ))))
   :pattern ((height (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
      x
   )))
   :qid prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
   :skolemid skolem_prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
)))
(assert
 (forall ((x OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.))
  (!
   (=>
    (is-OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array
     x
    )
    (height_lt (height (Poly%array%. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
        x
      ))
     ) (height (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
       x
   ))))
   :pattern ((height (Poly%array%. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
       x
   ))))
   :qid prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
   :skolemid skolem_prelude_datatype_height_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/ar
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= x (%Poly%tuple%1. (Poly%tuple%1. x)))
   :pattern ((Poly%tuple%1. x))
   :qid internal_crate__tuple__1_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (= x (Poly%tuple%1. (%Poly%tuple%1. x)))
   )
   :pattern ((has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__tuple__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T%0&)
    (has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1_constructor_definition
   :skolemid skolem_internal_tuple__1./tuple__1_constructor_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= (tuple%1./tuple%1/0 x) (tuple%1./tuple%1/?0 x))
   :pattern ((tuple%1./tuple%1/0 x))
   :qid internal_tuple__1./tuple__1/0_accessor_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (has_type (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) T%0&)
   )
   :pattern ((tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1/0_invariant_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_invariant_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (=>
    (is-tuple%1./tuple%1 x)
    (height_lt (height (tuple%1./tuple%1/0 x)) (height (Poly%tuple%1. x)))
   )
   :pattern ((height (tuple%1./tuple%1/0 x)))
   :qid prelude_datatype_height_tuple%1./tuple%1/0
   :skolemid skolem_prelude_datatype_height_tuple%1./tuple%1/0
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%tuple%1. T%0&. T%0&))
     (has_type y (TYPE%tuple%1. T%0&. T%0&))
     (ext_eq deep T%0& (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (tuple%1./tuple%1/0 (%Poly%tuple%1.
        y
    ))))
    (ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y))
   :qid internal_tuple__1./tuple__1_ext_equal_definition
   :skolemid skolem_internal_tuple__1./tuple__1_ext_equal_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(declare-fun array_new (Dcr Type Int %%Function%%) Poly)
(declare-fun array_index (Dcr Type Dcr Type %%Function%% Poly) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (= (array_new Tdcr T N Fn) (Poly%array%. Fn))
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_array_new
   :skolemid skolem_prelude_array_new
)))
(declare-fun %%apply%%1 (%%Function%% Int) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (=>
    (forall ((i Int)) (!
      (=>
       (and
        (<= 0 i)
        (< i N)
       )
       (has_type (%%apply%%1 Fn i) T)
      )
      :pattern ((has_type (%%apply%%1 Fn i) T))
      :qid prelude_has_type_array_elts
      :skolemid skolem_prelude_has_type_array_elts
    ))
    (has_type (array_new Tdcr T N Fn) (ARRAY Tdcr T $ (CONST_INT N)))
   )
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_has_type_array_new
   :skolemid skolem_prelude_has_type_array_new
)))
(assert
 (forall ((Tdcr Dcr) (T Type) (Nd Dcr) (Ndcr Dcr) (N Type) (Fn %%Function%%) (i Poly))
  (!
   (=>
    (and
     (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr N))
     (has_type i INT)
    )
    (has_type (array_index Tdcr T Nd N Fn i) T)
   )
   :pattern ((array_index Tdcr T Nd N Fn i) (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr
      N
   )))
   :qid prelude_has_type_array_index
   :skolemid skolem_prelude_has_type_array_index
)))
(assert
 (!
  (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%) (i Int)) (!
    (= (array_index Tdcr T $ (CONST_INT N) Fn (I i)) (%%apply%%1 Fn i))
    :pattern ((array_new Tdcr T N Fn) (%%apply%%1 Fn i))
    :qid prelude_array_index_trigger
    :skolemid skolem_prelude_array_index_trigger
  ))
  :named
  prelude_axiom_array_index
))
(assert
 (forall ((x fndef) (Self%&. Dcr) (Self%& Type)) (!
   (has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&))
   :pattern ((has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&)))
   :qid prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
   :skolemid skolem_prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%core!clone.Clone. Self%&. Self%&))
   :qid internal_core__clone__Clone_trait_type_bounds_definition
   :skolemid skolem_internal_core__clone__Clone_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. Self%&. Self%&)
    (tr_bound%core!clone.Clone. Self%&. Self%&)
   )
   :pattern ((tr_bound%core!marker.Copy. Self%&. Self%&))
   :qid internal_core__marker__Copy_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Copy_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&)
    (and
     (sized Self%&.)
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) (TYPE%core!option.Option.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 8)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 8)) (UINT 8))
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 64)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 64)) (UINT 64))
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 32)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 32)) (SINT 32))
)
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (DST (proj%%vstd!view.View./V
       A0&. A0&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (TYPE%tuple%1. (proj%%vstd!view.View./V
       A0&. A0&
      ) (proj%vstd!view.View./V A0&. A0&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST (proj%%vstd!view.View./V
       A1&. A1&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&) (proj%%vstd!view.View./V
       A1&. A1&
      ) (proj%vstd!view.View./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 8))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 8))
  ) (UINT 8)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
  ) (SINT 32)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
  ) (UINT 64)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) USIZE
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
       Self%&
      ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&.
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
      (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) BOOL
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) (REF T&.)
   )
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       REF T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) T&
   )
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF
       T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (ARRAY
        T&. T& N&. N&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (ARRAY T&. T& N&. N&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&.
        T& N&. N&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
     ) (ARRAY T&. T& N&. N&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (ARRAY T&. T& N&. N&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__array__impl&__20__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
        T&.
       ) T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) (TRACKED T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       TRACKED T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
       T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) (GHOST T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       GHOST T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
     ) $
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%core!option.Option. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
        T&. T&
       )
      ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
     ) (TYPE%core!option.Option. T&. T&)
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $
      (TYPE%core!option.Option. T&. T&)
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__option__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&.
        A& T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) (BOX A&. A& T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       BOX A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
        T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX
       A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
  ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
  ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.Seq.new.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.to_set.? (Dcr Type Poly) Poly)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!seq_lib.impl&%0.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!set.impl&%0.union.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!set.impl&%0.len.? (Dcr Type Poly) Int)
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)
(declare-fun vstd!array.array_view.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type Poly
  Poly
 ) Poly
)
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index%default%.? (Dcr Type Dcr
  Type Poly Poly
 ) Poly
)
(declare-fun vstd!pervasive.strictly_cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!pervasive.cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_Some.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_Some%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.is_some.? (Dcr Type Poly) Bool)
(declare-fun vstd!std_specs.option.is_none.? (Dcr Type Poly) Bool)
(declare-fun vstd!std_specs.option.spec_unwrap.? (Dcr Type Poly) Poly)
(declare-fun vstd!simple_pptr.impl&%1.addr.? (Dcr Type Poly) Int)
(declare-fun vstd!simple_pptr.impl&%1.mem_contents.? (Dcr Type Poly) vstd!raw_ptr.MemContents.)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.wf.?
 (Dcr Type Dcr Type Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
 (Dcr Type Dcr Type Poly) Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.?
 (Dcr Type Dcr Type Poly Poly) Int
)
(declare-fun vstd!raw_ptr.impl&%6.is_init.? (Dcr Type Poly) Bool)
(declare-fun vstd!set.Set.subset_of.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.spec_add.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!set.impl&%0.finite.? (Dcr Type Poly) Bool)
(declare-fun vstd!simple_pptr.impl&%1.is_init.? (Dcr Type Poly) Bool)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_4k.?
 () Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_2m.?
 () Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_1g.?
 () Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.?
 () Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.?
 (Dcr Type Dcr Type Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
 (Poly Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.?
 (Dcr Type Dcr Type Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?
 () Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
 (Poly) Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
 (Poly) Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
 (Poly) Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
 (Poly) Int
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.?
 (Poly Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.?
 (Poly Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.?
 (Poly) Bool
)
(declare-fun OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.?
 (Poly) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
   (=>
    (and
     (has_type len! NAT)
     (has_type f! (TYPE%fun%1. $ INT A&. A&))
    )
    (has_type (vstd!seq.Seq.new.? A&. A& len! f!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.new.? A&. A& len! f!))
   :qid internal_vstd!seq.Seq.new.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.new.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_len.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)) (%I len!))
    ))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)))
    :qid user_vstd__seq__lemma_seq_new_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_index.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (%I len!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!) (%%apply%%0
        (%Poly%fun%1. f!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!))
    :qid user_vstd__seq__lemma_seq_new_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq_lib.impl&%0.to_set.? A&. A& self!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!seq_lib.impl&%0.to_set.? A&. A& self!))
   :qid internal_vstd!seq_lib.impl&__0.to_set.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.to_set.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (needle! Poly)) (!
    (= (vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!) (exists ((i$ Poly)) (!
       (and
        (has_type i$ INT)
        (and
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? A&. A& self! i$) needle!)
       ))
       :pattern ((vstd!seq.Seq.index.? A&. A& self! i$))
       :qid user_vstd__seq_lib__impl&%0__contains_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__contains_0
    )))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!))
    :qid internal_vstd!seq_lib.impl&__0.contains.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.contains.?_definition
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.to_set_ensures.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (=>
      (sized A&.)
      (and
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
              A&. A& self!
             )
            ) (vstd!seq.Seq.index.? A&. A& self! i$)
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
             A&. A& self!
            )
           ) (vstd!seq.Seq.index.? A&. A& self! i$)
         ))
         :qid user_vstd__seq_lib__impl&%0__to_set_ensures_0
         :skolemid skolem_user_vstd__seq_lib__impl&%0__to_set_ensures_0
       ))
       (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
              A&. A& self!
             )
            ) a$
           ) (vstd!seq_lib.impl&%0.contains.? A&. A& self! a$)
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
             A&. A& self!
            )
           ) a$
         ))
         :qid user_vstd__seq_lib__impl&%0__to_set_ensures_1
         :skolemid skolem_user_vstd__seq_lib__impl&%0__to_set_ensures_1
    )))))
    :pattern ((vstd!seq_lib.impl&%0.to_set.? A&. A& self!))
    :qid user_vstd__seq_lib__impl&%0__to_set_ensures_2
    :skolemid skolem_user_vstd__seq_lib__impl&%0__to_set_ensures_2
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%2
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%3
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_decreases_to_entry.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
           K& V&. V& m! key!
        )))
       ) (height m!)
    )))
    :pattern ((height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
         K& V&. V& m! key!
    )))))
    :qid user_vstd__map__axiom_map_decreases_to_entry_0
    :skolemid skolem_user_vstd__map__axiom_map_decreases_to_entry_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!set.Set. A&. A&))
     (has_type s2! (TYPE%vstd!set.Set. A&. A&))
    )
    (has_type (vstd!set.impl&%0.union.? A&. A& self! s2!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.union.? A&. A& self! s2!))
   :qid internal_vstd!set.impl&__0.union.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.union.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_union.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.impl&%0.union.?
          A&. A& s1! s2!
         )
        ) a!
       ) (or
        (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a!)
        (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a!)
    ))))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.impl&%0.union.?
        A&. A& s1! s2!
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_union_0
    :skolemid skolem_user_vstd__set__lemma_set_union_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (<= 0 (vstd!set.impl&%0.len.? A&. A& self!))
   )
   :pattern ((vstd!set.impl&%0.len.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.len.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_contains_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (not (= (vstd!set.impl&%0.len.? A&. A& s!) 0))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (vstd!set.impl&%0.len.? A&. A& s!)
    )
    :qid user_vstd__set__lemma_set_contains_len_0
    :skolemid skolem_user_vstd__set__lemma_set_contains_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.array_view.)
)
(declare-fun %%lambda%%0 (Dcr Type Dcr Type %%Function%%) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (%%hole%%4
    %%Function%%
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (array_index %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 i$)
   )
   :pattern ((%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (= (vstd!array.array_view.? T&. T& N&. N& a!) (vstd!seq.Seq.new.? T&. T& (I (const_int
        N&
       )
      ) (Poly%fun%1. (mk_fun (%%lambda%%0 T&. T& N&. N& (%Poly%array%. a!))))
    ))
    :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
    :qid internal_vstd!array.array_view.?_definition
    :skolemid skolem_internal_vstd!array.array_view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
   (=>
    (has_type a! (ARRAY T&. T& N&. N&))
    (has_type (vstd!array.array_view.? T&. T& N&. N& a!) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
   :qid internal_vstd!array.array_view.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.array_view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%0.view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!) (vstd!array.array_view.? T&.
       T& N&. N& self!
    )))
    :pattern ((vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))
    :qid internal_vstd!array.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!array.impl&__0.view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&)))
   :qid internal_vstd__array__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__0_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_len_matches_n.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (ar! Poly)) (!
    (=>
     (has_type ar! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) ar!))
       (const_int N&)
    )))
    :pattern ((vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
       ar!
    )))
    :qid user_vstd__array__array_len_matches_n_0
    :skolemid skolem_user_vstd__array__array_len_matches_n_0
))))
(declare-fun req%vstd!array.ArrayAdditionalSpecFns.spec_index. (Dcr Type Dcr Type Poly
  Poly
 ) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self! i!)
    (=>
     %%global_location_label%%4
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T&
     self! i!
   ))
   :qid internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
      i!
     ) T&
   ))
   :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
     i!
   ))
   :qid internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%2.spec_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&. T& self!
       i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!)
       i!
    )))
    :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&.
      T& self! i!
    ))
    :qid internal_vstd!array.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!array.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&. T&)
   )
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&.
     T&
   ))
   :qid internal_vstd__array__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__2_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)
        i!
       ) (vstd!seq.Seq.index.? T&. T& (vstd!array.array_view.? T&. T& N&. N& a!) i!)
    )))
    :pattern ((array_index T&. T& N&. N& (%Poly%array%. a!) i!))
    :qid user_vstd__array__lemma_array_index_0
    :skolemid skolem_user_vstd__array__lemma_array_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_ext_equal.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type a1! (ARRAY T&. T& N&. N&))
      (has_type a2! (ARRAY T&. T& N&. N&))
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (ext_eq false (ARRAY T&. T& N&. N&) a1! a2!) (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a1!)
             i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a2!)
             i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a1!
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a2!
           ) i$
         ))
         :qid user_vstd__array__axiom_array_ext_equal_0
         :skolemid skolem_user_vstd__array__axiom_array_ext_equal_0
    )))))
    :pattern ((ext_eq false (ARRAY T&. T& N&. N&) a1! a2!))
    :qid user_vstd__array__axiom_array_ext_equal_1
    :skolemid skolem_user_vstd__array__axiom_array_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (array! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type array! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (ARRAY T&. T& N&. N&) array!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&.
            T& N&. N&
           ) array!
          ) i!
    ))))))
    :pattern ((has_resolved $ (ARRAY T&. T& N&. N&) array!) (vstd!seq.Seq.index.? T&. T&
      (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) array!) i!
    ))
    :qid user_vstd__array__axiom_array_has_resolved_0
    :skolemid skolem_user_vstd__array__axiom_array_has_resolved_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_decreases_to_seq.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (=>
     (has_type a! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (height_lt (height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)) (height a!))
    ))
    :pattern ((height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)))
    :qid user_vstd__array__axiom_array_decreases_to_seq_0
    :skolemid skolem_user_vstd__array__axiom_array_decreases_to_seq_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index_decreases.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
           N&. N&
          ) a!
         ) i!
        )
       ) (height a!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
         N&. N&
        ) a!
       ) i!
    )))
    :qid user_vstd__array__lemma_array_index_decreases_0
    :skolemid skolem_user_vstd__array__lemma_array_index_decreases_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(declare-fun ens%core!clone.Clone.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (%return! Poly)) (!
   (= (ens%core!clone.Clone.clone. Self%&. Self%& self! %return!) (has_type %return! Self%&))
   :pattern ((ens%core!clone.Clone.clone. Self%&. Self%& self! %return!))
   :qid internal_ens__core!clone.Clone.clone._definition
   :skolemid skolem_internal_ens__core!clone.Clone.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (Self%&. Dcr) (Self%& Type)) (!
   (=>
    (has_type closure%$ (TYPE%tuple%1. (REF Self%&.) Self%&))
    (=>
     (let
      ((self$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      true
     )
     (closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.)) (TYPE%tuple%1.
       (REF Self%&.) Self%&
      ) (F fndef_singleton) closure%$
   )))
   :pattern ((closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.))
     (TYPE%tuple%1. (REF Self%&.) Self%&) (F fndef_singleton) closure%$
   ))
   :qid user_core__clone__Clone__clone_0
   :skolemid skolem_user_core__clone__Clone__clone_0
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%tuple%0.)
)
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Tuple1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. T%0&. T%0&)
    (tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Clone1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. T%0&. T%0&)
    (tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Copy1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
    )
    (tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Clone2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
    )
    (tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Copy2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy2_trait_impl_definition
)))
(declare-fun ens%core!clone.impls.impl&%12.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%12.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 8) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%12.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__12.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__12.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 8)))
     (has_type res$ (UINT 8))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 8)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 8)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%12__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%12__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%28.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%28.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (SINT 32) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%28.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__28.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__28.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (SINT 32)))
     (has_type res$ (SINT 32))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (SINT 32)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (SINT 32)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%28__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%28__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%18.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%18.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 64) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%18.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__18.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__18.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 64)))
     (has_type res$ (UINT 64))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 64)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 64)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%18__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%18__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%10.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%10.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ USIZE x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%10.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__10.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__10.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) USIZE))
     (has_type res$ USIZE)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1. (
        REF $
       ) USIZE
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1.
      (REF $) USIZE
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%10__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%10__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%42.clone. (Poly Poly) Bool)
(assert
 (forall ((b! Poly) (%return! Poly)) (!
   (= (ens%core!clone.impls.impl&%42.clone. b! %return!) (and
     (ens%core!clone.Clone.clone. $ BOOL b! %return!)
     (= %return! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%42.clone. b! %return!))
   :qid internal_ens__core!clone.impls.impl&__42.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__42.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) BOOL))
     (has_type %return$ BOOL)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1. (REF
        $
       ) BOOL
      ) (F fndef_singleton) closure%$ %return$
     )
     (let
      ((b$ (%B (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%B %return$) b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1.
      (REF $) BOOL
     ) (F fndef_singleton) closure%$ %return$
   ))
   :qid user_core__clone__impls__impl&%42__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%42__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%6.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (REF T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%6.clone. T&. T& b! res!))
   :qid internal_ens__core!clone.impls.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (REF T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.))) (TYPE%tuple%1.
       (REF (REF T&.)) T&
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.)))
     (TYPE%tuple%1. (REF (REF T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%6__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%6__clone_0
)))
(assert
 (fuel_bool_default fuel%vstd!pervasive.strictly_cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.strictly_cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.strictly_cloned.? T&. T& a! b!) (closure_ens (FNDEF%core!clone.Clone.clone.
       T&. T&
      ) (DST (REF T&.)) (TYPE%tuple%1. (REF T&.) T&) (F fndef_singleton) (Poly%tuple%1.
       (tuple%1./tuple%1 a!)
      ) b!
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.strictly_cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.strictly_cloned.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!pervasive.cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.cloned.? T&. T& a! b!) (or
      (vstd!pervasive.strictly_cloned.? T&. T& a! b!)
      (= a! b!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.cloned.?_definition
))))
(declare-fun ens%core!array.impl&%20.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (res! Poly)) (!
   (= (ens%core!array.impl&%20.clone. T&. T& N&. N& a! res!) (and
     (ens%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&) a! res!)
     (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (const_int N&)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
            $ (ARRAY T&. T& N&. N&) a!
           ) i$
          ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
           i$
       ))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
          a!
         ) i$
       ))
       :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
          res!
         ) i$
       ))
       :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
           $ (ARRAY T&. T& N&. N&) a!
          ) i$
         ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
          i$
       )))
       :qid user_core__array__impl&%20__clone_0
       :skolemid skolem_user_core__array__impl&%20__clone_0
     ))
     (=>
      (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (ARRAY T&. T& N&.
         N&
        ) a!
       ) (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res!)
      )
      (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!) (vstd!view.View.view.? $ (ARRAY
         T&. T& N&. N&
        ) res!
   )))))
   :pattern ((ens%core!array.impl&%20.clone. T&. T& N&. N& a! res!))
   :qid internal_ens__core!array.impl&__20.clone._definition
   :skolemid skolem_internal_ens__core!array.impl&__20.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)))
     (has_type res$ (ARRAY T&. T& N&. N&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&)) (DST (REF $))
      (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)) (F fndef_singleton) closure%$ res$
     )
     (let
      ((a$ (%Poly%array%. (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (and
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
              $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)
             ) i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
             i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            (Poly%array%. a$)
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            res$
           ) i$
         ))
         :pattern ((vstd!pervasive.cloned.? T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.?
             $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)
            ) i$
           ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
            i$
         )))
         :qid user_core__array__impl&%20__clone_1
         :skolemid skolem_user_core__array__impl&%20__clone_1
       ))
       (=>
        (ext_eq false (TYPE%vstd!seq.Seq. T&. T&) (vstd!view.View.view.? $ (ARRAY T&. T& N&.
           N&
          ) (Poly%array%. a$)
         ) (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) res$)
        )
        (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) (Poly%array%. a$)) (vstd!view.View.view.?
          $ (ARRAY T&. T& N&. N&) res$
   )))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&. N&)) (DST
      (REF $)
     ) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&)) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__array__impl&%20__clone_2
   :skolemid skolem_user_core__array__impl&%20__clone_2
)))
(declare-fun ens%verus_builtin!impl&%9.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%9.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (TRACKED T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%9.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__9.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__9.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (TRACKED T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED T&.)))
      (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED
        T&.
      ))
     ) (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%9__clone_0
   :skolemid skolem_user_verus_builtin__impl&%9__clone_0
)))
(declare-fun ens%verus_builtin!impl&%7.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%7.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (GHOST T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%7.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__7.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__7.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (GHOST T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST T&.)))
      (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST
        T&.
      ))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%7__clone_0
   :skolemid skolem_user_verus_builtin__impl&%7__clone_0
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.is_Some.? Self%&. Self%& T&. T&
      self!
     ) BOOL
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_Some.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.is_Some.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.is_Some.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
      self!
     ) T&
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.is_some.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.is_some.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.is_some.? T&. T& option!) (is-core!option.Option./Some (%Poly%core!option.Option.
       option!
    )))
    :pattern ((vstd!std_specs.option.is_some.? T&. T& option!))
    :qid internal_vstd!std_specs.option.is_some.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.is_some.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.is_none.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.is_none.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.is_none.? T&. T& option!) (is-core!option.Option./None (%Poly%core!option.Option.
       option!
    )))
    :pattern ((vstd!std_specs.option.is_none.? T&. T& option!))
    :qid internal_vstd!std_specs.option.is_none.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.is_none.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.arrow_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.arrow_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. self!))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.is_Some.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.is_Some.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.is_Some.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (B (is-core!option.Option./Some (%Poly%core!option.Option. self!)))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_Some.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.is_Some.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.is_Some.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option. T&.
      T&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option.
      T&. T&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__option__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__option__impl&__0_trait_impl_definition
)))
(declare-fun req%vstd!std_specs.option.spec_unwrap. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (= (req%vstd!std_specs.option.spec_unwrap. T&. T& option!) (=>
     %%global_location_label%%5
     (is-core!option.Option./Some (%Poly%core!option.Option. option!))
   ))
   :pattern ((req%vstd!std_specs.option.spec_unwrap. T&. T& option!))
   :qid internal_req__vstd!std_specs.option.spec_unwrap._definition
   :skolemid skolem_internal_req__vstd!std_specs.option.spec_unwrap._definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.spec_unwrap.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.spec_unwrap.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.spec_unwrap.? T&. T& option!) (core!option.Option./Some/0
      T&. T& (%Poly%core!option.Option. option!)
    ))
    :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
    :qid internal_vstd!std_specs.option.spec_unwrap.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (=>
    (has_type option! (TYPE%core!option.Option. T&. T&))
    (has_type (vstd!std_specs.option.spec_unwrap.? T&. T& option!) T&)
   )
   :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
   :qid internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
)))
(declare-fun ens%core!option.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (opt! Poly) (res! Poly)) (!
   (= (ens%core!option.impl&%6.clone. T&. T& opt! res!) (and
     (ens%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&. T&) opt! res!)
     (=>
      (is-core!option.Option./None (%Poly%core!option.Option. opt!))
      (is-core!option.Option./None (%Poly%core!option.Option. res!))
     )
     (=>
      (is-core!option.Option./Some (%Poly%core!option.Option. opt!))
      (and
       (is-core!option.Option./Some (%Poly%core!option.Option. res!))
       (vstd!pervasive.cloned.? T&. T& (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option.
          opt!
         )
        ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. res!))
   )))))
   :pattern ((ens%core!option.impl&%6.clone. T&. T& opt! res!))
   :qid internal_ens__core!option.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!option.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)))
     (has_type res$ (TYPE%core!option.Option. T&. T&))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&. T&)) (
       DST (REF $)
      ) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)) (F fndef_singleton) closure%$
      res$
     )
     (let
      ((opt$ (%Poly%core!option.Option. (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (and
       (=>
        (is-core!option.Option./None opt$)
        (is-core!option.Option./None (%Poly%core!option.Option. res$))
       )
       (=>
        (is-core!option.Option./Some opt$)
        (and
         (is-core!option.Option./Some (%Poly%core!option.Option. res$))
         (vstd!pervasive.cloned.? T&. T& (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option.
            (Poly%core!option.Option. opt$)
           )
          ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. res$))
   )))))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option. T&.
       T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&)) (F fndef_singleton)
     closure%$ res$
   ))
   :qid user_core__option__impl&%6__clone_0
   :skolemid skolem_user_core__option__impl&%6__clone_0
)))
(declare-fun ens%alloc!boxed.impl&%15.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (b! Poly) (res! Poly)) (!
   (= (ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!) (and
     (ens%core!clone.Clone.clone. (BOX A&. A& T&.) T& b! res!)
     (vstd!pervasive.cloned.? T&. T& b! res!)
   ))
   :pattern ((ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!))
   :qid internal_ens__alloc!boxed.impl&__15.clone._definition
   :skolemid skolem_internal_ens__alloc!boxed.impl&__15.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF (BOX A&. A&
         T&.
       ))
      ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (vstd!pervasive.cloned.? T&. T& b$ res$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF
       (BOX A&. A& T&.)
      )
     ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_alloc__boxed__impl&%15__clone_0
   :skolemid skolem_user_alloc__boxed__impl&%15__clone_0
)))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (uInv SZ (vstd!simple_pptr.impl&%1.addr.? V&. V& self!))
   )
   :pattern ((vstd!simple_pptr.impl&%1.addr.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.addr.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.addr.?_pre_post_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (has_type (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? V&.
       V& self!
      )
     ) (TYPE%vstd!raw_ptr.MemContents. V&. V&)
   ))
   :pattern ((vstd!simple_pptr.impl&%1.mem_contents.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.mem_contents.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.mem_contents.?_pre_post_definition
)))
(declare-fun ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!lemma_usize_u64.
 (Int) Bool
)
(assert
 (forall ((x! Int)) (!
   (= (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!lemma_usize_u64.
     x!
    ) (= (uClip 64 (uClip SZ x!)) x!)
   )
   :pattern ((ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!lemma_usize_u64.
     x!
   ))
   :qid internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!lemma_usize_u64._definition
   :skolemid skolem_internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!lemma_usize_u64._definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
      T&. T& N&. N& self!
     ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       self!
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
      T&. T& N&. N& self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.view.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
      T&. T& N&. N& self!
     ) (TYPE%vstd!seq.Seq. T&. T&)
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
     T&. T& N&. N& self!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.view.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
      T&. T& N&. N& self!
     ) (uClip SZ (vstd!seq.Seq.len.? T&. T& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
        T&. T& N&. N& self!
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
      T&. T& N&. N& self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.spec_len.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.spec_len.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
      T&. T& N&. N& self!
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
     T&. T& N&. N& self!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.spec_len.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.spec_len.?_pre_post_definition
)))
(declare-fun ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.len.
 (Dcr Type Dcr Type OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
  Int
 ) Bool
)
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.)
   (l! Int)
  ) (!
   (= (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.len.
     T&. T& N&. N& self! l!
    ) (and
     (uInv SZ l!)
     (= l! (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/value_list_len
       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
        (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
         self!
     ))))
     (=>
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.wf.?
       T&. T& N&. N& (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
        self!
      ))
      (= l! (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
        T&. T& N&. N& (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
         self!
     ))))
     (=>
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.wf.?
       T&. T& N&. N& (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
        self!
      ))
      (= l! (vstd!seq.Seq.len.? T&. T& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
         T&. T& N&. N& (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
          self!
   )))))))
   :pattern ((ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.len.
     T&. T& N&. N& self! l!
   ))
   :qid internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.len._definition
   :skolemid skolem_internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.len._definition
)))
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%6 Bool)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (v! Poly)) (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.
     T&. T& N&. N& self! v!
    ) (and
     (=>
      %%global_location_label%%6
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.wf.?
       T&. T& N&. N& self!
     ))
     (=>
      %%global_location_label%%7
      (vstd!seq_lib.impl&%0.contains.? T&. T& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
        T&. T& N&. N& self!
       ) v!
   ))))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.
     T&. T& N&. N& self! v!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.get_node_ref._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.get_node_ref._definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (v! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
       T&. T& N&. N&
     ))
     (has_type v! T&)
    )
    (iInv 32 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.?
      T&. T& N&. N& self! v!
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.?
     T&. T& N&. N& self! v!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.get_node_ref.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.get_node_ref.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%6.is_init.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%6.is_init.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!raw_ptr.impl&%6.is_init.? T&. T& self!) (is-vstd!raw_ptr.MemContents./Init
      (%Poly%vstd!raw_ptr.MemContents. self!)
    ))
    :pattern ((vstd!raw_ptr.impl&%6.is_init.? T&. T& self!))
    :qid internal_vstd!raw_ptr.impl&__6.is_init.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__6.is_init.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!set.Set.subset_of.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.subset_of.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
    (= (vstd!set.Set.subset_of.? A&. A& self! s2!) (forall ((a$ Poly)) (!
       (=>
        (has_type a$ A&)
        (=>
         (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!) a$)
         (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$)
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!)
         a$
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
         a$
       ))
       :qid user_vstd__set__Set__subset_of_0
       :skolemid skolem_user_vstd__set__Set__subset_of_0
    )))
    :pattern ((vstd!set.Set.subset_of.? A&. A& self! s2!))
    :qid internal_vstd!set.Set.subset_of.?_definition
    :skolemid skolem_internal_vstd!set.Set.subset_of.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!set.impl&%0.spec_add.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.impl&%0.spec_add.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
    (= (vstd!set.impl&%0.spec_add.? A&. A& self! s2!) (vstd!set.impl&%0.union.? A&. A&
      self! s2!
    ))
    :pattern ((vstd!set.impl&%0.spec_add.? A&. A& self! s2!))
    :qid internal_vstd!set.impl&__0.spec_add.?_definition
    :skolemid skolem_internal_vstd!set.impl&__0.spec_add.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!set.Set. A&. A&))
     (has_type s2! (TYPE%vstd!set.Set. A&. A&))
    )
    (has_type (vstd!set.impl&%0.spec_add.? A&. A& self! s2!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.spec_add.? A&. A& self! s2!))
   :qid internal_vstd!set.impl&__0.spec_add.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.spec_add.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.impl&%0.finite.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.impl&%0.finite.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!set.impl&%0.finite.? A&. A& self!) true)
    :pattern ((vstd!set.impl&%0.finite.? A&. A& self!))
    :qid internal_vstd!set.impl&__0.finite.?_definition
    :skolemid skolem_internal_vstd!set.impl&__0.finite.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!simple_pptr.impl&%1.is_init.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!simple_pptr.impl&%1.is_init.)
  (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
    (= (vstd!simple_pptr.impl&%1.is_init.? V&. V& self!) (is-vstd!raw_ptr.MemContents./Init
      (vstd!simple_pptr.impl&%1.mem_contents.? V&. V& self!)
    ))
    :pattern ((vstd!simple_pptr.impl&%1.is_init.? V&. V& self!))
    :qid internal_vstd!simple_pptr.impl&__1.is_init.?_definition
    :skolemid skolem_internal_vstd!simple_pptr.impl&__1.is_init.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%14.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%14.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!) self!)
    )
    :pattern ((vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!))
    :qid internal_vstd!view.impl&__14.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__14.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%20.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%20.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 8) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 8) self!))
    :qid internal_vstd!view.impl&__20.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__20.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%26.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%26.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 64) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 64) self!))
    :qid internal_vstd!view.impl&__26.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__26.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%36.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%36.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 32) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 32) self!))
    :qid internal_vstd!view.impl&__36.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__36.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%46.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%46.view.)
  (forall ((A0&. Dcr) (A0& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (tr_bound%vstd!view.View. A0&. A0&)
     )
     (= (vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!) (Poly%tuple%1.
       (tuple%1./tuple%1 (vstd!view.View.view.? A0&. A0& (tuple%1./tuple%1/0 (%Poly%tuple%1.
           self!
    )))))))
    :pattern ((vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!))
    :qid internal_vstd!view.impl&__46.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__46.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%48.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%48.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
     )
     (= (vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!) (Poly%tuple%2.
       (tuple%2./tuple%2 (vstd!view.View.view.? A0&. A0& (tuple%2./tuple%2/0 (%Poly%tuple%2.
           self!
         ))
        ) (vstd!view.View.view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!))
    :qid internal_vstd!view.impl&__48.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__48.view.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (and
    (<= 0 12)
    (< 12 SZ)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_4k.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_4k.)
  (= OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_4k.?
   (uClip SZ (bitshl (I 1) (I 12)))
)))
(assert
 (uInv SZ OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_4k.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (and
    (<= 0 21)
    (< 21 SZ)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_2m.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_2m.)
  (= OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_2m.?
   (uClip SZ (bitshl (I 1) (I 21)))
)))
(assert
 (uInv SZ OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_2m.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (and
    (<= 0 30)
    (< 30 SZ)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_1g.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_1g.)
  (= OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_1g.?
   (uClip SZ (bitshl (I 1) (I 30)))
)))
(assert
 (uInv SZ OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PAGE_SZ_1g.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(assert
 (not (and
   (=>
    %%location_label%%0
    (uInv 64 (Mul 31 1024))
   )
   (=>
    (uInv 64 (Mul 31 1024))
    (and
     (=>
      %%location_label%%1
      (uInv 64 (Mul (uClip 64 (Mul 31 1024)) 1024))
     )
     (=>
      (uInv 64 (Mul (uClip 64 (Mul 31 1024)) 1024))
      (=>
       %%location_label%%2
       (uInv 64 (Mul (uClip 64 (Mul (uClip 64 (Mul 31 1024)) 1024)) 1024))
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.)
  (= OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.?
   (uClip 64 (Mul (uClip 64 (Mul (uClip 64 (Mul 31 1024)) 1024)) 1024))
)))
(assert
 (uInv 64 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.?)
)
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.?
      T&. T& N&. N& self!
     ) (forall ((i$ Poly) (j$ Poly)) (!
       (=>
        (and
         (has_type i$ INT)
         (has_type j$ INT)
        )
        (=>
         (and
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
                 T&. T& N&. N& self!
              )))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I j$)))
             (let
              ((tmp%%$5 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.spec_len.?
                 T&. T& N&. N& self!
              )))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
          )))))
          (not (= i$ j$))
         )
         (not (= (vstd!seq.Seq.index.? T&. T& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
              self!
             )
            ) i$
           ) (vstd!seq.Seq.index.? T&. T& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
              self!
             )
            ) j$
       )))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
           self!
          )
         ) i$
        ) (vstd!seq.Seq.index.? T&. T& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList./StaticLinkedList/spec_seq
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
           self!
          )
         ) j$
       ))
       :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__StaticLinkedList__unique_0
       :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__StaticLinkedList__unique_0
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.?
      T&. T& N&. N& self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.unique.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__1.unique.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.?
      self!
     ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       self!
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_4k.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_4k.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.?
      self!
     ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       self!
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_2m.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_2m.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.?
      self!
     ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       self!
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_1g.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_1g.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.)
  (forall ((self! Poly) (p! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
      self! p!
     ) (or
      (or
       (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k.?
           self!
         ))
        ) p!
       )
       (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m.?
           self!
         ))
        ) p!
      ))
      (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
         (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g.?
          self!
        ))
       ) p!
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
      self! p!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.page_is_mapped.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.page_is_mapped.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
      self!
     ) (%Poly%vstd!set.Set<usize.>. (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
        $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
         (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
           self!
    )))))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_4k.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_4k.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.)
  (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.?
      A&. A& N&. N& self!
     ) (= (vstd!seq.Seq.len.? A&. A& (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
        (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
         self!
       ))
      ) (const_int N&)
    ))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.?
      A&. A& N&. N& self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__13.wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__13.wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.)
  (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.?
      A&. A& N&. N& self!
     ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
       self!
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.?
      A&. A& N&. N& self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__13.view.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__13.view.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
      A&. A& N&. N&
    ))
    (has_type (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.?
      A&. A& N&. N& self!
     ) (TYPE%vstd!seq.Seq. A&. A&)
   ))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.view.?
     A&. A& N&. N& self!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__13.view.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__13.view.?_pre_post_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (and
   (=>
    %%location_label%%0
    (uInv SZ (Mul 2 1024))
   )
   (=>
    (uInv SZ (Mul 2 1024))
    (=>
     %%location_label%%1
     (uInv SZ (Mul (uClip SZ (Mul 2 1024)) 1024))
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.)
  (= OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?
   (uClip SZ (Mul (uClip SZ (Mul 2 1024)) 1024))
)))
(assert
 (uInv SZ OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?)
)
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.)
  (forall ((index! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.?
      index!
     ) (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I index!)))
       (let
        ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
    )))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.?
      index!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.?_definition
))))
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.
 (Poly) Bool
)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((i! Poly)) (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.
     i!
    ) (=>
     %%global_location_label%%8
     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_valid.?
      i!
   )))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.
     i!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr._definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.)
  (forall ((i! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
      i!
     ) (uClip SZ (Mul (%I i!) 4096))
    )
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
      i!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?_definition
))))
(assert
 (forall ((i! Poly)) (!
   (=>
    (has_type i! USIZE)
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
      i!
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
     i!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.?
      self!
     ) (and
      (and
       (and
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%13.wf.?
         $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
         $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
        ))))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ USIZE)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
              i$
          ))))
          :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
               ))))
              ) i$
          ))))
          :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
            i$
          ))
          :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__page_array_wf_0
          :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__page_array_wf_0
       )))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I i$)))
             (let
              ((tmp%%$5 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
           ))))
           (vstd!set.impl&%0.finite.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
         )))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__page_array_wf_1
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__page_array_wf_1
      )))
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ INT)
         (=>
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$7 (%I i$)))
            (let
             ((tmp%%$8 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
             (and
              (<= tmp%%$ tmp%%$7)
              (< tmp%%$7 tmp%%$8)
          ))))
          (vstd!set.impl&%0.finite.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
        )))))))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) i$
        ))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__page_array_wf_2
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__page_array_wf_2
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.page_array_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.page_array_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.)
  (forall ((ptr! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
      ptr!
     ) (and
      (= (EucMod (%I ptr!) 4096) 0)
      (< (EucDiv (%I ptr!) 4096) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?)
    ))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
      ptr!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?_definition
))))
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.
 (Poly) Bool
)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((ptr! Poly)) (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.
     ptr!
    ) (=>
     %%global_location_label%%9
     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
      ptr!
   )))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.
     ptr!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index._definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.)
  (forall ((ptr! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
      ptr!
     ) (uClip SZ (EucDiv (%I ptr!) 4096))
    )
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
      ptr!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?_definition
))))
(assert
 (forall ((ptr! Poly)) (!
   (=>
    (has_type ptr! USIZE)
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
      ptr!
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
     ptr!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.?
      self!
     ) (and
      (and
       (and
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.wf.?
         $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
        ))))
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.?
         $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
       )))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free4k
           ))
           (and
            (and
             (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
               $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
               )))
              ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
             )))))
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.?
               $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
                ))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
               ))))
              ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
            )))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) false
         ))))
         :pattern ((vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
            $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
         ))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_4k_wf_0
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_4k_wf_0
      )))
      (forall ((page_ptr$ Poly)) (!
        (=>
         (has_type page_ptr$ USIZE)
         (=>
          (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
            $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) page_ptr$
          )
          (and
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
            page_ptr$
           )
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                 page_ptr$
             ))))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free4k
        ))))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
          page_ptr$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              page_ptr$
        ))))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_4k_wf_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_4k_wf_1
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_4k_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_4k_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.)
  (forall ((ptr! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
      ptr!
     ) (and
      (= (EucMod (%I ptr!) 2097152) 0)
      (< (EucDiv (%I ptr!) 4096) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?)
    ))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
      ptr!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.?
      self!
     ) (and
      (and
       (and
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.wf.?
         $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
        ))))
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.?
         $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
       )))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free2m
           ))
           (and
            (and
             (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
               $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
               )))
              ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
             )))))
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.?
               $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
                ))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
               ))))
              ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
            )))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) false
         ))))
         :pattern ((vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
            $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
         ))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_2m_wf_0
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_2m_wf_0
      )))
      (forall ((page_ptr$ Poly)) (!
        (=>
         (has_type page_ptr$ USIZE)
         (=>
          (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
            $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) page_ptr$
          )
          (and
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
            page_ptr$
           )
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                 page_ptr$
             ))))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free2m
        ))))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
          page_ptr$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              page_ptr$
        ))))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_2m_wf_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_2m_wf_1
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_2m_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_2m_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.)
  (forall ((ptr! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
      ptr!
     ) (and
      (= (EucMod (%I ptr!) 1073741824) 0)
      (< (EucDiv (%I ptr!) 4096) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?)
    ))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
      ptr!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.?
      self!
     ) (and
      (and
       (and
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.wf.?
         $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
        ))))
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.unique.?
         $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
       )))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free1g
           ))
           (and
            (and
             (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
               $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
               )))
              ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
             )))))
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.get_node_ref.?
               $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
                ))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
               ))))
              ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
            )))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) false
         ))))
         :pattern ((vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
            $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
         ))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/rev_pointer
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_1g_wf_0
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_1g_wf_0
      )))
      (forall ((page_ptr$ Poly)) (!
        (=>
         (has_type page_ptr$ USIZE)
         (=>
          (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
            $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) page_ptr$
          )
          (and
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
            page_ptr$
           )
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                 page_ptr$
             ))))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free1g
        ))))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
          page_ptr$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              page_ptr$
        ))))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_1g_wf_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_1g_wf_1
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_1g_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.free_pages_1g_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.?
      self!
     ) (and
      (and
       (and
        (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
        ))))
        (forall ((p$ Poly)) (!
          (=>
           (has_type p$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
              )))
             ) p$
            )
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
             p$
          )))
          :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
             )))
            ) p$
           ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
            p$
          ))
          :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_4k_wf_0
          :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_4k_wf_0
       )))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated4k
           ))
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
              )))
             ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
            )))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) false
         ))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
         ))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_4k_wf_1
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_4k_wf_1
      )))
      (forall ((p$ Poly)) (!
        (=>
         (has_type p$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          )
          (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
               ))))
              ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                p$
            ))))
           ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated4k
        )))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              p$
        ))))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_4k_wf_2
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_4k_wf_2
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.allocated_pages_4k_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.allocated_pages_4k_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.?
      self!
     ) (and
      (and
       (and
        (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
        ))))
        (forall ((p$ Poly)) (!
          (=>
           (has_type p$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
              )))
             ) p$
            )
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
             p$
          )))
          :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
             )))
            ) p$
           ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
            p$
          ))
          :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_2m_wf_0
          :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_2m_wf_0
       )))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated2m
           ))
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
              )))
             ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
            )))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) false
         ))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
         ))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_2m_wf_1
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_2m_wf_1
      )))
      (forall ((p$ Poly)) (!
        (=>
         (has_type p$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_2m
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          )
          (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
               ))))
              ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                p$
            ))))
           ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated2m
        )))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              p$
        ))))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_2m_wf_2
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_2m_wf_2
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.allocated_pages_2m_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.allocated_pages_2m_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.?
      self!
     ) (and
      (and
       (and
        (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
        ))))
        (forall ((p$ Poly)) (!
          (=>
           (has_type p$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
              )))
             ) p$
            )
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
             p$
          )))
          :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
             )))
            ) p$
           ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
            p$
          ))
          :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_1g_wf_0
          :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_1g_wf_0
       )))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated1g
           ))
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
              )))
             ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
            )))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) false
         ))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_1g_wf_1
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_1g_wf_1
      )))
      (forall ((p$ Poly)) (!
        (=>
         (has_type p$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_1g
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          )
          (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
               ))))
              ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                p$
            ))))
           ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated1g
        )))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              p$
        ))))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_1g_wf_2
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__allocated_pages_1g_wf_2
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.allocated_pages_1g_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.allocated_pages_1g_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.?
      self!
     ) (and
      (and
       (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
           self!
       ))))
       (forall ((p$ Poly)) (!
         (=>
          (has_type p$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
             )))
            ) p$
           )
           (and
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
             p$
            )
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                  p$
              ))))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k
         ))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
           p$
         ))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
               p$
         ))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
           p$
         ))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_4k_wf_0
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_4k_wf_0
      )))
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ INT)
         (=>
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k
          ))
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
        )))))))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) i$
        ))))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_4k_wf_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_4k_wf_1
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_4k_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_4k_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.?
      self!
     ) (and
      (and
       (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
           self!
       ))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
           ))
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
             )))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
         )))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_2m_wf_0
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_2m_wf_0
      )))
      (forall ((p$ Poly)) (!
        (=>
         (has_type p$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          )
          (and
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
            p$
           )
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                 p$
             ))))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
           )))
          ) p$
         ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
          p$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              p$
        ))))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
           )))
          ) p$
         ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
          p$
        ))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_2m_wf_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_2m_wf_1
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_2m_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_2m_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.?
      self!
     ) (and
      (and
       (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
           self!
       ))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
           ))
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
             )))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
         )))))))
         :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/addr
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) i$
         ))))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_1g_wf_0
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_1g_wf_0
      )))
      (forall ((p$ Poly)) (!
        (=>
         (has_type p$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          )
          (and
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
            p$
           )
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                 p$
             ))))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
           )))
          ) p$
         ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
          p$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
              p$
        ))))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
           )))
          ) p$
         ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
          p$
        ))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_1g_wf_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_1g_wf_1
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_1g_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_1g_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.)
  (forall ((i! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?
      i!
     ) (and
      (= (EucMod (%I i!) 512) 0)
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 (%I i!)))
        (let
         ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
         (and
          (<= tmp%%$ tmp%%$1)
          (< tmp%%$1 tmp%%$2)
    ))))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?
      i!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.)
  (forall ((index! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
      index!
     ) (uClip SZ (Mul (EucDiv (%I index!) 512) 512))
    )
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
      index!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?_definition
))))
(assert
 (forall ((index! Poly)) (!
   (=>
    (has_type index! USIZE)
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
      index!
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
     index!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.)
  (forall ((i! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?
      i!
     ) (and
      (= (EucMod (%I i!) (uClip SZ (nClip (Mul 512 512)))) 0)
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 (%I i!)))
        (let
         ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
         (and
          (<= tmp%%$ tmp%%$1)
          (< tmp%%$1 tmp%%$2)
    ))))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?
      i!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.)
  (forall ((index! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
      index!
     ) (uClip SZ (Mul (Mul (EucDiv (EucDiv (%I index!) 512) 512) 512) 512))
    )
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
      index!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?_definition
))))
(assert
 (forall ((index! Poly)) (!
   (=>
    (has_type index! USIZE)
    (uInv SZ (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
      index!
   )))
   :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
     index!
   ))
   :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?_pre_post_definition
   :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.?
      self!
     ) (and
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ USIZE)
         (=>
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Merged2m
          ))
          (and
           (and
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?
              i$
             ) false
            )
            (or
             (or
              (or
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
                     i$
                 ))))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
               )
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
                     i$
                 ))))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free2m
              ))
              (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
                    i$
                ))))
               ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated2m
             ))
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
                   i$
               ))))
              ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Unavailable2m
           )))
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
                 i$
        )))))))))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?
          i$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_2m.?
          i$
        ))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__merged_pages_wf_0
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__merged_pages_wf_0
      ))
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ USIZE)
         (=>
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I i$)))
             (let
              ((tmp%%$5 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
           ))))
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Merged1g
          ))
          (and
           (and
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?
              i$
             ) false
            )
            (or
             (or
              (or
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
                     i$
                 ))))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
               )
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
                     i$
                 ))))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free1g
              ))
              (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
                    i$
                ))))
               ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated1g
             ))
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
                   i$
               ))))
              ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Unavailable1g
           )))
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
                 i$
        )))))))))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?
          i$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_truncate_1g.?
          i$
        ))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__merged_pages_wf_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__merged_pages_wf_1
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.merged_pages_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.merged_pages_wf.?_definition
))))
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((i! Poly) (j! Poly)) (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.
     i! j!
    ) (=>
     %%global_location_label%%10
     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?
      i!
   )))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.
     i! j!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild._definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.)
  (forall ((i! Poly) (j! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.?
      i! j!
     ) (let
      ((tmp%%$ (%I i!)))
      (let
       ((tmp%%$1 (%I j!)))
       (let
        ((tmp%%$2 (Add (%I i!) 512)))
        (and
         (< tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
    )))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.?
      i! j!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.?_definition
))))
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%11 Bool)
(assert
 (forall ((i! Poly) (j! Poly)) (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.
     i! j!
    ) (=>
     %%global_location_label%%11
     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?
      i!
   )))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.
     i! j!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild._definition
)))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.)
  (forall ((i! Poly) (j! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.?
      i! j!
     ) (let
      ((tmp%%$ (%I i!)))
      (let
       ((tmp%%$1 (%I j!)))
       (let
        ((tmp%%$2 (Add (%I i!) 262144)))
        (and
         (< tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
    )))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.?
      i! j!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.?
      self!
     ) (forall ((i$ Poly) (j$ Poly)) (!
       (=>
        (and
         (has_type i$ USIZE)
         (has_type j$ USIZE)
        )
        (and
         (=>
          (and
           (and
            (and
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$1 (%I i$)))
               (let
                ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
                (and
                 (<= tmp%%$ tmp%%$1)
                 (< tmp%%$1 tmp%%$2)
             ))))
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_2m_valid.?
              i$
            ))
            (or
             (or
              (or
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
                 ))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
               )
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
                 ))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free2m
              ))
              (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
                ))
               ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated2m
             ))
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
               ))
              ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Unavailable2m
           )))
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.?
            i$ j$
          ))
          (and
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) j$
             ))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Merged2m
           )
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) j$
         ))))))
         (=>
          (and
           (and
            (and
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$4 (%I i$)))
               (let
                ((tmp%%$5 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
                (and
                 (<= tmp%%$ tmp%%$4)
                 (< tmp%%$4 tmp%%$5)
             ))))
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index_1g_valid.?
              i$
            ))
            (or
             (or
              (or
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
                 ))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
               )
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
                 ))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free1g
              ))
              (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
                ))
               ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Allocated1g
             ))
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
               ))
              ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Unavailable1g
           )))
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.?
            i$ j$
          ))
          (and
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) j$
             ))
            ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Merged1g
           )
           (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/is_io_page
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) j$
       ))))))))
       :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_2m_vaild.?
         i$ j$
       ))
       :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index_merge_1g_vaild.?
         i$ j$
       ))
       :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__hugepages_wf_0
       :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__hugepages_wf_0
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.hugepages_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.hugepages_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.?
      self!
     ) (and
      (and
       (and
        (and
         (and
          (ext_eq false (TYPE%vstd!set.Set. $ USIZE) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
             $ (ARRAY $ (UINT 8) $ (CONST_INT 4096))
            ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
            ))
           ) (vstd!set.impl&%0.union.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_4k
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
             ))
            ) (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
              $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_4k
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
          )))))))
          (forall ((p$ Poly)) (!
            (=>
             (has_type p$ USIZE)
             (=>
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8) $ (CONST_INT 4096)))
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
                )))
               ) p$
              )
              (and
               (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ (ARRAY
                  $ (UINT 8) $ (CONST_INT 4096)
                 ) (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT
                     8
                    ) $ (CONST_INT 4096)
                   )
                  ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                   )
                  ) p$
               )))
               (= (vstd!simple_pptr.impl&%1.addr.? $ (ARRAY $ (UINT 8) $ (CONST_INT 4096)) (vstd!map.impl&%0.index.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8) $ (CONST_INT 4096)))
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                   )
                  ) p$
                 )
                ) (%I p$)
            ))))
            :pattern ((is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.?
               $ (ARRAY $ (UINT 8) $ (CONST_INT 4096)) (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
                 $ (ARRAY $ (UINT 8) $ (CONST_INT 4096))
                ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
                 )
                ) p$
            ))))
            :pattern ((vstd!simple_pptr.impl&%1.addr.? $ (ARRAY $ (UINT 8) $ (CONST_INT 4096))
              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT
                  8
                 ) $ (CONST_INT 4096)
                )
               ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_4k
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
                )
               ) p$
            )))
            :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__perm_wf_0
            :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__perm_wf_0
         )))
         (ext_eq false (TYPE%vstd!set.Set. $ USIZE) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
            $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152))
           ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
             self!
           ))
          ) (vstd!set.impl&%0.union.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_2m
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
            ))
           ) (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
             $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_2m
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
        ))))))))
        (forall ((p$ Poly)) (!
          (=>
           (has_type p$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152)))
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
              )))
             ) p$
            )
            (and
             (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ (ARRAY
                $ (UINT 8) $ (CONST_INT 2097152)
               ) (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT
                   8
                  ) $ (CONST_INT 2097152)
                 )
                ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
                 )
                ) p$
             )))
             (= (vstd!simple_pptr.impl&%1.addr.? $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152)) (vstd!map.impl&%0.index.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152)))
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
                 )
                ) p$
               )
              ) (%I p$)
          ))))
          :pattern ((is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.?
             $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152)) (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
               $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152))
              ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
               )
              ) p$
          ))))
          :pattern ((vstd!simple_pptr.impl&%1.addr.? $ (ARRAY $ (UINT 8) $ (CONST_INT 2097152))
            (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT
                8
               ) $ (CONST_INT 2097152)
              )
             ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_2m
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
              )
             ) p$
          )))
          :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__perm_wf_1
          :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__perm_wf_1
       )))
       (ext_eq false (TYPE%vstd!set.Set. $ USIZE) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
          $ (ARRAY $ (UINT 8) $ (CONST_INT 1073741824))
         ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
           self!
         ))
        ) (vstd!set.impl&%0.union.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/mapped_pages_1g
           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
          ))
         ) (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%1.view.?
           $ USIZE $ (CONST_INT 2097152) (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!StaticLinkedList.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/free_pages_1g
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
      ))))))))
      (forall ((p$ Poly)) (!
        (=>
         (has_type p$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8) $ (CONST_INT 1073741824)))
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) p$
          )
          (and
           (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ (ARRAY
              $ (UINT 8) $ (CONST_INT 1073741824)
             ) (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT
                 8
                ) $ (CONST_INT 1073741824)
               )
              ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
               )
              ) p$
           )))
           (= (vstd!simple_pptr.impl&%1.addr.? $ (ARRAY $ (UINT 8) $ (CONST_INT 1073741824)) (
              vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT
                 8
                ) $ (CONST_INT 1073741824)
               )
              ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
               )
              ) p$
             )
            ) (%I p$)
        ))))
        :pattern ((is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.?
           $ (ARRAY $ (UINT 8) $ (CONST_INT 1073741824)) (vstd!map.impl&%0.index.? $ USIZE $
            (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT 8) $ (CONST_INT 1073741824))) (
             OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
             )
            ) p$
        ))))
        :pattern ((vstd!simple_pptr.impl&%1.addr.? $ (ARRAY $ (UINT 8) $ (CONST_INT 1073741824))
          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ (ARRAY $ (UINT
              8
             ) $ (CONST_INT 1073741824)
            )
           ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_perms_1g
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
             self!
            )
           ) p$
        )))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__perm_wf_2
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__perm_wf_2
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.perm_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.perm_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.?
      self!
     ) (and
      (and
       (and
        (and
         (and
          (and
           (and
            (and
             (and
              (and
               (vstd!set.Set.subset_of.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!set.Set.
                  $ USIZE
                 ) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                 )))
                ) (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
               ))))
               (vstd!set.Set.subset_of.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!set.Set.
                  $ USIZE
                 ) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                 )))
                ) (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
              )))))
              (vstd!set.Set.subset_of.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!set.Set.
                 $ USIZE
                ) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
                )))
               ) (Poly%vstd!set.Set<usize.>. (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/allocated_pages_4k
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
             )))))
             (forall ((i$ Poly)) (!
               (=>
                (has_type i$ INT)
                (=>
                 (and
                  (let
                   ((tmp%%$ 0))
                   (let
                    ((tmp%%$1 (%I i$)))
                    (let
                     ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
                     (and
                      (<= tmp%%$ tmp%%$1)
                      (< tmp%%$1 tmp%%$2)
                  ))))
                  (or
                   (or
                    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                       (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                          (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                             self!
                         ))))
                        ) i$
                      ))
                     ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k
                    )
                    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                       (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                          (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                             self!
                         ))))
                        ) i$
                      ))
                     ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
                   ))
                   (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                      (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                       (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                        (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                         (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                            self!
                        ))))
                       ) i$
                     ))
                    ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
                 )))
                 (is-core!option.Option./Some (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                    (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                       (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                          self!
                      ))))
                     ) i$
               ))))))
               :pattern ((vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
                ) (is-core!option.Option./Some (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                       (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                        (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                         self!
                     ))))
                    ) i$
               )))))
               :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_0
               :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_0
            )))
            (forall ((i$ Poly)) (!
              (=>
               (has_type i$ INT)
               (=>
                (and
                 (let
                  ((tmp%%$ 0))
                  (let
                   ((tmp%%$4 (%I i$)))
                   (let
                    ((tmp%%$5 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
                    (and
                     (<= tmp%%$ tmp%%$4)
                     (< tmp%%$4 tmp%%$5)
                 ))))
                 (is-core!option.Option./Some (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                    (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                       (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                          self!
                      ))))
                     ) i$
                )))))
                (or
                 (or
                  (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                     (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                        (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                         (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                           self!
                       ))))
                      ) i$
                    ))
                   ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k
                  )
                  (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                     (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                        (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                         (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                           self!
                       ))))
                      ) i$
                    ))
                   ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
                 ))
                 (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                    (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                       (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                          self!
                      ))))
                     ) i$
                   ))
                  ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
              ))))
              :pattern ((vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
               ) (is-core!option.Option./Some (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
              )))))
              :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_1
              :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_1
           )))
           (forall ((i$ Poly)) (!
             (=>
              (has_type i$ USIZE)
              (=>
               (and
                (let
                 ((tmp%%$ 0))
                 (let
                  ((tmp%%$7 (%I i$)))
                  (let
                   ((tmp%%$8 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
                   (and
                    (<= tmp%%$ tmp%%$7)
                    (< tmp%%$7 tmp%%$8)
                ))))
                (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                       (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                        (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                         self!
                     ))))
                    ) i$
                  ))
                 ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k
               ))
               (and
                (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                   $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                      (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                       (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                        (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                         (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                            self!
                        ))))
                       ) i$
                )))))))
                (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                    ))
                   ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                        (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                         (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                           (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                              self!
                          ))))
                         ) i$
                  )))))))
                 ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
                   i$
             ))))))
             :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
               ))
              ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
             ))))
             :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_2
             :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_2
          )))
          (forall ((i$ Poly)) (!
            (=>
             (has_type i$ USIZE)
             (=>
              (and
               (let
                ((tmp%%$ 0))
                (let
                 ((tmp%%$10 (%I i$)))
                 (let
                  ((tmp%%$11 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
                  (and
                   (<= tmp%%$ tmp%%$10)
                   (< tmp%%$10 tmp%%$11)
               ))))
               (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) i$
                 ))
                ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
              ))
              (and
               (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                     (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                        (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                         (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                          (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                           self!
                       ))))
                      ) i$
               )))))))
               (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
                  $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                   ))
                  ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                       (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                          (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                             self!
                         ))))
                        ) i$
                 )))))))
                ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
                  i$
            ))))))
            :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
            ))))
            :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_3
            :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_3
         )))
         (forall ((i$ Poly)) (!
           (=>
            (has_type i$ USIZE)
            (=>
             (and
              (let
               ((tmp%%$ 0))
               (let
                ((tmp%%$13 (%I i$)))
                (let
                 ((tmp%%$14 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
                 (and
                  (<= tmp%%$ tmp%%$13)
                  (< tmp%%$13 tmp%%$14)
              ))))
              (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
                ))
               ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
             ))
             (and
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                    (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                       (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                          self!
                      ))))
                     ) i$
              )))))))
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
                 $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                  ))
                 ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                      (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                       (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                        (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                         (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                           (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                            self!
                        ))))
                       ) i$
                )))))))
               ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
                 i$
           ))))))
           :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
             ))
            ) (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
             (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
                ))))
               ) i$
           ))))
           :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_4
           :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_4
        )))
        (forall ((c_ptr$ Poly) (page_ptr$ Poly)) (!
          (=>
           (and
            (has_type c_ptr$ USIZE)
            (has_type page_ptr$ USIZE)
           )
           (=>
            (and
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
               ))))
              ) c_ptr$
             )
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
                $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
                 ))
                ) c_ptr$
               )
              ) page_ptr$
            ))
            (and
             (and
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
               page_ptr$
              )
              (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                    page_ptr$
                ))))
               ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k
             ))
             (= (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                       (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                        (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                         self!
                     ))))
                    ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                      page_ptr$
               )))))))
              ) c_ptr$
          ))))
          :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
              $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_4k
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
               ))
              ) c_ptr$
             )
            ) page_ptr$
          ))
          :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_5
          :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_5
       )))
       (forall ((c_ptr$ Poly) (page_ptr$ Poly)) (!
         (=>
          (and
           (has_type c_ptr$ USIZE)
           (has_type page_ptr$ USIZE)
          )
          (=>
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
              ))))
             ) c_ptr$
            )
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
               $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                  self!
                ))
               ) c_ptr$
              )
             ) page_ptr$
           ))
           (and
            (and
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_2m_valid.?
              page_ptr$
             )
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                   page_ptr$
               ))))
              ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
            ))
            (= (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                       (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                        self!
                    ))))
                   ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                     page_ptr$
              )))))))
             ) c_ptr$
         ))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
             $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_2m
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
              ))
             ) c_ptr$
            )
           ) page_ptr$
         ))
         :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_6
         :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_6
      )))
      (forall ((c_ptr$ Poly) (page_ptr$ Poly)) (!
        (=>
         (and
          (has_type c_ptr$ USIZE)
          (has_type page_ptr$ USIZE)
         )
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
             ))))
            ) c_ptr$
           )
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
              $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                 self!
               ))
              ) c_ptr$
             )
            ) page_ptr$
          ))
          (and
           (and
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_1g_valid.?
             page_ptr$
            )
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                  page_ptr$
              ))))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
           ))
           (= (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/owning_container
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                    page_ptr$
             )))))))
            ) c_ptr$
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.index.?
            $ USIZE $ (TYPE%vstd!set.Set. $ USIZE) (Poly%vstd!map.Map<usize./vstd!set.Set<usize.>.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/container_map_1g
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
             ))
            ) c_ptr$
           )
          ) page_ptr$
        ))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_7
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__container_wf_7
    ))))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.container_wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.container_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.?
      self!
     ) (forall ((i$ Poly)) (!
       (=>
        (has_type i$ INT)
        (=>
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (and
          (= (not (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) 0
            )
           ) (or
            (or
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
               ))
              ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped4k
             )
             (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                     (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                      self!
                  ))))
                 ) i$
               ))
              ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped2m
            ))
            (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
              (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
               (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                 (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                    (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                     self!
                 ))))
                ) i$
              ))
             ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Mapped1g
          )))
          (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   self!
               ))))
              ) i$
            ))
           ) (nClip (Add (vstd!set.impl&%0.len.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
              ))))
             ) (vstd!set.impl&%0.len.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings
                (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                 (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
                   (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                    (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                      (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                       self!
                   ))))
                  ) i$
       )))))))))))
       :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/ref_count
         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
          (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
             (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
            ))))
           ) i$
       ))))
       :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
          (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
             (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
            ))))
           ) i$
       ))))
       :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/mappings
         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
          (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
             (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
            ))))
           ) i$
       ))))
       :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/io_mappings
         (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
          (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
             (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                self!
            ))))
           ) i$
       ))))
       :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_have_reference_counter_0
       :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__mapped_pages_have_reference_counter_0
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_have_reference_counter.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.mapped_pages_have_reference_counter.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.)
  (forall ((self! Poly)) (!
    (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.?
      self!
     ) (and
      (and
       (and
        (and
         (and
          (and
           (and
            (and
             (and
              (and
               (and
                (and
                 (and
                  (and
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_array_wf.?
                    self!
                   )
                   (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k_wf.?
                    self!
                  ))
                  (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_2m_wf.?
                   self!
                 ))
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_1g_wf.?
                  self!
                ))
                (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_4k_wf.?
                 self!
               ))
               (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_2m_wf.?
                self!
              ))
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.allocated_pages_1g_wf.?
               self!
             ))
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_4k_wf.?
              self!
            ))
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_2m_wf.?
             self!
           ))
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_1g_wf.?
            self!
          ))
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.merged_pages_wf.?
           self!
         ))
         (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.hugepages_wf.?
          self!
        ))
        (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.perm_wf.?
         self!
       ))
       (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.container_wf.?
        self!
      ))
      (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.mapped_pages_have_reference_counter.?
       self!
    )))
    :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.?
      self!
    ))
    :qid internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.wf.?_definition
    :skolemid skolem_internal_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__5.wf.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_vstd__view__impl&__14_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__14_trait_impl_definition
)))
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 8))
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 64))
)
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 32))
)
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_vstd__view__impl&__46_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__46_trait_impl_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__48_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__48_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__15_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ USIZE)
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 8))
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 64))
)
(assert
 (tr_bound%core!clone.Clone. $ (SINT 32))
)
(assert
 (tr_bound%core!clone.Clone. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (REF T&.) T&)
   :pattern ((tr_bound%core!clone.Clone. (REF T&.) T&))
   :qid internal_core__clone__impls__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__impl&__20_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__35_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__35_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__32_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!clone.Clone. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__7_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!clone.Clone. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__9_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ INT)
)
(assert
 (tr_bound%core!clone.Clone. $ NAT)
)
(assert
 (tr_bound%core!marker.Copy. $ USIZE)
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 8))
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 64))
)
(assert
 (tr_bound%core!marker.Copy. $ (SINT 32))
)
(assert
 (tr_bound%core!marker.Copy. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (REF T&.) T&)
   :pattern ((tr_bound%core!marker.Copy. (REF T&.) T&))
   :qid internal_core__marker__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__4_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!marker.Copy. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%core!marker.Copy. $ (ARRAY T&. T& N&. N&)))
   :qid internal_core__array__impl&__19_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__19_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!clone.Clone. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!marker.Copy. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%core!marker.Copy. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_core__option__impl&__54_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__54_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!marker.Copy. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__8_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__8_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!marker.Copy. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__10_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__10_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ INT)
)
(assert
 (tr_bound%core!marker.Copy. $ NAT)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(declare-fun ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%3.clone.
 (Poly Poly) Bool
)
(assert
 (forall ((self! Poly) (%return! Poly)) (!
   (= (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%3.clone.
     self! %return!
    ) (and
     (ens%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
      self! %return!
     )
     (= %return! self!)
   ))
   :pattern ((ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%3.clone.
     self! %return!
   ))
   :qid internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__3.clone._definition
   :skolemid skolem_internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__3.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.))
     (has_type %return$ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
      (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
      (F fndef_singleton) closure%$ %return$
     )
     (let
      ((self$ (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
         (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))
      )))
      (= (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
        %return$
       ) self$
   ))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
     (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
     (F fndef_singleton) closure%$ %return$
   ))
   :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Page__clone_0
   :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__Page__clone_0
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= %return! self!)
   (=>
    %%location_label%%0
    (= %return! self!)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
)
(declare-fun ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%8.clone.
 (Poly Poly) Bool
)
(assert
 (forall ((self! Poly) (%return! Poly)) (!
   (= (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%8.clone.
     self! %return!
    ) (and
     (ens%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
      self! %return!
     )
     (= %return! self!)
   ))
   :pattern ((ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%8.clone.
     self! %return!
   ))
   :qid internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__8.clone._definition
   :skolemid skolem_internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__8.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.))
     (has_type %return$ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
      (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
      (F fndef_singleton) closure%$ %return$
     )
     (let
      ((self$ (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
         (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))
      )))
      (= (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.
        %return$
       ) self$
   ))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
     (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
     (F fndef_singleton) closure%$ %return$
   ))
   :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState__clone_0
   :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageState__clone_0
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= %return! self!)
   (=>
    %%location_label%%0
    (= %return! self!)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
)
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (
      DST (REF Self%&.)
     ) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $))
  (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST
     (REF (REF T&.))
    ) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T& N&.
       N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&.
       T& N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_core__array__impl&__20__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T&
       N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY
       T&. T& N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_core__array__impl&__20__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY T&. T&
       N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (ARRAY
       T&. T& N&. N&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (ARRAY T&. T& N&. N&))
   ))
   :qid internal_core__array__impl&__20__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__array__impl&__20__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (
      DST (REF (GHOST T&.))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
      T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_core__option__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_core__option__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!clone.Clone. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (TYPE%core!option.Option.
       T&. T&
      )
     ) (DST (REF $)) (TYPE%tuple%1. (REF $) (TYPE%core!option.Option. T&. T&))
   ))
   :qid internal_core__option__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__option__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&)
     (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
       T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.)
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState.)
))
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%6.free_pages_are_not_mapped.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 Bool
)
(declare-const %%global_location_label%%12 Bool)
(assert
 (forall ((self! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%6.free_pages_are_not_mapped.
     self!
    ) (=>
     %%global_location_label%%12
     (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.?
      (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
       self!
   ))))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%6.free_pages_are_not_mapped.
     self!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__6.free_pages_are_not_mapped._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__6.free_pages_are_not_mapped._definition
)))
(declare-fun ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%6.free_pages_are_not_mapped.
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
 Bool
)
(assert
 (forall ((self! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.))
  (!
   (= (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%6.free_pages_are_not_mapped.
     self!
    ) (forall ((page_ptr$ Poly)) (!
      (=>
       (has_type page_ptr$ USIZE)
       (=>
        (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
            (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
             self!
          )))
         ) page_ptr$
        )
        (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
          (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
           self!
          ) page_ptr$
         ) false
      )))
      :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
           (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
         )))
        ) page_ptr$
      ))
      :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
        (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
         self!
        ) page_ptr$
      ))
      :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_are_not_mapped_0
      :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_are_not_mapped_0
   )))
   :pattern ((ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%6.free_pages_are_not_mapped.
     self!
   ))
   :qid internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__6.free_pages_are_not_mapped._definition
   :skolemid skolem_internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&__6.free_pages_are_not_mapped._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.)
(declare-const tmp%1 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
   self!
  ) TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
))
(assert
 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.wf.?
  (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
   self!
)))
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (=>
   (= tmp%1 (forall ((page_ptr$ Poly)) (!
      (=>
       (has_type page_ptr$ USIZE)
       (=>
        (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
           (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
            (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
             self!
          )))
         ) page_ptr$
        )
        (and
         (and
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr_valid.?
           page_ptr$
          )
          (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page./Page/state
            (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
             (vstd!seq.Seq.index.? $ TYPE%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Page.
              (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array./Array/seq
               (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!Array.
                 (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator./PageAllocator/page_array
                  (%Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                   (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
                    self!
               )))))
              ) (I (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
                page_ptr$
            ))))
           ) OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageState./Free4k
         ))
         (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
           (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
           ) page_ptr$
          ) false
      ))))
      :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
          (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
           (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
            self!
         )))
        ) page_ptr$
      ))
      :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
        (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
         self!
        ) page_ptr$
      ))
      :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_are_not_mapped_2
      :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_are_not_mapped_2
   )))
   (and
    (=>
     %%location_label%%0
     tmp%1
    )
    (=>
     tmp%1
     (=>
      %%location_label%%1
      (forall ((page_ptr$ Poly)) (!
        (=>
         (has_type page_ptr$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
              (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
               self!
            )))
           ) page_ptr$
          )
          (= (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
            (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
             self!
            ) page_ptr$
           ) false
        )))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.free_pages_4k.?
             (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
              self!
           )))
          ) page_ptr$
        ))
        :pattern ((OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!impl&%5.page_is_mapped.?
          (Poly%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!PageAllocator.
           self!
          ) page_ptr$
        ))
        :qid user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_are_not_mapped_1
        :skolemid skolem_user_OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped__PageAllocator__free_pages_are_not_mapped_1
))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index.
 (Int) Bool
)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((ptr! Int)) (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index.
     ptr!
    ) (=>
     %%global_location_label%%13
     (= (EucMod ptr! 4096) 0)
   ))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index.
     ptr!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index._definition
)))
(declare-fun ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index.
 (Int Int) Bool
)
(assert
 (forall ((ptr! Int) (ret! Int)) (!
   (= (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index.
     ptr! ret!
    ) (and
     (uInv SZ ret!)
     (= ret! (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
       (I ptr!)
   ))))
   :pattern ((ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index.
     ptr! ret!
   ))
   :qid internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index._definition
   :skolemid skolem_internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_ptr2page_index._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ret! Int)
(declare-const ptr! Int)
(assert
 fuel_defaults
)
(assert
 (uInv SZ ptr!)
)
(assert
 (= (EucMod ptr! 4096) 0)
)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (and
   (=>
    %%location_label%%0
    (not (= 4096 0))
   )
   (=>
    (not (= 4096 0))
    (=>
     (= ret! (uClip SZ (EucDiv ptr! 4096)))
     (=>
      %%location_label%%1
      (= ret! (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_ptr2page_index.?
        (I ptr!)
))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(declare-fun req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr.
 (Int) Bool
)
(declare-const %%global_location_label%%14 Bool)
(assert
 (forall ((i! Int)) (!
   (= (req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr.
     i!
    ) (=>
     %%global_location_label%%14
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 i!))
       (let
        ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr.
     i!
   ))
   :qid internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr._definition
   :skolemid skolem_internal_req__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr._definition
)))
(declare-fun ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr.
 (Int Int) Bool
)
(assert
 (forall ((i! Int) (ret! Int)) (!
   (= (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr.
     i! ret!
    ) (and
     (uInv SZ ret!)
     (= ret! (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
       (I i!)
   ))))
   :pattern ((ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr.
     i! ret!
   ))
   :qid internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr._definition
   :skolemid skolem_internal_ens__OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!page_index2page_ptr._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ret! Int)
(declare-const i! Int)
(declare-const tmp%1 Int)
(assert
 fuel_defaults
)
(assert
 (uInv SZ i!)
)
(assert
 (let
  ((tmp%%$ 0))
  (let
   ((tmp%%$1 i!))
   (let
    ((tmp%%$2 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!NUM_PAGES.?))
    (and
     (<= tmp%%$ tmp%%$1)
     (< tmp%%$1 tmp%%$2)
)))))
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (=>
   (= tmp%1 OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!MAX_USIZE.?)
   (=>
    (ens%OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!lemma_usize_u64.
     tmp%1
    )
    (and
     (=>
      %%location_label%%0
      (uInv SZ (Mul i! 4096))
     )
     (=>
      (uInv SZ (Mul i! 4096))
      (=>
       (= ret! (uClip SZ (Mul i! 4096)))
       (=>
        %%location_label%%1
        (= ret! (OS__allocator__page_allocator_spec_impl__impl1__free_pages_are_not_mapped!spec_page_index2page_ptr.?
          (I i!)
))))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
