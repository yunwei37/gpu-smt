(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!std_specs.option.impl&%0.get_Some_0. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.is_None. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_spec_len. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_has_resolved. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%14.view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%20.view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.
 FuelId
)
(declare-const fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!std_specs.option.impl&%0.get_Some_0. fuel%vstd!std_specs.option.impl&%0.is_None.
  fuel%vstd!std_specs.vec.axiom_spec_len. fuel%vstd!std_specs.vec.axiom_vec_has_resolved.
  fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view. fuel%vstd!function.axiom_fn_mut_call_requires.
  fuel%vstd!function.axiom_fn_mut_call_ensures. fuel%vstd!iset.lemma_iset_ext_equal.
  fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index. fuel%vstd!map.axiom_map_index_decreases.
  fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep. fuel%vstd!seq.impl&%2.spec_index.
  fuel%vstd!seq.lemma_seq_index_decreases. fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep.
  fuel%vstd!set.Set.contains. fuel%vstd!set.axiom_set_ext_equal. fuel%vstd!set.axiom_set_ext_equal_deep.
  fuel%vstd!set.axiom_set_decreases_to_member. fuel%vstd!view.impl&%0.view. fuel%vstd!view.impl&%2.view.
  fuel%vstd!view.impl&%4.view. fuel%vstd!view.impl&%6.view. fuel%vstd!view.impl&%14.view.
  fuel%vstd!view.impl&%16.view. fuel%vstd!view.impl&%18.view. fuel%vstd!view.impl&%20.view.
  fuel%vstd!view.impl&%30.view. fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.
  fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne. fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.
  fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt. fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.
  fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.
  fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view. fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.
  fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view. fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.
  fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.
  fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
  (and
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_spec_len.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.option.OptionAdditionalFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.
 (Dcr Type) Bool
)
(declare-fun tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!VerusClone.
 (Dcr Type) Bool
)
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-sort alloc!alloc.Global. 0)
(declare-sort alloc!vec.Vec<u8./alloc!alloc.Global.>. 0)
(declare-sort alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
 0
)
(declare-sort vstd!seq.Seq<u8.>. 0)
(declare-datatypes ((core!option.Option. 0) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
   0
  ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
   0
  ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
   0
  ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. 0) (
   IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint. 0
  ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering. 0) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
   0
  ) (tuple%0. 0)
 ) (((core!option.Option./None) (core!option.Option./Some (core!option.Option./Some/?0
     Poly
   ))
  ) ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint
    (IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint/?id
     vstd!seq.Seq<u8.>.
   ))
  ) ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec
    (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/?v
     Poly
   ))
  ) ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap
    (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/?keys
     IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/?vals
     alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/?m
     Poly
   ))
  ) ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap
    (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/?lows
     IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/?m
     Poly
   ))
  ) ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint (
     IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/?id
     alloc!vec.Vec<u8./alloc!alloc.Global.>.
   ))
  ) ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Less) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Equal)
   (IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Greater)
  ) ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator
    (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/?k
     core!option.Option.
   ))
  ) ((tuple%0./tuple%0))
))
(declare-fun core!option.Option./Some/0 (Dcr Type core!option.Option.) Poly)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint/id
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.) vstd!seq.Seq<u8.>.
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.)
 Poly
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.)
 IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/vals
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.)
 alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.)
 Poly
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.) IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.) Poly
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/id
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.) alloc!vec.Vec<u8./alloc!alloc.Global.>.
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.) core!option.Option.
)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-fun TYPE%core!option.Option. (Dcr Type) Type)
(declare-fun TYPE%alloc!vec.Vec. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-const TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
 Type
)
(declare-fun TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
 (Dcr Type) Type
)
(declare-fun TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
 (Dcr Type) Type
)
(declare-fun TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
 (Dcr Type) Type
)
(declare-const TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
 Type
)
(declare-const TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
 Type
)
(declare-fun TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
 (Dcr Type) Type
)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (alloc!vec.Vec<u8./alloc!alloc.Global.>.)
 Poly
)
(declare-fun %Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (Poly) alloc!vec.Vec<u8./alloc!alloc.Global.>.)
(declare-fun Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
 (alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.)
 Poly
)
(declare-fun %Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
 (Poly) alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
)
(declare-fun Poly%vstd!seq.Seq<u8.>. (vstd!seq.Seq<u8.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<u8.>. (Poly) vstd!seq.Seq<u8.>.)
(declare-fun Poly%core!option.Option. (core!option.Option.) Poly)
(declare-fun %Poly%core!option.Option. (Poly) core!option.Option.)
(declare-fun Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.) Poly
)
(declare-fun %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
)
(declare-fun Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.)
 Poly
)
(declare-fun %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
)
(declare-fun Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.)
 Poly
)
(declare-fun %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
)
(declare-fun Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.) Poly
)
(declare-fun %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
)
(declare-fun Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.) Poly
)
(declare-fun %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
)
(declare-fun Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.) Poly
)
(declare-fun %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
)
(declare-fun Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.) Poly
)
(declare-fun %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x alloc!vec.Vec<u8./alloc!alloc.Global.>.)) (!
   (= x (%Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
      x
   )))
   :pattern ((Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. x))
   :qid internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_box_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.))
    (= x (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (%Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
       x
   ))))
   :pattern ((has_type x (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.)))
   :qid internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_unbox_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!vec.Vec<u8./alloc!alloc.Global.>.)) (!
   (has_type (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. x) (TYPE%alloc!vec.Vec. $ (
      UINT 8
     ) $ TYPE%alloc!alloc.Global.
   ))
   :pattern ((has_type (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. x) (TYPE%alloc!vec.Vec.
      $ (UINT 8) $ TYPE%alloc!alloc.Global.
   )))
   :qid internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_has_type_always_definition
   :skolemid skolem_internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_has_type_always_definition
)))
(assert
 (forall ((x alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.))
  (!
   (= x (%Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
     (Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
      x
   )))
   :pattern ((Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
     x
   ))
   :qid internal_alloc__vec__Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>_box_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%alloc!vec.Vec. $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
      $ TYPE%alloc!alloc.Global.
    ))
    (= x (Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
      (%Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
       x
   ))))
   :pattern ((has_type x (TYPE%alloc!vec.Vec. $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
      $ TYPE%alloc!alloc.Global.
   )))
   :qid internal_alloc__vec__Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>_unbox_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.))
  (!
   (has_type (Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
     x
    ) (TYPE%alloc!vec.Vec. $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
     $ TYPE%alloc!alloc.Global.
   ))
   :pattern ((has_type (Poly%alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.
      x
     ) (TYPE%alloc!vec.Vec. $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
      $ TYPE%alloc!alloc.Global.
   )))
   :qid internal_alloc__vec__Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>_has_type_always_definition
   :skolemid skolem_internal_alloc__vec__Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (= x (%Poly%vstd!seq.Seq<u8.>. (Poly%vstd!seq.Seq<u8.>. x)))
   :pattern ((Poly%vstd!seq.Seq<u8.>. x))
   :qid internal_vstd__seq__Seq<u8.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (UINT 8)))
    (= x (Poly%vstd!seq.Seq<u8.>. (%Poly%vstd!seq.Seq<u8.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8)))
   :pattern ((has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_has_type_always_definition
)))
(assert
 (forall ((x core!option.Option.)) (!
   (= x (%Poly%core!option.Option. (Poly%core!option.Option. x)))
   :pattern ((Poly%core!option.Option. x))
   :qid internal_core__option__Option_box_axiom_definition
   :skolemid skolem_internal_core__option__Option_box_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (= x (Poly%core!option.Option. (%Poly%core!option.Option. x)))
   )
   :pattern ((has_type x (TYPE%core!option.Option. V&. V&)))
   :qid internal_core__option__Option_unbox_axiom_definition
   :skolemid skolem_internal_core__option__Option_unbox_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type)) (!
   (has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
     V&. V&
   ))
   :pattern ((has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./None_constructor_definition
   :skolemid skolem_internal_core!option.Option./None_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (_0! Poly)) (!
   (=>
    (has_type _0! V&)
    (has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :pattern ((has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./Some_constructor_definition
   :skolemid skolem_internal_core!option.Option./Some_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (= (core!option.Option./Some/0 V&. V& x) (core!option.Option./Some/?0 x))
   )
   :pattern ((core!option.Option./Some/0 V&. V& x))
   :qid internal_core!option.Option./Some/0_accessor_definition
   :skolemid skolem_internal_core!option.Option./Some/0_accessor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (has_type (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) V&)
   )
   :pattern ((core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) (has_type
     x (TYPE%core!option.Option. V&. V&)
   ))
   :qid internal_core!option.Option./Some/0_invariant_definition
   :skolemid skolem_internal_core!option.Option./Some/0_invariant_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (height_lt (height (core!option.Option./Some/0 V&. V& x)) (height (Poly%core!option.Option.
       x
   ))))
   :pattern ((height (core!option.Option./Some/0 V&. V& x)))
   :qid prelude_datatype_height_core!option.Option./Some/0
   :skolemid skolem_prelude_datatype_height_core!option.Option./Some/0
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./None (%Poly%core!option.Option. x))
     (is-core!option.Option./None (%Poly%core!option.Option. y))
    )
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./None_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./None_ext_equal_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./Some (%Poly%core!option.Option. x))
     (is-core!option.Option./Some (%Poly%core!option.Option. y))
     (ext_eq deep V& (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x))
      (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. y))
    ))
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./Some_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./Some_ext_equal_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.))
  (!
   (= x (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
      x
   )))
   :pattern ((Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__AbstractEndPoint_box_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__AbstractEndPoint_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.)
    (= x (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
       x
   ))))
   :pattern ((has_type x TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__AbstractEndPoint_unbox_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__AbstractEndPoint_unbox_axiom_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint/id
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint/?id
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint/id
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint/id_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint/id_accessor_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.))
  (!
   (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
     x
    ) TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
   )
   :pattern ((has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
      x
     ) TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__AbstractEndPoint_has_type_always_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__AbstractEndPoint_has_type_always_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.))
  (!
   (= x (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      x
   )))
   :pattern ((Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedVec_box_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedVec_box_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      K&. K&
    ))
    (= x (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
       x
   ))))
   :pattern ((has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedVec_unbox_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedVec_unbox_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (_v! Poly)) (!
   (=>
    (has_type _v! (TYPE%alloc!vec.Vec. K&. K& $ TYPE%alloc!alloc.Global.))
    (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec
       _v!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      K&. K&
   )))
   :pattern ((has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec
       _v!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec_constructor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec_constructor_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/?v
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v_accessor_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      K&. K&
    ))
    (has_type (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
       x
      )
     ) (TYPE%alloc!vec.Vec. K&. K& $ TYPE%alloc!alloc.Global.)
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
     (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      x
     )
    ) (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v_invariant_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v_invariant_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec
     x
    )
    (height_lt (height (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
       x
      )
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
       x
   ))))
   :pattern ((height (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
      x
   )))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec./StrictlyOrderedVec/v
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.))
  (!
   (= x (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      x
   )))
   :pattern ((Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedMap_box_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedMap_box_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
    ))
    (= x (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       x
   ))))
   :pattern ((has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedMap_unbox_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__StrictlyOrderedMap_unbox_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (_keys! IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.)
   (_vals! alloc!vec.Vec<IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./alloc!alloc.Global.>.)
   (_m! Poly)
  ) (!
   (=>
    (and
     (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
       _keys!
      ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
       K&. K&
     ))
     (has_type _m! (TYPE%vstd!map.Map. K&. K& $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.))
    )
    (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap
       _keys! _vals! _m!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
   )))
   :pattern ((has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap
       _keys! _vals! _m!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap_constructor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap_constructor_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/?keys
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys_accessor_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
    ))
    (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
       (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
        x
      ))
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      K&. K&
   )))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
     (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      x
     )
    ) (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys_invariant_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys_invariant_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/vals
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/?vals
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/vals
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/vals_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/vals_accessor_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/?m
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m_accessor_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
    ))
    (has_type (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       x
      )
     ) (TYPE%vstd!map.Map. K&. K& $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.)
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
     (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      x
     )
    ) (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m_invariant_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m_invariant_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap
     x
    )
    (height_lt (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
       (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
        x
      ))
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       x
   ))))
   :pattern ((height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedVec.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
       x
   ))))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/keys
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap
     x
    )
    (height_lt (height (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
       x
      )
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       x
   ))))
   :pattern ((height (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
      x
   )))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap
     x
    )
    (height_lt (height (fun_from_recursive_field (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
        x
      ))
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       x
   ))))
   :pattern ((height (fun_from_recursive_field (IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
       x
   ))))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap./StrictlyOrderedMap/m
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.))
  (!
   (= x (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. x)
   ))
   :pattern ((Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__DelegationMap_box_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__DelegationMap_box_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
    ))
    (= x (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. x)
   )))
   :pattern ((has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__DelegationMap_unbox_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__DelegationMap_unbox_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (_lows! IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.)
   (_m! Poly)
  ) (!
   (=>
    (and
     (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       _lows!
      ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       K&. K&
     ))
     (has_type _m! (TYPE%vstd!map.Map. K&. K& $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.))
    )
    (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap
       _lows! _m!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
   )))
   :pattern ((has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap
       _lows! _m!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap_constructor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap_constructor_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/?lows
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows_accessor_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
    ))
    (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
       (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. x)
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      K&. K&
   )))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
     (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. x)
    ) (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows_invariant_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows_invariant_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/?m
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m_accessor_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
    ))
    (has_type (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. x)
     ) (TYPE%vstd!map.Map. K&. K& $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.)
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
     (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. x)
    ) (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m_invariant_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m_invariant_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap
     x
    )
    (height_lt (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
       (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
        x
      ))
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
       x
   ))))
   :pattern ((height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!StrictlyOrderedMap.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
       x
   ))))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/lows
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap
     x
    )
    (height_lt (height (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
       x
      )
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
       x
   ))))
   :pattern ((height (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
      x
   )))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap
     x
    )
    (height_lt (height (fun_from_recursive_field (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
        x
      ))
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
       x
   ))))
   :pattern ((height (fun_from_recursive_field (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
       x
   ))))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.))
  (!
   (= x (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint. (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
      x
   )))
   :pattern ((Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__EndPoint_box_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__EndPoint_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.)
    (= x (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint. (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
       x
   ))))
   :pattern ((has_type x TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__EndPoint_unbox_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__EndPoint_unbox_axiom_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/id
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/?id
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/id
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/id_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/id_accessor_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.))
  (!
   (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
     x
    ) TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
   )
   :pattern ((has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
      x
     ) TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__EndPoint_has_type_always_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__EndPoint_has_type_always_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.))
  (!
   (= x (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering. (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
      x
   )))
   :pattern ((Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__Ordering_box_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__Ordering_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.)
    (= x (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering. (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
       x
   ))))
   :pattern ((has_type x TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__Ordering_unbox_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__Ordering_unbox_axiom_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.))
  (!
   (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
     x
    ) TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
   )
   :pattern ((has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
      x
     ) TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__Ordering_has_type_always_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__Ordering_has_type_always_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.))
  (!
   (= x (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. x)
   ))
   :pattern ((Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyIterator_box_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyIterator_box_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      K&. K&
    ))
    (= x (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. x)
   )))
   :pattern ((has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyIterator_unbox_axiom_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyIterator_unbox_axiom_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (_k! core!option.Option.)) (!
   (=>
    (has_type (Poly%core!option.Option. _k!) (TYPE%core!option.Option. K&. K&))
    (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator
       _k!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. K&.
      K&
   )))
   :pattern ((has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator
       _k!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. K&.
      K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator_constructor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator_constructor_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.))
  (!
   (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
     x
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/?k
     x
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
     x
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k_accessor_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k_accessor_definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      K&. K&
    ))
    (has_type (Poly%core!option.Option. (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
       (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. x)
      )
     ) (TYPE%core!option.Option. K&. K&)
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
     (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. x)
    ) (has_type x (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      K&. K&
   )))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k_invariant_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k_invariant_definition
)))
(assert
 (forall ((x IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.))
  (!
   (=>
    (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator
     x
    )
    (height_lt (height (Poly%core!option.Option. (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
        x
      ))
     ) (height (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
       x
   ))))
   :pattern ((height (Poly%core!option.Option. (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
       x
   ))))
   :qid prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
   :skolemid skolem_prelude_datatype_height_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&)
    (and
     (sized Self%&.)
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait. Self%&.
     Self%&
    )
    (sized Self%&.)
   )
   :pattern ((tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.
     Self%&. Self%&
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait_trait_type_bounds_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!VerusClone. Self%&.
     Self%&
    )
    (sized Self%&.)
   )
   :pattern ((tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!VerusClone.
     Self%&. Self%&
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__VerusClone_trait_type_bounds_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent__VerusClone_trait_type_bounds_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) (TYPE%vstd!seq.Seq.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) (TYPE%core!option.Option.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 8)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 8)) (UINT 8))
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!std_specs.vec.spec_vec_len.? (Dcr Type Dcr Type Poly) Int)
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.get_Some_0%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_None.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_None%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
 (Dcr Type Poly Poly) Poly
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec%default%.?
 (Dcr Type Poly Poly) Poly
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.?
 (Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.?
 (Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt.?
 (Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne.?
 (Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.?
 (Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.?
 (Dcr Type Poly Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.?
 (Dcr Type Poly Poly Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.?
 (Dcr Type Poly) Poly
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.?
 (Dcr Type Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view.?
 (Poly) IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.?
 (Dcr Type Poly Poly Poly Poly) Bool
)
(declare-fun IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.?
 (Dcr Type Poly Poly) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%2
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%3
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
   (=>
    (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
    (uInv SZ (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   )
   :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   :qid internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_vstd__view__impl&__8_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__8_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_spec_len.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
     (=>
      (and
       (and
        (sized T&.)
        (sized A&.)
       )
       (tr_bound%core!alloc.Allocator. A&. A&)
      )
      (= (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!) (vstd!seq.Seq.len.? T&. T&
        (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v!)
    ))))
    :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
    :qid user_vstd__std_specs__vec__axiom_spec_len_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_spec_len_0
))))
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (vec! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type vec! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
      (has_type i! INT)
     )
     (=>
      (sized T&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? T&. T& $ TYPE%alloc!alloc.Global. vec!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
            T&. T& $ TYPE%alloc!alloc.Global.
           ) vec!
          ) i!
    ))))))
    :pattern ((has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
     (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
        TYPE%alloc!alloc.Global.
       ) vec!
      ) i!
    ))
    :qid user_vstd__std_specs__vec__axiom_vec_has_resolved_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_has_resolved_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
  (forall ((T&. Dcr) (T& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
     (=>
      (sized T&.)
      (height_lt (height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
         v!
        )
       ) (height v!)
    )))
    :pattern ((height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
       v!
    )))
    :qid user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? Self%&. Self%& T&.
      T& self!
     ) T&
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? Self%&. Self%& T&.
     T& self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.get_Some_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.get_Some_0.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.is_None.? Self%&. Self%& T&. T&
      self!
     ) BOOL
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_None.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.is_None.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.is_None.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (other! Poly)) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type other! Self%&)
    )
    (has_type (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
      Self%&. Self%& self! other!
     ) TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
     Self%&. Self%& self! other!
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?_pre_post_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.)
  (forall ((self! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? self!)
     (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Equal (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
       self!
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.?
      self!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.eq.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.eq.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.)
  (forall ((self! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? self!)
     (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Less (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering.
       self!
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.?
      self!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.lt.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.lt.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt.)
  (forall ((self! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt.? self!)
     (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Greater (
       %Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering. self!
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt.?
      self!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.gt.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.gt.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne.)
  (forall ((self! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne.? self!)
     (not (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Equal
       (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering. self!)
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne.?
      self!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.ne.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.ne.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.)
  (forall ((self! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.? self!)
     (not (is-IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering./Greater
       (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!Ordering. self!)
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.?
      self!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.le.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__0.le.?_definition
))))
(declare-fun ens%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_properties.
 (Dcr Type) Bool
)
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (= (ens%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_properties.
     Self%&. Self%&
    ) (and
     (forall ((a$ Poly) (b$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
        )
        (= (= a$ b$) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.?
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.? Self%&.
           Self%& a$ b$
       ))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
         Self%&. Self%& a$ b$
       ))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_0
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_0
     ))
     (forall ((a$ Poly)) (!
       (=>
        (has_type a$ Self%&)
        (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
          Self%&. Self%& a$ a$
       )))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
         Self%&. Self%& a$ a$
       ))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_1
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_1
     ))
     (forall ((a$ Poly) (b$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
        )
        (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& a$ b$
          )
         ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& b$ a$
       ))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
         Self%&. Self%& a$ b$
       ))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_2
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_2
     ))
     (forall ((a$ Poly) (b$ Poly) (c$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
         (has_type c$ Self%&)
        )
        (=>
         (and
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& a$ b$
          ))
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& b$ c$
         )))
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& a$ c$
       ))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.?
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.? Self%&.
          Self%& a$ b$
         )
        ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.eq.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
          Self%&. Self%& b$ c$
       )))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_3
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_3
     ))
     (forall ((a$ Poly) (b$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
        )
        (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& a$ b$
          )
         ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.gt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& b$ a$
       ))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.?
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.? Self%&.
          Self%& a$ b$
       )))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_4
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_4
     ))
     (forall ((a$ Poly) (b$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
        )
        (=>
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.ne.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& a$ b$
         ))
         (or
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& a$ b$
          ))
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& b$ a$
       )))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
         Self%&. Self%& a$ b$
       ))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
         Self%&. Self%& b$ a$
       ))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_5
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_5
     ))
     (forall ((a$ Poly) (b$ Poly) (c$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
         (has_type c$ Self%&)
        )
        (=>
         (and
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& a$ b$
          ))
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& b$ c$
         )))
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& a$ c$
       ))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.?
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.? Self%&.
          Self%& a$ b$
         )
        ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
          Self%&. Self%& b$ c$
       )))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_6
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_6
     ))
     (forall ((a$ Poly) (b$ Poly) (c$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
         (has_type c$ Self%&)
        )
        (=>
         (and
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& a$ b$
          ))
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& b$ c$
         )))
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& a$ c$
       ))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.?
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.? Self%&.
          Self%& a$ b$
         )
        ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
          Self%&. Self%& b$ c$
       )))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_7
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_7
     ))
     (forall ((a$ Poly) (b$ Poly) (c$ Poly)) (!
       (=>
        (and
         (has_type a$ Self%&)
         (has_type b$ Self%&)
         (has_type c$ Self%&)
        )
        (=>
         (and
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& a$ b$
          ))
          (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
            Self%&. Self%& b$ c$
         )))
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
           Self%&. Self%& a$ c$
       ))))
       :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.le.?
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.? Self%&.
          Self%& a$ b$
         )
        ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
          Self%&. Self%& b$ c$
       )))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_8
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__KeyTrait__cmp_properties_8
   ))))
   :pattern ((ens%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_properties.
     Self%&. Self%&
   ))
   :qid internal_ens__IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_properties._definition
   :skolemid skolem_internal_ens__IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_properties._definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.get_Some_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.get_Some_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. self!))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.get_Some_0.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.get_Some_0.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.get_Some_0.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.is_None.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.is_None.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.is_None.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (B (is-core!option.Option./None (%Poly%core!option.Option. self!)))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_None.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.is_None.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.is_None.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%14.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%14.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!) self!)
    )
    :pattern ((vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!))
    :qid internal_vstd!view.impl&__14.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__14.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%20.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%20.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 8) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 8) self!))
    :qid internal_vstd!view.impl&__20.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__20.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option. T&.
      T&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option.
      T&. T&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__option__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__option__impl&__0_trait_impl_definition
)))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.)
  (forall ((K&. Dcr) (K& Type) (self! Poly) (other! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.? K&.
      K& self! other!
     ) (or
      (and
       (not (is-core!option.Option./None (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
          (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. self!)
       )))
       (is-core!option.Option./None (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
         (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. other!)
      )))
      (and
       (and
        (not (is-core!option.Option./None (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
           (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. self!)
        )))
        (not (is-core!option.Option./None (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
           (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. other!)
       ))))
       (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%0.lt.? (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_spec.?
         K&. K& (core!option.Option./Some/0 K&. K& (%Poly%core!option.Option. (Poly%core!option.Option.
            (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
             (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. self!)
          )))
         ) (core!option.Option./Some/0 K&. K& (%Poly%core!option.Option. (Poly%core!option.Option.
            (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator/k
             (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. other!)
    )))))))))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.?
      K&. K& self! other!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.lt_spec.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.lt_spec.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.)
  (forall ((K&. Dcr) (K& Type) (lhs! Poly) (ki! Poly) (rhs! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.? K&.
      K& lhs! ki! rhs!
     ) (and
      (not (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.?
        K&. K& ki! lhs!
      ))
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.? K&.
       K& ki! rhs!
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.?
      K&. K& lhs! ki! rhs!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__1.between.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__1.between.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.)
  (forall ((K&. Dcr) (K& Type) (self! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.? K&. K&
      self!
     ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap./DelegationMap/m
      (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap. self!)
    ))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.?
      K&. K& self!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.view.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.view.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      K&. K&
    ))
    (has_type (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.?
      K&. K& self!
     ) (TYPE%vstd!map.Map. K&. K& $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.)
   ))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.?
     K&. K& self!
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.view.?_pre_post_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.)
  (forall ((K&. Dcr) (K& Type) (k! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.? K&.
      K& k!
     ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator./KeyIterator
      (%Poly%core!option.Option. (Poly%core!option.Option. (core!option.Option./Some k!)))
    ))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.?
      K&. K& k!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.new_spec.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.new_spec.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (k! Poly)) (!
   (=>
    (has_type k! K&)
    (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
      (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.? K&.
       K& k!
      )
     ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. K&.
      K&
   )))
   :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.?
     K&. K& k!
   ))
   :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.new_spec.?_pre_post_definition
   :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.new_spec.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view.)
  (forall ((self! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view.? self!)
     (IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint./AbstractEndPoint
      (%Poly%vstd!seq.Seq<u8.>. (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ (UINT 8) $
         TYPE%alloc!alloc.Global.
        ) (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint./EndPoint/id
          (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint. self!)
    ))))))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view.?
      self!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__3.view.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__3.view.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.)
  (forall ((K&. Dcr) (K& Type) (self! Poly) (lo! Poly) (hi! Poly) (dst! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.?
      K&. K& self! lo! hi! dst!
     ) (forall ((k$ Poly)) (!
       (=>
        (has_type k$ K&)
        (=>
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%1.between.? K&.
          K& lo! (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
           (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.new_spec.? K&.
            K& k$
           )
          ) hi!
         )
         (= (%Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
           (vstd!map.impl&%0.index.? K&. K& $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
            (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.? K&. K&
             self!
            ) k$
           )
          ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%3.view.? dst!)
       )))
       :pattern ((vstd!map.impl&%0.index.? K&. K& $ TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!AbstractEndPoint.
         (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.view.? K&. K&
          self!
         ) k$
       ))
       :qid user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__DelegationMap__range_consistent_0
       :skolemid skolem_user_IR__delegation_map_v__impl4__empty_key_range_is_consistent__DelegationMap__range_consistent_0
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.?
      K&. K& self! lo! hi! dst!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.range_consistent.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.range_consistent.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.)
)
(assert
 (=>
  (fuel_bool fuel%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.)
  (forall ((K&. Dcr) (K& Type) (self! Poly) (other! Poly)) (!
    (= (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.? K&.
      K& self! other!
     ) (not (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.lt_spec.?
       K&. K& self! other!
    )))
    :pattern ((IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.?
      K&. K& self! other!
    ))
    :qid internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.geq_spec.?_definition
    :skolemid skolem_internal_IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__4.geq_spec.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_vstd__view__impl&__14_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__14_trait_impl_definition
)))
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 8))
)
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(declare-fun req%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.empty_key_range_is_consistent.
 (Dcr Type IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
  IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
  IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
 ) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (self! IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.)
   (lo! IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.) (hi!
    IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
   ) (id! IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.)
  ) (!
   (= (req%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.empty_key_range_is_consistent.
     K&. K& self! lo! hi! id!
    ) (=>
     %%global_location_label%%4
     (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.? K&.
      K& (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. lo!)
      (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. hi!)
   )))
   :pattern ((req%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.empty_key_range_is_consistent.
     K&. K& self! lo! hi! id!
   ))
   :qid internal_req__IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.empty_key_range_is_consistent._definition
   :skolemid skolem_internal_req__IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.empty_key_range_is_consistent._definition
)))
(declare-fun ens%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.empty_key_range_is_consistent.
 (Dcr Type IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
  IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
  IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.
 ) Bool
)
(assert
 (forall ((K&. Dcr) (K& Type) (self! IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.)
   (lo! IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.) (hi!
    IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
   ) (id! IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.)
  ) (!
   (= (ens%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.empty_key_range_is_consistent.
     K&. K& self! lo! hi! id!
    ) (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.?
     K&. K& (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      self!
     ) (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. lo!)
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. hi!)
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint. id!)
   ))
   :pattern ((ens%IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.empty_key_range_is_consistent.
     K&. K& self! lo! hi! id!
   ))
   :qid internal_ens__IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.empty_key_range_is_consistent._definition
   :skolemid skolem_internal_ens__IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&__2.empty_key_range_is_consistent._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const K&. Dcr)
(declare-const K& Type)
(declare-const self! IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.)
(declare-const lo! IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.)
(declare-const hi! IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.)
(declare-const id! IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint.)
(assert
 fuel_defaults
)
(assert
 (sized K&.)
)
(assert
 (tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait. K&.
  K&
))
(assert
 (tr_bound%IR__delegation_map_v__impl4__empty_key_range_is_consistent!VerusClone. K&.
  K&
))
(assert
 (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
   self!
  ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
   K&. K&
)))
(assert
 (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
   lo!
  ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. K&.
   K&
)))
(assert
 (has_type (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator.
   hi!
  ) (TYPE%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. K&.
   K&
)))
(assert
 (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%4.geq_spec.? K&.
  K& (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. lo!)
  (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. hi!)
))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (ens%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyTrait.cmp_properties.
    K&. K&
   )
   (=>
    %%location_label%%0
    (IR__delegation_map_v__impl4__empty_key_range_is_consistent!impl&%2.range_consistent.?
     K&. K& (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!DelegationMap.
      self!
     ) (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. lo!)
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!KeyIterator. hi!)
     (Poly%IR__delegation_map_v__impl4__empty_key_range_is_consistent!EndPoint. id!)
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
