(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.axiom_map_decreases_to_entry. FuelId)
(declare-const fuel%vstd!map.lemma_map_insert_domain. FuelId)
(declare-const fuel%vstd!map.lemma_map_insert_same. FuelId)
(declare-const fuel%vstd!map.axiom_map_insert_different. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!pervasive.strictly_cloned. FuelId)
(declare-const fuel%vstd!pervasive.cloned. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index_range_from. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index_range_to. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index_range. FuelId)
(declare-const fuel%vstd!seq.impl&%2.take. FuelId)
(declare-const fuel%vstd!seq.impl&%2.skip. FuelId)
(declare-const fuel%vstd!seq.Seq.last. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_two_subranges_index. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.drop_last. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.fold_left. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.Set.subset_of. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_same. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_different. FuelId)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write. FuelId)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq. FuelId)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.lemma_write_seq.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G. FuelId)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT. FuelId)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem. FuelId)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!lemma_core_mem_pml4.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!function.axiom_fn_mut_call_requires. fuel%vstd!function.axiom_fn_mut_call_ensures.
  fuel%vstd!iset.lemma_iset_ext_equal. fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index.
  fuel%vstd!map.axiom_map_index_decreases. fuel%vstd!map.axiom_map_decreases_to_entry.
  fuel%vstd!map.lemma_map_insert_domain. fuel%vstd!map.lemma_map_insert_same. fuel%vstd!map.axiom_map_insert_different.
  fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep. fuel%vstd!pervasive.strictly_cloned.
  fuel%vstd!pervasive.cloned. fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.impl&%2.spec_index_range_from.
  fuel%vstd!seq.impl&%2.spec_index_range_to. fuel%vstd!seq.impl&%2.spec_index_range.
  fuel%vstd!seq.impl&%2.take. fuel%vstd!seq.impl&%2.skip. fuel%vstd!seq.Seq.last. fuel%vstd!seq.lemma_seq_index_decreases.
  fuel%vstd!seq.lemma_seq_subrange_decreases. fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep.
  fuel%vstd!seq.lemma_seq_subrange_len. fuel%vstd!seq.lemma_seq_subrange_index. fuel%vstd!seq.lemma_seq_two_subranges_index.
  fuel%vstd!seq_lib.impl&%0.drop_last. fuel%vstd!seq_lib.impl&%0.fold_left. fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.
  fuel%vstd!set.Set.contains. fuel%vstd!set.Set.subset_of. fuel%vstd!set.axiom_set_ext_equal.
  fuel%vstd!set.axiom_set_ext_equal_deep. fuel%vstd!set.axiom_set_decreases_to_member.
  fuel%vstd!set.lemma_set_insert_same. fuel%vstd!set.lemma_set_insert_different. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.lemma_write_seq.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.
  fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem. fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!lemma_core_mem_pml4.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.axiom_map_decreases_to_entry.)
   (fuel_bool_default fuel%vstd!map.lemma_map_insert_domain.)
   (fuel_bool_default fuel%vstd!map.lemma_map_insert_same.)
   (fuel_bool_default fuel%vstd!map.axiom_map_insert_different.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_two_subranges_index.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_same.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_different.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%core!clone.Clone. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Copy. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%verus_builtin!Integer. (Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-sort vstd!map.Map<usize./usize.>. 0)
(declare-sort vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
 0
)
(declare-sort vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
 0
)
(declare-sort vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
 0
)
(declare-sort vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
 0
)
(declare-sort vstd!seq.Seq<u8.>. 0)
(declare-sort vstd!seq.Seq<tuple%2<usize./usize.>.>. 0)
(declare-sort vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
 0
)
(declare-sort vstd!set.Set<usize.>. 0)
(declare-sort vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>. 0)
(declare-sort vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>. 0)
(declare-datatypes ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. 0) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
   0
  ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. 0) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
   0
  ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. 0) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.
   0
  ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. 0) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.
   0
  ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. 0) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
   0
  ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. 0) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.
   0
  ) (tuple%0. 0) (tuple%1. 0) (tuple%2. 0)
 ) (((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/?core
     NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/?tso vstd!set.Set<usize.>.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/?nonpos vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/?mem
     vstd!map.Map<usize./usize.>.
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/?pml4 Int)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?addr
     Int
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?P Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?RW
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?US Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?PWT
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?PCD Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?XD
     Bool
    )
   ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?addr
     Int
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?P Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?RW
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?US Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?PWT
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?PCD Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?G
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?PAT Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?XD
     Bool
    )
   ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Invalid)
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/?node_id
     Int
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/?core_id Int)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/?base
     Int
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/?size Int)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/?is_writable
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/?is_supervisor Bool) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/?disable_execute
     Bool
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/?frame
     NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/?flags NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity./Mapping) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity./Unmapping))
  ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/?vaddr
     Int
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/?path vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/?complete Bool)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?node_count
     Int
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?core_count Int)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?range_ptmem tuple%2.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?range_mem tuple%2.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?phys_mem_size Int)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?happy
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?phys_mem vstd!seq.Seq<u8.>.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?pt_mem NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?tlbs vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?walks vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?sbuf vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?writes NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?polarity NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?hist NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/?pending_maps
     vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
    ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/?pending_unmaps vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.)
   )
  ) ((tuple%0./tuple%0)) ((tuple%1./tuple%1 (tuple%1./tuple%1/?0 Poly))) ((tuple%2./tuple%2
    (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1 Poly)
))))
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/tso (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
 vstd!set.Set<usize.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/nonpos (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
 vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
 vstd!map.Map<usize./usize.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
 Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/P (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/RW (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/US (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PWT (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PCD (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/XD (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/P (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/RW (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/US (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PWT (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PCD (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/G (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PAT (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/XD (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
 Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
 Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base (
  NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
 ) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size (
  NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
 ) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_writable (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_supervisor
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/disable_execute
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/flags (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
 Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/path (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
 vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/complete (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.) tuple%2.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.) tuple%2.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/happy (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/phys_mem (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 vstd!seq.Seq<u8.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/tlbs (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/walks (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/sbuf (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/polarity (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/hist (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_maps
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.) vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_unmaps
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.) vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
)
(declare-fun tuple%1./tuple%1/0 (tuple%1.) Poly)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-fun TYPE%fun%2. (Dcr Type Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. Type)
(declare-fun TYPE%tuple%1. (Dcr Type) Type)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-fun FNDEF%core!clone.Clone.clone. (Dcr Type) Type)
(declare-fun Poly%fun%2. (%%Function%%) Poly)
(declare-fun %Poly%fun%2. (Poly) %%Function%%)
(declare-fun Poly%vstd!map.Map<usize./usize.>. (vstd!map.Map<usize./usize.>.) Poly)
(declare-fun %Poly%vstd!map.Map<usize./usize.>. (Poly) vstd!map.Map<usize./usize.>.)
(declare-fun Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
 (vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.) Poly
)
(declare-fun %Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
 (Poly) vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
)
(declare-fun Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
 (vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
 (Poly) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
)
(declare-fun Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
 (vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
 (Poly) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
)
(declare-fun Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
 (vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
 (Poly) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
)
(declare-fun Poly%vstd!seq.Seq<u8.>. (vstd!seq.Seq<u8.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<u8.>. (Poly) vstd!seq.Seq<u8.>.)
(declare-fun Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (vstd!seq.Seq<tuple%2<usize./usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (Poly) vstd!seq.Seq<tuple%2<usize./usize.>.>.)
(declare-fun Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
 (vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
 (Poly) vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
)
(declare-fun Poly%vstd!set.Set<usize.>. (vstd!set.Set<usize.>.) Poly)
(declare-fun %Poly%vstd!set.Set<usize.>. (Poly) vstd!set.Set<usize.>.)
(declare-fun Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>. (
  vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.
 ) Poly
)
(declare-fun %Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.
 (Poly) vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.
)
(declare-fun Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>. (
  vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.
 ) Poly
)
(declare-fun %Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.
 (Poly) vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)
 Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. (Poly) NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%1. (tuple%1.) Poly)
(declare-fun %Poly%tuple%1. (Poly) tuple%1.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%2. (Poly%fun%2. x)))
   :pattern ((Poly%fun%2. x))
   :qid internal_crate__fun__2_box_axiom_definition
   :skolemid skolem_internal_crate__fun__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (= x (Poly%fun%2. (%Poly%fun%2. x)))
   )
   :pattern ((has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&)))
   :qid internal_crate__fun__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__2_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    %%Function%%
   )
  ) (!
   (=>
    (forall ((T%0 Poly) (T%1 Poly)) (!
      (=>
       (and
        (has_type T%0 T%0&)
        (has_type T%1 T%1&)
       )
       (has_type (%%apply%%0 x T%0 T%1) T%2&)
      )
      :pattern ((has_type (%%apply%%0 x T%0 T%1) T%2&))
      :qid internal_crate__fun__2_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__2_constructor_inner_definition
    ))
    (has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
   )
   :pattern ((has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :qid internal_crate__fun__2_constructor_definition
   :skolemid skolem_internal_crate__fun__2_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (has_type (%%apply%%0 x T%0 T%1) T%2&)
   )
   :pattern ((%%apply%%0 x T%0 T%1) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&.
      T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_apply_definition
   :skolemid skolem_internal_crate__fun__2_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (height_lt (height (%%apply%%0 x T%0 T%1)) (height (fun_from_recursive_field (Poly%fun%2.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0 T%1)) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&.
      T%0& T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_height_apply_definition
   :skolemid skolem_internal_crate__fun__2_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (deep
    Bool
   ) (x Poly) (y Poly)
  ) (!
   (=>
    (and
     (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type y (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (forall ((T%0 Poly) (T%1 Poly)) (!
       (=>
        (and
         (has_type T%0 T%0&)
         (has_type T%1 T%1&)
        )
        (ext_eq deep T%2& (%%apply%%0 (%Poly%fun%2. x) T%0 T%1) (%%apply%%0 (%Poly%fun%2. y)
          T%0 T%1
       )))
       :pattern ((ext_eq deep T%2& (%%apply%%0 (%Poly%fun%2. x) T%0 T%1) (%%apply%%0 (%Poly%fun%2.
           y
          ) T%0 T%1
       )))
       :qid internal_crate__fun__2_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__2_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y))
   :qid internal_crate__fun__2_ext_equal_definition
   :skolemid skolem_internal_crate__fun__2_ext_equal_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./usize.>.)) (!
   (= x (%Poly%vstd!map.Map<usize./usize.>. (Poly%vstd!map.Map<usize./usize.>. x)))
   :pattern ((Poly%vstd!map.Map<usize./usize.>. x))
   :qid internal_vstd__map__Map<usize./usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ USIZE))
    (= x (Poly%vstd!map.Map<usize./usize.>. (%Poly%vstd!map.Map<usize./usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ USIZE)))
   :qid internal_vstd__map__Map<usize./usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./usize.>.)) (!
   (has_type (Poly%vstd!map.Map<usize./usize.>. x) (TYPE%vstd!map.Map. $ USIZE $ USIZE))
   :pattern ((has_type (Poly%vstd!map.Map<usize./usize.>. x) (TYPE%vstd!map.Map. $ USIZE
      $ USIZE
   )))
   :qid internal_vstd__map__Map<usize./usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>. (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.))
    (= x (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>. (%Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)))
   :qid internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
   ))
   :qid internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
     (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
     x
   ))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
    ))
    (= x (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
      (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
     x
    ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. $ (TYPE%vstd!map.Map.
      $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.
   )))
   :pattern ((has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.
      x
     ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. $ (TYPE%vstd!map.Map.
       $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.
   ))))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
     (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
     x
   ))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
    ))
    (= x (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
      (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
     x
    ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. $ (TYPE%vstd!seq.Seq.
      (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   )))
   :pattern ((has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
      x
     ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. $ (TYPE%vstd!seq.Seq.
       (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   ))))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
     (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
     x
   ))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      $ (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
    ))
    (= x (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
      (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      $ (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
     x
    ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. $ (TYPE%vstd!set.Set.
      $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
   )))
   :pattern ((has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.
      x
     ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. $ (TYPE%vstd!set.Set.
       $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
   ))))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (= x (%Poly%vstd!seq.Seq<u8.>. (Poly%vstd!seq.Seq<u8.>. x)))
   :pattern ((Poly%vstd!seq.Seq<u8.>. x))
   :qid internal_vstd__seq__Seq<u8.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (UINT 8)))
    (= x (Poly%vstd!seq.Seq<u8.>. (%Poly%vstd!seq.Seq<u8.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8)))
   :pattern ((has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./usize.>.>.)) (!
   (= x (%Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. x))
   :qid internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)))
    (= x (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (%Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))))
   :qid internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./usize.>.>.)) (!
   (has_type (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. x) (TYPE%vstd!seq.Seq. (DST $)
     (TYPE%tuple%2. $ USIZE $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. x) (TYPE%vstd!seq.Seq.
      (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   )))
   :qid internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
     (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
     x
   ))
   :qid internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)))
    (= x (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
      (%Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.))))
   :qid internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
     x
    ) (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.))
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.
      x
     ) (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.))
   ))
   :qid internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (= x (%Poly%vstd!set.Set<usize.>. (Poly%vstd!set.Set<usize.>. x)))
   :pattern ((Poly%vstd!set.Set<usize.>. x))
   :qid internal_vstd__set__Set<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ USIZE))
    (= x (Poly%vstd!set.Set<usize.>. (%Poly%vstd!set.Set<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE))
   :pattern ((has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.)) (!
   (= x (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>. (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.
      x
   )))
   :pattern ((Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>. x))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.))
    (= x (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>. (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.)) (!
   (has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>. x)
    (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
   )
   :pattern ((has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.
      x
     ) (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
   ))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.)) (!
   (= x (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>. (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.
      x
   )))
   :pattern ((Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>. x))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.))
    (= x (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>. (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.)) (!
   (has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>. x)
    (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
   )
   :pattern ((has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.
      x
     ) (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
   ))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>_has_type_always_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Writes_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Writes_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Writes_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Writes_unbox_axiom_definition
)))
(assert
 (forall ((_core! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.) (_tso! vstd!set.Set<usize.>.)
   (_nonpos! vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.>.)
  ) (!
   (=>
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. _core!) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes
       _core! _tso! _nonpos!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes
       _core! _tso! _nonpos!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/?core
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core
       (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. x)
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/core_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/tso x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/?tso
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/tso x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/tso_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/tso_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/nonpos x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/?nonpos
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/nonpos x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/nonpos_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes./Writes/nonpos_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTMem_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTMem_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTMem_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTMem_unbox_axiom_definition
)))
(assert
 (forall ((_mem! vstd!map.Map<usize./usize.>.) (_pml4! Int)) (!
   (=>
    (uInv SZ _pml4!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem
       _mem! _pml4!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem
       _mem! _pml4!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/?mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/?pml4
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__GPDE_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__GPDE_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__GPDE_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__GPDE_unbox_axiom_definition
)))
(assert
 (forall ((_addr! Int) (_P! Bool) (_RW! Bool) (_US! Bool) (_PWT! Bool) (_PCD! Bool)
   (_XD! Bool)
  ) (!
   (=>
    (uInv SZ _addr!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory
       _addr! _P! _RW! _US! _PWT! _PCD! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory
       _addr! _P! _RW! _US! _PWT! _PCD! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?addr
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/P x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?P
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/P x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/P_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/P_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/RW x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?RW
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/RW x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/RW_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/RW_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/US x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?US
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/US x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/US_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/US_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PWT x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?PWT
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PWT x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PWT_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PWT_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PCD x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?PCD
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PCD x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PCD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PCD_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/XD x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/?XD
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/XD x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/XD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/XD_accessor_definition
)))
(assert
 (forall ((_addr! Int) (_P! Bool) (_RW! Bool) (_US! Bool) (_PWT! Bool) (_PCD! Bool)
   (_G! Bool) (_PAT! Bool) (_XD! Bool)
  ) (!
   (=>
    (uInv SZ _addr!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page
       _addr! _P! _RW! _US! _PWT! _PCD! _G! _PAT! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page
       _addr! _P! _RW! _US! _PWT! _PCD! _G! _PAT! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?addr
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/P x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?P
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/P x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/P_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/P_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/RW x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?RW
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/RW x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/RW_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/RW_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/US x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?US
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/US x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/US_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/US_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PWT x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?PWT
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PWT x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PWT_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PWT_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PCD x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?PCD
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PCD x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PCD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PCD_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/G x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?G
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/G x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/G_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/G_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PAT x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?PAT
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PAT x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PAT_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PAT_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/XD x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/?XD
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/XD x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/XD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/XD_accessor_definition
)))
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Invalid)
  TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Core_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Core_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Core_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Core_unbox_axiom_definition
)))
(assert
 (forall ((_node_id! Int) (_core_id! Int)) (!
   (=>
    (and
     (<= 0 _node_id!)
     (<= 0 _core_id!)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core
       _node_id! _core_id!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core
       _node_id! _core_id!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/?node_id
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/node_id_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/?core_id
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./Core/core_id_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__MemRegion_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__MemRegion_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__MemRegion_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__MemRegion_unbox_axiom_definition
)))
(assert
 (forall ((_base! Int) (_size! Int)) (!
   (=>
    (and
     (<= 0 _base!)
     (<= 0 _size!)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion
       _base! _size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion
       _base! _size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/?base
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/base_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/?size
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion./MemRegion/size_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags_unbox_axiom_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_writable x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/?is_writable
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_writable x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_writable_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_writable_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_supervisor x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/?is_supervisor
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_supervisor x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_supervisor_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/is_supervisor_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/disable_execute x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/?disable_execute
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/disable_execute x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/disable_execute_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags./Flags/disable_execute_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)) (!
   (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. x) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. x) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags_has_type_always_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags_has_type_always_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTE_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTE_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTE_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTE_unbox_axiom_definition
)))
(assert
 (forall ((_frame! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.) (_flags! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.))
  (!
   (=>
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. _frame!) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE
       _frame! _flags!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE
       _frame! _flags!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/?frame
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame
       (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE. x)
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!MemRegion.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/frame_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/flags x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/?flags
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/flags x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/flags_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE./PTE/flags_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Polarity_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Polarity_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Polarity_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Polarity_unbox_axiom_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)) (!
   (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. x) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity. x) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Polarity_has_type_always_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Polarity_has_type_always_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Walk_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Walk_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Walk_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Walk_unbox_axiom_definition
)))
(assert
 (forall ((_vaddr! Int) (_path! vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.>.>.)
   (_complete! Bool)
  ) (!
   (=>
    (uInv SZ _vaddr!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk
       _vaddr! _path! _complete!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk
       _vaddr! _path! _complete!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/?vaddr
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/vaddr_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/path x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/?path
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/path x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/path_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/path_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/complete x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/?complete
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/complete x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/complete_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk./Walk/complete_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Constants_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Constants_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Constants_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Constants_unbox_axiom_definition
)))
(assert
 (forall ((_node_count! Int) (_core_count! Int) (_range_ptmem! tuple%2.) (_range_mem!
    tuple%2.
   ) (_phys_mem_size! Int)
  ) (!
   (=>
    (and
     (<= 0 _node_count!)
     (<= 0 _core_count!)
     (has_type (Poly%tuple%2. _range_ptmem!) (TYPE%tuple%2. $ NAT $ NAT))
     (has_type (Poly%tuple%2. _range_mem!) (TYPE%tuple%2. $ NAT $ NAT))
     (<= 0 _phys_mem_size!)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants
       _node_count! _core_count! _range_ptmem! _range_mem! _phys_mem_size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants
       _node_count! _core_count! _range_ptmem! _range_mem! _phys_mem_size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count x) (
     NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?node_count x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count
     (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/node_count_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count x) (
     NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?core_count x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count
     (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/core_count_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem x)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?range_ptmem x)
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
    (has_type (Poly%tuple%2. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem
       (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
      )
     ) (TYPE%tuple%2. $ NAT $ NAT)
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem
     (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_ptmem_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?range_mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
    (has_type (Poly%tuple%2. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem
       (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
      )
     ) (TYPE%tuple%2. $ NAT $ NAT)
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem
     (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/range_mem_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size x)
    (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/?phys_mem_size x)
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size
     (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants./Constants/phys_mem_size_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__State_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__State_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__State_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__State_unbox_axiom_definition
)))
(assert
 (forall ((_happy! Bool) (_phys_mem! vstd!seq.Seq<u8.>.) (_pt_mem! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
   (_tlbs! vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTE.>.>.)
   (_walks! vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Walk.>.>.)
   (_sbuf! vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.)
   (_writes! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.) (_polarity! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Polarity.)
   (_hist! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)
  ) (!
   (=>
    (and
     (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. _pt_mem!) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
     (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. _writes!) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State
       _happy! _phys_mem! _pt_mem! _tlbs! _walks! _sbuf! _writes! _polarity! _hist!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State
       _happy! _phys_mem! _pt_mem! _tlbs! _walks! _sbuf! _writes! _polarity! _hist!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/happy x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?happy
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/happy x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/happy_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/happy_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/phys_mem x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?phys_mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/phys_mem x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/phys_mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/phys_mem_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?pt_mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem
       (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. x)
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/tlbs x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?tlbs
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/tlbs x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/tlbs_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/tlbs_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/walks x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?walks
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/walks x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/walks_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/walks_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/sbuf x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?sbuf
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/sbuf x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/sbuf_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/sbuf_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?writes
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes
       (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. x)
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Writes.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/writes_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/polarity x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?polarity
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/polarity x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/polarity_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/polarity_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/hist x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/?hist
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/hist x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/hist_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/hist_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)) (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. x))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__History_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__History_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__History_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__History_unbox_axiom_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_maps x) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/?pending_maps
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_maps
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_maps_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_maps_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)) (!
   (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_unmaps x) (
     NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/?pending_unmaps x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_unmaps
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_unmaps_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History./History/pending_unmaps_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)) (!
   (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. x) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.)
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History. x) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!History.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__History_has_type_always_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__History_has_type_always_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= x (%Poly%tuple%1. (Poly%tuple%1. x)))
   :pattern ((Poly%tuple%1. x))
   :qid internal_crate__tuple__1_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (= x (Poly%tuple%1. (%Poly%tuple%1. x)))
   )
   :pattern ((has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__tuple__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T%0&)
    (has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1_constructor_definition
   :skolemid skolem_internal_tuple__1./tuple__1_constructor_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= (tuple%1./tuple%1/0 x) (tuple%1./tuple%1/?0 x))
   :pattern ((tuple%1./tuple%1/0 x))
   :qid internal_tuple__1./tuple__1/0_accessor_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (has_type (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) T%0&)
   )
   :pattern ((tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1/0_invariant_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_invariant_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (=>
    (is-tuple%1./tuple%1 x)
    (height_lt (height (tuple%1./tuple%1/0 x)) (height (Poly%tuple%1. x)))
   )
   :pattern ((height (tuple%1./tuple%1/0 x)))
   :qid prelude_datatype_height_tuple%1./tuple%1/0
   :skolemid skolem_prelude_datatype_height_tuple%1./tuple%1/0
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%tuple%1. T%0&. T%0&))
     (has_type y (TYPE%tuple%1. T%0&. T%0&))
     (ext_eq deep T%0& (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (tuple%1./tuple%1/0 (%Poly%tuple%1.
        y
    ))))
    (ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y))
   :qid internal_tuple__1./tuple__1_ext_equal_definition
   :skolemid skolem_internal_tuple__1./tuple__1_ext_equal_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(assert
 (forall ((x fndef) (Self%&. Dcr) (Self%& Type)) (!
   (has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&))
   :pattern ((has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&)))
   :qid prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
   :skolemid skolem_prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%core!clone.Clone. Self%&. Self%&))
   :qid internal_core__clone__Clone_trait_type_bounds_definition
   :skolemid skolem_internal_core__clone__Clone_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. Self%&. Self%&)
    (tr_bound%core!clone.Clone. Self%&. Self%&)
   )
   :pattern ((tr_bound%core!marker.Copy. Self%&. Self%&))
   :qid internal_core__marker__Copy_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Copy_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%verus_builtin!Integer. Self%&. Self%&)
    (tr_bound%core!marker.Copy. Self%&. Self%&)
   )
   :pattern ((tr_bound%verus_builtin!Integer. Self%&. Self%&))
   :qid internal_verus_builtin__Integer_trait_type_bounds_definition
   :skolemid skolem_internal_verus_builtin__Integer_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 8))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 8))
  ) (UINT 8)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) USIZE
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
       Self%&
      ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&.
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
      (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) BOOL
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) (REF T&.)
   )
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       REF T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) T&
   )
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF
       T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
        T&.
       ) T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) (TRACKED T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       TRACKED T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
       T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) (GHOST T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       GHOST T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&.
        A& T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) (BOX A&. A& T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       BOX A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
        T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX
       A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
  ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
  ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.
))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.Seq.subrange.? (Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index_range.? (Dcr Type Dcr Type Dcr Type Poly Poly
  Poly
 ) Poly
)
(declare-fun vstd!seq_lib.impl&%0.drop_last.? (Dcr Type Poly) Poly)
(declare-fun vstd!seq.Seq.last.? (Dcr Type Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.fold_left.? (Dcr Type Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.rec%fold_left.? (Dcr Type Dcr Type Poly Poly Poly
  Fuel
 ) Poly
)
(declare-fun vstd!seq.impl&%2.skip.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index_range_from.? (Dcr Type Dcr Type Poly Poly)
 Poly
)
(declare-fun vstd!seq.impl&%2.take.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index_range_to.? (Dcr Type Dcr Type Poly Poly)
 Poly
)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.insert.? (Dcr Type Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!set.Set.insert.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!pervasive.strictly_cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!pervasive.cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.? (Poly Poly Poly)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.? (Poly Poly)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
)
(declare-fun vstd!set.Set.subset_of.? (Dcr Type Poly Poly) Bool)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%8.valid_core.? (Poly Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G.? (Poly) Bool)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.?
 (Poly) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.? (
  Poly
 ) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.? (Poly)
 Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.? (Poly Poly)
 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(declare-fun ens%core!clone.Clone.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (%return! Poly)) (!
   (= (ens%core!clone.Clone.clone. Self%&. Self%& self! %return!) (has_type %return! Self%&))
   :pattern ((ens%core!clone.Clone.clone. Self%&. Self%& self! %return!))
   :qid internal_ens__core!clone.Clone.clone._definition
   :skolemid skolem_internal_ens__core!clone.Clone.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (Self%&. Dcr) (Self%& Type)) (!
   (=>
    (has_type closure%$ (TYPE%tuple%1. (REF Self%&.) Self%&))
    (=>
     (let
      ((self$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      true
     )
     (closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.)) (TYPE%tuple%1.
       (REF Self%&.) Self%&
      ) (F fndef_singleton) closure%$
   )))
   :pattern ((closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.))
     (TYPE%tuple%1. (REF Self%&.) Self%&) (F fndef_singleton) closure%$
   ))
   :qid user_core__clone__Clone__clone_0
   :skolemid skolem_user_core__clone__Clone__clone_0
)))
(assert
 (tr_bound%core!clone.Clone. $ INT)
)
(assert
 (tr_bound%core!marker.Copy. $ INT)
)
(assert
 (tr_bound%verus_builtin!Integer. $ INT)
)
(declare-fun req%vstd!seq.Seq.subrange. (Dcr Type Poly Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (= (req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!) (=>
     %%global_location_label%%2
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I start_inclusive!)))
       (let
        ((tmp%%$2 (%I end_exclusive!)))
        (let
         ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& self!)))
         (and
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
          )
          (<= tmp%%$2 tmp%%$3)
   )))))))
   :pattern ((req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_req__vstd!seq.Seq.subrange._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.subrange._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type start_inclusive! INT)
     (has_type end_exclusive! INT)
    )
    (has_type (vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!) (
      TYPE%vstd!seq.Seq. A&. A&
   )))
   :pattern ((vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_vstd!seq.Seq.subrange.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.subrange.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index_range. (Dcr Type Dcr Type Dcr Type Poly
  Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (J&. Dcr) (J& Type) (self! Poly) (
    i! Poly
   ) (j! Poly)
  ) (!
   (= (req%vstd!seq.impl&%2.spec_index_range. A&. A& I&. I& J&. J& self! i! j!) (=>
     %%global_location_label%%3
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (%I j!)))
        (let
         ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& self!)))
         (and
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
          )
          (<= tmp%%$2 tmp%%$3)
   )))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index_range. A&. A& I&. I& J&. J& self! i! j!))
   :qid internal_req__vstd!seq.impl&__2.spec_index_range._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index_range._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index_range.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index_range.)
  (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (J&. Dcr) (J& Type) (self! Poly) (
     i! Poly
    ) (j! Poly)
   ) (!
    (= (vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!) (vstd!seq.Seq.subrange.?
      A&. A& self! i! j!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!))
    :qid internal_vstd!seq.impl&__2.spec_index_range.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (J&. Dcr) (J& Type) (self! Poly) (
    i! Poly
   ) (j! Poly)
  ) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! I&)
     (has_type j! J&)
    )
    (has_type (vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!) (
      TYPE%vstd!seq.Seq. A&. A&
   )))
   :pattern ((vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!))
   :qid internal_vstd!seq.impl&__2.spec_index_range.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
      (has_type j! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I i!)))
          (let
           ((tmp%%$2 (%I j!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (< (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (vstd!seq.Seq.len.?
         A&. A& s!
      )))
      (height_lt (height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)))
    :qid user_vstd__seq__lemma_seq_subrange_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I j!)))
         (let
          ((tmp%%$2 (%I k!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
            )
            (<= tmp%%$2 tmp%%$3)
      ))))))
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)) (Sub (%I k!)
        (%I j!)
    ))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)))
    :qid user_vstd__seq__lemma_seq_subrange_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I j!)))
          (let
           ((tmp%%$2 (%I k!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$5 (%I i!)))
         (let
          ((tmp%%$6 (Sub (%I k!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$5)
           (< tmp%%$5 tmp%%$6)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!) (vstd!seq.Seq.index.?
        A&. A& s! (I (Add (%I i!) (%I j!)))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!))
    :qid user_vstd__seq__lemma_seq_subrange_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_two_subranges_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k1! Poly) (k2! Poly) (i! Poly))
   (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k1! INT)
      (has_type k2! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized A&.)
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I j!)))
            (let
             ((tmp%%$2 (%I k1!)))
             (let
              ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
              (and
               (and
                (<= tmp%%$ tmp%%$1)
                (<= tmp%%$1 tmp%%$2)
               )
               (<= tmp%%$2 tmp%%$3)
         ))))))
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$5 (%I j!)))
           (let
            ((tmp%%$6 (%I k2!)))
            (let
             ((tmp%%$7 (vstd!seq.Seq.len.? A&. A& s!)))
             (and
              (and
               (<= tmp%%$ tmp%%$5)
               (<= tmp%%$5 tmp%%$6)
              )
              (<= tmp%%$6 tmp%%$7)
        ))))))
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$9 (%I i!)))
          (let
           ((tmp%%$10 (Sub (%I k1!) (%I j!))))
           (and
            (<= tmp%%$ tmp%%$9)
            (< tmp%%$9 tmp%%$10)
       )))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$12 (%I i!)))
         (let
          ((tmp%%$13 (Sub (%I k2!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$12)
           (< tmp%%$12 tmp%%$13)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!) (vstd!seq.Seq.index.?
        A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k2!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!)
     (vstd!seq.Seq.subrange.? A&. A& s! j! k2!)
    )
    :qid user_vstd__seq__lemma_seq_two_subranges_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_two_subranges_index_0
))))
(declare-fun req%vstd!seq_lib.impl&%0.drop_last. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (= (req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!) (=>
     %%global_location_label%%4
     (>= (vstd!seq.Seq.len.? A&. A& self!) 1)
   ))
   :pattern ((req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!))
   :qid internal_req__vstd!seq_lib.impl&__0.drop_last._definition
   :skolemid skolem_internal_req__vstd!seq_lib.impl&__0.drop_last._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.drop_last.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.drop_last.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (vstd!seq.Seq.subrange.? A&. A&
      self! (I 0) (I (Sub (vstd!seq.Seq.len.? A&. A& self!) 1))
    ))
    :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
    :qid internal_vstd!seq_lib.impl&__0.drop_last.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
   :qid internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.last. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (= (req%vstd!seq.Seq.last. A&. A& self!) (=>
     %%global_location_label%%5
     (< 0 (vstd!seq.Seq.len.? A&. A& self!))
   ))
   :pattern ((req%vstd!seq.Seq.last. A&. A& self!))
   :qid internal_req__vstd!seq.Seq.last._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.last._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.Seq.last.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.Seq.last.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq.Seq.last.? A&. A& self!) (vstd!seq.Seq.index.? A&. A& self! (I (Sub (vstd!seq.Seq.len.?
         A&. A& self!
        ) 1
    ))))
    :pattern ((vstd!seq.Seq.last.? A&. A& self!))
    :qid internal_vstd!seq.Seq.last.?_definition
    :skolemid skolem_internal_vstd!seq.Seq.last.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq.Seq.last.? A&. A& self!) A&)
   )
   :pattern ((vstd!seq.Seq.last.? A&. A& self!))
   :qid internal_vstd!seq.Seq.last.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.last.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.fold_left.)
)
(declare-const fuel_nat%vstd!seq_lib.impl&%0.fold_left. Fuel)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (= (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%) (vstd!seq_lib.impl&%0.rec%fold_left.?
     A&. A& B&. B& self! b! f! zero
   ))
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%))
   :qid internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_zero_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_zero_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (=>
    (and
     (sized A&.)
     (sized B&.)
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (= (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! (succ fuel%)) (
      ite
      (= (vstd!seq.Seq.len.? A&. A& self!) 0)
      b!
      (%%apply%%0 (%Poly%fun%2. f!) (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& (
         vstd!seq_lib.impl&%0.drop_last.? A&. A& self!
        ) b! f! fuel%
       ) (vstd!seq.Seq.last.? A&. A& self!)
   ))))
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! (succ fuel%)))
   :qid internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_body_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.fold_left.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly))
   (!
    (=>
     (and
      (sized A&.)
      (sized B&.)
      (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! B&)
      (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
     )
     (= (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!) (vstd!seq_lib.impl&%0.rec%fold_left.?
       A&. A& B&. B& self! b! f! (succ fuel_nat%vstd!seq_lib.impl&%0.fold_left.)
    )))
    :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!))
    :qid internal_vstd!seq_lib.impl&__0.fold_left.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!) B&)
   )
   :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!))
   :qid internal_vstd!seq_lib.impl&__0.fold_left.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%) B&)
   )
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%))
   :qid internal_vstd!seq_lib.impl&__0.rec__fold_left.?_pre_post_rec_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.rec__fold_left.?_pre_post_rec_definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.skip.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.skip.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.skip.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      n! (I (vstd!seq.Seq.len.? A&. A& self!))
    ))
    :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.skip.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.skip.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.skip.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index_range_from. (Dcr Type Dcr Type Poly Poly)
 Bool
)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index_range_from. A&. A& I&. I& self! i!) (=>
     %%global_location_label%%6
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (<= tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index_range_from. A&. A& I&. I& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index_range_from._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index_range_from._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index_range_from.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index_range_from.)
  (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!) (vstd!seq.Seq.subrange.?
      A&. A& self! i! (I (vstd!seq.Seq.len.? A&. A& self!))
    ))
    :pattern ((vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index_range_from.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_from.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! I&)
    )
    (has_type (vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!) (TYPE%vstd!seq.Seq.
      A&. A&
   )))
   :pattern ((vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index_range_from.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_from.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.take.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.take.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.take.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      (I 0) n!
    ))
    :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.take.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.take.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.take.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.take.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.take.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index_range_to. (Dcr Type Dcr Type Poly Poly)
 Bool
)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (J&. Dcr) (J& Type) (self! Poly) (j! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index_range_to. A&. A& J&. J& self! j!) (=>
     %%global_location_label%%7
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I j!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (<= tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index_range_to. A&. A& J&. J& self! j!))
   :qid internal_req__vstd!seq.impl&__2.spec_index_range_to._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index_range_to._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index_range_to.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index_range_to.)
  (forall ((A&. Dcr) (A& Type) (J&. Dcr) (J& Type) (self! Poly) (j! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!) (vstd!seq.Seq.subrange.?
      A&. A& self! (I 0) j!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!))
    :qid internal_vstd!seq.impl&__2.spec_index_range_to.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_to.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (J&. Dcr) (J& Type) (self! Poly) (j! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type j! J&)
    )
    (has_type (vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!) (TYPE%vstd!seq.Seq.
      A&. A&
   )))
   :pattern ((vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!))
   :qid internal_vstd!seq.impl&__2.spec_index_range_to.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_to.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
     k! Poly
    )
   ) (!
    (=>
     (and
      (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! B&)
      (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
      (has_type k! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (sized B&.)
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I k!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
         k! (I (vstd!seq.Seq.len.? A&. A& self!))
        ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
          (I 0) k!
         ) b! f!
        ) f!
       ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!)
    )))
    :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&.
       A& self! (I 0) k!
      ) b! f!
    ))
    :qid user_vstd__seq_lib__impl&%0__lemma_fold_left_split_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__lemma_fold_left_split_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%8
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%9
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_decreases_to_entry.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
           K& V&. V& m! key!
        )))
       ) (height m!)
    )))
    :pattern ((height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
         K& V&. V& m! key!
    )))))
    :qid user_vstd__map__axiom_map_decreases_to_entry_0
    :skolemid skolem_user_vstd__map__axiom_map_decreases_to_entry_0
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly) (value! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
     (has_type value! V&)
    )
    (has_type (vstd!map.impl&%0.insert.? K&. K& V&. V& self! key! value!) (TYPE%vstd!map.Map.
      K&. K& V&. V&
   )))
   :pattern ((vstd!map.impl&%0.insert.? K&. K& V&. V& self! key! value!))
   :qid internal_vstd!map.impl&__0.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.insert.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!set.Set. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!set.Set.insert.? A&. A& self! a!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!set.Set.insert.? A&. A& self! a!))
   :qid internal_vstd!set.Set.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.Set.insert.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_insert_domain.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly) (value! Poly))
   (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V& m!
         key! value!
        )
       ) (vstd!set.Set.insert.? K&. K& (vstd!map.impl&%0.dom.? K&. K& V&. V& m!) key!)
    )))
    :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&.
       V& m! key! value!
    )))
    :qid user_vstd__map__lemma_map_insert_domain_0
    :skolemid skolem_user_vstd__map__lemma_map_insert_domain_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_insert_same.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly) (value! Poly))
   (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V&
         m! key! value!
        ) key!
       ) value!
    )))
    :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K&
       V&. V& m! key! value!
      ) key!
    ))
    :qid user_vstd__map__lemma_map_insert_same_0
    :skolemid skolem_user_vstd__map__lemma_map_insert_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_insert_different.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key1! Poly) (key2! Poly)
    (value! Poly)
   ) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key1! K&)
      (has_type key2! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (not (= key1! key2!))
      )
      (= (vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V&
         m! key2! value!
        ) key1!
       ) (vstd!map.impl&%0.index.? K&. K& V&. V& m! key1!)
    )))
    :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K&
       V&. V& m! key2! value!
      ) key1!
    ))
    :qid user_vstd__map__axiom_map_insert_different_0
    :skolemid skolem_user_vstd__map__axiom_map_insert_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
         A&. A& s! a!
        )
       ) a!
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a!
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_insert_same_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a1! A&)
      (has_type a2! A&)
     )
     (=>
      (and
       (sized A&.)
       (not (= a1! a2!))
      )
      (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
          A&. A& s! a2!
         )
        ) a1!
       ) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a1!)
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a2!
       )
      ) a1!
    ))
    :qid user_vstd__set__lemma_set_insert_different_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%tuple%0.)
)
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Tuple1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. T%0&. T%0&)
    (tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Clone1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. T%0&. T%0&)
    (tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Copy1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
    )
    (tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Clone2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
    )
    (tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Copy2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy2_trait_impl_definition
)))
(declare-fun ens%core!clone.impls.impl&%12.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%12.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 8) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%12.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__12.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__12.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 8)))
     (has_type res$ (UINT 8))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 8)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 8)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%12__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%12__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%10.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%10.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ USIZE x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%10.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__10.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__10.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) USIZE))
     (has_type res$ USIZE)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1. (
        REF $
       ) USIZE
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1.
      (REF $) USIZE
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%10__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%10__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%42.clone. (Poly Poly) Bool)
(assert
 (forall ((b! Poly) (%return! Poly)) (!
   (= (ens%core!clone.impls.impl&%42.clone. b! %return!) (and
     (ens%core!clone.Clone.clone. $ BOOL b! %return!)
     (= %return! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%42.clone. b! %return!))
   :qid internal_ens__core!clone.impls.impl&__42.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__42.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) BOOL))
     (has_type %return$ BOOL)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1. (REF
        $
       ) BOOL
      ) (F fndef_singleton) closure%$ %return$
     )
     (let
      ((b$ (%B (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%B %return$) b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1.
      (REF $) BOOL
     ) (F fndef_singleton) closure%$ %return$
   ))
   :qid user_core__clone__impls__impl&%42__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%42__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%6.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (REF T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%6.clone. T&. T& b! res!))
   :qid internal_ens__core!clone.impls.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (REF T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.))) (TYPE%tuple%1.
       (REF (REF T&.)) T&
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.)))
     (TYPE%tuple%1. (REF (REF T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%6__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%6__clone_0
)))
(declare-fun ens%verus_builtin!impl&%9.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%9.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (TRACKED T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%9.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__9.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__9.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (TRACKED T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED T&.)))
      (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED
        T&.
      ))
     ) (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%9__clone_0
   :skolemid skolem_user_verus_builtin__impl&%9__clone_0
)))
(declare-fun ens%verus_builtin!impl&%7.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%7.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (GHOST T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%7.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__7.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__7.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (GHOST T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST T&.)))
      (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST
        T&.
      ))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%7__clone_0
   :skolemid skolem_user_verus_builtin__impl&%7__clone_0
)))
(assert
 (fuel_bool_default fuel%vstd!pervasive.strictly_cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.strictly_cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.strictly_cloned.? T&. T& a! b!) (closure_ens (FNDEF%core!clone.Clone.clone.
       T&. T&
      ) (DST (REF T&.)) (TYPE%tuple%1. (REF T&.) T&) (F fndef_singleton) (Poly%tuple%1.
       (tuple%1./tuple%1 a!)
      ) b!
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.strictly_cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.strictly_cloned.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!pervasive.cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.cloned.? T&. T& a! b!) (or
      (vstd!pervasive.strictly_cloned.? T&. T& a! b!)
      (= a! b!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.cloned.?_definition
))))
(declare-fun ens%alloc!boxed.impl&%15.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (b! Poly) (res! Poly)) (!
   (= (ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!) (and
     (ens%core!clone.Clone.clone. (BOX A&. A& T&.) T& b! res!)
     (vstd!pervasive.cloned.? T&. T& b! res!)
   ))
   :pattern ((ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!))
   :qid internal_ens__alloc!boxed.impl&__15.clone._definition
   :skolemid skolem_internal_ens__alloc!boxed.impl&__15.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF (BOX A&. A&
         T&.
       ))
      ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (vstd!pervasive.cloned.? T&. T& b$ res$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF
       (BOX A&. A& T&.)
      )
     ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_alloc__boxed__impl&%15__clone_0
   :skolemid skolem_user_alloc__boxed__impl&%15__clone_0
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.)
  (forall ((self! Poly) (addr! Poly) (value! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.? self! addr! value!)
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem (%Poly%vstd!map.Map<usize./usize.>.
       (vstd!map.impl&%0.insert.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem
          (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. self!)
         )
        ) addr! value!
       )
      ) (%I (I (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
          self!
    ))))))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.? self! addr! value!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write.?_definition
))))
(assert
 (forall ((self! Poly) (addr! Poly) (value! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
     (has_type addr! USIZE)
     (has_type value! USIZE)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.?
       self! addr! value!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.? self! addr! value!))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.)
)
(declare-fun %%lambda%%0 () %%Function%%)
(assert
 (forall ((acc$ Poly) (wr$ Poly)) (!
   (= (%%apply%%0 %%lambda%%0 acc$ wr$) (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write.? acc$ (tuple%2./tuple%2/0
       (%Poly%tuple%2. wr$)
      ) (tuple%2./tuple%2/1 (%Poly%tuple%2. wr$))
   )))
   :pattern ((%%apply%%0 %%lambda%%0 acc$ wr$))
)))
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.)
  (forall ((self! Poly) (writes! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.? self! writes!) (
      %Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (vstd!seq_lib.impl&%0.fold_left.?
       (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
       writes! self! (Poly%fun%2. (mk_fun %%lambda%%0))
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.? self! writes!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write_seq.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write_seq.?_definition
))))
(assert
 (forall ((self! Poly) (writes! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
     (has_type writes! (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)))
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.?
       self! writes!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.? self! writes!))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write_seq.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.write_seq.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.subset_of.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.subset_of.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
    (= (vstd!set.Set.subset_of.? A&. A& self! s2!) (forall ((a$ Poly)) (!
       (=>
        (has_type a$ A&)
        (=>
         (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!) a$)
         (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$)
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!)
         a$
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
         a$
       ))
       :qid user_vstd__set__Set__subset_of_0
       :skolemid skolem_user_vstd__set__Set__subset_of_0
    )))
    :pattern ((vstd!set.Set.subset_of.? A&. A& self! s2!))
    :qid internal_vstd!set.Set.subset_of.?_definition
    :skolemid skolem_internal_vstd!set.Set.subset_of.?_definition
))))
(declare-fun ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.lemma_write_seq.
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. vstd!seq.Seq<tuple%2<usize./usize.>.>.)
 Bool
)
(assert
 (forall ((self! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.) (writes! vstd!seq.Seq<tuple%2<usize./usize.>.>.))
  (!
   (= (ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.lemma_write_seq. self! writes!)
    (and
     (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
        (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.?
          (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. self!) (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>.
           writes!
       ))))
      ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
        (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. self!)
     )))
     (vstd!set.Set.subset_of.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
        (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
          (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. self!)
       )))
      ) (vstd!map.impl&%0.dom.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem
         (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
           (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.? (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
             self!
            ) (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. writes!)
   )))))))))
   :pattern ((ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.lemma_write_seq. self!
     writes!
   ))
   :qid internal_ens__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.lemma_write_seq._definition
   :skolemid skolem_internal_ens__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__0.lemma_write_seq._definition
)))
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.lemma_write_seq.)
  (forall ((self! Poly) (writes! Poly)) (!
    (=>
     (and
      (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
      (has_type writes! (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)))
     )
     (and
      (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
         (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.?
           self! writes!
        )))
       ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
         self!
      )))
      (vstd!set.Set.subset_of.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>.
         (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
           self!
        )))
       ) (vstd!map.impl&%0.dom.? $ USIZE $ USIZE (Poly%vstd!map.Map<usize./usize.>. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/mem
          (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
            (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.? self! writes!)
    ))))))))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.? self! writes!))
    :qid user_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTMem__lemma_write_seq_0
    :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__PTMem__lemma_write_seq_0
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G. (Poly)
 Bool
)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G. self!) (=>
     %%global_location_label%%10
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_G._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_G._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/G
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_G.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_G.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_G.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT. (Poly)
 Bool
)
(declare-const %%global_location_label%%11 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT. self!) (=>
     %%global_location_label%%11
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_PAT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_PAT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PAT
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_PAT.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_PAT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_PAT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.
 (Poly) Bool
)
(declare-const %%global_location_label%%12 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr. self!)
    (=>
     %%global_location_label%%12
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_addr._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_addr._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.? self!)
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/addr (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_addr.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_addr.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.?
      self!
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_addr.?
     self!
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_addr.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_addr.?_pre_post_definition
)))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.
 (Poly) Bool
)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P. self!)
    (=>
     %%global_location_label%%13
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_P._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_P._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.? self!) (
      NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/P (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_P.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_P.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_P.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.
 (Poly) Bool
)
(declare-const %%global_location_label%%14 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW. self!)
    (=>
     %%global_location_label%%14
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_RW._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_RW._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.? self!)
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/RW (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_RW.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_RW.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_RW.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.
 (Poly) Bool
)
(declare-const %%global_location_label%%15 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US. self!)
    (=>
     %%global_location_label%%15
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_US._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_US._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.? self!)
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/US (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_US.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_US.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_US.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.
 (Poly) Bool
)
(declare-const %%global_location_label%%16 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT. self!)
    (=>
     %%global_location_label%%16
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PWT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PWT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.? self!)
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PWT (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PWT.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PWT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PWT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.
 (Poly) Bool
)
(declare-const %%global_location_label%%17 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD. self!)
    (=>
     %%global_location_label%%17
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PCD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PCD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.? self!)
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/PCD (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_PCD.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PCD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_PCD.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.
 (Poly) Bool
)
(declare-const %%global_location_label%%18 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD. self!)
    (=>
     %%global_location_label%%18
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_XD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_XD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.? self!)
     (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Directory/XD (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Directory_XD.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_XD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Directory_XD.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.
 (Poly) Bool
)
(declare-const %%global_location_label%%19 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr. self!)
    (=>
     %%global_location_label%%19
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_addr._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_addr._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/addr
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_addr.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_addr.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.? self!))
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_addr.? self!))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_addr.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_addr.?_pre_post_definition
)))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P. (
  Poly
 ) Bool
)
(declare-const %%global_location_label%%20 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P. self!) (=>
     %%global_location_label%%20
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_P._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_P._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/P
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_P.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_P.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_P.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.
 (Poly) Bool
)
(declare-const %%global_location_label%%21 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW. self!) (=>
     %%global_location_label%%21
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_RW._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_RW._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/RW
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_RW.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_RW.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_RW.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US.
 (Poly) Bool
)
(declare-const %%global_location_label%%22 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US. self!) (=>
     %%global_location_label%%22
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_US._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_US._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/US
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_US.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_US.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_US.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.
 (Poly) Bool
)
(declare-const %%global_location_label%%23 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT. self!) (
     =>
     %%global_location_label%%23
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PWT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PWT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PWT
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PWT.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PWT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PWT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD.
 (Poly) Bool
)
(declare-const %%global_location_label%%24 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD. self!) (
     =>
     %%global_location_label%%24
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PCD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PCD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PCD
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PCD.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PCD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PCD.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G. (
  Poly
 ) Bool
)
(declare-const %%global_location_label%%25 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G. self!) (=>
     %%global_location_label%%25
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_G._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_G._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/G
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_G.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_G.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_G.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT.
 (Poly) Bool
)
(declare-const %%global_location_label%%26 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT. self!) (
     =>
     %%global_location_label%%26
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PAT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PAT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/PAT
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_PAT.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PAT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_PAT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.
 (Poly) Bool
)
(declare-const %%global_location_label%%27 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD. self!) (=>
     %%global_location_label%%27
     (is-NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD. self!))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_XD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_XD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.? self!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE./Page/XD
      (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%1.arrow_Page_XD.? self!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_XD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__1.arrow_Page_XD.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.)
  (forall ((self! Poly) (core! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.? self! core!) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.write_seq.?
      (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem
        (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. self!)
       )
      ) (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
       $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
        (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/sbuf (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
          self!
        ))
       ) core!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.? self! core!))
    :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__9.core_mem.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__9.core_mem.?_definition
))))
(assert
 (forall ((self! Poly) (core! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
     (has_type core! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.?
       self! core!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.? self! core!))
   :qid internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__9.core_mem.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__9.core_mem.?_pre_post_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__15_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ USIZE)
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 8))
)
(assert
 (tr_bound%core!clone.Clone. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (REF T&.) T&)
   :pattern ((tr_bound%core!clone.Clone. (REF T&.) T&))
   :qid internal_core__clone__impls__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__35_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__35_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__32_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!clone.Clone. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__7_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!clone.Clone. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__9_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ NAT)
)
(assert
 (tr_bound%core!marker.Copy. $ USIZE)
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 8))
)
(assert
 (tr_bound%core!marker.Copy. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (REF T&.) T&)
   :pattern ((tr_bound%core!marker.Copy. (REF T&.) T&))
   :qid internal_core__marker__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!marker.Copy. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__8_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__8_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!marker.Copy. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__10_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__10_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ NAT)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(assert
 (tr_bound%verus_builtin!Integer. $ (UINT 8))
)
(assert
 (tr_bound%verus_builtin!Integer. $ USIZE)
)
(assert
 (tr_bound%verus_builtin!Integer. $ NAT)
)
(declare-fun ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%4.clone. (Poly Poly)
 Bool
)
(assert
 (forall ((self! Poly) (%return! Poly)) (!
   (= (ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%4.clone. self! %return!) (
     and
     (ens%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
      self! %return!
     )
     (= %return! self!)
   ))
   :pattern ((ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%4.clone. self! %return!))
   :qid internal_ens__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__4.clone._definition
   :skolemid skolem_internal_ens__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__4.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.))
     (has_type %return$ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
      (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
      (F fndef_singleton) closure%$ %return$
     )
     (let
      ((self$ (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. (tuple%1./tuple%1/0 (%Poly%tuple%1.
           closure%$
      )))))
      (= (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. %return$) self$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
     (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
     (F fndef_singleton) closure%$ %return$
   ))
   :qid user_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Core__clone_0
   :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Core__clone_0
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= %return! self!)
   (=>
    %%location_label%%0
    (= %return! self!)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
)
(declare-fun ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%7.clone. (Poly Poly)
 Bool
)
(assert
 (forall ((self! Poly) (%return! Poly)) (!
   (= (ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%7.clone. self! %return!) (
     and
     (ens%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.
      self! %return!
     )
     (= %return! self!)
   ))
   :pattern ((ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%7.clone. self! %return!))
   :qid internal_ens__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__7.clone._definition
   :skolemid skolem_internal_ens__NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&__7.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.))
     (has_type %return$ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
      (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
      (F fndef_singleton) closure%$ %return$
     )
     (let
      ((self$ (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. (tuple%1./tuple%1/0 (
           %Poly%tuple%1. closure%$
      )))))
      (= (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags. %return$) self$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
     (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
     (F fndef_singleton) closure%$ %return$
   ))
   :qid user_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags__clone_0
   :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_core_mem_pm14__Flags__clone_0
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= %return! self!)
   (=>
    %%location_label%%0
    (= %return! self!)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
)
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (
      DST (REF Self%&.)
     ) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $))
  (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST
     (REF (REF T&.))
    ) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (
      DST (REF (GHOST T&.))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
      T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&)
     (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
       T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Flags.)
))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const state! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
(declare-const c! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
(declare-const core! NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
(declare-const tmp%1 NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.)
(declare-const tmp%2 vstd!seq.Seq<tuple%2<usize./usize.>.>.)
(assert
 fuel_defaults
)
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. state!) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.)
)
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants. c!) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.)
)
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. core!) TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.)
)
(assert
 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%8.valid_core.? (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Constants.
   c!
  ) (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. core!)
))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= tmp%1 (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
      (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. state!)
   )))
   (=>
    (= tmp%2 (%Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
       $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
        (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/sbuf (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
          (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. state!)
        ))
       ) (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core. core!)
    )))
    (=>
     (ens%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%0.lemma_write_seq. tmp%1 tmp%2)
     (=>
      %%location_label%%0
      (= (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
         (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!impl&%9.core_mem.?
           (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. state!) (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!Core.
            core!
        ))))
       ) (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem./PTMem/pml4 (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem.
         (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!PTMem. (NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State./State/pt_mem
           (%Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State. (Poly%NR__spec_t__mmu__rl2__lemma_core_mem_pm14!State.
             state!
)))))))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
