(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (= SZ 64)
)
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!layout.layout_of_primitives. FuelId)
(declare-const fuel%vstd!layout.layout_of_unit_tuple. FuelId)
(declare-const fuel%vstd!layout.layout_of_references_and_pointers. FuelId)
(declare-const fuel%vstd!layout.layout_of_references_and_pointers_for_sized_types.
 FuelId
)
(declare-const fuel%vstd!layout.layout_of_references_and_pointers_for_unsized_types.
 FuelId
)
(declare-const fuel%vstd!layout.align_properties. FuelId)
(declare-const fuel%vstd!layout.align_nonzero. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.axiom_map_decreases_to_entry. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!pervasive.strictly_cloned. FuelId)
(declare-const fuel%vstd!pervasive.cloned. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%3.view. FuelId)
(declare-const fuel%vstd!raw_ptr.ptrs_mut_eq. FuelId)
(declare-const fuel%vstd!raw_ptr.ptrs_mut_eq_sized. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_empty. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_same. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_push_index_different. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.contains. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!set.lemma_set_empty. FuelId)
(declare-const fuel%vstd!slice.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!slice.axiom_spec_len. FuelId)
(declare-const fuel%vstd!slice.len%returns_clause_autospec. FuelId)
(declare-const fuel%vstd!slice.axiom_slice_ext_equal. FuelId)
(declare-const fuel%vstd!slice.axiom_slice_has_resolved. FuelId)
(declare-const fuel%vstd!slice.axiom_slice_decreases_to_seq. FuelId)
(declare-const fuel%vstd!slice.lemma_slice_index_decreases. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%20.view. FuelId)
(declare-const fuel%vstd!view.impl&%22.view. FuelId)
(declare-const fuel%vstd!view.impl&%24.view. FuelId)
(declare-const fuel%vstd!view.impl&%26.view. FuelId)
(declare-const fuel%vstd!view.impl&%28.view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%vstd!view.impl&%32.view. FuelId)
(declare-const fuel%vstd!view.impl&%34.view. FuelId)
(declare-const fuel%vstd!view.impl&%36.view. FuelId)
(declare-const fuel%vstd!view.impl&%38.view. FuelId)
(declare-const fuel%vstd!view.impl&%40.view. FuelId)
(declare-const fuel%vstd!view.impl&%42.view. FuelId)
(declare-const fuel%vstd!view.impl&%44.view. FuelId)
(declare-const fuel%vstd!view.impl&%46.view. FuelId)
(declare-const fuel%vstd!view.impl&%48.view. FuelId)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!VERUS_layout_of_usize.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%8.contains_fst.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%9.writer_sbuf.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.
 FuelId
)
(declare-const fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!lemma_writes_tso_empty_implies_sbuf_empty.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!function.axiom_fn_mut_call_requires. fuel%vstd!function.axiom_fn_mut_call_ensures.
  fuel%vstd!iset.lemma_iset_ext_equal. fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!layout.layout_of_primitives.
  fuel%vstd!layout.layout_of_unit_tuple. fuel%vstd!layout.layout_of_references_and_pointers.
  fuel%vstd!layout.layout_of_references_and_pointers_for_sized_types. fuel%vstd!layout.layout_of_references_and_pointers_for_unsized_types.
  fuel%vstd!layout.align_properties. fuel%vstd!layout.align_nonzero. fuel%vstd!map.impl&%0.spec_index.
  fuel%vstd!map.axiom_map_index_decreases. fuel%vstd!map.axiom_map_decreases_to_entry.
  fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep. fuel%vstd!pervasive.strictly_cloned.
  fuel%vstd!pervasive.cloned. fuel%vstd!raw_ptr.impl&%3.view. fuel%vstd!raw_ptr.ptrs_mut_eq.
  fuel%vstd!raw_ptr.ptrs_mut_eq_sized. fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.lemma_seq_index_decreases.
  fuel%vstd!seq.lemma_seq_empty. fuel%vstd!seq.lemma_seq_push_len. fuel%vstd!seq.lemma_seq_push_index_same.
  fuel%vstd!seq.lemma_seq_push_index_different. fuel%vstd!seq.lemma_seq_ext_equal.
  fuel%vstd!seq.lemma_seq_ext_equal_deep. fuel%vstd!seq_lib.impl&%0.contains. fuel%vstd!set.Set.contains.
  fuel%vstd!set.axiom_set_ext_equal. fuel%vstd!set.axiom_set_ext_equal_deep. fuel%vstd!set.axiom_set_decreases_to_member.
  fuel%vstd!set.lemma_set_empty. fuel%vstd!slice.impl&%2.spec_index. fuel%vstd!slice.axiom_spec_len.
  fuel%vstd!slice.len%returns_clause_autospec. fuel%vstd!slice.axiom_slice_ext_equal.
  fuel%vstd!slice.axiom_slice_has_resolved. fuel%vstd!slice.axiom_slice_decreases_to_seq.
  fuel%vstd!slice.lemma_slice_index_decreases. fuel%vstd!view.impl&%0.view. fuel%vstd!view.impl&%2.view.
  fuel%vstd!view.impl&%4.view. fuel%vstd!view.impl&%6.view. fuel%vstd!view.impl&%16.view.
  fuel%vstd!view.impl&%18.view. fuel%vstd!view.impl&%20.view. fuel%vstd!view.impl&%22.view.
  fuel%vstd!view.impl&%24.view. fuel%vstd!view.impl&%26.view. fuel%vstd!view.impl&%28.view.
  fuel%vstd!view.impl&%30.view. fuel%vstd!view.impl&%32.view. fuel%vstd!view.impl&%34.view.
  fuel%vstd!view.impl&%36.view. fuel%vstd!view.impl&%38.view. fuel%vstd!view.impl&%40.view.
  fuel%vstd!view.impl&%42.view. fuel%vstd!view.impl&%44.view. fuel%vstd!view.impl&%46.view.
  fuel%vstd!view.impl&%48.view. fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!VERUS_layout_of_usize.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%8.contains_fst.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%9.writer_sbuf.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.
  fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!lemma_writes_tso_empty_implies_sbuf_empty.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
  (and
   (fuel_bool_default fuel%vstd!layout.align_properties.)
   (fuel_bool_default fuel%vstd!layout.align_nonzero.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (and
   (fuel_bool_default fuel%vstd!layout.layout_of_primitives.)
   (fuel_bool_default fuel%vstd!layout.layout_of_unit_tuple.)
   (fuel_bool_default fuel%vstd!layout.layout_of_references_and_pointers.)
   (fuel_bool_default fuel%vstd!layout.layout_of_references_and_pointers_for_sized_types.)
   (fuel_bool_default fuel%vstd!layout.layout_of_references_and_pointers_for_unsized_types.)
   (fuel_bool_default fuel%vstd!layout.group_align_properties.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.axiom_map_decreases_to_entry.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
  (and
   (fuel_bool_default fuel%vstd!raw_ptr.ptrs_mut_eq.)
   (fuel_bool_default fuel%vstd!raw_ptr.ptrs_mut_eq_sized.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_empty.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_same.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_push_index_different.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
   (fuel_bool_default fuel%vstd!set.lemma_set_empty.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
  (and
   (fuel_bool_default fuel%vstd!slice.axiom_spec_len.)
   (fuel_bool_default fuel%vstd!slice.axiom_slice_ext_equal.)
   (fuel_bool_default fuel%vstd!slice.axiom_slice_has_resolved.)
   (fuel_bool_default fuel%vstd!slice.axiom_slice_decreases_to_seq.)
   (fuel_bool_default fuel%vstd!slice.lemma_slice_index_decreases.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%vstd!slice.SliceAdditionalSpecFns. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%core!clone.Clone. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Copy. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.
 (Dcr Type) Bool
)
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-fun proj%%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
 (Dcr Type) Dcr
)
(declare-fun proj%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
 (Dcr Type) Type
)
(declare-fun pointee_metadata% (Dcr) Type)
(declare-fun pointee_metadata%% (Dcr) Dcr)
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (= (pointee_metadata% d) TYPE%tuple%0.)
   )
   :pattern ((pointee_metadata% d))
   :qid prelude_project_pointee_metadata_sized
   :skolemid skolem_prelude_project_pointee_metadata_sized
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (= (pointee_metadata%% d) $)
   )
   :pattern ((pointee_metadata%% d))
   :qid prelude_project_pointee_metadata_decoration_sized
   :skolemid skolem_prelude_project_pointee_metadata_decoration_sized
)))
(assert
 (= (pointee_metadata% $slice) USIZE)
)
(assert
 (= (pointee_metadata%% $slice) $)
)
(assert
 (forall ((d Dcr)) (!
   (= (pointee_metadata% (DST d)) (pointee_metadata% d))
   :pattern ((pointee_metadata% (DST d)))
   :qid prelude_project_pointee_metadata_decorate_struct_inherit
   :skolemid skolem_prelude_project_pointee_metadata_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (= (pointee_metadata%% (DST d)) (pointee_metadata%% d))
   :pattern ((pointee_metadata%% (DST d)))
   :qid prelude_project_pointee_metadata_decoration_decorate_struct_inherit
   :skolemid skolem_prelude_project_pointee_metadata_decoration_decorate_struct_inherit
)))
(declare-sort alloc!alloc.Global. 0)
(declare-sort vstd!map.Map<usize./usize.>. 0)
(declare-sort vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
 0
)
(declare-sort vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
 0
)
(declare-sort vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
 0
)
(declare-sort vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
 0
)
(declare-sort vstd!raw_ptr.Provenance. 0)
(declare-sort vstd!seq.Seq<u8.>. 0)
(declare-sort vstd!seq.Seq<tuple%2<usize./usize.>.>. 0)
(declare-sort vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
 0
)
(declare-sort vstd!set.Set<usize.>. 0)
(declare-sort vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
 0
)
(declare-sort vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
 0
)
(declare-datatypes ((vstd!raw_ptr.PtrData. 0) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
   0
  ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem. 0) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
   0
  ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. 0) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
   0
  ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags. 0) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
   0
  ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity. 0) (
   NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk. 0
  ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants. 0)
  (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. 0) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
   0
  ) (tuple%0. 0) (tuple%1. 0) (tuple%2. 0)
 ) (((vstd!raw_ptr.PtrData./PtrData (vstd!raw_ptr.PtrData./PtrData/?addr Int) (vstd!raw_ptr.PtrData./PtrData/?provenance
     vstd!raw_ptr.Provenance.
    ) (vstd!raw_ptr.PtrData./PtrData/?metadata Poly)
   )
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/?core
     NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/?tso
     vstd!set.Set<usize.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/?nonpos
     vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/?mem
     vstd!map.Map<usize./usize.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/?pml4
     Int
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?addr
     Int
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?P
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?RW
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?US
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?PWT
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?PCD
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?XD
     Bool
    )
   ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?addr
     Int
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?P Bool)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?RW Bool)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?US Bool)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?PWT Bool)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?PCD Bool)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?G Bool)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?PAT Bool)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?XD Bool)
   ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Invalid)
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/?node_id
     Int
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/?core_id
     Int
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/?base
     Int
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/?size
     Int
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/?is_writable
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/?is_supervisor
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/?disable_execute
     Bool
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/?frame
     NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/?flags
     NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity./Mapping)
   (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity./Unmapping)
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/?vaddr
     Int
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/?path
     vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/?complete
     Bool
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?node_count
     Int
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?core_count
     Int
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?range_ptmem
     tuple%2.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?range_mem
     tuple%2.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?phys_mem_size
     Int
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?happy
     Bool
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?phys_mem
     vstd!seq.Seq<u8.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?pt_mem
     NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?tlbs
     vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?walks
     vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?sbuf
     vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?writes
     NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?polarity
     NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?hist
     NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
   ))
  ) ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/?pending_maps
     vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/?pending_unmaps
     vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
   ))
  ) ((tuple%0./tuple%0)) ((tuple%1./tuple%1 (tuple%1./tuple%1/?0 Poly))) ((tuple%2./tuple%2
    (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1 Poly)
))))
(declare-fun vstd!raw_ptr.PtrData./PtrData/addr (vstd!raw_ptr.PtrData.) Int)
(declare-fun vstd!raw_ptr.PtrData./PtrData/provenance (vstd!raw_ptr.PtrData.) vstd!raw_ptr.Provenance.)
(declare-fun vstd!raw_ptr.PtrData./PtrData/metadata (vstd!raw_ptr.PtrData.) Poly)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.) vstd!set.Set<usize.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/nonpos
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.) vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/mem
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.) vstd!map.Map<usize./usize.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/P
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/RW
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/US
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PWT
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PCD
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/XD
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/P
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/RW
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/US
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PWT
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PCD
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/G
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PAT
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/XD
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_writable
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_supervisor
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/disable_execute
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/flags
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/path
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.) vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/complete
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.) tuple%2.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.) tuple%2.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/happy
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/phys_mem
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) vstd!seq.Seq<u8.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/tlbs
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/walks
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/polarity
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/hist
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_maps
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.) vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_unmaps
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.) vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
)
(declare-fun tuple%1./tuple%1/0 (tuple%1.) Poly)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-const TYPE%vstd!raw_ptr.Provenance. Type)
(declare-fun TYPE%vstd!raw_ptr.PtrData. (Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
 Type
)
(declare-const TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
 Type
)
(declare-fun TYPE%tuple%1. (Dcr Type) Type)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-fun FNDEF%core!clone.Clone.clone. (Dcr Type) Type)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%vstd!map.Map<usize./usize.>. (vstd!map.Map<usize./usize.>.) Poly)
(declare-fun %Poly%vstd!map.Map<usize./usize.>. (Poly) vstd!map.Map<usize./usize.>.)
(declare-fun Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
 (vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
 (Poly) vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
)
(declare-fun Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
 (vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
 (Poly) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
)
(declare-fun Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
 (vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
 (Poly) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
)
(declare-fun Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
 (vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
 (Poly) vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
)
(declare-fun Poly%vstd!raw_ptr.Provenance. (vstd!raw_ptr.Provenance.) Poly)
(declare-fun %Poly%vstd!raw_ptr.Provenance. (Poly) vstd!raw_ptr.Provenance.)
(declare-fun Poly%vstd!seq.Seq<u8.>. (vstd!seq.Seq<u8.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<u8.>. (Poly) vstd!seq.Seq<u8.>.)
(declare-fun Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (vstd!seq.Seq<tuple%2<usize./usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (Poly) vstd!seq.Seq<tuple%2<usize./usize.>.>.)
(declare-fun Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
 (vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
 (Poly) vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
)
(declare-fun Poly%vstd!set.Set<usize.>. (vstd!set.Set<usize.>.) Poly)
(declare-fun %Poly%vstd!set.Set<usize.>. (Poly) vstd!set.Set<usize.>.)
(declare-fun Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
 (vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.)
 Poly
)
(declare-fun %Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
 (Poly) vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
)
(declare-fun Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
 (vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.)
 Poly
)
(declare-fun %Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
 (Poly) vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
)
(declare-fun Poly%vstd!raw_ptr.PtrData. (vstd!raw_ptr.PtrData.) Poly)
(declare-fun %Poly%vstd!raw_ptr.PtrData. (Poly) vstd!raw_ptr.PtrData.)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
)
(declare-fun Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.) Poly
)
(declare-fun %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
 (Poly) NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%1. (tuple%1.) Poly)
(declare-fun %Poly%tuple%1. (Poly) tuple%1.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./usize.>.)) (!
   (= x (%Poly%vstd!map.Map<usize./usize.>. (Poly%vstd!map.Map<usize./usize.>. x)))
   :pattern ((Poly%vstd!map.Map<usize./usize.>. x))
   :qid internal_vstd__map__Map<usize./usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ USIZE))
    (= x (Poly%vstd!map.Map<usize./usize.>. (%Poly%vstd!map.Map<usize./usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ USIZE)))
   :qid internal_vstd__map__Map<usize./usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./usize.>.)) (!
   (has_type (Poly%vstd!map.Map<usize./usize.>. x) (TYPE%vstd!map.Map. $ USIZE $ USIZE))
   :pattern ((has_type (Poly%vstd!map.Map<usize./usize.>. x) (TYPE%vstd!map.Map. $ USIZE
      $ USIZE
   )))
   :qid internal_vstd__map__Map<usize./usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
     (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.))
    (= x (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
      (%Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)))
   :qid internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
   ))
   :qid internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
     (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
     x
   ))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
    ))
    (= x (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
      (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
     x
    ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
     $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
   ))
   :pattern ((has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.
      x
     ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!map.Map. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
     (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
     x
   ))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
    ))
    (= x (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
      (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
     x
    ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
     $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
   ))
   :pattern ((has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
      x
     ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple__2<usize./usize.>.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
     (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
     x
   ))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
    ))
    (= x (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
      (%Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
     x
    ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
     $ (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
   ))
   :pattern ((has_type (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.
      x
     ) (TYPE%vstd!map.Map. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      $ (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
   )))
   :qid internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!raw_ptr.Provenance.)) (!
   (= x (%Poly%vstd!raw_ptr.Provenance. (Poly%vstd!raw_ptr.Provenance. x)))
   :pattern ((Poly%vstd!raw_ptr.Provenance. x))
   :qid internal_vstd__raw_ptr__Provenance_box_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__Provenance_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%vstd!raw_ptr.Provenance.)
    (= x (Poly%vstd!raw_ptr.Provenance. (%Poly%vstd!raw_ptr.Provenance. x)))
   )
   :pattern ((has_type x TYPE%vstd!raw_ptr.Provenance.))
   :qid internal_vstd__raw_ptr__Provenance_unbox_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__Provenance_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!raw_ptr.Provenance.)) (!
   (has_type (Poly%vstd!raw_ptr.Provenance. x) TYPE%vstd!raw_ptr.Provenance.)
   :pattern ((has_type (Poly%vstd!raw_ptr.Provenance. x) TYPE%vstd!raw_ptr.Provenance.))
   :qid internal_vstd__raw_ptr__Provenance_has_type_always_definition
   :skolemid skolem_internal_vstd__raw_ptr__Provenance_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (= x (%Poly%vstd!seq.Seq<u8.>. (Poly%vstd!seq.Seq<u8.>. x)))
   :pattern ((Poly%vstd!seq.Seq<u8.>. x))
   :qid internal_vstd__seq__Seq<u8.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (UINT 8)))
    (= x (Poly%vstd!seq.Seq<u8.>. (%Poly%vstd!seq.Seq<u8.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8)))
   :pattern ((has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./usize.>.>.)) (!
   (= x (%Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. x))
   :qid internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)))
    (= x (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (%Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))))
   :qid internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./usize.>.>.)) (!
   (has_type (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. x) (TYPE%vstd!seq.Seq. (DST $)
     (TYPE%tuple%2. $ USIZE $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. x) (TYPE%vstd!seq.Seq.
      (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   )))
   :qid internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
     (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
     x
   ))
   :qid internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)))
    (= x (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
      (%Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))))
   :qid internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
     x
    ) (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.
      x
     ) (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
   ))
   :qid internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<tuple__2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (= x (%Poly%vstd!set.Set<usize.>. (Poly%vstd!set.Set<usize.>. x)))
   :pattern ((Poly%vstd!set.Set<usize.>. x))
   :qid internal_vstd__set__Set<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ USIZE))
    (= x (Poly%vstd!set.Set<usize.>. (%Poly%vstd!set.Set<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE))
   :pattern ((has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.))
  (!
   (= x (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
     (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
      x
   )))
   :pattern ((Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
     x
   ))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.))
    (= x (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
      (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.))
  (!
   (has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
     x
    ) (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
   )
   :pattern ((has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.
      x
     ) (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
   ))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.))
  (!
   (= x (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
     (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
      x
   )))
   :pattern ((Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
     x
   ))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.))
    (= x (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
      (%Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.))
  (!
   (has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
     x
    ) (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
   )
   :pattern ((has_type (Poly%vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.
      x
     ) (TYPE%vstd!set.Set. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
   ))
   :qid internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= x (%Poly%vstd!raw_ptr.PtrData. (Poly%vstd!raw_ptr.PtrData. x)))
   :pattern ((Poly%vstd!raw_ptr.PtrData. x))
   :qid internal_vstd__raw_ptr__PtrData_box_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__PtrData_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (= x (Poly%vstd!raw_ptr.PtrData. (%Poly%vstd!raw_ptr.PtrData. x)))
   )
   :pattern ((has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&)))
   :qid internal_vstd__raw_ptr__PtrData_unbox_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__PtrData_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_addr! Int) (_provenance! vstd!raw_ptr.Provenance.) (
    _metadata! Poly
   )
  ) (!
   (=>
    (and
     (uInv SZ _addr!)
     (has_type _metadata! (pointee_metadata% T&.))
    )
    (has_type (Poly%vstd!raw_ptr.PtrData. (vstd!raw_ptr.PtrData./PtrData _addr! _provenance!
       _metadata!
      )
     ) (TYPE%vstd!raw_ptr.PtrData. T&. T&)
   ))
   :pattern ((has_type (Poly%vstd!raw_ptr.PtrData. (vstd!raw_ptr.PtrData./PtrData _addr!
       _provenance! _metadata!
      )
     ) (TYPE%vstd!raw_ptr.PtrData. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.PtrData./PtrData_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData_constructor_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= (vstd!raw_ptr.PtrData./PtrData/addr x) (vstd!raw_ptr.PtrData./PtrData/?addr x))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/addr x))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/addr_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/addr_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (uInv SZ (vstd!raw_ptr.PtrData./PtrData/addr (%Poly%vstd!raw_ptr.PtrData. x)))
   )
   :pattern ((vstd!raw_ptr.PtrData./PtrData/addr (%Poly%vstd!raw_ptr.PtrData. x)) (has_type
     x (TYPE%vstd!raw_ptr.PtrData. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/addr_invariant_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/addr_invariant_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= (vstd!raw_ptr.PtrData./PtrData/provenance x) (vstd!raw_ptr.PtrData./PtrData/?provenance
     x
   ))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/provenance x))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/provenance_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/provenance_accessor_definition
)))
(assert
 (forall ((x vstd!raw_ptr.PtrData.)) (!
   (= (vstd!raw_ptr.PtrData./PtrData/metadata x) (vstd!raw_ptr.PtrData./PtrData/?metadata
     x
   ))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/metadata x))
   :qid internal_vstd!raw_ptr.PtrData./PtrData/metadata_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/metadata_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (has_type (vstd!raw_ptr.PtrData./PtrData/metadata (%Poly%vstd!raw_ptr.PtrData. x))
     (pointee_metadata% T&.)
   ))
   :pattern ((vstd!raw_ptr.PtrData./PtrData/metadata (%Poly%vstd!raw_ptr.PtrData. x))
    (has_type x (TYPE%vstd!raw_ptr.PtrData. T&. T&))
   )
   :qid internal_vstd!raw_ptr.PtrData./PtrData/metadata_invariant_definition
   :skolemid skolem_internal_vstd!raw_ptr.PtrData./PtrData/metadata_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Writes_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Writes_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. x)
   )))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Writes_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Writes_unbox_axiom_definition
)))
(assert
 (forall ((_core! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
   (_tso! vstd!set.Set<usize.>.) (_nonpos! vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.>.)
  ) (!
   (=>
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      _core!
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes _core!
       _tso! _nonpos!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes _core!
       _tso! _nonpos!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/?core
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. x)
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/?tso
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/nonpos
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/?nonpos
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/nonpos
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/nonpos_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/nonpos_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTMem_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTMem_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem. (
       %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem. x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTMem_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTMem_unbox_axiom_definition
)))
(assert
 (forall ((_mem! vstd!map.Map<usize./usize.>.) (_pml4! Int)) (!
   (=>
    (uInv SZ _pml4!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem _mem!
       _pml4!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem _mem!
       _pml4!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/mem
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/?mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/mem
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/mem_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/?pml4
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem. x)
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem./PTMem/pml4_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. (
      Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__GPDE_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__GPDE_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__GPDE_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__GPDE_unbox_axiom_definition
)))
(assert
 (forall ((_addr! Int) (_P! Bool) (_RW! Bool) (_US! Bool) (_PWT! Bool) (_PCD! Bool)
   (_XD! Bool)
  ) (!
   (=>
    (uInv SZ _addr!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory _addr!
       _P! _RW! _US! _PWT! _PCD! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory _addr!
       _P! _RW! _US! _PWT! _PCD! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?addr
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. x)
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/P
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?P
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/P
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/P_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/P_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/RW
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?RW
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/RW
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/RW_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/RW_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/US
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?US
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/US
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/US_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/US_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PWT
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?PWT
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PWT
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PWT_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PWT_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PCD
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?PCD
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PCD
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PCD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PCD_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/XD
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/?XD
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/XD
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/XD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/XD_accessor_definition
)))
(assert
 (forall ((_addr! Int) (_P! Bool) (_RW! Bool) (_US! Bool) (_PWT! Bool) (_PCD! Bool)
   (_G! Bool) (_PAT! Bool) (_XD! Bool)
  ) (!
   (=>
    (uInv SZ _addr!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page _addr!
       _P! _RW! _US! _PWT! _PCD! _G! _PAT! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page _addr!
       _P! _RW! _US! _PWT! _PCD! _G! _PAT! _XD!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?addr
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. x)
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/P x)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?P x)
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/P
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/P_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/P_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/RW x)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?RW x)
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/RW
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/RW_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/RW_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/US x)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?US x)
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/US
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/US_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/US_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PWT
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?PWT
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PWT
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PWT_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PWT_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PCD
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?PCD
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PCD
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PCD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PCD_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/G x)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?G x)
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/G
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/G_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/G_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PAT
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?PAT
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PAT
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PAT_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PAT_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/XD x)
    (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/?XD x)
   )
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/XD
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/XD_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/XD_accessor_definition
)))
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
   NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Invalid
  ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (
      Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Core_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Core_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Core_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Core_unbox_axiom_definition
)))
(assert
 (forall ((_node_id! Int) (_core_id! Int)) (!
   (=>
    (and
     (<= 0 _node_id!)
     (<= 0 _core_id!)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core _node_id!
       _core_id!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core _node_id!
       _core_id!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/?node_id
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. x)
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/node_id_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/?core_id
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. x)
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./Core/core_id_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__MemRegion_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__MemRegion_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__MemRegion_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__MemRegion_unbox_axiom_definition
)))
(assert
 (forall ((_base! Int) (_size! Int)) (!
   (=>
    (and
     (<= 0 _base!)
     (<= 0 _size!)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion
       _base! _size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion
       _base! _size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/?base
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/base_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/?size
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion./MemRegion/size_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags. (
       %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags. x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags_unbox_axiom_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_writable
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/?is_writable
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_writable
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_writable_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_writable_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_supervisor
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/?is_supervisor
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_supervisor
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_supervisor_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/is_supervisor_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/disable_execute
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/?disable_execute
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/disable_execute
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/disable_execute_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags./Flags/disable_execute_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.))
  (!
   (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
     x
    ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
   )
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
      x
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags_has_type_always_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags_has_type_always_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
      x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTE_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTE_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE. (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTE_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__PTE_unbox_axiom_definition
)))
(assert
 (forall ((_frame! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.)
   (_flags! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
  ) (!
   (=>
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
      _frame!
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE _frame!
       _flags!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE _frame!
       _flags!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/?frame
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.
        x
      ))
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MemRegion.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/frame_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/flags
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/?flags
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/flags
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/flags_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE./PTE/flags_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Polarity_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Polarity_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity. x)
   )))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Polarity_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Polarity_unbox_axiom_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.))
  (!
   (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
     x
    ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
   )
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
      x
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Polarity_has_type_always_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Polarity_has_type_always_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk. (
      Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk. x
   )))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Walk_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Walk_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk. (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Walk_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Walk_unbox_axiom_definition
)))
(assert
 (forall ((_vaddr! Int) (_path! vstd!seq.Seq<tuple%2<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.>.>.)
   (_complete! Bool)
  ) (!
   (=>
    (uInv SZ _vaddr!)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk _vaddr!
       _path! _complete!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk _vaddr!
       _path! _complete!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/?vaddr
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk. x)
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/vaddr_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/path
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/?path
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/path
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/path_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/path_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/complete
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/?complete
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/complete
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/complete_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk./Walk/complete_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Constants_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Constants_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
       x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Constants_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Constants_unbox_axiom_definition
)))
(assert
 (forall ((_node_count! Int) (_core_count! Int) (_range_ptmem! tuple%2.) (_range_mem!
    tuple%2.
   ) (_phys_mem_size! Int)
  ) (!
   (=>
    (and
     (<= 0 _node_count!)
     (<= 0 _core_count!)
     (has_type (Poly%tuple%2. _range_ptmem!) (TYPE%tuple%2. $ NAT $ NAT))
     (has_type (Poly%tuple%2. _range_mem!) (TYPE%tuple%2. $ NAT $ NAT))
     (<= 0 _phys_mem_size!)
    )
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants
       _node_count! _core_count! _range_ptmem! _range_mem! _phys_mem_size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants
       _node_count! _core_count! _range_ptmem! _range_mem! _phys_mem_size!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?node_count
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/node_count_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?core_count
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/core_count_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?range_ptmem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
    (has_type (Poly%tuple%2. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem
       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
        x
      ))
     ) (TYPE%tuple%2. $ NAT $ NAT)
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_ptmem_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?range_mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
    (has_type (Poly%tuple%2. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem
       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
        x
      ))
     ) (TYPE%tuple%2. $ NAT $ NAT)
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/range_mem_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/?phys_mem_size
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
    (<= 0 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
       x
   ))))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
      x
     )
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants./Constants/phys_mem_size_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (
       %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. x
   ))))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State_unbox_axiom_definition
)))
(assert
 (forall ((_happy! Bool) (_phys_mem! vstd!seq.Seq<u8.>.) (_pt_mem! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.)
   (_tlbs! vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!map.Map<usize./NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTE.>.>.)
   (_walks! vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!set.Set<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Walk.>.>.)
   (_sbuf! vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.)
   (_writes! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.)
   (_polarity! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Polarity.)
   (_hist! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.)
  ) (!
   (=>
    (and
     (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
       _pt_mem!
      ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
     )
     (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
       _writes!
      ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
    ))
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State _happy!
       _phys_mem! _pt_mem! _tlbs! _walks! _sbuf! _writes! _polarity! _hist!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
   ))
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State _happy!
       _phys_mem! _pt_mem! _tlbs! _walks! _sbuf! _writes! _polarity! _hist!
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State_constructor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State_constructor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/happy
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?happy
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/happy
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/happy_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/happy_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/phys_mem
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?phys_mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/phys_mem
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/phys_mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/phys_mem_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?pt_mem
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem
       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. x)
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!PTMem.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/pt_mem_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/tlbs
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?tlbs
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/tlbs
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/tlbs_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/tlbs_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/walks
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?walks
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/walks
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/walks_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/walks_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?sbuf
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?writes
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.)
    (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. x)
      )
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
     (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. x)
    ) (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.)
   )
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes_invariant_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes_invariant_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/polarity
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?polarity
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/polarity
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/polarity_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/polarity_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/hist
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/?hist
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/hist
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/hist_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/hist_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.))
  (!
   (= x (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
     (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History. x)
   ))
   :pattern ((Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__History_box_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__History_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.)
    (= x (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History. x)
   )))
   :pattern ((has_type x TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__History_unbox_axiom_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__History_unbox_axiom_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_maps
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/?pending_maps
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_maps
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_maps_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_maps_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.))
  (!
   (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_unmaps
     x
    ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/?pending_unmaps
     x
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_unmaps
     x
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_unmaps_accessor_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History./History/pending_unmaps_accessor_definition
)))
(assert
 (forall ((x NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.))
  (!
   (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
     x
    ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
   )
   :pattern ((has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
      x
     ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!History.
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__History_has_type_always_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__History_has_type_always_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= x (%Poly%tuple%1. (Poly%tuple%1. x)))
   :pattern ((Poly%tuple%1. x))
   :qid internal_crate__tuple__1_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (= x (Poly%tuple%1. (%Poly%tuple%1. x)))
   )
   :pattern ((has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__tuple__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T%0&)
    (has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1_constructor_definition
   :skolemid skolem_internal_tuple__1./tuple__1_constructor_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= (tuple%1./tuple%1/0 x) (tuple%1./tuple%1/?0 x))
   :pattern ((tuple%1./tuple%1/0 x))
   :qid internal_tuple__1./tuple__1/0_accessor_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (has_type (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) T%0&)
   )
   :pattern ((tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1/0_invariant_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_invariant_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (=>
    (is-tuple%1./tuple%1 x)
    (height_lt (height (tuple%1./tuple%1/0 x)) (height (Poly%tuple%1. x)))
   )
   :pattern ((height (tuple%1./tuple%1/0 x)))
   :qid prelude_datatype_height_tuple%1./tuple%1/0
   :skolemid skolem_prelude_datatype_height_tuple%1./tuple%1/0
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%tuple%1. T%0&. T%0&))
     (has_type y (TYPE%tuple%1. T%0&. T%0&))
     (ext_eq deep T%0& (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (tuple%1./tuple%1/0 (%Poly%tuple%1.
        y
    ))))
    (ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y))
   :qid internal_tuple__1./tuple__1_ext_equal_definition
   :skolemid skolem_internal_tuple__1./tuple__1_ext_equal_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(assert
 (forall ((x fndef) (Self%&. Dcr) (Self%& Type)) (!
   (has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&))
   :pattern ((has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&)))
   :qid prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
   :skolemid skolem_prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!slice.SliceAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!slice.SliceAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__slice__SliceAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__slice__SliceAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%core!clone.Clone. Self%&. Self%&))
   :qid internal_core__clone__Clone_trait_type_bounds_definition
   :skolemid skolem_internal_core__clone__Clone_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. Self%&. Self%&)
    (tr_bound%core!clone.Clone. Self%&. Self%&)
   )
   :pattern ((tr_bound%core!marker.Copy. Self%&. Self%&))
   :qid internal_core__marker__Copy_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Copy_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.
     Self%&. Self%&
    )
    (and
     (sized Self%&.)
     (sized (proj%%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
       Self%&. Self%&
   ))))
   :pattern ((tr_bound%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.
     Self%&. Self%&
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__SeqTupExt_trait_type_bounds_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__SeqTupExt_trait_type_bounds_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%vstd!view.View./V $ (PTR T&. T&)) $)
   :pattern ((proj%%vstd!view.View./V $ (PTR T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%vstd!view.View./V $ (PTR T&. T&)) (TYPE%vstd!raw_ptr.PtrData. T&. T&))
   :pattern ((proj%vstd!view.View./V $ (PTR T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)) $)
   :pattern ((proj%%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)) (TYPE%vstd!raw_ptr.PtrData.
     T&. T&
   ))
   :pattern ((proj%vstd!view.View./V (CONST_PTR $) (PTR T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__raw_ptr__impl&__3_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%vstd!view.View./V $slice (SLICE T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $slice (SLICE T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%vstd!view.View./V $slice (SLICE T&. T&)) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((proj%vstd!view.View./V $slice (SLICE T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__slice__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 8)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 8)) (UINT 8))
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 16)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 16)) (UINT 16))
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 32)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 32)) (UINT 32))
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 64)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 64)) (UINT 64))
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 128)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 128)) (UINT 128))
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 8)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 8)) (SINT 8))
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 16)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 16)) (SINT 16))
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 32)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 32)) (SINT 32))
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 64)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 64)) (SINT 64))
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 128)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 128)) (SINT 128))
)
(assert
 (= (proj%%vstd!view.View./V $ ISIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ ISIZE) ISIZE)
)
(assert
 (= (proj%%vstd!view.View./V $ CHAR) $)
)
(assert
 (= (proj%vstd!view.View./V $ CHAR) CHAR)
)
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (DST (proj%%vstd!view.View./V
       A0&. A0&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (= (proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)) (TYPE%tuple%1. (proj%%vstd!view.View./V
       A0&. A0&
      ) (proj%vstd!view.View./V A0&. A0&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__46_assoc_type_impl_false_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST (proj%%vstd!view.View./V
       A1&. A1&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&) (proj%%vstd!view.View./V
       A1&. A1&
      ) (proj%vstd!view.View./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (and
     (sized A&.)
     (sized B&.)
    )
    (= (proj%%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
      $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&))
     ) A&.
   ))
   :pattern ((proj%%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
     $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&))
   ))
   :qid internal_proj____NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__impl&__8_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__impl&__8_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (and
     (sized A&.)
     (sized B&.)
    )
    (= (proj%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
      $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&))
     ) A&
   ))
   :pattern ((proj%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
     $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&))
   ))
   :qid internal_proj__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__impl&__8_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__impl&__8_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 8))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 8))
  ) (UINT 8)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 8))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 8))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 8))
  ) (SINT 8)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 16))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 16))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 16))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 16))
  ) (UINT 16)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 16))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 16))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 16))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 16))
  ) (SINT 16)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 32))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 32))
  ) (UINT 32)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
  ) (SINT 32)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
  ) (UINT 64)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 64))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 64))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 64))
  ) (SINT 64)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 128))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 128))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (UINT 128))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 128))
  ) (UINT 128)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 128))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 128))
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ (SINT 128))
   (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 128))
  ) (SINT 128)
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) USIZE
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ ISIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) ISIZE)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ ISIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) ISIZE)
  ) ISIZE
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
       Self%&
      ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&.
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
      (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) BOOL
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ CHAR)
   (DST (REF $)) (TYPE%tuple%1. (REF $) CHAR)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ CHAR)
   (DST (REF $)) (TYPE%tuple%1. (REF $) CHAR)
  ) CHAR
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) (REF T&.)
   )
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       REF T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) T&
   )
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF
       T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
        T&.
       ) T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) (TRACKED T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       TRACKED T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
       T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) (GHOST T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       GHOST T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&.
        A& T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) (BOX A&. A& T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       BOX A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
        T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX
       A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
  ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
  ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.Seq.empty.? (Dcr Type) Poly)
(declare-fun vstd!seq.Seq.push.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!set.Set.empty.? (Dcr Type) Poly)
(declare-fun vstd!slice.spec_slice_len.? (Dcr Type Poly) Int)
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)
(declare-fun vstd!slice.len%returns_clause_autospec.? (Dcr Type Poly) Int)
(declare-fun vstd!slice.SliceAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type Poly
  Poly
 ) Poly
)
(declare-fun vstd!slice.SliceAdditionalSpecFns.spec_index%default%.? (Dcr Type Dcr
  Type Poly Poly
 ) Poly
)
(declare-fun vstd!raw_ptr.view_reverse_for_eq.? (Dcr Type Poly) Poly)
(declare-fun vstd!raw_ptr.view_reverse_for_eq_sized.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!layout.size_of.? (Dcr Type) Int)
(declare-fun vstd!layout.align_of.? (Dcr Type) Int)
(declare-fun vstd!arithmetic.power2.is_pow2.? (Poly) Bool)
(declare-fun vstd!pervasive.strictly_cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!pervasive.cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?
 () Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%7.valid_core.?
 (Poly Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?
 (Dcr Type Poly Poly) Poly
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst%default%.?
 (Dcr Type Poly Poly) Poly
)
(declare-fun vstd!seq_lib.impl&%0.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.?
 (Poly) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.?
 (Poly) Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.?
 () Int
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%9.writer_sbuf.?
 (Poly) vstd!seq.Seq<tuple%2<usize./usize.>.>.
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.?
 (Poly Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.?
 (Poly) Bool
)
(declare-fun NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.?
 (Poly Poly) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!seq.Seq.empty.? A&. A&) (TYPE%vstd!seq.Seq. A&. A&))
   :pattern ((vstd!seq.Seq.empty.? A&. A&))
   :qid internal_vstd!seq.Seq.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.empty.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_empty.)
  (forall ((A&. Dcr) (A& Type)) (!
    (=>
     (sized A&.)
     (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)) 0)
    )
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)))
    :qid user_vstd__seq__lemma_seq_empty_0
    :skolemid skolem_user_vstd__seq__lemma_seq_empty_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!seq.Seq.push.? A&. A& self! a!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.push.? A&. A& self! a!))
   :qid internal_vstd!seq.Seq.push.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.push.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)) (nClip (Add (vstd!seq.Seq.len.?
          A&. A& s!
         ) 1
    )))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!)))
    :qid user_vstd__seq__lemma_seq_push_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (= (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) a!)
    ))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_same_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_push_index_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type a! A&)
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (< (%I i!) (vstd!seq.Seq.len.? A&. A& s!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!) (vstd!seq.Seq.index.?
        A&. A& s! i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.push.? A&. A& s! a!) i!))
    :qid user_vstd__seq__lemma_seq_push_index_different_0
    :skolemid skolem_user_vstd__seq__lemma_seq_push_index_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%2
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%3
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_decreases_to_entry.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
           K& V&. V& m! key!
        )))
       ) (height m!)
    )))
    :pattern ((height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
         K& V&. V& m! key!
    )))))
    :qid user_vstd__map__axiom_map_decreases_to_entry_0
    :skolemid skolem_user_vstd__map__axiom_map_decreases_to_entry_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!set.Set.empty.? A&. A&) (TYPE%vstd!set.Set. A&. A&))
   :pattern ((vstd!set.Set.empty.? A&. A&))
   :qid internal_vstd!set.Set.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.Set.empty.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_empty.)
  (forall ((A&. Dcr) (A& Type) (a! Poly)) (!
    (=>
     (has_type a! A&)
     (=>
      (sized A&.)
      (not (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.empty.?
          A&. A&
         )
        ) a!
    ))))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.empty.?
        A&. A&
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_empty_0
    :skolemid skolem_user_vstd__set__lemma_set_empty_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
   (=>
    (has_type slice! (SLICE T&. T&))
    (uInv SZ (vstd!slice.spec_slice_len.? T&. T& slice!))
   )
   :pattern ((vstd!slice.spec_slice_len.? T&. T& slice!))
   :qid internal_vstd!slice.spec_slice_len.?_pre_post_definition
   :skolemid skolem_internal_vstd!slice.spec_slice_len.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!view.View. $slice (SLICE T&. T&))
   )
   :pattern ((tr_bound%vstd!view.View. $slice (SLICE T&. T&)))
   :qid internal_vstd__slice__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__slice__impl&__0_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_spec_len.)
  (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
    (=>
     (has_type slice! (SLICE T&. T&))
     (=>
      (sized T&.)
      (= (vstd!slice.spec_slice_len.? T&. T& slice!) (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.?
         $slice (SLICE T&. T&) slice!
    )))))
    :pattern ((vstd!slice.spec_slice_len.? T&. T& slice!))
    :qid user_vstd__slice__axiom_spec_len_0
    :skolemid skolem_user_vstd__slice__axiom_spec_len_0
))))
(assert
 (fuel_bool_default fuel%vstd!slice.len%returns_clause_autospec.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!slice.len%returns_clause_autospec.)
  (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
    (= (vstd!slice.len%returns_clause_autospec.? T&. T& slice!) (vstd!slice.spec_slice_len.?
      T&. T& slice!
    ))
    :pattern ((vstd!slice.len%returns_clause_autospec.? T&. T& slice!))
    :qid internal_vstd!slice.len__returns_clause_autospec.?_definition
    :skolemid skolem_internal_vstd!slice.len__returns_clause_autospec.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (slice! Poly)) (!
   (=>
    (has_type slice! (SLICE T&. T&))
    (uInv SZ (vstd!slice.len%returns_clause_autospec.? T&. T& slice!))
   )
   :pattern ((vstd!slice.len%returns_clause_autospec.? T&. T& slice!))
   :qid internal_vstd!slice.len__returns_clause_autospec.?_pre_post_definition
   :skolemid skolem_internal_vstd!slice.len__returns_clause_autospec.?_pre_post_definition
)))
(declare-fun req%vstd!slice.SliceAdditionalSpecFns.spec_index. (Dcr Type Dcr Type Poly
  Poly
 ) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!slice.SliceAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self! i!)
    (=>
     %%global_location_label%%4
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!slice.SliceAdditionalSpecFns.spec_index. Self%&. Self%& T&. T&
     self! i!
   ))
   :qid internal_req__vstd!slice.SliceAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!slice.SliceAdditionalSpecFns.spec_index._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!slice.SliceAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
      i!
     ) T&
   ))
   :pattern ((vstd!slice.SliceAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
     i!
   ))
   :qid internal_vstd!slice.SliceAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!slice.SliceAdditionalSpecFns.spec_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!slice.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!slice.impl&%2.spec_index.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!slice.SliceAdditionalSpecFns.spec_index.? $slice (SLICE T&. T&) T&. T& self!
       i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) self!)
       i!
    )))
    :pattern ((vstd!slice.SliceAdditionalSpecFns.spec_index.? $slice (SLICE T&. T&) T&.
      T& self! i!
    ))
    :qid internal_vstd!slice.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!slice.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!slice.SliceAdditionalSpecFns. $slice (SLICE T&. T&) T&. T&)
   )
   :pattern ((tr_bound%vstd!slice.SliceAdditionalSpecFns. $slice (SLICE T&. T&) T&. T&))
   :qid internal_vstd__slice__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__slice__impl&__2_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_slice_ext_equal.)
  (forall ((T&. Dcr) (T& Type) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type a1! (SLICE T&. T&))
      (has_type a2! (SLICE T&. T&))
     )
     (=>
      (sized T&.)
      (= (ext_eq false (SLICE T&. T&) a1! a2!) (and
        (= (vstd!slice.len%returns_clause_autospec.? T&. T& a1!) (vstd!slice.len%returns_clause_autospec.?
          T&. T& a2!
        ))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!slice.len%returns_clause_autospec.? T&. T& a1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) a1!) i$)
             (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) a2!) i$)
          )))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&)
             a1!
            ) i$
          ))
          :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&)
             a2!
            ) i$
          ))
          :qid user_vstd__slice__axiom_slice_ext_equal_0
          :skolemid skolem_user_vstd__slice__axiom_slice_ext_equal_0
    ))))))
    :pattern ((ext_eq false (SLICE T&. T&) a1! a2!))
    :qid user_vstd__slice__axiom_slice_ext_equal_1
    :skolemid skolem_user_vstd__slice__axiom_slice_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_slice_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (slice! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type slice! (SLICE T&. T&))
      (has_type i! INT)
     )
     (=>
      (sized T&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!slice.spec_slice_len.? T&. T& slice!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $slice (SLICE T&. T&) slice!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE
            T&. T&
           ) slice!
          ) i!
    ))))))
    :pattern ((has_resolved $slice (SLICE T&. T&) slice!) (vstd!seq.Seq.index.? T&. T&
      (vstd!view.View.view.? $slice (SLICE T&. T&) slice!) i!
    ))
    :qid user_vstd__slice__axiom_slice_has_resolved_0
    :skolemid skolem_user_vstd__slice__axiom_slice_has_resolved_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!slice.axiom_slice_decreases_to_seq.)
  (forall ((T&. Dcr) (T& Type) (s! Poly)) (!
    (=>
     (has_type s! (SLICE T&. T&))
     (=>
      (sized T&.)
      (height_lt (height (vstd!view.View.view.? $slice (SLICE T&. T&) s!)) (height s!))
    ))
    :pattern ((height (vstd!view.View.view.? $slice (SLICE T&. T&) s!)))
    :qid user_vstd__slice__axiom_slice_decreases_to_seq_0
    :skolemid skolem_user_vstd__slice__axiom_slice_decreases_to_seq_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!slice.lemma_slice_index_decreases.)
  (forall ((T&. Dcr) (T& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (SLICE T&. T&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized T&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $slice (SLICE T&. T&) s!))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&.
           T&
          ) s!
         ) i!
        )
       ) (height s!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $slice (SLICE T&.
         T&
        ) s!
       ) i!
    )))
    :qid user_vstd__slice__lemma_slice_index_decreases_0
    :skolemid skolem_user_vstd__slice__lemma_slice_index_decreases_0
))))
(assert
 (forall ((T&. Dcr) (T& Type) (data! Poly)) (!
   (=>
    (has_type data! (TYPE%vstd!raw_ptr.PtrData. T&. T&))
    (has_type (vstd!raw_ptr.view_reverse_for_eq.? T&. T& data!) (PTR T&. T&))
   )
   :pattern ((vstd!raw_ptr.view_reverse_for_eq.? T&. T& data!))
   :qid internal_vstd!raw_ptr.view_reverse_for_eq.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.view_reverse_for_eq.?_pre_post_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%vstd!view.View. $ (PTR T&. T&))
   :pattern ((tr_bound%vstd!view.View. $ (PTR T&. T&)))
   :qid internal_vstd__raw_ptr__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__raw_ptr__impl&__2_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.ptrs_mut_eq.)
  (forall ((T&. Dcr) (T& Type) (a! Poly)) (!
    (=>
     (has_type a! (PTR T&. T&))
     (= (vstd!raw_ptr.view_reverse_for_eq.? T&. T& (vstd!view.View.view.? $ (PTR T&. T&)
        a!
       )
      ) a!
    ))
    :pattern ((vstd!view.View.view.? $ (PTR T&. T&) a!))
    :qid user_vstd__raw_ptr__ptrs_mut_eq_0
    :skolemid skolem_user_vstd__raw_ptr__ptrs_mut_eq_0
))))
(assert
 (forall ((T&. Dcr) (T& Type) (addr! Poly) (provenance! Poly)) (!
   (=>
    (and
     (has_type addr! USIZE)
     (has_type provenance! TYPE%vstd!raw_ptr.Provenance.)
    )
    (has_type (vstd!raw_ptr.view_reverse_for_eq_sized.? T&. T& addr! provenance!) (PTR
      T&. T&
   )))
   :pattern ((vstd!raw_ptr.view_reverse_for_eq_sized.? T&. T& addr! provenance!))
   :qid internal_vstd!raw_ptr.view_reverse_for_eq_sized.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.view_reverse_for_eq_sized.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.ptrs_mut_eq_sized.)
  (forall ((T&. Dcr) (T& Type) (a! Poly)) (!
    (=>
     (has_type a! (PTR T&. T&))
     (=>
      (sized T&.)
      (= (vstd!raw_ptr.view_reverse_for_eq_sized.? T&. T& (I (vstd!raw_ptr.PtrData./PtrData/addr
          (%Poly%vstd!raw_ptr.PtrData. (vstd!view.View.view.? $ (PTR T&. T&) a!))
         )
        ) (Poly%vstd!raw_ptr.Provenance. (vstd!raw_ptr.PtrData./PtrData/provenance (%Poly%vstd!raw_ptr.PtrData.
           (vstd!view.View.view.? $ (PTR T&. T&) a!)
        )))
       ) a!
    )))
    :pattern ((vstd!view.View.view.? $ (PTR T&. T&) a!))
    :qid user_vstd__raw_ptr__ptrs_mut_eq_sized_0
    :skolemid skolem_user_vstd__raw_ptr__ptrs_mut_eq_sized_0
))))
(assert
 (forall ((V&. Dcr) (V& Type)) (!
   (<= 0 (vstd!layout.size_of.? V&. V&))
   :pattern ((vstd!layout.size_of.? V&. V&))
   :qid internal_vstd!layout.size_of.?_pre_post_definition
   :skolemid skolem_internal_vstd!layout.size_of.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!layout.layout_of_primitives.)
  (and
   (and
    (and
     (and
      (and
       (and
        (and
         (and
          (= (vstd!layout.size_of.? $ BOOL) 1)
          (= (vstd!layout.size_of.? $ CHAR) 4)
         )
         (let
          ((tmp%%$ (vstd!layout.size_of.? $ (UINT 8))))
          (let
           ((tmp%%$1 (vstd!layout.size_of.? $ (SINT 8))))
           (let
            ((tmp%%$2 1))
            (and
             (= tmp%%$ tmp%%$1)
             (= tmp%%$1 tmp%%$2)
        )))))
        (let
         ((tmp%%$ (vstd!layout.size_of.? $ (UINT 16))))
         (let
          ((tmp%%$4 (vstd!layout.size_of.? $ (SINT 16))))
          (let
           ((tmp%%$5 2))
           (and
            (= tmp%%$ tmp%%$4)
            (= tmp%%$4 tmp%%$5)
       )))))
       (let
        ((tmp%%$ (vstd!layout.size_of.? $ (UINT 32))))
        (let
         ((tmp%%$7 (vstd!layout.size_of.? $ (SINT 32))))
         (let
          ((tmp%%$8 4))
          (and
           (= tmp%%$ tmp%%$7)
           (= tmp%%$7 tmp%%$8)
      )))))
      (let
       ((tmp%%$ (vstd!layout.size_of.? $ (UINT 64))))
       (let
        ((tmp%%$10 (vstd!layout.size_of.? $ (SINT 64))))
        (let
         ((tmp%%$11 8))
         (and
          (= tmp%%$ tmp%%$10)
          (= tmp%%$10 tmp%%$11)
     )))))
     (let
      ((tmp%%$ (vstd!layout.size_of.? $ (UINT 128))))
      (let
       ((tmp%%$13 (vstd!layout.size_of.? $ (SINT 128))))
       (let
        ((tmp%%$14 16))
        (and
         (= tmp%%$ tmp%%$13)
         (= tmp%%$13 tmp%%$14)
    )))))
    (= (vstd!layout.size_of.? $ USIZE) (vstd!layout.size_of.? $ ISIZE))
   )
   (= (nClip (Mul (vstd!layout.size_of.? $ USIZE) 8)) SZ)
)))
(assert
 (forall ((V&. Dcr) (V& Type)) (!
   (<= 0 (vstd!layout.align_of.? V&. V&))
   :pattern ((vstd!layout.align_of.? V&. V&))
   :qid internal_vstd!layout.align_of.?_pre_post_definition
   :skolemid skolem_internal_vstd!layout.align_of.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!layout.layout_of_unit_tuple.)
  (and
   (= (vstd!layout.size_of.? $ TYPE%tuple%0.) 0)
   (= (vstd!layout.align_of.? $ TYPE%tuple%0.) 1)
)))
(assert
 (=>
  (fuel_bool fuel%vstd!layout.layout_of_references_and_pointers.)
  (forall ((T&. Dcr) (T& Type)) (!
    (and
     (let
      ((tmp%%$ (vstd!layout.size_of.? $ (PTR T&. T&))))
      (let
       ((tmp%%$1 (vstd!layout.size_of.? (CONST_PTR $) (PTR T&. T&))))
       (let
        ((tmp%%$2 (vstd!layout.size_of.? (REF T&.) T&)))
        (and
         (= tmp%%$ tmp%%$1)
         (= tmp%%$1 tmp%%$2)
     ))))
     (let
      ((tmp%%$ (vstd!layout.align_of.? $ (PTR T&. T&))))
      (let
       ((tmp%%$4 (vstd!layout.align_of.? (CONST_PTR $) (PTR T&. T&))))
       (let
        ((tmp%%$5 (vstd!layout.align_of.? (REF T&.) T&)))
        (and
         (= tmp%%$ tmp%%$4)
         (= tmp%%$4 tmp%%$5)
    )))))
    :pattern ((vstd!layout.size_of.? $ (PTR T&. T&)))
    :pattern ((vstd!layout.size_of.? (CONST_PTR $) (PTR T&. T&)))
    :pattern ((vstd!layout.size_of.? (REF T&.) T&))
    :pattern ((vstd!layout.align_of.? $ (PTR T&. T&)))
    :pattern ((vstd!layout.align_of.? (CONST_PTR $) (PTR T&. T&)))
    :pattern ((vstd!layout.align_of.? (REF T&.) T&))
    :qid user_vstd__layout__layout_of_references_and_pointers_0
    :skolemid skolem_user_vstd__layout__layout_of_references_and_pointers_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!layout.layout_of_references_and_pointers_for_sized_types.)
  (forall ((T&. Dcr) (T& Type)) (!
    (=>
     (sized T&.)
     (and
      (= (vstd!layout.size_of.? $ (PTR T&. T&)) (vstd!layout.size_of.? $ USIZE))
      (= (vstd!layout.align_of.? $ (PTR T&. T&)) (vstd!layout.align_of.? $ USIZE))
    ))
    :pattern ((vstd!layout.size_of.? $ (PTR T&. T&)))
    :pattern ((vstd!layout.align_of.? $ (PTR T&. T&)))
    :qid user_vstd__layout__layout_of_references_and_pointers_for_sized_types_0
    :skolemid skolem_user_vstd__layout__layout_of_references_and_pointers_for_sized_types_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!layout.layout_of_references_and_pointers_for_unsized_types.)
  (forall ((T&. Dcr) (T& Type)) (!
    (and
     (>= (vstd!layout.size_of.? $ (PTR T&. T&)) (vstd!layout.size_of.? $ USIZE))
     (>= (vstd!layout.align_of.? $ (PTR T&. T&)) (vstd!layout.align_of.? $ USIZE))
    )
    :pattern ((vstd!layout.size_of.? $ (PTR T&. T&)))
    :pattern ((vstd!layout.align_of.? $ (PTR T&. T&)))
    :qid user_vstd__layout__layout_of_references_and_pointers_for_unsized_types_0
    :skolemid skolem_user_vstd__layout__layout_of_references_and_pointers_for_unsized_types_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!layout.align_properties.)
  (forall ((T&. Dcr) (T& Type)) (!
    (=>
     (sized T&.)
     (and
      (= (EucMod (vstd!layout.size_of.? T&. T&) (vstd!layout.align_of.? T&. T&)) 0)
      (vstd!arithmetic.power2.is_pow2.? (I (vstd!layout.align_of.? T&. T&)))
    ))
    :pattern ((vstd!layout.align_of.? T&. T&))
    :qid user_vstd__layout__align_properties_0
    :skolemid skolem_user_vstd__layout__align_properties_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!layout.align_nonzero.)
  (forall ((T&. Dcr) (T& Type)) (!
    (=>
     (sized T&.)
     (> (vstd!layout.align_of.? T&. T&) 0)
    )
    :pattern ((vstd!layout.align_of.? T&. T&))
    :qid user_vstd__layout__align_nonzero_0
    :skolemid skolem_user_vstd__layout__align_nonzero_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(declare-fun ens%core!clone.Clone.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (%return! Poly)) (!
   (= (ens%core!clone.Clone.clone. Self%&. Self%& self! %return!) (has_type %return! Self%&))
   :pattern ((ens%core!clone.Clone.clone. Self%&. Self%& self! %return!))
   :qid internal_ens__core!clone.Clone.clone._definition
   :skolemid skolem_internal_ens__core!clone.Clone.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (Self%&. Dcr) (Self%& Type)) (!
   (=>
    (has_type closure%$ (TYPE%tuple%1. (REF Self%&.) Self%&))
    (=>
     (let
      ((self$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      true
     )
     (closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.)) (TYPE%tuple%1.
       (REF Self%&.) Self%&
      ) (F fndef_singleton) closure%$
   )))
   :pattern ((closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.))
     (TYPE%tuple%1. (REF Self%&.) Self%&) (F fndef_singleton) closure%$
   ))
   :qid user_core__clone__Clone__clone_0
   :skolemid skolem_user_core__clone__Clone__clone_0
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%tuple%0.)
)
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Tuple1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. T%0&. T%0&)
    (tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Clone1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. T%0&. T%0&)
    (tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Copy1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
    )
    (tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Clone2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
    )
    (tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Copy2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy2_trait_impl_definition
)))
(declare-fun ens%core!clone.impls.impl&%12.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%12.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 8) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%12.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__12.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__12.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 8)))
     (has_type res$ (UINT 8))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 8)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 8)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%12__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%12__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%24.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%24.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (SINT 8) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%24.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__24.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__24.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (SINT 8)))
     (has_type res$ (SINT 8))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 8)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (SINT 8)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 8)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (SINT 8)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%24__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%24__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%14.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%14.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 16) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%14.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__14.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__14.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 16)))
     (has_type res$ (UINT 16))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 16)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 16)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 16)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 16)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%14__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%14__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%26.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%26.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (SINT 16) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%26.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__26.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__26.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (SINT 16)))
     (has_type res$ (SINT 16))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 16)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (SINT 16)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 16)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (SINT 16)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%26__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%26__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%16.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%16.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 32) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%16.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__16.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__16.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 32)))
     (has_type res$ (UINT 32))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 32)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 32)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 32)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 32)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%16__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%16__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%28.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%28.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (SINT 32) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%28.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__28.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__28.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (SINT 32)))
     (has_type res$ (SINT 32))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (SINT 32)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (SINT 32)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%28__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%28__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%18.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%18.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 64) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%18.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__18.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__18.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 64)))
     (has_type res$ (UINT 64))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 64)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (UINT 64)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%18__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%18__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%30.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%30.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (SINT 64) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%30.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__30.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__30.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (SINT 64)))
     (has_type res$ (SINT 64))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 64)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (SINT 64)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 64)) (DST (REF $)) (TYPE%tuple%1.
      (REF $) (SINT 64)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%30__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%30__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%20.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%20.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (UINT 128) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%20.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__20.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__20.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (UINT 128)))
     (has_type res$ (UINT 128))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 128)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (UINT 128)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (UINT 128)) (DST (REF $)) (
      TYPE%tuple%1. (REF $) (UINT 128)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%20__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%20__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%32.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%32.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ (SINT 128) x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%32.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__32.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__32.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) (SINT 128)))
     (has_type res$ (SINT 128))
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 128)) (DST (REF $)) (TYPE%tuple%1.
       (REF $) (SINT 128)
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ (SINT 128)) (DST (REF $)) (
      TYPE%tuple%1. (REF $) (SINT 128)
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%32__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%32__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%10.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%10.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ USIZE x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%10.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__10.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__10.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) USIZE))
     (has_type res$ USIZE)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1. (
        REF $
       ) USIZE
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1.
      (REF $) USIZE
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%10__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%10__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%22.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%22.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ ISIZE x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%22.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__22.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__22.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) ISIZE))
     (has_type res$ ISIZE)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ ISIZE) (DST (REF $)) (TYPE%tuple%1. (
        REF $
       ) ISIZE
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ ISIZE) (DST (REF $)) (TYPE%tuple%1.
      (REF $) ISIZE
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%22__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%22__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%42.clone. (Poly Poly) Bool)
(assert
 (forall ((b! Poly) (%return! Poly)) (!
   (= (ens%core!clone.impls.impl&%42.clone. b! %return!) (and
     (ens%core!clone.Clone.clone. $ BOOL b! %return!)
     (= %return! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%42.clone. b! %return!))
   :qid internal_ens__core!clone.impls.impl&__42.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__42.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) BOOL))
     (has_type %return$ BOOL)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1. (REF
        $
       ) BOOL
      ) (F fndef_singleton) closure%$ %return$
     )
     (let
      ((b$ (%B (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%B %return$) b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1.
      (REF $) BOOL
     ) (F fndef_singleton) closure%$ %return$
   ))
   :qid user_core__clone__impls__impl&%42__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%42__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%44.clone. (Poly Poly) Bool)
(assert
 (forall ((c! Poly) (%return! Poly)) (!
   (= (ens%core!clone.impls.impl&%44.clone. c! %return!) (and
     (ens%core!clone.Clone.clone. $ CHAR c! %return!)
     (= %return! c!)
   ))
   :pattern ((ens%core!clone.impls.impl&%44.clone. c! %return!))
   :qid internal_ens__core!clone.impls.impl&__44.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__44.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) CHAR))
     (has_type %return$ CHAR)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ CHAR) (DST (REF $)) (TYPE%tuple%1. (REF
        $
       ) CHAR
      ) (F fndef_singleton) closure%$ %return$
     )
     (let
      ((c$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I %return$) c$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ CHAR) (DST (REF $)) (TYPE%tuple%1.
      (REF $) CHAR
     ) (F fndef_singleton) closure%$ %return$
   ))
   :qid user_core__clone__impls__impl&%44__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%44__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%6.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (REF T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%6.clone. T&. T& b! res!))
   :qid internal_ens__core!clone.impls.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (REF T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.))) (TYPE%tuple%1.
       (REF (REF T&.)) T&
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.)))
     (TYPE%tuple%1. (REF (REF T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%6__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%6__clone_0
)))
(declare-fun ens%verus_builtin!impl&%9.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%9.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (TRACKED T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%9.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__9.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__9.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (TRACKED T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED T&.)))
      (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED
        T&.
      ))
     ) (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%9__clone_0
   :skolemid skolem_user_verus_builtin__impl&%9__clone_0
)))
(declare-fun ens%verus_builtin!impl&%7.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%7.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (GHOST T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%7.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__7.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__7.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (GHOST T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST T&.)))
      (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST
        T&.
      ))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%7__clone_0
   :skolemid skolem_user_verus_builtin__impl&%7__clone_0
)))
(assert
 (fuel_bool_default fuel%vstd!pervasive.strictly_cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.strictly_cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.strictly_cloned.? T&. T& a! b!) (closure_ens (FNDEF%core!clone.Clone.clone.
       T&. T&
      ) (DST (REF T&.)) (TYPE%tuple%1. (REF T&.) T&) (F fndef_singleton) (Poly%tuple%1.
       (tuple%1./tuple%1 a!)
      ) b!
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.strictly_cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.strictly_cloned.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!pervasive.cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.cloned.? T&. T& a! b!) (or
      (vstd!pervasive.strictly_cloned.? T&. T& a! b!)
      (= a! b!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.cloned.?_definition
))))
(declare-fun ens%alloc!boxed.impl&%15.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (b! Poly) (res! Poly)) (!
   (= (ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!) (and
     (ens%core!clone.Clone.clone. (BOX A&. A& T&.) T& b! res!)
     (vstd!pervasive.cloned.? T&. T& b! res!)
   ))
   :pattern ((ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!))
   :qid internal_ens__alloc!boxed.impl&__15.clone._definition
   :skolemid skolem_internal_ens__alloc!boxed.impl&__15.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF (BOX A&. A&
         T&.
       ))
      ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (vstd!pervasive.cloned.? T&. T& b$ res$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF
       (BOX A&. A& T&.)
      )
     ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_alloc__boxed__impl&%15__clone_0
   :skolemid skolem_user_alloc__boxed__impl&%15__clone_0
)))
(assert
 (= (vstd!layout.size_of.? $ USIZE) 8)
)
(assert
 (uInv SZ NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?)
)
(declare-fun ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!axiom_max_phyaddr_width_facts.
 (Int) Bool
)
(assert
 (forall ((no%param Int)) (!
   (= (ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!axiom_max_phyaddr_width_facts.
     no%param
    ) (let
     ((tmp%%$ 32))
     (let
      ((tmp%%$1 NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?))
      (let
       ((tmp%%$2 52))
       (and
        (<= tmp%%$ tmp%%$1)
        (<= tmp%%$1 tmp%%$2)
   )))))
   :pattern ((ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!axiom_max_phyaddr_width_facts.
     no%param
   ))
   :qid internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!axiom_max_phyaddr_width_facts._definition
   :skolemid skolem_internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!axiom_max_phyaddr_width_facts._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (fst! Poly)) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type fst! (proj%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt./A
       Self%&. Self%&
    )))
    (has_type (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?
      Self%&. Self%& self! fst!
     ) BOOL
   ))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?
     Self%&. Self%& self! fst!
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%3.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%3.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!view.View.view.? (CONST_PTR $) (PTR T&. T&) self!) (vstd!view.View.view.?
      $ (PTR T&. T&) self!
    ))
    :pattern ((vstd!view.View.view.? (CONST_PTR $) (PTR T&. T&) self!))
    :qid internal_vstd!raw_ptr.impl&__3.view.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__3.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (needle! Poly)) (!
    (= (vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!) (exists ((i$ Poly)) (!
       (and
        (has_type i$ INT)
        (and
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? A&. A& self! i$) needle!)
       ))
       :pattern ((vstd!seq.Seq.index.? A&. A& self! i$))
       :qid user_vstd__seq_lib__impl&%0__contains_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__contains_0
    )))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!))
    :qid internal_vstd!seq_lib.impl&__0.contains.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.contains.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%20.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%20.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 8) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 8) self!))
    :qid internal_vstd!view.impl&__20.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__20.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%22.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%22.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 16) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 16) self!))
    :qid internal_vstd!view.impl&__22.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__22.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%24.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%24.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 32) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 32) self!))
    :qid internal_vstd!view.impl&__24.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__24.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%26.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%26.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 64) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 64) self!))
    :qid internal_vstd!view.impl&__26.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__26.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%28.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%28.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 128) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 128) self!))
    :qid internal_vstd!view.impl&__28.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__28.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%32.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%32.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 8) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 8) self!))
    :qid internal_vstd!view.impl&__32.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__32.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%34.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%34.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 16) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 16) self!))
    :qid internal_vstd!view.impl&__34.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__34.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%36.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%36.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 32) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 32) self!))
    :qid internal_vstd!view.impl&__36.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__36.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%38.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%38.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 64) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 64) self!))
    :qid internal_vstd!view.impl&__38.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__38.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%40.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%40.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 128) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 128) self!))
    :qid internal_vstd!view.impl&__40.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__40.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%42.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%42.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ ISIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ ISIZE self!))
    :qid internal_vstd!view.impl&__42.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__42.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%44.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%44.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ CHAR self!) self!)
    :pattern ((vstd!view.View.view.? $ CHAR self!))
    :qid internal_vstd!view.impl&__44.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__44.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%46.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%46.view.)
  (forall ((A0&. Dcr) (A0& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (tr_bound%vstd!view.View. A0&. A0&)
     )
     (= (vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!) (Poly%tuple%1.
       (tuple%1./tuple%1 (vstd!view.View.view.? A0&. A0& (tuple%1./tuple%1/0 (%Poly%tuple%1.
           self!
    )))))))
    :pattern ((vstd!view.View.view.? (DST A0&.) (TYPE%tuple%1. A0&. A0&) self!))
    :qid internal_vstd!view.impl&__46.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__46.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%48.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%48.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
     )
     (= (vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!) (Poly%tuple%2.
       (tuple%2./tuple%2 (vstd!view.View.view.? A0&. A0& (tuple%2./tuple%2/0 (%Poly%tuple%2.
           self!
         ))
        ) (vstd!view.View.view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!))
    :qid internal_vstd!view.impl&__48.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__48.view.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.
 (Poly) Bool
)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.
     self!
    ) (=>
     %%global_location_label%%5
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_PAT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_PAT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PAT
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_PAT.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_PAT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_PAT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.
 (Poly) Bool
)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.
     self!
    ) (=>
     %%global_location_label%%6
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_G._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_G._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/G (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_G.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_G.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_G.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.
 (Poly) Bool
)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.
     self!
    ) (=>
     %%global_location_label%%7
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
   )))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_addr._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_addr._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/addr
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_addr.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_addr.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.?
      self!
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_addr.?
     self!
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_addr.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_addr.?_pre_post_definition
)))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.
 (Poly) Bool
)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.
     self!
    ) (=>
     %%global_location_label%%8
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
   )))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_P._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_P._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/P
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_P.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_P.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_P.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.
 (Poly) Bool
)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.
     self!
    ) (=>
     %%global_location_label%%9
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
   )))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_RW._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_RW._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/RW
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_RW.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_RW.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_RW.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.
 (Poly) Bool
)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.
     self!
    ) (=>
     %%global_location_label%%10
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
   )))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_US._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_US._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/US
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_US.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_US.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_US.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.
 (Poly) Bool
)
(declare-const %%global_location_label%%11 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.
     self!
    ) (=>
     %%global_location_label%%11
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
   )))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PWT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PWT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PWT
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PWT.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PWT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PWT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.
 (Poly) Bool
)
(declare-const %%global_location_label%%12 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.
     self!
    ) (=>
     %%global_location_label%%12
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
   )))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PCD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PCD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/PCD
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_PCD.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PCD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_PCD.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.
 (Poly) Bool
)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.
     self!
    ) (=>
     %%global_location_label%%13
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
   )))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_XD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_XD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Directory/XD
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Directory_XD.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_XD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Directory_XD.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.
 (Poly) Bool
)
(declare-const %%global_location_label%%14 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.
     self!
    ) (=>
     %%global_location_label%%14
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_addr._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_addr._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/addr
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_addr.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_addr.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.)
    (uInv SZ (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.?
      self!
   )))
   :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_addr.?
     self!
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_addr.?_pre_post_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_addr.?_pre_post_definition
)))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.
 (Poly) Bool
)
(declare-const %%global_location_label%%15 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.
     self!
    ) (=>
     %%global_location_label%%15
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_P._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_P._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/P (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_P.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_P.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_P.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.
 (Poly) Bool
)
(declare-const %%global_location_label%%16 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.
     self!
    ) (=>
     %%global_location_label%%16
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_RW._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_RW._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/RW (
       %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_RW.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_RW.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_RW.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.
 (Poly) Bool
)
(declare-const %%global_location_label%%17 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.
     self!
    ) (=>
     %%global_location_label%%17
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_US._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_US._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/US (
       %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_US.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_US.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_US.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.
 (Poly) Bool
)
(declare-const %%global_location_label%%18 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.
     self!
    ) (=>
     %%global_location_label%%18
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PWT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PWT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PWT
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PWT.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PWT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PWT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.
 (Poly) Bool
)
(declare-const %%global_location_label%%19 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.
     self!
    ) (=>
     %%global_location_label%%19
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PCD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PCD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PCD
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PCD.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PCD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PCD.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.
 (Poly) Bool
)
(declare-const %%global_location_label%%20 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.
     self!
    ) (=>
     %%global_location_label%%20
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_G._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_G._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/G (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_G.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_G.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_G.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.
 (Poly) Bool
)
(declare-const %%global_location_label%%21 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.
     self!
    ) (=>
     %%global_location_label%%21
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PAT._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PAT._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/PAT
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!)
    ))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_PAT.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PAT.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_PAT.?_definition
))))
(declare-fun req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.
 (Poly) Bool
)
(declare-const %%global_location_label%%22 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.
     self!
    ) (=>
     %%global_location_label%%22
     (is-NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE.
       self!
   ))))
   :pattern ((req%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.
     self!
   ))
   :qid internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_XD._definition
   :skolemid skolem_internal_req__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_XD._definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.?
      self!
     ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE./Page/XD (
       %Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!GPDE. self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%0.arrow_Page_XD.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_XD.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__0.arrow_Page_XD.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.)
  (= NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.?
   (uClip SZ (Sub (uClip SZ (bitshl (I 1) (I NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?)))
     1
)))))
(assert
 (uInv SZ NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.?)
)
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%8.contains_fst.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%8.contains_fst.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (fst! Poly)) (!
    (=>
     (and
      (sized A&.)
      (sized B&.)
     )
     (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?
       $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&)) self! fst!
      ) (B (exists ((i$ Poly)) (!
         (and
          (has_type i$ INT)
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? (DST B&.) (TYPE%tuple%2. A&. A& B&. B&) self!)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (%Poly%tuple%2. (vstd!seq.Seq.index.? (DST B&.) (TYPE%tuple%2. A&. A& B&. B&) self!
              i$
             )
            ) (tuple%2./tuple%2 fst! (tuple%2./tuple%2/1 (%Poly%tuple%2. (vstd!seq.Seq.index.? (DST
                 B&.
                ) (TYPE%tuple%2. A&. A& B&. B&) self! i$
         )))))))
         :pattern ((vstd!seq.Seq.index.? (DST B&.) (TYPE%tuple%2. A&. A& B&. B&) self! i$))
         :qid user_vstd__seq__Seq__contains_fst_0
         :skolemid skolem_user_vstd__seq__Seq__contains_fst_0
    )))))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?
      $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&)) self! fst!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__8.contains_fst.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__8.contains_fst.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%9.writer_sbuf.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%9.writer_sbuf.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%9.writer_sbuf.?
      self!
     ) (%Poly%vstd!seq.Seq<tuple%2<usize./usize.>.>. (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
       $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
        (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
         (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
        )
       ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
         (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
           (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
            (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
    ))))))))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%9.writer_sbuf.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__9.writer_sbuf.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__9.writer_sbuf.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.)
  (forall ((self! Poly) (c! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.?
      self! c!
     ) (forall ((core$ Poly)) (!
       (=>
        (has_type core$ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
        (=>
         (and
          (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%7.valid_core.?
           c! core$
          )
          (not (= (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
             core$
            ) (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
             (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
               (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
         )))))))
         (= (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
           $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
            (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
             (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
            )
           ) core$
          ) (vstd!seq.Seq.empty.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
       )))
       :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%7.valid_core.?
         c! core$
       ))
       :qid user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State__non_writer_sbufs_are_empty_0
       :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State__non_writer_sbufs_are_empty_0
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.?
      self! c!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.non_writer_sbufs_are_empty.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.non_writer_sbufs_are_empty.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.?
      self!
     ) (forall ((i1$ Poly) (i2$ Poly)) (!
       (=>
        (and
         (has_type i1$ INT)
         (has_type i2$ INT)
        )
        (=>
         (and
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i1$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!map.impl&%0.index.?
                  $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
                   (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
                  ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
                   (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                    (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
                   )
                  ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
                    (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
                      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
              )))))))))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I i2$)))
             (let
              ((tmp%%$5 (vstd!seq.Seq.len.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!map.impl&%0.index.?
                  $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
                   (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
                  ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
                   (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                    (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
                   )
                  ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
                    (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
                      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
              )))))))))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
          )))))
          (not (= i1$ i2$))
         )
         (not (= (tuple%2./tuple%2/0 (%Poly%tuple%2. (vstd!seq.Seq.index.? (DST $) (TYPE%tuple%2.
               $ USIZE $ USIZE
              ) (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
               $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
                (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
                )
               ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
                   (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                    (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
               )))))
              ) i2$
            ))
           ) (tuple%2./tuple%2/0 (%Poly%tuple%2. (vstd!seq.Seq.index.? (DST $) (TYPE%tuple%2. $
               USIZE $ USIZE
              ) (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
               $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
                (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
                )
               ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
                   (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                    (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
               )))))
              ) i1$
       )))))))
       :pattern ((vstd!seq.Seq.index.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!map.impl&%0.index.?
          $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
           (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
          ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
           (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
            (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
           )
          ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
            (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
              (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
               (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
          )))))
         ) i2$
        ) (vstd!seq.Seq.index.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!map.impl&%0.index.?
          $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
           (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
          ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
           (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
            (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
           )
          ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
            (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
              (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
               (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
          )))))
         ) i1$
       ))
       :qid user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State__writer_sbuf_entries_are_unique_0
       :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State__writer_sbuf_entries_are_unique_0
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.writer_sbuf_entries_are_unique.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.writer_sbuf_entries_are_unique.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type)) (!
   (=>
    (and
     (sized A&.)
     (sized B&.)
    )
    (tr_bound%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.
     $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&))
   ))
   :pattern ((tr_bound%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.
     $ (TYPE%vstd!seq.Seq. (DST B&.) (TYPE%tuple%2. A&. A& B&. B&))
   ))
   :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__impl&__8_trait_impl_definition
   :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__impl&__8_trait_impl_definition
)))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.)
  (forall ((self! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.?
      self!
     ) (forall ((a$ Poly)) (!
       (=>
        (has_type a$ USIZE)
        (=>
         (%B (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!SeqTupExt.contains_fst.?
           $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (vstd!map.impl&%0.index.?
            $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
             (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
            ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
             (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
              (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
             )
            ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
              (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
                (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
            )))))
           ) a$
         ))
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso
             (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
               (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
           )))))
          ) a$
       )))
       :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
           (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso
            (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
              (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
               (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. self!)
          )))))
         ) a$
       ))
       :qid user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State__writer_sbuf_subset_tso_writes_0
       :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__State__writer_sbuf_subset_tso_writes_0
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.?
      self!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.writer_sbuf_subset_tso_writes.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.writer_sbuf_subset_tso_writes.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.)
)
(assert
 (=>
  (fuel_bool fuel%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.)
  (forall ((self! Poly) (c! Poly)) (!
    (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.?
      self! c!
     ) (and
      (and
       (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.non_writer_sbufs_are_empty.?
        self! c!
       )
       (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_entries_are_unique.?
        self!
      ))
      (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.writer_sbuf_subset_tso_writes.?
       self!
    )))
    :pattern ((NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.?
      self! c!
    ))
    :qid internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.inv_sbuf_facts.?_definition
    :skolemid skolem_internal_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__10.inv_sbuf_facts.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%vstd!view.View. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%vstd!view.View. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_vstd__raw_ptr__impl&__3_trait_impl_definition
   :skolemid skolem_internal_vstd__raw_ptr__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 8))
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 16))
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 32))
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 64))
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 128))
)
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 8))
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 16))
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 32))
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 64))
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 128))
)
(assert
 (tr_bound%vstd!view.View. $ ISIZE)
)
(assert
 (tr_bound%vstd!view.View. $ CHAR)
)
(assert
 (forall ((A0&. Dcr) (A0& Type)) (!
   (=>
    (and
     (sized A0&.)
     (tr_bound%vstd!view.View. A0&. A0&)
    )
    (tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A0&.) (TYPE%tuple%1. A0&. A0&)))
   :qid internal_vstd__view__impl&__46_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__46_trait_impl_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__48_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__48_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__15_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& $slice) (SLICE T&. T&))
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& $slice) (SLICE T&. T&)))
   :qid internal_alloc__boxed__impl&__16_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__16_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ USIZE)
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 8))
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 16))
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 32))
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 64))
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 128))
)
(assert
 (tr_bound%core!clone.Clone. $ ISIZE)
)
(assert
 (tr_bound%core!clone.Clone. $ (SINT 8))
)
(assert
 (tr_bound%core!clone.Clone. $ (SINT 16))
)
(assert
 (tr_bound%core!clone.Clone. $ (SINT 32))
)
(assert
 (tr_bound%core!clone.Clone. $ (SINT 64))
)
(assert
 (tr_bound%core!clone.Clone. $ (SINT 128))
)
(assert
 (tr_bound%core!clone.Clone. $ BOOL)
)
(assert
 (tr_bound%core!clone.Clone. $ CHAR)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%core!clone.Clone. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_core__clone__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. $ (PTR T&. T&))
   :pattern ((tr_bound%core!clone.Clone. $ (PTR T&. T&)))
   :qid internal_core__clone__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__4_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (REF T&.) T&)
   :pattern ((tr_bound%core!clone.Clone. (REF T&.) T&))
   :qid internal_core__clone__impls__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__35_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__35_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__32_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!clone.Clone. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__7_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!clone.Clone. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__9_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ INT)
)
(assert
 (tr_bound%core!clone.Clone. $ NAT)
)
(assert
 (tr_bound%core!marker.Copy. $ USIZE)
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 8))
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 16))
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 32))
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 64))
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 128))
)
(assert
 (tr_bound%core!marker.Copy. $ ISIZE)
)
(assert
 (tr_bound%core!marker.Copy. $ (SINT 8))
)
(assert
 (tr_bound%core!marker.Copy. $ (SINT 16))
)
(assert
 (tr_bound%core!marker.Copy. $ (SINT 32))
)
(assert
 (tr_bound%core!marker.Copy. $ (SINT 64))
)
(assert
 (tr_bound%core!marker.Copy. $ (SINT 128))
)
(assert
 (tr_bound%core!marker.Copy. $ BOOL)
)
(assert
 (tr_bound%core!marker.Copy. $ CHAR)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (CONST_PTR $) (PTR T&. T&))
   :pattern ((tr_bound%core!marker.Copy. (CONST_PTR $) (PTR T&. T&)))
   :qid internal_core__marker__impl&__58_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__58_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. $ (PTR T&. T&))
   :pattern ((tr_bound%core!marker.Copy. $ (PTR T&. T&)))
   :qid internal_core__marker__impl&__59_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__59_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (REF T&.) T&)
   :pattern ((tr_bound%core!marker.Copy. (REF T&.) T&))
   :qid internal_core__marker__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__4_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!marker.Copy. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__8_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__8_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!marker.Copy. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__10_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__10_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ INT)
)
(assert
 (tr_bound%core!marker.Copy. $ NAT)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(declare-fun ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%3.clone.
 (Poly Poly) Bool
)
(assert
 (forall ((self! Poly) (%return! Poly)) (!
   (= (ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%3.clone.
     self! %return!
    ) (and
     (ens%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
      self! %return!
     )
     (= %return! self!)
   ))
   :pattern ((ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%3.clone.
     self! %return!
   ))
   :qid internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__3.clone._definition
   :skolemid skolem_internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__3.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.))
     (has_type %return$ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
      (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
      (F fndef_singleton) closure%$ %return$
     )
     (let
      ((self$ (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
         (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))
      )))
      (= (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. %return$)
       self$
   ))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
     (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
     (F fndef_singleton) closure%$ %return$
   ))
   :qid user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Core__clone_0
   :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Core__clone_0
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= %return! self!)
   (=>
    %%location_label%%0
    (= %return! self!)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
)
(declare-fun ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%6.clone.
 (Poly Poly) Bool
)
(assert
 (forall ((self! Poly) (%return! Poly)) (!
   (= (ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%6.clone.
     self! %return!
    ) (and
     (ens%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
      self! %return!
     )
     (= %return! self!)
   ))
   :pattern ((ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%6.clone.
     self! %return!
   ))
   :qid internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__6.clone._definition
   :skolemid skolem_internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.))
     (has_type %return$ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
      (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
      (F fndef_singleton) closure%$ %return$
     )
     (let
      ((self$ (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.
         (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))
      )))
      (= (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags. %return$)
       self$
   ))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
     (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
     (F fndef_singleton) closure%$ %return$
   ))
   :qid user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags__clone_0
   :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__Flags__clone_0
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= %return! self!)
   (=>
    %%location_label%%0
    (= %return! self!)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
)
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 8)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 8))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (SINT 8)) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) (SINT 8))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (SINT 8)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 8))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (SINT 8)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 8))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 16)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 16))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 16)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 16))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 16))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 16))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (SINT 16)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 16))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (SINT 16)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 16))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (SINT 16))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 16))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 32)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 32))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 32)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 32))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 32))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 32))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (SINT 32))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 32))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 64))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 64))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (SINT 64)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 64))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (SINT 64)) (
   DST (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 64))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (SINT 64))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 64))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (UINT 128)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (UINT 128))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (UINT 128))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 128))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (UINT 128))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (UINT 128))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ (SINT 128)) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) (SINT 128))
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ (SINT 128))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 128))
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ (SINT 128))
  (DST (REF $)) (TYPE%tuple%1. (REF $) (SINT 128))
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ ISIZE) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) ISIZE)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ ISIZE) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) ISIZE)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ ISIZE) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) ISIZE)
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (
      DST (REF Self%&.)
     ) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $))
  (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ CHAR) (DST (REF $))
  (TYPE%tuple%1. (REF $) CHAR)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ CHAR) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) CHAR)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ CHAR) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) CHAR)
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST
     (REF (REF T&.))
    ) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (
      DST (REF (GHOST T&.))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
      T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&)
     (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
       T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Flags.)
))
(declare-fun ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR.
 (Int) Bool
)
(assert
 (forall ((%return! Int)) (!
   (= (ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR.
     %return!
    ) (and
     (uInv SZ %return!)
     (= %return! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.?)
   ))
   :pattern ((ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR.
     %return!
   ))
   :qid internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR._definition
   :skolemid skolem_internal_ens__NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(assert
 (not (=>
   (ens%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!axiom_max_phyaddr_width_facts.
    0
   )
   (and
    (=>
     %%location_label%%0
     true
    )
    (=>
     (= (uClip SZ (bitshl (I 1) (I 32))) 4294967296)
     (and
      (=>
       %%location_label%%1
       true
      )
      (=>
       (forall ((m$ Poly) (n$ Poly)) (!
         (=>
          (and
           (has_type m$ USIZE)
           (has_type n$ USIZE)
          )
          (=>
           (let
            ((tmp%%$ (%I n$)))
            (let
             ((tmp%%$4 (%I m$)))
             (let
              ((tmp%%$5 64))
              (and
               (< tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
           ))))
           (< (uClip SZ (bitshl (I 1) (I (%I n$)))) (uClip SZ (bitshl (I 1) (I (%I m$)))))
         ))
         :pattern ((uClip SZ (bitshl (I 1) (I (%I n$)))) (uClip SZ (bitshl (I 1) (I (%I m$)))))
         :qid user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__MAX_PHYADDR_0
         :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__MAX_PHYADDR_0
       ))
       (and
        (=>
         %%location_label%%2
         (and
          (<= 0 NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?)
          (< NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?
           64
        )))
        (=>
         (and
          (<= 0 NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?)
          (< NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?
           64
         ))
         (and
          (=>
           %%location_label%%3
           (uInv SZ (Sub (uClip SZ (bitshl (I 1) (I NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?)))
             1
          )))
          (=>
           (uInv SZ (Sub (uClip SZ (bitshl (I 1) (I NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?)))
             1
           ))
           (=>
            (= %return! (uClip SZ (Sub (uClip SZ (bitshl (I 1) (I NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_WIDTH.?)))
               1
            )))
            (=>
             %%location_label%%4
             (= %return! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!MAX_PHYADDR_SPEC.?)
)))))))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const pre! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.)
(declare-const c! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.)
(declare-const core! NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.)
(declare-const a@ Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
   pre!
  ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
))
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
   c!
  ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants.
))
(assert
 (has_type (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
   core!
  ) TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
))
(assert
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%10.inv_sbuf_facts.?
  (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. pre!)
  (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants. c!)
))
(assert
 (= (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso
   (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
     (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
      (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
        pre!
   )))))
  ) (%Poly%vstd!set.Set<usize.>. (vstd!set.Set.empty.? $ USIZE))
))
(assert
 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!impl&%7.valid_core.?
  (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Constants. c!)
  (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
))
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(declare-const %%location_label%%5 Bool)
(assert
 (not (or
   (and
    (=>
     (= core! (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
       (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
         (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
          (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
            pre!
     )))))))
     (and
      (=>
       (has_type a@ (TYPE%tuple%2. $ USIZE $ USIZE))
       (=>
        (vstd!seq_lib.impl&%0.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!map.impl&%0.index.?
          $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
           (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
          ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
           (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
            (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
              pre!
           )))
          ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
         ) a@
        )
        (=>
         (= tmp%1 (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/tso
              (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
                (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                   pre!
            )))))))
           ) (tuple%2./tuple%2/0 (%Poly%tuple%2. a@))
         ))
         (and
          (=>
           %%location_label%%0
           tmp%1
          )
          (=>
           tmp%1
           (=>
            %%location_label%%1
            false
      ))))))
      (=>
       (forall ((a$ Poly)) (!
         (=>
          (has_type a$ (TYPE%tuple%2. $ USIZE $ USIZE))
          (not (vstd!seq_lib.impl&%0.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!map.impl&%0.index.?
             $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
              (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
             ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
              (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
               (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                 pre!
              )))
             ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
            ) a$
         )))
         :pattern ((vstd!seq_lib.impl&%0.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
           (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
            $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
             (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
              (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                pre!
             )))
            ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
           ) a$
         ))
         :qid user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__lemma_writes_tso_empty_implies_sbuf_empty_1
         :skolemid skolem_user_NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty__lemma_writes_tso_empty_implies_sbuf_empty_1
       ))
       (and
        (or
         (and
          (=>
           (not (ext_eq false (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (vstd!map.impl&%0.index.?
              $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
               (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
              ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
               (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                  pre!
               )))
              ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
             ) (vstd!seq.Seq.empty.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
           ))
           (=>
            (= tmp%2 (vstd!seq_lib.impl&%0.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (
               vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
               $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
                (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                   pre!
                )))
               ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
              ) (vstd!seq.Seq.index.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!map.impl&%0.index.?
                $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
                 (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
                ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
                 (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                  (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                    pre!
                 )))
                ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
               ) (I 0)
            )))
            (and
             (=>
              %%location_label%%2
              tmp%2
             )
             (=>
              tmp%2
              (=>
               %%location_label%%3
               false
          )))))
          (=>
           (not (not (ext_eq false (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
              (vstd!map.impl&%0.index.? $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core.
               $ (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
                (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
                 (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                   pre!
                )))
               ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
              ) (vstd!seq.Seq.empty.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
           )))
           %%switch_label%%1
         ))
         (and
          (not %%switch_label%%1)
          (=>
           %%location_label%%4
           (ext_eq false (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (vstd!map.impl&%0.index.?
             $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
              (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
             ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
              (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
               (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
                 pre!
              )))
             ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
            ) (vstd!seq.Seq.empty.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
        ))))
        (=>
         (ext_eq false (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (vstd!map.impl&%0.index.?
           $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
            (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
           ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
            (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
             (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
               pre!
            )))
           ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
          ) (vstd!seq.Seq.empty.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
         )
         %%switch_label%%0
    )))))
    (=>
     (not (= core! (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes./Writes/core
        (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Writes.
          (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/writes
           (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
             pre!
     ))))))))
     %%switch_label%%0
   ))
   (and
    (not %%switch_label%%0)
    (=>
     %%location_label%%5
     (ext_eq false (TYPE%vstd!seq.Seq. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)) (vstd!map.impl&%0.index.?
       $ TYPE%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. $ (TYPE%vstd!seq.Seq.
        (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
       ) (Poly%vstd!map.Map<NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core./vstd!seq.Seq<tuple%2<usize./usize.>.>.>.
        (NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State./State/sbuf
         (%Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State. (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!State.
           pre!
        )))
       ) (Poly%NR__spec_t__mmu__rl2__lemma_writes_tso_empty_implies_sbuf_empty!Core. core!)
      ) (vstd!seq.Seq.empty.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
