(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const shift! (_ BitVec 64))
(declare-const x! (_ BitVec 64))
(declare-const tmp$$$$bitvectmp1 (_ BitVec 64))
(assert
 (and
  (bvult ((_ zero_extend 63) (_ bv0 1)) shift!)
  (bvult shift! ((_ zero_extend 57) (_ bv64 7)))
))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (bvlshr x! shift!) (let
     ((tmp$$$$bitvectmp0 (_ bv2 2)))
     (ite
      (= tmp$$$$bitvectmp0 (_ bv0 2))
      tmp$$$$bitvectmp1
      (bvudiv (bvlshr x! (bvsub shift! ((_ zero_extend 63) (_ bv1 1)))) ((_ zero_extend 62)
        tmp$$$$bitvectmp0
))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
