(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.lemma_map_new_domain. FuelId)
(declare-const fuel%vstd!map.lemma_map_new_index. FuelId)
(declare-const fuel%vstd!map.lemma_map_empty. FuelId)
(declare-const fuel%vstd!map.lemma_map_insert_domain. FuelId)
(declare-const fuel%vstd!map.lemma_map_insert_same. FuelId)
(declare-const fuel%vstd!map.axiom_map_insert_different. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map_lib.impl&%0.contains_key. FuelId)
(declare-const fuel%vstd!map_lib.impl&%0.contains_pair. FuelId)
(declare-const fuel%vstd!map_lib.impl&%0.union_prefer_right. FuelId)
(declare-const fuel%vstd!pervasive.strictly_cloned. FuelId)
(declare-const fuel%vstd!pervasive.cloned. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!set.lemma_set_empty. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_same. FuelId)
(declare-const fuel%vstd!set.lemma_set_insert_different. FuelId)
(declare-const fuel%vstd!set.lemma_set_union. FuelId)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.
 FuelId
)
(declare-const fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!function.axiom_fn_mut_call_requires. fuel%vstd!function.axiom_fn_mut_call_ensures.
  fuel%vstd!iset.lemma_iset_ext_equal. fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index.
  fuel%vstd!map.axiom_map_index_decreases. fuel%vstd!map.lemma_map_new_domain. fuel%vstd!map.lemma_map_new_index.
  fuel%vstd!map.lemma_map_empty. fuel%vstd!map.lemma_map_insert_domain. fuel%vstd!map.lemma_map_insert_same.
  fuel%vstd!map.axiom_map_insert_different. fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep.
  fuel%vstd!map_lib.impl&%0.contains_key. fuel%vstd!map_lib.impl&%0.contains_pair.
  fuel%vstd!map_lib.impl&%0.union_prefer_right. fuel%vstd!pervasive.strictly_cloned.
  fuel%vstd!pervasive.cloned. fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.lemma_seq_index_decreases.
  fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep. fuel%vstd!set.Set.contains.
  fuel%vstd!set.axiom_set_ext_equal. fuel%vstd!set.axiom_set_ext_equal_deep. fuel%vstd!set.axiom_set_decreases_to_member.
  fuel%vstd!set.lemma_set_empty. fuel%vstd!set.lemma_set_insert_same. fuel%vstd!set.lemma_set_insert_different.
  fuel%vstd!set.lemma_set_union. fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.
  fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.lemma_map_new_domain.)
   (fuel_bool_default fuel%vstd!map.lemma_map_new_index.)
   (fuel_bool_default fuel%vstd!map.lemma_map_empty.)
   (fuel_bool_default fuel%vstd!map.lemma_map_insert_domain.)
   (fuel_bool_default fuel%vstd!map.lemma_map_insert_same.)
   (fuel_bool_default fuel%vstd!map.axiom_map_insert_different.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
   (fuel_bool_default fuel%vstd!set.lemma_set_empty.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_same.)
   (fuel_bool_default fuel%vstd!set.lemma_set_insert_different.)
   (fuel_bool_default fuel%vstd!set.lemma_set_union.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%core!clone.Clone. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Copy. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-sort vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
 0
)
(declare-sort vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
 0
)
(declare-sort vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
 0
)
(declare-datatypes ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
   0
  ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
   0
  ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
   0
  ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
   0
  ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
   0
  ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
   0
  ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
   0
  ) (tuple%0. 0) (tuple%1. 0)
 ) (((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/?base
     Int
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/?size
     Int
   ))
  ) ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/?is_writable
     Bool
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/?is_supervisor
     Bool
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/?disable_execute
     Bool
   ))
  ) ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/?frame
     NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/?flags
     NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
   ))
  ) ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/?entry_size
     Int
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/?num_entries
     Int
   ))
  ) ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/?layers
     vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
   ))
  ) ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/?0
     NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
    )
   ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/?0
     NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
    )
   ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Invalid)
  ) ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory
    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?entries
     vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?layer
     Int
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?base_vaddr
     Int
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?arch
     NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
   ))
  ) ((tuple%0./tuple%0)) ((tuple%1./tuple%1 (tuple%1./tuple%1/?0 Poly)))
))
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
 Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
 Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_writable
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
 Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_supervisor
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
 Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/disable_execute
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
 Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/flags
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
 Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
 Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
 vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
 vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
 Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
 Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
)
(declare-fun tuple%1./tuple%1/0 (tuple%1.) Poly)
(declare-fun TYPE%fun%1. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-const TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
 Type
)
(declare-const TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
 Type
)
(declare-const TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
 Type
)
(declare-const TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
 Type
)
(declare-const TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
 Type
)
(declare-const TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
 Type
)
(declare-const TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
 Type
)
(declare-fun TYPE%tuple%1. (Dcr Type) Type)
(declare-fun FNDEF%core!clone.Clone.clone. (Dcr Type) Type)
(declare-fun Poly%fun%1. (%%Function%%) Poly)
(declare-fun %Poly%fun%1. (Poly) %%Function%%)
(declare-fun Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
 (vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
 (Poly) vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
)
(declare-fun Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
 (vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
 (Poly) vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
)
(declare-fun Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
 (vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
 (Poly) vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
)
(declare-fun Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
 Poly
)
(declare-fun %Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
)
(declare-fun Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
 Poly
)
(declare-fun %Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
)
(declare-fun Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
 Poly
)
(declare-fun %Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
)
(declare-fun Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
 Poly
)
(declare-fun %Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
)
(declare-fun Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
 Poly
)
(declare-fun %Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
)
(declare-fun Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
 Poly
)
(declare-fun %Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
)
(declare-fun Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
 Poly
)
(declare-fun %Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%1. (tuple%1.) Poly)
(declare-fun %Poly%tuple%1. (Poly) tuple%1.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%1. (Poly%fun%1. x)))
   :pattern ((Poly%fun%1. x))
   :qid internal_crate__fun__1_box_axiom_definition
   :skolemid skolem_internal_crate__fun__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%fun%1. (%Poly%fun%1. x)))
   )
   :pattern ((has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__1_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x %%Function%%)) (!
   (=>
    (forall ((T%0 Poly)) (!
      (=>
       (has_type T%0 T%0&)
       (has_type (%%apply%%0 x T%0) T%1&)
      )
      :pattern ((has_type (%%apply%%0 x T%0) T%1&))
      :qid internal_crate__fun__1_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__1_constructor_inner_definition
    ))
    (has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_constructor_definition
   :skolemid skolem_internal_crate__fun__1_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (has_type (%%apply%%0 x T%0) T%1&)
   )
   :pattern ((%%apply%%0 x T%0) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&.
      T%1&
   )))
   :qid internal_crate__fun__1_apply_definition
   :skolemid skolem_internal_crate__fun__1_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (height_lt (height (%%apply%%0 x T%0)) (height (fun_from_recursive_field (Poly%fun%1.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0)) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_crate__fun__1_height_apply_definition
   :skolemid skolem_internal_crate__fun__1_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (forall ((T%0 Poly)) (!
       (=>
        (has_type T%0 T%0&)
        (ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1. y) T%0))
       )
       :pattern ((ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1.
           y
          ) T%0
       )))
       :qid internal_crate__fun__1_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__1_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_crate__fun__1_ext_equal_definition
   :skolemid skolem_internal_crate__fun__1_ext_equal_definition
)))
(assert
 (forall ((x vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.))
  (!
   (= x (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
     (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
     x
   ))
   :qid internal_vstd__map__Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
    (= x (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
      (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)))
   :qid internal_vstd__map__Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.))
  (!
   (has_type (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
     x
    ) (TYPE%vstd!map.Map. $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
   )
   :pattern ((has_type (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
      x
     ) (TYPE%vstd!map.Map. $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
   ))
   :qid internal_vstd__map__Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
     x
   ))
   :qid internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.))
    (= x (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (%Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)))
   :qid internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
     x
    ) (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      x
     ) (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
   ))
   :qid internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
     x
   ))
   :qid internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.))
    (= x (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
      (%Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)))
   :qid internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
     x
    ) (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
      x
     ) (TYPE%vstd!seq.Seq. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
   ))
   :qid internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>_has_type_always_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.))
  (!
   (= x (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      x
   )))
   :pattern ((Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__MemRegion_box_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__MemRegion_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
    (= x (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
       x
   ))))
   :pattern ((has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__MemRegion_unbox_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__MemRegion_unbox_axiom_definition
)))
(assert
 (forall ((_base! Int) (_size! Int)) (!
   (=>
    (and
     (<= 0 _base!)
     (<= 0 _size!)
    )
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion
       _base! _size!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
   ))
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion
       _base! _size!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion_constructor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion_constructor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/?base
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
       x
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/base_invariant_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/?size
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
       x
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size_invariant_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.))
  (!
   (= x (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
      x
   )))
   :pattern ((Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags_box_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
    (= x (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
       x
   ))))
   :pattern ((has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags_unbox_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags_unbox_axiom_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_writable
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/?is_writable
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_writable
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_writable_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_writable_accessor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_supervisor
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/?is_supervisor
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_supervisor
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_supervisor_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/is_supervisor_accessor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/disable_execute
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/?disable_execute
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/disable_execute
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/disable_execute_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags./Flags/disable_execute_accessor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.))
  (!
   (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
     x
    ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
   )
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
      x
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags_has_type_always_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags_has_type_always_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
  (!
   (= x (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      x
   )))
   :pattern ((Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__PTE_box_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__PTE_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
    (= x (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
       x
   ))))
   :pattern ((has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__PTE_unbox_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__PTE_unbox_axiom_definition
)))
(assert
 (forall ((_frame! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.)
   (_flags! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
  ) (!
   (=>
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      _frame!
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
    )
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE
       _frame! _flags!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
   ))
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE
       _frame! _flags!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE_constructor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE_constructor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/?frame
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
        x
      ))
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame_invariant_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/flags
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/?flags
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/flags
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/flags_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/flags_accessor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.))
  (!
   (= x (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      x
   )))
   :pattern ((Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__ArchLayer_box_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__ArchLayer_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
    (= x (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       x
   ))))
   :pattern ((has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__ArchLayer_unbox_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__ArchLayer_unbox_axiom_definition
)))
(assert
 (forall ((_entry_size! Int) (_num_entries! Int)) (!
   (=>
    (and
     (<= 0 _entry_size!)
     (<= 0 _num_entries!)
    )
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer
       _entry_size! _num_entries!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
   ))
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer
       _entry_size! _num_entries!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer_constructor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer_constructor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/?entry_size
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       x
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size_invariant_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/?num_entries
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       x
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries_invariant_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.))
  (!
   (= x (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
      x
   )))
   :pattern ((Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch_box_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
    (= x (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
       x
   ))))
   :pattern ((has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch_unbox_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch_unbox_axiom_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/?layers
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers_accessor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.))
  (!
   (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
     x
    ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
   )
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
      x
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch_has_type_always_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch_has_type_always_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.))
  (!
   (= x (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      x
   )))
   :pattern ((Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__NodeEntry_box_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__NodeEntry_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
    (= x (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       x
   ))))
   :pattern ((has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__NodeEntry_unbox_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__NodeEntry_unbox_axiom_definition
)))
(assert
 (forall ((_0! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
  (!
   (=>
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      _0!
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
    )
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
       _0!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
   ))
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
       _0!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory_constructor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory_constructor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/?0
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        x
      ))
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0_invariant_definition
)))
(assert
 (forall ((_0! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
  (!
   (=>
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      _0!
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
    )
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
       _0!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
   ))
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
       _0!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page_constructor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page_constructor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/?0
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        x
      ))
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0_invariant_definition
)))
(assert
 (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
   NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Invalid
  ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.))
  (!
   (=>
    (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
     x
    )
    (height_lt (height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
        x
      ))
     ) (height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       x
   ))))
   :pattern ((height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
       x
   ))))
   :qid prelude_datatype_height_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
   :skolemid skolem_prelude_datatype_height_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
  (!
   (= x (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      x
   )))
   :pattern ((Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory_box_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
    (= x (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       x
   ))))
   :pattern ((has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory_unbox_axiom_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory_unbox_axiom_definition
)))
(assert
 (forall ((_entries! vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.)
   (_layer! Int) (_base_vaddr! Int) (_arch! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
  ) (!
   (=>
    (and
     (<= 0 _layer!)
     (<= 0 _base_vaddr!)
    )
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory
       _entries! _layer! _base_vaddr! _arch!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
   ))
   :pattern ((has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory
       _entries! _layer! _base_vaddr! _arch!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory_constructor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory_constructor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?entries
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries_accessor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?layer
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       x
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer_invariant_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?base_vaddr
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       x
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      x
     )
    ) (has_type x TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
   )
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr_invariant_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr_invariant_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
  (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
     x
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/?arch
     x
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
     x
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch_accessor_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch_accessor_definition
)))
(assert
 (forall ((x NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.))
  (!
   (=>
    (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory
     x
    )
    (height_lt (height (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
        x
      ))
     ) (height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       x
   ))))
   :pattern ((height (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
       x
   ))))
   :qid prelude_datatype_height_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
   :skolemid skolem_prelude_datatype_height_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= x (%Poly%tuple%1. (Poly%tuple%1. x)))
   :pattern ((Poly%tuple%1. x))
   :qid internal_crate__tuple__1_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (= x (Poly%tuple%1. (%Poly%tuple%1. x)))
   )
   :pattern ((has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__tuple__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__1_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T%0&)
    (has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((has_type (Poly%tuple%1. (tuple%1./tuple%1 _0!)) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1_constructor_definition
   :skolemid skolem_internal_tuple__1./tuple__1_constructor_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (= (tuple%1./tuple%1/0 x) (tuple%1./tuple%1/?0 x))
   :pattern ((tuple%1./tuple%1/0 x))
   :qid internal_tuple__1./tuple__1/0_accessor_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%1. T%0&. T%0&))
    (has_type (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) T%0&)
   )
   :pattern ((tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (has_type x (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_tuple__1./tuple__1/0_invariant_definition
   :skolemid skolem_internal_tuple__1./tuple__1/0_invariant_definition
)))
(assert
 (forall ((x tuple%1.)) (!
   (=>
    (is-tuple%1./tuple%1 x)
    (height_lt (height (tuple%1./tuple%1/0 x)) (height (Poly%tuple%1. x)))
   )
   :pattern ((height (tuple%1./tuple%1/0 x)))
   :qid prelude_datatype_height_tuple%1./tuple%1/0
   :skolemid skolem_prelude_datatype_height_tuple%1./tuple%1/0
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%tuple%1. T%0&. T%0&))
     (has_type y (TYPE%tuple%1. T%0&. T%0&))
     (ext_eq deep T%0& (tuple%1./tuple%1/0 (%Poly%tuple%1. x)) (tuple%1./tuple%1/0 (%Poly%tuple%1.
        y
    ))))
    (ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%1. T%0&. T%0&) x y))
   :qid internal_tuple__1./tuple__1_ext_equal_definition
   :skolemid skolem_internal_tuple__1./tuple__1_ext_equal_definition
)))
(assert
 (forall ((x fndef) (Self%&. Dcr) (Self%& Type)) (!
   (has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&))
   :pattern ((has_type (F x) (FNDEF%core!clone.Clone.clone. Self%&. Self%&)))
   :qid prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
   :skolemid skolem_prelude_has_type_fndef_FNDEF%core!clone.Clone.clone.
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%core!clone.Clone. Self%&. Self%&))
   :qid internal_core__clone__Clone_trait_type_bounds_definition
   :skolemid skolem_internal_core__clone__Clone_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. Self%&. Self%&)
    (tr_bound%core!clone.Clone. Self%&. Self%&)
   )
   :pattern ((tr_bound%core!marker.Copy. Self%&. Self%&))
   :qid internal_core__marker__Copy_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Copy_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ USIZE)
   (DST (REF $)) (TYPE%tuple%1. (REF $) USIZE)
  ) USIZE
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
       Self%&
      ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&.
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
      (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
     ) Self%&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__Clone__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ BOOL)
   (DST (REF $)) (TYPE%tuple%1. (REF $) BOOL)
  ) BOOL
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) (REF T&.)
   )
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       REF T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
    ) T&
   )
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (REF
       T&.
      ) T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
        T&.
       ) T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) (TRACKED T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       TRACKED T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
       T&
      ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) (GHOST T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       GHOST T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
       T&
      ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&.
        A& T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) (BOX A&. A& T&.)
   ))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (
       BOX A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
        T&.
       ) T&
      ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
     ) T&
   ))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. (BOX
       A&. A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
  ) $
))
(assert
 (= (proj%core!ops.function.FnOnce./Output $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
   (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
  ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.new.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.empty.? (Dcr Type Dcr Type) Poly)
(declare-fun vstd!set.Set.empty.? (Dcr Type) Poly)
(declare-fun vstd!map.impl&%0.insert.? (Dcr Type Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!set.Set.insert.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!set.impl&%0.union.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!pervasive.strictly_cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!pervasive.cloned.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!pervasive.arbitrary.? (Dcr Type) Poly)
(declare-fun vstd!map_lib.impl&%0.contains_key.? (Dcr Type Dcr Type Poly Poly) Bool)
(declare-fun vstd!map_lib.impl&%0.contains_pair.? (Dcr Type Dcr Type Poly Poly Poly)
 Bool
)
(declare-fun vstd!map_lib.impl&%0.union_prefer_right.? (Dcr Type Dcr Type Poly Poly)
 Poly
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.?
 () Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.?
 () Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.?
 () Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?
 (Poly Poly Poly) Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
 (Poly Poly) Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
 (Poly Poly) Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.?
 (Poly Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
 (Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.?
 (Poly Poly Poly Poly) Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.?
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.?
 (Poly) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
 (Poly Poly) Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
 (Poly Poly) vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
 (Poly Poly Fuel) vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
 (Poly Poly) vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
 (Poly Poly Fuel) vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.?
 (Poly Poly) vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
 (Poly Poly Fuel) vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
 (Poly) Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
 (Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
 (Poly) Int
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.?
 (Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
 (Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
 (Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
 (Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
 (Poly Fuel) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.?
 (Poly) Bool
)
(declare-fun NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
 (Poly Fuel) Bool
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%2
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%3
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (s! Poly) (fv! Poly)) (!
   (=>
    (and
     (has_type s! (TYPE%vstd!set.Set. K&. K&))
     (has_type fv! (TYPE%fun%1. K&. K& V&. V&))
    )
    (has_type (vstd!map.impl&%0.new.? K&. K& V&. V& s! fv!) (TYPE%vstd!map.Map. K&. K&
      V&. V&
   )))
   :pattern ((vstd!map.impl&%0.new.? K&. K& V&. V& s! fv!))
   :qid internal_vstd!map.impl&__0.new.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.new.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_new_domain.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (s! Poly) (fv! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. K&. K&))
      (has_type fv! (TYPE%fun%1. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.new.? K&. K& V&. V& s! fv!))
       s!
    )))
    :pattern ((vstd!map.impl&%0.new.? K&. K& V&. V& s! fv!))
    :qid user_vstd__map__lemma_map_new_domain_0
    :skolemid skolem_user_vstd__map__lemma_map_new_domain_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_new_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (s! Poly) (fv! Poly) (k! Poly)) (
    !
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. K&. K&))
      (has_type fv! (TYPE%fun%1. K&. K& V&. V&))
      (has_type k! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& s!) k!)
      )
      (= (vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.new.? K&. K& V&. V& s!
         fv!
        ) k!
       ) (%%apply%%0 (%Poly%fun%1. fv!) k!)
    )))
    :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.new.? K&. K& V&.
       V& s! fv!
      ) k!
    ))
    :qid user_vstd__map__lemma_map_new_index_0
    :skolemid skolem_user_vstd__map__lemma_map_new_index_0
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type)) (!
   (has_type (vstd!map.impl&%0.empty.? K&. K& V&. V&) (TYPE%vstd!map.Map. K&. K& V&. V&))
   :pattern ((vstd!map.impl&%0.empty.? K&. K& V&. V&))
   :qid internal_vstd!map.impl&__0.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.empty.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!set.Set.empty.? A&. A&) (TYPE%vstd!set.Set. A&. A&))
   :pattern ((vstd!set.Set.empty.? A&. A&))
   :qid internal_vstd!set.Set.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.Set.empty.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_empty.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type)) (!
    (=>
     (and
      (sized K&.)
      (sized V&.)
     )
     (= (vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.empty.? K&. K& V&. V&))
      (vstd!set.Set.empty.? K&. K&)
    ))
    :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.empty.? K&. K& V&.
       V&
    )))
    :qid user_vstd__map__lemma_map_empty_0
    :skolemid skolem_user_vstd__map__lemma_map_empty_0
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly) (value! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
     (has_type value! V&)
    )
    (has_type (vstd!map.impl&%0.insert.? K&. K& V&. V& self! key! value!) (TYPE%vstd!map.Map.
      K&. K& V&. V&
   )))
   :pattern ((vstd!map.impl&%0.insert.? K&. K& V&. V& self! key! value!))
   :qid internal_vstd!map.impl&__0.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.insert.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!set.Set. A&. A&))
     (has_type a! A&)
    )
    (has_type (vstd!set.Set.insert.? A&. A& self! a!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!set.Set.insert.? A&. A& self! a!))
   :qid internal_vstd!set.Set.insert.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.Set.insert.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_insert_domain.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly) (value! Poly))
   (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V& m!
         key! value!
        )
       ) (vstd!set.Set.insert.? K&. K& (vstd!map.impl&%0.dom.? K&. K& V&. V& m!) key!)
    )))
    :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&.
       V& m! key! value!
    )))
    :qid user_vstd__map__lemma_map_insert_domain_0
    :skolemid skolem_user_vstd__map__lemma_map_insert_domain_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.lemma_map_insert_same.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly) (value! Poly))
   (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V&
         m! key! value!
        ) key!
       ) value!
    )))
    :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K&
       V&. V& m! key! value!
      ) key!
    ))
    :qid user_vstd__map__lemma_map_insert_same_0
    :skolemid skolem_user_vstd__map__lemma_map_insert_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_insert_different.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key1! Poly) (key2! Poly)
    (value! Poly)
   ) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key1! K&)
      (has_type key2! K&)
      (has_type value! V&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (not (= key1! key2!))
      )
      (= (vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K& V&. V&
         m! key2! value!
        ) key1!
       ) (vstd!map.impl&%0.index.? K&. K& V&. V& m! key1!)
    )))
    :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& (vstd!map.impl&%0.insert.? K&. K&
       V&. V& m! key2! value!
      ) key1!
    ))
    :qid user_vstd__map__axiom_map_insert_different_0
    :skolemid skolem_user_vstd__map__axiom_map_insert_different_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_empty.)
  (forall ((A&. Dcr) (A& Type) (a! Poly)) (!
    (=>
     (has_type a! A&)
     (=>
      (sized A&.)
      (not (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.empty.?
          A&. A&
         )
        ) a!
    ))))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.empty.?
        A&. A&
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_empty_0
    :skolemid skolem_user_vstd__set__lemma_set_empty_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_same.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
         A&. A& s! a!
        )
       ) a!
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a!
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_insert_same_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_same_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_insert_different.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a1! A&)
      (has_type a2! A&)
     )
     (=>
      (and
       (sized A&.)
       (not (= a1! a2!))
      )
      (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
          A&. A& s! a2!
         )
        ) a1!
       ) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a1!)
    )))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.Set.insert.?
        A&. A& s! a2!
       )
      ) a1!
    ))
    :qid user_vstd__set__lemma_set_insert_different_0
    :skolemid skolem_user_vstd__set__lemma_set_insert_different_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!set.Set. A&. A&))
     (has_type s2! (TYPE%vstd!set.Set. A&. A&))
    )
    (has_type (vstd!set.impl&%0.union.? A&. A& self! s2!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.union.? A&. A& self! s2!))
   :qid internal_vstd!set.impl&__0.union.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.union.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_union.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (sized A&.)
      (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.impl&%0.union.?
          A&. A& s1! s2!
         )
        ) a!
       ) (or
        (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a!)
        (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a!)
    ))))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!set.impl&%0.union.?
        A&. A& s1! s2!
       )
      ) a!
    ))
    :qid user_vstd__set__lemma_set_union_0
    :skolemid skolem_user_vstd__set__lemma_set_union_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(declare-fun ens%core!clone.Clone.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (%return! Poly)) (!
   (= (ens%core!clone.Clone.clone. Self%&. Self%& self! %return!) (has_type %return! Self%&))
   :pattern ((ens%core!clone.Clone.clone. Self%&. Self%& self! %return!))
   :qid internal_ens__core!clone.Clone.clone._definition
   :skolemid skolem_internal_ens__core!clone.Clone.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (Self%&. Dcr) (Self%& Type)) (!
   (=>
    (has_type closure%$ (TYPE%tuple%1. (REF Self%&.) Self%&))
    (=>
     (let
      ((self$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      true
     )
     (closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.)) (TYPE%tuple%1.
       (REF Self%&.) Self%&
      ) (F fndef_singleton) closure%$
   )))
   :pattern ((closure_req (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (DST (REF Self%&.))
     (TYPE%tuple%1. (REF Self%&.) Self%&) (F fndef_singleton) closure%$
   ))
   :qid user_core__clone__Clone__clone_0
   :skolemid skolem_user_core__clone__Clone__clone_0
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%tuple%0.)
)
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Tuple1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. T%0&. T%0&)
    (tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Clone1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone1_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. T%0&. T%0&)
    (tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%0&.) (TYPE%tuple%1. T%0&. T%0&)))
   :qid internal_crate__impl_tuple&__Copy1_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy1_trait_impl_definition
)))
(declare-fun ens%core!clone.impls.impl&%10.clone. (Poly Poly) Bool)
(assert
 (forall ((x! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%10.clone. x! res!) (and
     (ens%core!clone.Clone.clone. $ USIZE x! res!)
     (= res! x!)
   ))
   :pattern ((ens%core!clone.impls.impl&%10.clone. x! res!))
   :qid internal_ens__core!clone.impls.impl&__10.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__10.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) USIZE))
     (has_type res$ USIZE)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1. (
        REF $
       ) USIZE
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((x$ (%I (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%I res$) x$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF $)) (TYPE%tuple%1.
      (REF $) USIZE
     ) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%10__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%10__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%42.clone. (Poly Poly) Bool)
(assert
 (forall ((b! Poly) (%return! Poly)) (!
   (= (ens%core!clone.impls.impl&%42.clone. b! %return!) (and
     (ens%core!clone.Clone.clone. $ BOOL b! %return!)
     (= %return! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%42.clone. b! %return!))
   :qid internal_ens__core!clone.impls.impl&__42.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__42.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) BOOL))
     (has_type %return$ BOOL)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1. (REF
        $
       ) BOOL
      ) (F fndef_singleton) closure%$ %return$
     )
     (let
      ((b$ (%B (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$)))))
      (= (%B %return$) b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $)) (TYPE%tuple%1.
      (REF $) BOOL
     ) (F fndef_singleton) closure%$ %return$
   ))
   :qid user_core__clone__impls__impl&%42__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%42__clone_0
)))
(declare-fun ens%core!clone.impls.impl&%6.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%core!clone.impls.impl&%6.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (REF T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%core!clone.impls.impl&%6.clone. T&. T& b! res!))
   :qid internal_ens__core!clone.impls.impl&__6.clone._definition
   :skolemid skolem_internal_ens__core!clone.impls.impl&__6.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (REF T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.))) (TYPE%tuple%1.
       (REF (REF T&.)) T&
      ) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST (REF (REF T&.)))
     (TYPE%tuple%1. (REF (REF T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_core__clone__impls__impl&%6__clone_0
   :skolemid skolem_user_core__clone__impls__impl&%6__clone_0
)))
(declare-fun ens%verus_builtin!impl&%9.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%9.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (TRACKED T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%9.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__9.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__9.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (TRACKED T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED T&.)))
      (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&) (DST (REF (TRACKED
        T&.
      ))
     ) (TYPE%tuple%1. (REF (TRACKED T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%9__clone_0
   :skolemid skolem_user_verus_builtin__impl&%9__clone_0
)))
(declare-fun ens%verus_builtin!impl&%7.clone. (Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (b! Poly) (res! Poly)) (!
   (= (ens%verus_builtin!impl&%7.clone. T&. T& b! res!) (and
     (ens%core!clone.Clone.clone. (GHOST T&.) T& b! res!)
     (= res! b!)
   ))
   :pattern ((ens%verus_builtin!impl&%7.clone. T&. T& b! res!))
   :qid internal_ens__verus_builtin!impl&__7.clone._definition
   :skolemid skolem_internal_ens__verus_builtin!impl&__7.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (GHOST T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST T&.)))
      (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (= res$ b$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (DST (REF (GHOST
        T&.
      ))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_verus_builtin__impl&%7__clone_0
   :skolemid skolem_user_verus_builtin__impl&%7__clone_0
)))
(assert
 (fuel_bool_default fuel%vstd!pervasive.strictly_cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.strictly_cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.strictly_cloned.? T&. T& a! b!) (closure_ens (FNDEF%core!clone.Clone.clone.
       T&. T&
      ) (DST (REF T&.)) (TYPE%tuple%1. (REF T&.) T&) (F fndef_singleton) (Poly%tuple%1.
       (tuple%1./tuple%1 a!)
      ) b!
    ))
    :pattern ((vstd!pervasive.strictly_cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.strictly_cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.strictly_cloned.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!pervasive.cloned.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!pervasive.cloned.)
  (forall ((T&. Dcr) (T& Type) (a! Poly) (b! Poly)) (!
    (= (vstd!pervasive.cloned.? T&. T& a! b!) (or
      (vstd!pervasive.strictly_cloned.? T&. T& a! b!)
      (= a! b!)
    ))
    :pattern ((vstd!pervasive.cloned.? T&. T& a! b!))
    :qid internal_vstd!pervasive.cloned.?_definition
    :skolemid skolem_internal_vstd!pervasive.cloned.?_definition
))))
(declare-fun ens%alloc!boxed.impl&%15.clone. (Dcr Type Dcr Type Poly Poly) Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (b! Poly) (res! Poly)) (!
   (= (ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!) (and
     (ens%core!clone.Clone.clone. (BOX A&. A& T&.) T& b! res!)
     (vstd!pervasive.cloned.? T&. T& b! res!)
   ))
   :pattern ((ens%alloc!boxed.impl&%15.clone. T&. T& A&. A& b! res!))
   :qid internal_ens__alloc!boxed.impl&__15.clone._definition
   :skolemid skolem_internal_ens__alloc!boxed.impl&__15.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (res$ Poly) (T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&))
     (has_type res$ T&)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF (BOX A&. A&
         T&.
       ))
      ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
     )
     (let
      ((b$ (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))))
      (vstd!pervasive.cloned.? T&. T& b$ res$)
   )))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&) (DST (REF
       (BOX A&. A& T&.)
      )
     ) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&) (F fndef_singleton) closure%$ res$
   ))
   :qid user_alloc__boxed__impl&%15__clone_0
   :skolemid skolem_user_alloc__boxed__impl&%15__clone_0
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!pervasive.arbitrary.? A&. A&) A&)
   :pattern ((vstd!pervasive.arbitrary.? A&. A&))
   :qid internal_vstd!pervasive.arbitrary.?_pre_post_definition
   :skolemid skolem_internal_vstd!pervasive.arbitrary.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!map_lib.impl&%0.contains_key.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map_lib.impl&%0.contains_key.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (k! Poly)) (!
    (= (vstd!map_lib.impl&%0.contains_key.? K&. K& V&. V& self! k!) (vstd!iset.ISet.contains.?
      K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
      k!
    ))
    :pattern ((vstd!map_lib.impl&%0.contains_key.? K&. K& V&. V& self! k!))
    :qid internal_vstd!map_lib.impl&__0.contains_key.?_definition
    :skolemid skolem_internal_vstd!map_lib.impl&__0.contains_key.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!map_lib.impl&%0.contains_pair.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map_lib.impl&%0.contains_pair.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (k! Poly) (v! Poly))
   (!
    (= (vstd!map_lib.impl&%0.contains_pair.? K&. K& V&. V& self! k! v!) (and
      (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
         K&. K& V&. V& self!
        )
       ) k!
      )
      (=>
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& self!
         )
        ) k!
       )
       (= (vstd!map.impl&%0.index.? K&. K& V&. V& self! k!) v!)
    )))
    :pattern ((vstd!map_lib.impl&%0.contains_pair.? K&. K& V&. V& self! k! v!))
    :qid internal_vstd!map_lib.impl&__0.contains_pair.?_definition
    :skolemid skolem_internal_vstd!map_lib.impl&__0.contains_pair.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!map_lib.impl&%0.union_prefer_right.)
)
(declare-fun %%lambda%%0 (Dcr Type Poly Dcr Type Dcr Type Poly Dcr Type Dcr Type Poly)
 %%Function%%
)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Poly) (%%hole%%3 Dcr) (%%hole%%4
    Type
   ) (%%hole%%5 Dcr) (%%hole%%6 Type) (%%hole%%7 Poly) (%%hole%%8 Dcr) (%%hole%%9 Type)
   (%%hole%%10 Dcr) (%%hole%%11 Type) (%%hole%%12 Poly) (k$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 %%hole%%5
      %%hole%%6 %%hole%%7 %%hole%%8 %%hole%%9 %%hole%%10 %%hole%%11 %%hole%%12
     ) k$
    ) (ite
     (vstd!iset.ISet.contains.? %%hole%%0 %%hole%%1 %%hole%%2 k$)
     (vstd!map.impl&%0.index.? %%hole%%3 %%hole%%4 %%hole%%5 %%hole%%6 %%hole%%7 k$)
     (vstd!map.impl&%0.index.? %%hole%%8 %%hole%%9 %%hole%%10 %%hole%%11 %%hole%%12 k$)
   ))
   :pattern ((%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4
      %%hole%%5 %%hole%%6 %%hole%%7 %%hole%%8 %%hole%%9 %%hole%%10 %%hole%%11 %%hole%%12
     ) k$
)))))
(assert
 (=>
  (fuel_bool fuel%vstd!map_lib.impl&%0.union_prefer_right.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (m2! Poly)) (!
    (= (vstd!map_lib.impl&%0.union_prefer_right.? K&. K& V&. V& self! m2!) (vstd!map.impl&%0.new.?
      K&. K& V&. V& (vstd!set.impl&%0.union.? K&. K& (vstd!map.impl&%0.dom.? K&. K& V&. V&
        self!
       ) (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
      ) (Poly%fun%1. (mk_fun (%%lambda%%0 K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
           K&. K& V&. V& m2!
          )
         ) K&. K& V&. V& m2! K&. K& V&. V& self!
    )))))
    :pattern ((vstd!map_lib.impl&%0.union_prefer_right.? K&. K& V&. V& self! m2!))
    :qid internal_vstd!map_lib.impl&__0.union_prefer_right.?_definition
    :skolemid skolem_internal_vstd!map_lib.impl&__0.union_prefer_right.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (m2! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
    )
    (has_type (vstd!map_lib.impl&%0.union_prefer_right.? K&. K& V&. V& self! m2!) (TYPE%vstd!map.Map.
      K&. K& V&. V&
   )))
   :pattern ((vstd!map_lib.impl&%0.union_prefer_right.? K&. K& V&. V& self! m2!))
   :qid internal_vstd!map_lib.impl&__0.union_prefer_right.?_pre_post_definition
   :skolemid skolem_internal_vstd!map_lib.impl&__0.union_prefer_right.?_pre_post_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.)
  (= NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.?
   4
)))
(assert
 (uInv SZ NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.)
  (= NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.?
   512
)))
(assert
 (uInv SZ NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.?)
)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(assert
 fuel_defaults
)
(assert
 (not true)
)
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.)
  (= NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.?
   (nClip (Mul (nClip (Mul (nClip (Mul 512 512)) 512)) 4096))
)))
(assert
 (<= 0 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.?)
)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.)
  (forall ((base! Poly) (idx! Poly) (entry_size! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?
      base! idx! entry_size!
     ) (nClip (Add (%I base!) (nClip (Mul (%I idx!) (%I entry_size!)))))
    )
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?
      base! idx! entry_size!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?_definition
))))
(assert
 (forall ((base! Poly) (idx! Poly) (entry_size! Poly)) (!
   (=>
    (and
     (has_type base! NAT)
     (has_type idx! NAT)
     (has_type entry_size! NAT)
    )
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?
      base! idx! entry_size!
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?
     base! idx! entry_size!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?_pre_post_definition
)))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((self! Poly) (layer! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
     self! layer!
    ) (=>
     %%global_location_label%%4
     (< (%I layer!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          self!
   )))))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
     self! layer!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(declare-const self! Poly)
(declare-const layer! Poly)
(declare-const tmp%1 Poly)
(declare-const tmp%2 Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
)
(assert
 (has_type layer! NAT)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (< (%I layer!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        self!
   )))))
   (=>
    (= tmp%2 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        self!
    ))))
    (=>
     %%location_label%%0
     (req%vstd!seq.impl&%2.spec_index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      tmp%2 layer!
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.)
  (forall ((self! Poly) (layer! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
      self! layer!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/entry_size
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           self!
         ))
        ) layer!
    ))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
      self! layer!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size.?_definition
))))
(assert
 (forall ((self! Poly) (layer! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
     (has_type layer! NAT)
    )
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
      self! layer!
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
     self! layer!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size.?_pre_post_definition
)))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((self! Poly) (layer! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
     self! layer!
    ) (=>
     %%global_location_label%%5
     (< (%I layer!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          self!
   )))))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
     self! layer!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.num_entries._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.num_entries._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(declare-const self! Poly)
(declare-const layer! Poly)
(declare-const tmp%1 Poly)
(declare-const tmp%2 Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
)
(assert
 (has_type layer! NAT)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (< (%I layer!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        self!
   )))))
   (=>
    (= tmp%2 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        self!
    ))))
    (=>
     %%location_label%%0
     (req%vstd!seq.Seq.index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      tmp%2 layer!
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.)
  (forall ((self! Poly) (layer! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
      self! layer!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer./ArchLayer/num_entries
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           self!
         ))
        ) layer!
    ))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
      self! layer!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.num_entries.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.num_entries.?_definition
))))
(assert
 (forall ((self! Poly) (layer! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
     (has_type layer! NAT)
    )
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
      self! layer!
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
     self! layer!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.num_entries.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.num_entries.?_pre_post_definition
)))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((self! Poly) (i! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.
     self! i!
    ) (=>
     %%global_location_label%%6
     (< (%I i!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          self!
   )))))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.
     self! i!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size_is_next_layer_size._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size_is_next_layer_size._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const i! Poly)
(declare-const tmp%1 Int)
(declare-const tmp%2 Int)
(declare-const tmp%3 Poly)
(declare-const tmp%4 Int)
(declare-const tmp%5 Poly)
(declare-const tmp%6 Int)
(declare-const tmp%7 Int)
(declare-const tmp%8 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
)
(assert
 (has_type i! NAT)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(assert
 (not (=>
   (< (%I i!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        self!
   )))))
   (or
    (and
     (=>
      (< (nClip (Add (%I i!) 1)) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           self!
      )))))
      (and
       (=>
        %%location_label%%0
        (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
         self! i!
       ))
       (=>
        (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
          self! i!
        ))
        (=>
         (= tmp%7 tmp%1)
         (=>
          (= tmp%3 (I (nClip (Add (%I i!) 1))))
          (and
           (=>
            %%location_label%%1
            (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
             self! tmp%3
           ))
           (=>
            (= tmp%2 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
              self! (I (nClip (Add (%I i!) 1)))
            ))
            (=>
             (= tmp%6 tmp%2)
             (=>
              (= tmp%5 (I (nClip (Add (%I i!) 1))))
              (and
               (=>
                %%location_label%%2
                (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
                 self! tmp%5
               ))
               (=>
                (= tmp%4 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
                  self! (I (nClip (Add (%I i!) 1)))
                ))
                (=>
                 (= tmp%8 (= tmp%7 (nClip (Mul tmp%6 tmp%4))))
                 %%switch_label%%0
     ))))))))))))
     (=>
      (not (< (nClip (Add (%I i!) 1)) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
            self!
      ))))))
      (=>
       (= tmp%8 true)
       %%switch_label%%0
    )))
    (not %%switch_label%%0)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.)
  (forall ((self! Poly) (i! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.?
      self! i!
     ) (=>
      (< (nClip (Add (%I i!) 1)) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           self!
      )))))
      (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
        self! i!
       ) (nClip (Mul (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
          self! (I (nClip (Add (%I i!) 1)))
         ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
          self! (I (nClip (Add (%I i!) 1)))
    ))))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.?
      self! i!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size_is_next_layer_size.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_size_is_next_layer_size.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const i@ Poly)
(declare-const tmp%%@ Int)
(declare-const tmp%%$1@ Int)
(declare-const tmp%%$2@ Int)
(declare-const tmp%%$3@ Int)
(declare-const tmp%%$4@ Int)
(declare-const tmp%%$5@ Int)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Bool)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Bool)
(declare-const tmp%5 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%switch_label%%2 Bool)
(declare-const %%switch_label%%3 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(assert
 (not (or
   (and
    (=>
     (<= (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          self!
       )))
      ) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.?
     )
     (=>
      (has_type i@ NAT)
      (or
       (and
        (=>
         (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
           (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
              self!
         )))))
         (=>
          (= tmp%%@ 0)
          (and
           (=>
            %%location_label%%0
            (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
             self! i@
           ))
           (=>
            (= tmp%%$2@ NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.?)
            (or
             (and
              (=>
               (and
                (< tmp%%@ tmp%%$1@)
                (<= tmp%%$1@ tmp%%$2@)
               )
               (=>
                (= tmp%%$3@ 0)
                (and
                 (=>
                  %%location_label%%1
                  (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
                   self! i@
                 ))
                 (=>
                  (= tmp%%$5@ NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.?)
                  (=>
                   (= tmp%1 (and
                     (< tmp%%$3@ tmp%%$4@)
                     (<= tmp%%$4@ tmp%%$5@)
                   ))
                   %%switch_label%%3
              )))))
              (=>
               (not (and
                 (< tmp%%@ tmp%%$1@)
                 (<= tmp%%$1@ tmp%%$2@)
               ))
               (=>
                (= tmp%1 false)
                %%switch_label%%3
             )))
             (and
              (not %%switch_label%%3)
              (or
               (and
                (=>
                 tmp%1
                 (and
                  (=>
                   %%location_label%%2
                   (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.
                    self! i@
                  ))
                  (=>
                   (= tmp%2 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.?
                     self! i@
                   ))
                   (=>
                    (= tmp%3 tmp%2)
                    %%switch_label%%2
                ))))
                (=>
                 (not tmp%1)
                 (=>
                  (= tmp%3 false)
                  %%switch_label%%2
               )))
               (and
                (not %%switch_label%%2)
                (=>
                 (= tmp%4 tmp%3)
                 %%switch_label%%1
        )))))))))
        (=>
         (not (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
               self!
         ))))))
         (=>
          (= tmp%4 true)
          %%switch_label%%1
       )))
       (and
        (not %%switch_label%%1)
        (=>
         (= tmp%5 (forall ((i$ Poly)) (!
            (=>
             (has_type i$ NAT)
             (=>
              (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
                (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
                   self!
              )))))
              (and
               (and
                (let
                 ((tmp%%$ 0))
                 (let
                  ((tmp%%$13 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
                     self! i$
                  )))
                  (let
                   ((tmp%%$14 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.?))
                   (and
                    (< tmp%%$ tmp%%$13)
                    (<= tmp%%$13 tmp%%$14)
                ))))
                (let
                 ((tmp%%$ 0))
                 (let
                  ((tmp%%$16 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
                     self! i$
                  )))
                  (let
                   ((tmp%%$17 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.?))
                   (and
                    (< tmp%%$ tmp%%$16)
                    (<= tmp%%$16 tmp%%$17)
               )))))
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.?
                self! i$
            ))))
            :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
              self! i$
            ))
            :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
              self! i$
            ))
            :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch__inv_1
            :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch__inv_1
         )))
         %%switch_label%%0
    )))))
    (=>
     (not (<= (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           self!
        )))
       ) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.?
     ))
     (=>
      (= tmp%5 false)
      %%switch_label%%0
   )))
   (not %%switch_label%%0)
)))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
      self!
     ) (and
      (<= (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           self!
        )))
       ) NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_LAYERS.?
      )
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ NAT)
         (=>
          (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
               self!
          )))))
          (and
           (and
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
                 self! i$
              )))
              (let
               ((tmp%%$2 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_MAX_ENTRY_SIZE.?))
               (and
                (< tmp%%$ tmp%%$1)
                (<= tmp%%$1 tmp%%$2)
            ))))
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$4 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
                 self! i$
              )))
              (let
               ((tmp%%$5 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!X86_NUM_ENTRIES.?))
               (and
                (< tmp%%$ tmp%%$4)
                (<= tmp%%$4 tmp%%$5)
           )))))
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size_is_next_layer_size.?
            self! i$
        ))))
        :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
          self! i$
        ))
        :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
          self! i$
        ))
        :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch__inv_0
        :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Arch__inv_0
    ))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.inv.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.inv.?_definition
))))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.
 (Poly Poly Poly Poly) Bool
)
(declare-const %%global_location_label%%7 Bool)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((self! Poly) (layer! Poly) (base! Poly) (idx! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.
     self! layer! base! idx!
    ) (and
     (=>
      %%global_location_label%%7
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
       self!
     ))
     (=>
      %%global_location_label%%8
      (< (%I layer!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           self!
   ))))))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.
     self! layer! base! idx!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_base._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_base._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(declare-const self! Poly)
(declare-const layer! Poly)
(declare-const base! Poly)
(declare-const idx! Poly)
(declare-const tmp%1 Int)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
)
(assert
 (has_type layer! NAT)
)
(assert
 (has_type base! NAT)
)
(assert
 (has_type idx! NAT)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
    self!
   )
   (=>
    (< (%I layer!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         self!
    )))))
    (=>
     (= tmp%2 base!)
     (=>
      (= tmp%3 idx!)
      (=>
       %%location_label%%0
       (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
        self! layer!
))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.)
  (forall ((self! Poly) (layer! Poly) (base! Poly) (idx! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.?
      self! layer! base! idx!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?
      base! idx! (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
        self! layer!
    ))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.?
      self! layer! base! idx!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_base.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_base.?_definition
))))
(assert
 (forall ((self! Poly) (layer! Poly) (base! Poly) (idx! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.)
     (has_type layer! NAT)
     (has_type base! NAT)
     (has_type idx! NAT)
    )
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.?
      self! layer! base! idx!
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_base.?
     self! layer! base! idx!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_base.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__3.entry_base.?_pre_post_definition
)))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
 (Poly) Bool
)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
     self!
    ) (=>
     %%global_location_label%%9
     (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       self!
   ))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
     self!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Directory_0._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Directory_0._definition
)))
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.?
      self!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       self!
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Directory_0.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Directory_0.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.?
       self!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.?
     self!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Directory_0.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Directory_0.?_pre_post_definition
)))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.
 (Poly) Bool
)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.
     self!
    ) (=>
     %%global_location_label%%10
     (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       self!
   ))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.
     self!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Page_0._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Page_0._definition
)))
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.?
      self!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       self!
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Page_0.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Page_0.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
    (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.?
       self!
      )
     ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.?
     self!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Page_0.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__4.arrow_Page_0.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.)
  (forall ((self! Poly) (idx! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
      self! idx!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!entry_base_from_index.?
      (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
       ))
      ) idx! (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
         ))
        ) (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
    )))))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
      self! idx!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_base.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_base.?_definition
))))
(assert
 (forall ((self! Poly) (idx! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
     (has_type idx! NAT)
    )
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
      self! idx!
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
     self! idx!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_base.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_base.?_pre_post_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! Poly)
(declare-const entry! Poly)
(declare-const tmp%1 vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(declare-const tmp%4 vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
(declare-const decrease%init0 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
(declare-const decrease%init1 Int)
(declare-const decrease%init2 Int)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(assert
 (has_type entry! NAT)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= decrease%init0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
     self!
   ))
   (=>
    (= decrease%init1 (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
          self!
       )))
      ) (%I entry!)
    ))
    (=>
     (= decrease%init2 1)
     (or
      (and
       (=>
        (< (%I entry!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
        )))))
        (=>
         (= tmp%2 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
           (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
            ))
           ) entry!
         ))
         (=>
          (= tmp%3 (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
             self! entry!
          )))
          (and
           (=>
            %%location_label%%0
            (check_decrease_height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (let
               ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                  tmp%2
                 )
                ) (base!$1 (%I tmp%3))
               )
               self!$0
              )
             ) (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              decrease%init0
             ) (check_decrease_height (I (let
                ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                   tmp%2
                  )
                 ) (base!$1 (%I tmp%3))
                )
                0
               )
              ) (I decrease%init1) (check_decrease_height (I (let
                 ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                    tmp%2
                   )
                  ) (base!$1 (%I tmp%3))
                 )
                 0
                )
               ) (I decrease%init2) false
           ))))
           (=>
            (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.?
              (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
                ))
               ) entry!
              ) (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
                self! entry!
            ))))
            (=>
             (= tmp%4 tmp%1)
             %%switch_label%%0
       ))))))
       (=>
        (not (< (%I entry!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
           (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
        ))))))
        (=>
         (= tmp%4 (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
           (vstd!pervasive.arbitrary.? $ (TYPE%vstd!map.Map. $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
         ))
         %%switch_label%%0
      )))
      (not %%switch_label%%0)
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! Poly)
(declare-const i! Poly)
(declare-const tmp%1 vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
(declare-const tmp%2 Poly)
(declare-const tmp%3 vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
(declare-const tmp%4 Poly)
(declare-const tmp%5 Poly)
(declare-const decrease%init0 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
(declare-const decrease%init1 Int)
(declare-const decrease%init2 Int)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(assert
 (has_type i! NAT)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(assert
 (not (=>
   (= decrease%init0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
     self!
   ))
   (=>
    (= decrease%init1 (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
          self!
       )))
      ) (%I i!)
    ))
    (=>
     (= decrease%init2 2)
     (or
      (and
       (=>
        (< (%I i!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
        )))))
        (=>
         (= tmp%2 (I (nClip (Add (%I i!) 1))))
         (and
          (=>
           %%location_label%%0
           (check_decrease_height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             (let
              ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
                )
               ) (i!$1 (%I tmp%2))
              )
              self!$0
             )
            ) (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             decrease%init0
            ) (check_decrease_height (I (let
               ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
                 )
                ) (i!$1 (%I tmp%2))
               )
               (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                  (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                   (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!$0
                 ))))
                ) i!$1
              ))
             ) (I decrease%init1) (check_decrease_height (I (let
                ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   self!
                  )
                 ) (i!$1 (%I tmp%2))
                )
                2
               )
              ) (I decrease%init2) false
          ))))
          (=>
           (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
             self! (I (nClip (Add (%I i!) 1)))
           ))
           (=>
            (= tmp%4 (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
              tmp%1
            ))
            (and
             (=>
              %%location_label%%1
              (check_decrease_height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                (let
                 ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!
                   )
                  ) (entry!$1 (%I i!))
                 )
                 self!$0
                )
               ) (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                decrease%init0
               ) (check_decrease_height (I (let
                  ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!
                    )
                   ) (entry!$1 (%I i!))
                  )
                  (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                    (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                        self!$0
                    ))))
                   ) entry!$1
                 ))
                ) (I decrease%init1) (check_decrease_height (I (let
                   ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      self!
                     )
                    ) (entry!$1 (%I i!))
                   )
                   1
                  )
                 ) (I decrease%init2) false
             ))))
             (=>
              (= tmp%3 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                self! i!
              ))
              (=>
               (= tmp%5 (vstd!map_lib.impl&%0.union_prefer_right.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                 tmp%4 (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                  tmp%3
               )))
               %%switch_label%%0
       ))))))))
       (=>
        (not (< (%I i!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
           (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
        ))))))
        (=>
         (= tmp%5 (vstd!map.impl&%0.empty.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
         %%switch_label%%0
      )))
      (not %%switch_label%%0)
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! Poly)
(declare-const base! Poly)
(declare-const tmp%1 vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
(declare-const d@ NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
(declare-const tmp%2 vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
(declare-const tmp%3 Poly)
(declare-const decrease%init0 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
(declare-const decrease%init1 Int)
(declare-const decrease%init2 Int)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
)
(assert
 (has_type base! NAT)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= decrease%init0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
     self!
   ))
   (=>
    (= decrease%init1 0)
    (=>
     (= decrease%init2 0)
     (or
      (and
       (=>
        (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          self!
        ))
        (=>
         (= tmp%3 (let
           ((p$ (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               self!
           ))))
           (vstd!map.impl&%0.insert.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
            (vstd!map.impl&%0.empty.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
            base! (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
             p$
         ))))
         %%switch_label%%0
       ))
       (=>
        (not (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
           self!
        )))
        (or
         (and
          (=>
           (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             self!
           ))
           (=>
            (= d@ (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               self!
            )))
            (and
             (=>
              %%location_label%%0
              (check_decrease_height (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                (let
                 ((self!$0 d@) (i!$1 0))
                 self!$0
                )
               ) (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                decrease%init0
               ) (check_decrease_height (I (let
                  ((self!$0 d@) (i!$1 0))
                  (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                    (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                        self!$0
                    ))))
                   ) i!$1
                 ))
                ) (I decrease%init1) (check_decrease_height (I (let
                   ((self!$0 d@) (i!$1 0))
                   2
                  )
                 ) (I decrease%init2) false
             ))))
             (=>
              (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 d@
                ) (I 0)
              ))
              (=>
               (= tmp%2 tmp%1)
               %%switch_label%%1
          )))))
          (=>
           (not (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              self!
           )))
           (=>
            (= tmp%2 (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
              (vstd!map.impl&%0.empty.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
            ))
            %%switch_label%%1
         )))
         (and
          (not %%switch_label%%1)
          (=>
           (= tmp%3 (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
             tmp%2
           ))
           %%switch_label%%0
      )))))
      (not %%switch_label%%0)
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.)
)
(declare-const fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.
 Fuel
)
(assert
 (forall ((self! Poly) (entry! Poly) (fuel% Fuel)) (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
     self! entry! fuel%
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
     self! entry! zero
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
     self! entry! fuel%
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_of_entry._fuel_to_zero_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_of_entry._fuel_to_zero_definition
)))
(assert
 (forall ((self! Poly) (entry! Poly) (fuel% Fuel)) (!
   (=>
    (and
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
     (has_type entry! NAT)
    )
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
      self! entry! (succ fuel%)
     ) (ite
      (< (%I entry!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
      )))))
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
       (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
         ))
        ) entry!
       ) (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_base.?
         self! entry!
        )
       ) fuel%
      )
      (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
       (vstd!pervasive.arbitrary.? $ (TYPE%vstd!map.Map. $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.))
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
     self! entry! (succ fuel%)
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_of_entry._fuel_to_body_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_of_entry._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.)
  (forall ((self! Poly) (entry! Poly)) (!
    (=>
     (and
      (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
      (has_type entry! NAT)
     )
     (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
       self! entry!
      ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
       self! entry! (succ (succ (succ fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.)))
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
      self! entry!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_of_entry.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_of_entry.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.)
)
(declare-const fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.
 Fuel
)
(assert
 (forall ((self! Poly) (i! Poly) (fuel% Fuel)) (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
     self! i! fuel%
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
     self! i! zero
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
     self! i! fuel%
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_aux._fuel_to_zero_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_aux._fuel_to_zero_definition
)))
(assert
 (forall ((self! Poly) (i! Poly) (fuel% Fuel)) (!
   (=>
    (and
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
     (has_type i! NAT)
    )
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
      self! i! (succ fuel%)
     ) (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
      (ite
       (< (%I i!) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
       )))))
       (vstd!map_lib.impl&%0.union_prefer_right.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
        (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
          self! (I (nClip (Add (%I i!) 1))) fuel%
         )
        ) (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_of_entry.?
          self! i! fuel%
       )))
       (vstd!map.impl&%0.empty.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
     self! i! (succ fuel%)
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_aux._fuel_to_body_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_aux._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.)
  (forall ((self! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
      (has_type i! NAT)
     )
     (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
       self! i!
      ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
       self! i! (succ fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.)
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
      self! i!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_aux.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.interp_aux.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.)
)
(declare-const fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.
 Fuel
)
(assert
 (forall ((self! Poly) (base! Poly) (fuel% Fuel)) (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
     self! base! fuel%
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
     self! base! zero
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
     self! base! fuel%
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__5.interp._fuel_to_zero_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__5.interp._fuel_to_zero_definition
)))
(assert
 (forall ((self! Poly) (base! Poly) (fuel% Fuel)) (!
   (=>
    (and
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
     (has_type base! NAT)
    )
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
      self! base! (succ fuel%)
     ) (ite
      (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        self!
      ))
      (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
       (let
        ((p$ (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            self!
        ))))
        (vstd!map.impl&%0.insert.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
         (vstd!map.impl&%0.empty.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
         base! (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
          p$
      ))))
      (ite
       (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
         self!
       ))
       (let
        ((d$ (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            self!
        ))))
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%interp_aux.?
         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
          d$
         ) (I 0) fuel%
       ))
       (%Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
        (vstd!map.impl&%0.empty.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
   )))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
     self! base! (succ fuel%)
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__5.interp._fuel_to_body_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__5.interp._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.)
  (forall ((self! Poly) (base! Poly)) (!
    (=>
     (and
      (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.)
      (has_type base! NAT)
     )
     (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.?
       self! base!
      ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.rec%interp.?
       self! base! (succ (succ (succ fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.)))
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%5.interp.?
      self! base!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__5.interp.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__5.interp.?_definition
))))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.
 (Poly) Bool
)
(declare-const %%global_location_label%%11 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.
     self!
    ) (=>
     %%global_location_label%%11
     (< (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
        self!
       )
      ) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
   ))))))))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.
     self!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.num_entries._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.num_entries._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(declare-const self! Poly)
(declare-const tmp%1 Int)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (< (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      self!
     )
    ) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
   ))))))))
   (=>
    (= tmp%2 (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
        self!
    ))))
    (=>
     (= tmp%3 (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
     ))))
     (=>
      %%location_label%%0
      (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.
       tmp%2 tmp%3
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
      self!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.num_entries.?
      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
       ))
      ) (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
    )))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.num_entries.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.num_entries.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
      self!
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
     self!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.num_entries.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.num_entries.?_pre_post_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const tmp%1 Int)
(declare-const tmp%2 Int)
(declare-const tmp%3 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(assert
 (not (or
   (and
    (=>
     (and
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
       (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
          self!
      ))))
      (< (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
        )
       ) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
     )))))))))
     (=>
      (= tmp%2 (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
      )))))
      (and
       (=>
        %%location_label%%0
        (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.
         self!
       ))
       (=>
        (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
          self!
        ))
        (=>
         (= tmp%3 (= tmp%2 tmp%1))
         %%switch_label%%0
    )))))
    (=>
     (not (and
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
       ))))
       (< (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
          self!
         )
        ) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
     ))))))))))
     (=>
      (= tmp%3 false)
      %%switch_label%%0
   )))
   (not %%switch_label%%0)
)))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
      self!
     ) (and
      (and
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.inv.?
        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
       ))))
       (< (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
          self!
         )
        ) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
      )))))))))
      (= (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
        )))
       ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
        self!
    ))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.well_formed.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.well_formed.?_definition
))))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.
 (Poly) Bool
)
(declare-const %%global_location_label%%12 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.
     self!
    ) (=>
     %%global_location_label%%12
     (< (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
        self!
       )
      ) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
   ))))))))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.
     self!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_size._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_size._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Int)
(declare-const self! Poly)
(declare-const tmp%1 Int)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (< (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
      self!
     )
    ) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
   ))))))))
   (=>
    (= tmp%2 (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
        self!
    ))))
    (=>
     (= tmp%3 (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
     ))))
     (=>
      %%location_label%%0
      (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.
       tmp%2 tmp%3
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
      self!
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%3.entry_size.?
      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
       ))
      ) (I (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
         self!
    )))))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_size.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_size.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
    (<= 0 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
      self!
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
     self!
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_size.?_pre_post_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.entry_size.?_pre_post_definition
)))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.
 (Poly) Bool
)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.
     self!
    ) (=>
     %%global_location_label%%13
     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
      self!
   )))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.
     self!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.pages_match_entry_size._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.pages_match_entry_size._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const i@ Poly)
(declare-const tmp%1 Poly)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Poly)
(declare-const tmp%5 Poly)
(declare-const tmp%6 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
(declare-const tmp%7 Int)
(declare-const tmp%8 Int)
(declare-const tmp%9 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(assert
 (not (=>
   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
    self!
   )
   (=>
    (has_type i@ NAT)
    (or
     (and
      (=>
       (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
       )))))
       (=>
        (= tmp%2 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
        ))))
        (and
         (=>
          %%location_label%%0
          (req%vstd!seq.impl&%2.spec_index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
           tmp%2 i@
         ))
         (=>
          (= tmp%1 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
             ))
            ) i@
          ))
          (=>
           (= tmp%3 (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              tmp%1
           )))
           %%switch_label%%1
      )))))
      (=>
       (not (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
       ))))))
       (=>
        (= tmp%3 false)
        %%switch_label%%1
     )))
     (and
      (not %%switch_label%%1)
      (or
       (and
        (=>
         tmp%3
         (=>
          (= tmp%5 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
          ))))
          (and
           (=>
            %%location_label%%1
            (req%vstd!seq.impl&%2.spec_index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             tmp%5 i@
           ))
           (=>
            (= tmp%4 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
               ))
              ) i@
            ))
            (and
             (=>
              %%location_label%%2
              (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Page_0.
               tmp%4
             ))
             (=>
              (= tmp%6 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
                (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                 tmp%4
              )))
              (=>
               (= tmp%8 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
                  (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
                   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
                    (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                      tmp%6
               )))))))
               (and
                (=>
                 %%location_label%%3
                 (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.
                  self!
                ))
                (=>
                 (= tmp%7 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
                   self!
                 ))
                 (=>
                  (= tmp%9 (= tmp%8 tmp%7))
                  %%switch_label%%0
        ))))))))))
        (=>
         (not tmp%3)
         (=>
          (= tmp%9 true)
          %%switch_label%%0
       )))
       (not %%switch_label%%0)
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.?
      self!
     ) (forall ((i$ Poly)) (!
       (=>
        (has_type i$ NAT)
        (=>
         (and
          (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
          )))))
          (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
              ))
             ) i$
         ))))
         (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
               (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                  (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                   (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      self!
                    ))
                   ) i$
           ))))))))
          ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
           self!
       ))))
       :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion./MemRegion/size
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!MemRegion.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE./PTE/frame
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Page/0
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                  (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                   (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!
                  ))
                 ) i$
       ))))))))))
       :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__pages_match_entry_size_0
       :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__pages_match_entry_size_0
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.pages_match_entry_size.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.pages_match_entry_size.?_definition
))))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
 (Poly) Bool
)
(declare-const %%global_location_label%%14 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
     self!
    ) (=>
     %%global_location_label%%14
     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
      self!
   )))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
     self!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_are_in_next_layer._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_are_in_next_layer._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const i@ Poly)
(declare-const tmp%1 Poly)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Poly)
(declare-const tmp%5 Poly)
(declare-const tmp%6 Int)
(declare-const tmp%7 Poly)
(declare-const tmp%8 Int)
(declare-const tmp%9 Int)
(declare-const tmp%10 Bool)
(declare-const directory@ NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
(declare-const tmp%11 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%switch_label%%2 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(assert
 (not (=>
   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
    self!
   )
   (=>
    (has_type i@ NAT)
    (or
     (and
      (=>
       (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
       )))))
       (=>
        (= tmp%2 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
        ))))
        (and
         (=>
          %%location_label%%0
          (req%vstd!seq.Seq.index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
           tmp%2 i@
         ))
         (=>
          (= tmp%1 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
             ))
            ) i@
          ))
          (=>
           (= tmp%3 (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              tmp%1
           )))
           %%switch_label%%2
      )))))
      (=>
       (not (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
       ))))))
       (=>
        (= tmp%3 false)
        %%switch_label%%2
     )))
     (and
      (not %%switch_label%%2)
      (or
       (and
        (=>
         tmp%3
         (=>
          (= tmp%5 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
          ))))
          (and
           (=>
            %%location_label%%1
            (req%vstd!seq.impl&%2.spec_index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             tmp%5 i@
           ))
           (=>
            (= tmp%4 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
               ))
              ) i@
            ))
            (and
             (=>
              %%location_label%%2
              (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
               tmp%4
             ))
             (or
              (and
               (=>
                (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    directory@
                  ))
                 ) (nClip (Add (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
                    (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!
                    )
                   ) 1
                )))
                (=>
                 (= tmp%9 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
                   (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     directory@
                 ))))
                 (=>
                  (= tmp%8 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
                    (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!
                  )))
                  (=>
                   (= tmp%7 i@)
                   (and
                    (=>
                     %%location_label%%3
                     (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.
                      self!
                    ))
                    (=>
                     (= tmp%6 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
                       self!
                     ))
                     (=>
                      (= tmp%10 (= tmp%9 (nClip (Add tmp%8 (nClip (Mul (%I tmp%7) tmp%6))))))
                      %%switch_label%%1
               )))))))
               (=>
                (not (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
                   (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     directory@
                   ))
                  ) (nClip (Add (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
                     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      self!
                     )
                    ) 1
                ))))
                (=>
                 (= tmp%10 false)
                 %%switch_label%%1
              )))
              (and
               (not %%switch_label%%1)
               (=>
                (= tmp%11 tmp%10)
                %%switch_label%%0
        ))))))))
        (=>
         (not tmp%3)
         (=>
          (= tmp%11 true)
          %%switch_label%%0
       )))
       (not %%switch_label%%0)
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
      self!
     ) (forall ((i$ Poly)) (!
       (=>
        (has_type i$ NAT)
        (=>
         (and
          (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
          )))))
          (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
              ))
             ) i$
         ))))
         (let
          ((directory$ (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
                ))
               ) i$
          )))))
          (and
           (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               directory$
             ))
            ) (nClip (Add (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
               )
              ) 1
           )))
           (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               directory$
             ))
            ) (nClip (Add (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/base_vaddr
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
               )
              ) (nClip (Mul (%I i$) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.entry_size.?
                 self!
       ))))))))))
       :pattern ((vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
          ))
         ) i$
       ))
       :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_are_in_next_layer_0
       :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_are_in_next_layer_0
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_are_in_next_layer.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_are_in_next_layer.?_definition
))))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const i@ Poly)
(declare-const tmp%1 Poly)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Poly)
(declare-const tmp%5 Poly)
(declare-const tmp%6 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
(declare-const tmp%7 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(assert
 (not (=>
   (has_type i@ NAT)
   (or
    (and
     (=>
      (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
        (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
      )))))
      (=>
       (= tmp%2 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
       ))))
       (and
        (=>
         %%location_label%%0
         (req%vstd!seq.Seq.index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          tmp%2 i@
        ))
        (=>
         (= tmp%1 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
           (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
            ))
           ) i@
         ))
         (=>
          (= tmp%3 (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             tmp%1
          )))
          %%switch_label%%1
     )))))
     (=>
      (not (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
      ))))))
      (=>
       (= tmp%3 false)
       %%switch_label%%1
    )))
    (and
     (not %%switch_label%%1)
     (or
      (and
       (=>
        tmp%3
        (=>
         (= tmp%5 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
         ))))
         (and
          (=>
           %%location_label%%1
           (req%vstd!seq.Seq.index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            tmp%5 i@
          ))
          (=>
           (= tmp%4 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
              ))
             ) i@
           ))
           (and
            (=>
             %%location_label%%2
             (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
              tmp%4
            ))
            (=>
             (= tmp%6 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                tmp%4
             )))
             (=>
              (= tmp%7 (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   tmp%6
                 ))
                ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
              ))))
              %%switch_label%%0
       )))))))
       (=>
        (not tmp%3)
        (=>
         (= tmp%7 true)
         %%switch_label%%0
      )))
      (not %%switch_label%%0)
))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.)
)
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.)
  (forall ((self! Poly)) (!
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
      self!
     ) (forall ((i$ Poly)) (!
       (=>
        (has_type i$ NAT)
        (=>
         (and
          (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
          )))))
          (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
            (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
              ))
             ) i$
         ))))
         (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   self!
                 ))
                ) i$
           )))))
          ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
       )))))
       :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
               ))
              ) i$
       )))))))
       :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_match_arch_0
       :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_match_arch_0
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_match_arch.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_match_arch.?_definition
))))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.
 (Poly) Bool
)
(declare-const %%global_location_label%%15 Bool)
(declare-const %%global_location_label%%16 Bool)
(declare-const %%global_location_label%%17 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.
     self!
    ) (and
     (=>
      %%global_location_label%%15
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
       self!
     ))
     (=>
      %%global_location_label%%16
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
       self!
     ))
     (=>
      %%global_location_label%%17
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
       self!
   ))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.
     self!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Bool)
(declare-const decrease%init0 Int)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= decrease%init0 (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
      ))))))
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       self!
   ))))
   (or
    (and
     (=>
      (and
       (and
        (and
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
          self!
         )
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.?
          self!
        ))
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
         self!
       ))
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
        self!
      ))
      (and
       (=>
        %%location_label%%0
        (check_decrease_height (I (let
           ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
           )))
           (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
             (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
                (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!$0
             )))))))
            ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!$0
          )))))
         ) (I decrease%init0) true
       ))
       (=>
        (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.?
          self!
        ))
        (=>
         (= tmp%2 tmp%1)
         %%switch_label%%0
     ))))
     (=>
      (not (and
        (and
         (and
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
           self!
          )
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.?
           self!
         ))
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
          self!
        ))
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
         self!
      )))
      (=>
       (= tmp%2 false)
       %%switch_label%%0
    )))
    (not %%switch_label%%0)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Bool)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Bool)
(declare-const tmp%5 Bool)
(declare-const tmp%6 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%switch_label%%2 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(assert
 (not (or
   (and
    (=>
     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
      self!
     )
     (and
      (=>
       %%location_label%%0
       (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.
        self!
      ))
      (=>
       (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.?
         self!
       ))
       (=>
        (= tmp%2 tmp%1)
        %%switch_label%%2
    ))))
    (=>
     (not (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
       self!
     ))
     (=>
      (= tmp%2 false)
      %%switch_label%%2
   )))
   (and
    (not %%switch_label%%2)
    (or
     (and
      (=>
       tmp%2
       (and
        (=>
         %%location_label%%1
         (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
          self!
        ))
        (=>
         (= tmp%3 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
           self!
         ))
         (=>
          (= tmp%4 tmp%3)
          %%switch_label%%1
      ))))
      (=>
       (not tmp%2)
       (=>
        (= tmp%4 false)
        %%switch_label%%1
     )))
     (and
      (not %%switch_label%%1)
      (or
       (and
        (=>
         (and
          tmp%4
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
           self!
         ))
         (and
          (=>
           %%location_label%%2
           (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.
            self!
          ))
          (=>
           (= tmp%5 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.?
             self!
           ))
           (=>
            (= tmp%6 tmp%5)
            %%switch_label%%0
        ))))
        (=>
         (not (and
           tmp%4
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
            self!
         )))
         (=>
          (= tmp%6 false)
          %%switch_label%%0
       )))
       (not %%switch_label%%0)
)))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! Poly)
(declare-const i@ Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Bool)
(declare-const tmp%4 Bool)
(declare-const decrease%init0 Int)
(declare-const decrease%init1 Int)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= decrease%init0 (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
      ))))))
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       self!
   ))))
   (=>
    (= decrease%init1 0)
    (or
     (and
      (=>
       (and
        (and
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
          self!
         )
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
          self!
        ))
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
         self!
       ))
       (=>
        (has_type i@ NAT)
        (or
         (and
          (=>
           (and
            (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
            )))))
            (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
                ))
               ) i@
           ))))
           (=>
            (= tmp%2 (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                  (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                   (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!
                  ))
                 ) i@
            )))))
            (and
             (=>
              %%location_label%%0
              (check_decrease_height (I (let
                 ((self!$0 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    tmp%2
                 )))
                 (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
                   (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
                    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
                     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
                      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
                       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
                        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                          self!$0
                   )))))))
                  ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
                   (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!$0
                )))))
               ) (I decrease%init0) false
             ))
             (=>
              (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
                (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                   (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                    (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                     ))
                    ) i@
              ))))))
              (=>
               (= tmp%3 tmp%1)
               %%switch_label%%1
          )))))
          (=>
           (not (and
             (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
             )))))
             (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   self!
                 ))
                ) i@
           )))))
           (=>
            (= tmp%3 true)
            %%switch_label%%1
         )))
         (and
          (not %%switch_label%%1)
          (=>
           (= tmp%4 (forall ((i$ Poly)) (!
              (=>
               (has_type i$ NAT)
               (=>
                (and
                 (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                   (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      self!
                 )))))
                 (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                   (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                    (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                     ))
                    ) i$
                ))))
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
                 (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
                   (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                    (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                        self!
                      ))
                     ) i$
              )))))))
              :pattern ((vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   self!
                 ))
                ) i$
              ))
              :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_obey_invariant_0
              :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_obey_invariant_0
           )))
           %%switch_label%%0
      )))))
      (=>
       (not (and
         (and
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
           self!
          )
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
           self!
         ))
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
          self!
       )))
       (=>
        (= tmp%4 (%B (vstd!pervasive.arbitrary.? $ BOOL)))
        %%switch_label%%0
     )))
     (not %%switch_label%%0)
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Bool)
(declare-const self! Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Bool)
(declare-const tmp%3 Bool)
(declare-const i@ Poly)
(declare-const tmp%4 Poly)
(declare-const tmp%5 Poly)
(declare-const tmp%6 Bool)
(declare-const tmp%7 Poly)
(declare-const tmp%8 Poly)
(declare-const tmp%9 NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
(declare-const tmp%10 Bool)
(declare-const tmp%11 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
)
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%switch_label%%2 Bool)
(declare-const %%switch_label%%3 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(assert
 (not (=>
   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
    self!
   )
   (and
    (=>
     %%location_label%%0
     (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
      self!
    ))
    (=>
     (= tmp%1 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
       self!
     ))
     (=>
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
       self!
      )
      (=>
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
        self!
       )
       (or
        (and
         (=>
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
           self!
          )
          (and
           (=>
            %%location_label%%1
            (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.
             self!
           ))
           (=>
            (= tmp%2 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
              self!
            ))
            (=>
             (= tmp%3 tmp%2)
             %%switch_label%%3
         ))))
         (=>
          (not (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
            self!
          ))
          (=>
           (= tmp%3 false)
           %%switch_label%%3
        )))
        (and
         (not %%switch_label%%3)
         (or
          (and
           (=>
            (and
             tmp%3
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
              self!
            ))
            (=>
             (has_type i@ NAT)
             (or
              (and
               (=>
                (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                  (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                    (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!
                )))))
                (=>
                 (= tmp%5 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                    (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!
                 ))))
                 (and
                  (=>
                   %%location_label%%2
                   (req%vstd!seq.impl&%2.spec_index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                    tmp%5 i@
                  ))
                  (=>
                   (= tmp%4 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                     (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                       (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                        self!
                      ))
                     ) i@
                   ))
                   (=>
                    (= tmp%6 (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
                      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                       tmp%4
                    )))
                    %%switch_label%%2
               )))))
               (=>
                (not (< (%I i@) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                   (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      self!
                ))))))
                (=>
                 (= tmp%6 false)
                 %%switch_label%%2
              )))
              (and
               (not %%switch_label%%2)
               (or
                (and
                 (=>
                  tmp%6
                  (=>
                   (= tmp%8 (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                   ))))
                   (and
                    (=>
                     %%location_label%%3
                     (req%vstd!seq.impl&%2.spec_index. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                      tmp%8 i@
                    ))
                    (=>
                     (= tmp%7 (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                          self!
                        ))
                       ) i@
                     ))
                     (and
                      (=>
                       %%location_label%%4
                       (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%4.arrow_Directory_0.
                        tmp%7
                      ))
                      (=>
                       (= tmp%9 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
                         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                          tmp%7
                       )))
                       (=>
                        (= tmp%10 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
                          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                           tmp%9
                        )))
                        %%switch_label%%1
                 )))))))
                 (=>
                  (not tmp%6)
                  (=>
                   (= tmp%10 true)
                   %%switch_label%%1
                )))
                (and
                 (not %%switch_label%%1)
                 (=>
                  (= tmp%11 (forall ((i$ Poly)) (!
                     (=>
                      (has_type i$ NAT)
                      (=>
                       (and
                        (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                          (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                             self!
                        )))))
                        (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
                         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                          (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                           (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                              self!
                            ))
                           ) i$
                       ))))
                       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
                        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
                          (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                           (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                            (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                              (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                               self!
                             ))
                            ) i$
                     )))))))
                     :pattern ((vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
                       (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                         (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                          self!
                        ))
                       ) i$
                     ))
                     :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_obey_invariant_2
                     :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_obey_invariant_2
                  )))
                  %%switch_label%%0
           )))))))
           (=>
            (not (and
              tmp%3
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
               self!
            )))
            (=>
             (= tmp%11 (%B (vstd!pervasive.arbitrary.? $ BOOL)))
             %%switch_label%%0
          )))
          (not %%switch_label%%0)
))))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.)
)
(declare-const fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.
 Fuel
)
(assert
 (forall ((self! Poly) (fuel% Fuel)) (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
     self! fuel%
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
     self! zero
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
     self! fuel%
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.inv._fuel_to_zero_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.inv._fuel_to_zero_definition
)))
(assert
 (forall ((self! Poly) (fuel% Fuel)) (!
   (=>
    (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
      self! (succ fuel%)
     ) (and
      (and
       (and
        (and
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
          self!
         )
         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.pages_match_entry_size.?
          self!
        ))
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
         self!
       ))
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
        self!
      ))
      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
       self! fuel%
   ))))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
     self! (succ fuel%)
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.inv._fuel_to_body_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.inv._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.)
  (forall ((self! Poly)) (!
    (=>
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
     (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
       self!
      ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
       self! (succ (succ fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.))
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.inv.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.inv.?_definition
))))
(assert
 (fuel_bool_default fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.)
)
(declare-const fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.
 Fuel
)
(assert
 (forall ((self! Poly) (fuel% Fuel)) (!
   (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
     self! fuel%
    ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
     self! zero
   ))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
     self! fuel%
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant._fuel_to_zero_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant._fuel_to_zero_definition
)))
(assert
 (forall ((self! Poly) (fuel% Fuel)) (!
   (=>
    (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
    (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
      self! (succ fuel%)
     ) (ite
      (and
       (and
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.well_formed.?
         self!
        )
        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_are_in_next_layer.?
         self!
       ))
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_match_arch.?
        self!
      ))
      (forall ((i$ Poly)) (!
        (=>
         (has_type i$ NAT)
         (=>
          (and
           (< (%I i$) (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
               (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
           )))))
           (is-NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
             (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
               ))
              ) i$
          ))))
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%inv.?
           (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry./Directory/0
             (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
              (vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
               (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
                 (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
                ))
               ) i$
            )))
           ) fuel%
        )))
        :pattern ((vstd!seq.Seq.index.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
           ))
          ) i$
        ))
        :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_obey_invariant_1
        :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__directories_obey_invariant_1
      ))
      (%B (vstd!pervasive.arbitrary.? $ BOOL))
   )))
   :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
     self! (succ fuel%)
   ))
   :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant._fuel_to_body_definition
   :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.)
  (forall ((self! Poly)) (!
    (=>
     (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
     (= (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.?
       self!
      ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.rec%directories_obey_invariant.?
       self! (succ (succ fuel_nat%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.))
    )))
    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.directories_obey_invariant.?
      self!
    ))
    :qid internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant.?_definition
    :skolemid skolem_internal_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.directories_obey_invariant.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__15_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ USIZE)
)
(assert
 (tr_bound%core!clone.Clone. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (REF T&.) T&)
   :pattern ((tr_bound%core!clone.Clone. (REF T&.) T&))
   :qid internal_core__clone__impls__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__35_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__35_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__32_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!clone.Clone. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__7_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!clone.Clone. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__9_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ INT)
)
(assert
 (tr_bound%core!clone.Clone. $ NAT)
)
(assert
 (tr_bound%core!marker.Copy. $ USIZE)
)
(assert
 (tr_bound%core!marker.Copy. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (REF T&.) T&)
   :pattern ((tr_bound%core!marker.Copy. (REF T&.) T&))
   :qid internal_core__marker__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!marker.Copy. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__8_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__8_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!marker.Copy. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__10_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__10_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ INT)
)
(assert
 (tr_bound%core!marker.Copy. $ NAT)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(declare-fun ens%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%2.clone.
 (Poly Poly) Bool
)
(assert
 (forall ((self! Poly) (%return! Poly)) (!
   (= (ens%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%2.clone.
     self! %return!
    ) (and
     (ens%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
      self! %return!
     )
     (= %return! self!)
   ))
   :pattern ((ens%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%2.clone.
     self! %return!
   ))
   :qid internal_ens__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__2.clone._definition
   :skolemid skolem_internal_ens__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__2.clone._definition
)))
(assert
 (forall ((closure%$ Poly) (%return$ Poly)) (!
   (=>
    (and
     (has_type closure%$ (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.))
     (has_type %return$ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
    )
    (=>
     (closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
      (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
      (F fndef_singleton) closure%$ %return$
     )
     (let
      ((self$ (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
         (tuple%1./tuple%1/0 (%Poly%tuple%1. closure%$))
      )))
      (= (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.
        %return$
       ) self$
   ))))
   :pattern ((closure_ens (FNDEF%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
     (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
     (F fndef_singleton) closure%$ %return$
   ))
   :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags__clone_0
   :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Flags__clone_0
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const %return! Poly)
(declare-const self! Poly)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   (= %return! self!)
   (=>
    %%location_label%%0
    (= %return! self!)
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(pop)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
)
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ USIZE) (DST
   (REF $)
  ) (TYPE%tuple%1. (REF $) USIZE)
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&) (
      DST (REF Self%&.)
     ) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (and
     (sized Self%&.)
     (tr_bound%core!clone.Clone. Self%&. Self%&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&. Self%&)
     (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. Self%&.
      Self%&
     ) (DST (REF Self%&.)) (TYPE%tuple%1. (REF Self%&.) Self%&)
   ))
   :qid internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__Clone__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF $))
  (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (REF
    $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ BOOL) (DST (
    REF $
   )
  ) (TYPE%tuple%1. (REF $) BOOL)
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&) (DST
     (REF (REF T&.))
    ) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.) T&)
    (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (REF T&.)
      T&
     ) (DST (REF (REF T&.))) (TYPE%tuple%1. (REF (REF T&.)) T&)
   ))
   :qid internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.) T&)
     (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%core!marker.Copy. T&. T&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED T&.)
      T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (TRACKED
       T&.
      ) T&
     ) (DST (REF (TRACKED T&.))) (TYPE%tuple%1. (REF (TRACKED T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&) (
      DST (REF (GHOST T&.))
     ) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.)
      T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST T&.) T&)
     (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (GHOST
       T&.
      ) T&
     ) (DST (REF (GHOST T&.))) (TYPE%tuple%1. (REF (GHOST T&.)) T&)
   ))
   :qid internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.) T&)
     (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A&
       T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__Fn_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnMut_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&. A& T&.)
      T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. (BOX A&.
       A& T&.
      ) T&
     ) (DST (REF (BOX A&. A& T&.))) (TYPE%tuple%1. (REF (BOX A&. A& T&.)) T&)
   ))
   :qid internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15__clone__impl_fndef&__FnOnce_trait_impl_definition
)))
(assert
 (tr_bound%core!ops.function.Fn. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
))
(assert
 (tr_bound%core!ops.function.FnMut. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
))
(assert
 (tr_bound%core!ops.function.FnOnce. $ (FNDEF%core!clone.Clone.clone. $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
  (DST (REF $)) (TYPE%tuple%1. (REF $) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Flags.)
))
(declare-fun req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
  Int
 ) Bool
)
(declare-const %%global_location_label%%18 Bool)
(assert
 (forall ((self! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
   (j! Int)
  ) (!
   (= (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
     self! j!
    ) (=>
     %%global_location_label%%18
     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       self!
   ))))
   :pattern ((req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
     self! j!
   ))
   :qid internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.lemma_interp_aux_contains_implies_interp_of_entry_contains._definition
   :skolemid skolem_internal_req__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.lemma_interp_aux_contains_implies_interp_of_entry_contains._definition
)))
(declare-fun ens%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
  Int
 ) Bool
)
(assert
 (forall ((self! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
   (j! Int)
  ) (!
   (= (ens%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
     self! j!
    ) (and
     (forall ((base$ Poly) (pte$ Poly)) (!
       (=>
        (and
         (has_type base$ NAT)
         (has_type pte$ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
        )
        (=>
         (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
          (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
            ) (I j!)
           )
          ) base$ pte$
         )
         (exists ((i$ Poly)) (!
           (and
            (has_type i$ NAT)
            (and
             (let
              ((tmp%%$ j!))
              (let
               ((tmp%%$1 (%I i$)))
               (let
                ((tmp%%$2 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                   (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!
                ))))
                (and
                 (<= tmp%%$ tmp%%$1)
                 (< tmp%%$1 tmp%%$2)
             ))))
             (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
              (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
                ) i$
               )
              ) base$ pte$
           )))
           :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
             ) i$
           ))
           :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_0
           :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_0
       ))))
       :pattern ((vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
         (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
           (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            self!
           ) (I j!)
          )
         ) base$ pte$
       ))
       :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_1
       :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_1
     ))
     (forall ((base$ Poly)) (!
       (=>
        (has_type base$ NAT)
        (=>
         (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
            $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
            (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
              (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
              ) (I j!)
           )))
          ) base$
         )
         (exists ((i$ Poly)) (!
           (and
            (has_type i$ NAT)
            (and
             (let
              ((tmp%%$ j!))
              (let
               ((tmp%%$1 (%I i$)))
               (let
                ((tmp%%$2 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                   (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!
                ))))
                (and
                 (<= tmp%%$ tmp%%$1)
                 (< tmp%%$1 tmp%%$2)
             ))))
             (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                  (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                   self!
                  ) i$
               )))
              ) base$
           )))
           :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
             ) i$
           ))
           :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_2
           :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_2
       ))))
       :pattern ((vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
           $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
           (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
             ) (I j!)
          )))
         ) base$
       ))
       :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_3
       :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_3
   ))))
   :pattern ((ens%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
     self! j!
   ))
   :qid internal_ens__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.lemma_interp_aux_contains_implies_interp_of_entry_contains._definition
   :skolemid skolem_internal_ens__NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&__6.lemma_interp_aux_contains_implies_interp_of_entry_contains._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.)
(declare-const j! Int)
(declare-const tmp%1 Int)
(declare-const base@ Poly)
(declare-const pte@ Poly)
(declare-const base$1@ Poly)
(declare-const tmp%%@ vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.)
(declare-const decrease%init0 Int)
(declare-const decrease%init1 Int)
(assert
 fuel_defaults
)
(assert
 (has_type (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
   self!
  ) TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
))
(assert
 (<= 0 j!)
)
(assert
 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.inv.?
  (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
   self!
)))
(declare-const %%switch_label%%0 Bool)
(declare-const %%switch_label%%1 Bool)
(declare-const %%switch_label%%2 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(declare-const %%location_label%%5 Bool)
(assert
 (not (=>
   (= decrease%init0 (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
      (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
        (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
      )))))))
     ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
      (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
       (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
        self!
   )))))
   (=>
    (= decrease%init1 (Sub (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
       (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
        self!
       )
      ) j!
    ))
    (or
     (and
      (=>
       (>= j! (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
         (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
          (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
           (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             self!
       ))))))
       %%switch_label%%0
      )
      (=>
       (not (>= j! (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.
          (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!NodeEntry.>.
           (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/entries
            (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
              self!
       )))))))
       (=>
        (= tmp%%@ (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
           self!
          ) (I j!)
        ))
        (=>
         (= tmp%1 (nClip (Add j! 1)))
         (and
          (=>
           %%location_label%%0
           (check_decrease_height (I (let
              ((self!$0 self!) (j!$1 tmp%1))
              (Sub (vstd!seq.Seq.len.? $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.
                (Poly%vstd!seq.Seq<NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!ArchLayer.>.
                 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch./Arch/layers
                  (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
                   (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Arch.
                    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/arch
                     (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!$0
                )))))))
               ) (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory./Directory/layer
                (%Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!$0
             )))))
            ) (I decrease%init0) (check_decrease_height (I (let
               ((self!$0 self!) (j!$1 tmp%1))
               (Sub (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                 (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!$0
                 )
                ) j!$1
              ))
             ) (I decrease%init1) false
          )))
          (and
           (=>
            %%location_label%%1
            (req%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
             self! tmp%1
           ))
           (=>
            (ens%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.lemma_interp_aux_contains_implies_interp_of_entry_contains.
             self! tmp%1
            )
            (and
             (=>
              (has_type base@ NAT)
              (=>
               (has_type pte@ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
               (=>
                (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                 (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                  (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                   (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!
                   ) (I j!)
                  )
                 ) base@ pte@
                )
                (or
                 (and
                  (=>
                   (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                    (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                      ) (I (nClip (Add j! 1)))
                     )
                    ) base@ pte@
                   )
                   %%switch_label%%2
                  )
                  (=>
                   (not (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                     (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                      (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                       (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                        self!
                       ) (I (nClip (Add j! 1)))
                      )
                     ) base@ pte@
                   ))
                   %%switch_label%%2
                 ))
                 (and
                  (not %%switch_label%%2)
                  (=>
                   %%location_label%%2
                   (exists ((i$ Poly)) (!
                     (and
                      (has_type i$ NAT)
                      (and
                       (let
                        ((tmp%%$1 j!))
                        (let
                         ((tmp%%$2 (%I i$)))
                         (let
                          ((tmp%%$3 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                              self!
                          ))))
                          (and
                           (<= tmp%%$1 tmp%%$2)
                           (< tmp%%$2 tmp%%$3)
                       ))))
                       (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                        (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                           self!
                          ) i$
                         )
                        ) base@ pte@
                     )))
                     :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                       (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                        self!
                       ) i$
                     ))
                     :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_8
                     :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_8
             ))))))))
             (=>
              (forall ((base$ Poly) (pte$ Poly)) (!
                (=>
                 (and
                  (has_type base$ NAT)
                  (has_type pte$ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
                 )
                 (=>
                  (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                   (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      self!
                     ) (I j!)
                    )
                   ) base$ pte$
                  )
                  (exists ((i$ Poly)) (!
                    (and
                     (has_type i$ NAT)
                     (and
                      (let
                       ((tmp%%$4 j!))
                       (let
                        ((tmp%%$5 (%I i$)))
                        (let
                         ((tmp%%$6 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                            (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                             self!
                         ))))
                         (and
                          (<= tmp%%$4 tmp%%$5)
                          (< tmp%%$5 tmp%%$6)
                      ))))
                      (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                       (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                          self!
                         ) i$
                        )
                       ) base$ pte$
                    )))
                    :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                      ) i$
                    ))
                    :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_9
                    :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_9
                ))))
                :pattern ((vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                  (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                   (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                    (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                     self!
                    ) (I j!)
                   )
                  ) base$ pte$
                ))
                :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_10
                :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_10
              ))
              (and
               (=>
                (has_type base$1@ NAT)
                (=>
                 (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                    $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                    (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                     (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                      ) (I j!)
                   )))
                  ) base$1@
                 )
                 (or
                  (and
                   (=>
                    (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                       $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                       (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                          self!
                         ) (I (nClip (Add j! 1)))
                      )))
                     ) base$1@
                    )
                    %%switch_label%%1
                   )
                   (=>
                    (not (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                        $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                        (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                         (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                          (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                           self!
                          ) (I (nClip (Add j! 1)))
                       )))
                      ) base$1@
                    ))
                    %%switch_label%%1
                  ))
                  (and
                   (not %%switch_label%%1)
                   (=>
                    %%location_label%%3
                    (exists ((i$ Poly)) (!
                      (and
                       (has_type i$ NAT)
                       (and
                        (let
                         ((tmp%%$7 j!))
                         (let
                          ((tmp%%$8 (%I i$)))
                          (let
                           ((tmp%%$9 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                              (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                               self!
                           ))))
                           (and
                            (<= tmp%%$7 tmp%%$8)
                            (< tmp%%$8 tmp%%$9)
                        ))))
                        (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                           $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                           (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                              self!
                             ) i$
                          )))
                         ) base$1@
                      )))
                      :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                         self!
                        ) i$
                      ))
                      :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_11
                      :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_11
               )))))))
               (=>
                (forall ((base$ Poly)) (!
                  (=>
                   (has_type base$ NAT)
                   (=>
                    (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                       $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                       (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                        (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                         (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                          self!
                         ) (I j!)
                      )))
                     ) base$
                    )
                    (exists ((i$ Poly)) (!
                      (and
                       (has_type i$ NAT)
                       (and
                        (let
                         ((tmp%%$10 j!))
                         (let
                          ((tmp%%$11 (%I i$)))
                          (let
                           ((tmp%%$12 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                              (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                               self!
                           ))))
                           (and
                            (<= tmp%%$10 tmp%%$11)
                            (< tmp%%$11 tmp%%$12)
                        ))))
                        (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                           $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                           (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                            (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                             (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                              self!
                             ) i$
                          )))
                         ) base$
                      )))
                      :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                         self!
                        ) i$
                      ))
                      :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_12
                      :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_12
                  ))))
                  :pattern ((vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                      $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                      (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                       (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                        (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                         self!
                        ) (I j!)
                     )))
                    ) base$
                  ))
                  :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_13
                  :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_13
                ))
                %%switch_label%%0
     )))))))))))
     (and
      (not %%switch_label%%0)
      (and
       (=>
        %%location_label%%4
        (forall ((base$ Poly) (pte$ Poly)) (!
          (=>
           (and
            (has_type base$ NAT)
            (has_type pte$ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.)
           )
           (=>
            (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
             (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
              (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
               (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                self!
               ) (I j!)
              )
             ) base$ pte$
            )
            (exists ((i$ Poly)) (!
              (and
               (has_type i$ NAT)
               (and
                (let
                 ((tmp%%$ j!))
                 (let
                  ((tmp%%$1 (%I i$)))
                  (let
                   ((tmp%%$2 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                   ))))
                   (and
                    (<= tmp%%$ tmp%%$1)
                    (< tmp%%$1 tmp%%$2)
                ))))
                (vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                 (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                  (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                   (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                    self!
                   ) i$
                  )
                 ) base$ pte$
              )))
              :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
                ) i$
              ))
              :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_4
              :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_4
          ))))
          :pattern ((vstd!map_lib.impl&%0.contains_pair.? $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
            (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
             (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
              (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
               self!
              ) (I j!)
             )
            ) base$ pte$
          ))
          :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_5
          :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_5
       )))
       (=>
        %%location_label%%5
        (forall ((base$ Poly)) (!
          (=>
           (has_type base$ NAT)
           (=>
            (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
               $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
               (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                 (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                  self!
                 ) (I j!)
              )))
             ) base$
            )
            (exists ((i$ Poly)) (!
              (and
               (has_type i$ NAT)
               (and
                (let
                 ((tmp%%$ j!))
                 (let
                  ((tmp%%$1 (%I i$)))
                  (let
                   ((tmp%%$2 (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.num_entries.?
                      (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                       self!
                   ))))
                   (and
                    (<= tmp%%$ tmp%%$1)
                    (< tmp%%$1 tmp%%$2)
                ))))
                (vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
                   $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
                   (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
                    (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                     (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                      self!
                     ) i$
                  )))
                 ) base$
              )))
              :pattern ((NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_of_entry.?
                (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
                ) i$
              ))
              :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_6
              :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_6
          ))))
          :pattern ((vstd!iset.ISet.contains.? $ NAT (vstd!set.impl&%0.to_iset.? $ NAT (vstd!map.impl&%0.dom.?
              $ NAT $ TYPE%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.
              (Poly%vstd!map.Map<nat./NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!PTE.>.
               (NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!impl&%6.interp_aux.?
                (Poly%NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains!Directory.
                 self!
                ) (I j!)
             )))
            ) base$
          ))
          :qid user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_7
          :skolemid skolem_user_NR__impl_u__l1__impl2__lemma_interp_aux_contains_implies_interp_of_entry_contains__Directory__lemma_interp_aux_contains_implies_interp_of_entry_contains_7
))))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
