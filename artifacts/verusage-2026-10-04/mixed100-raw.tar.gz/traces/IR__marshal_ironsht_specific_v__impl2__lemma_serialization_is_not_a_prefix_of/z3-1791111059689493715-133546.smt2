(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!std_specs.vec.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_spec_len. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_index_decreases. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_has_resolved. FuelId)
(declare-const fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.axiom_map_decreases_to_entry. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index_range_from. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index_range_to. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index_range. FuelId)
(declare-const fuel%vstd!seq.impl&%2.take. FuelId)
(declare-const fuel%vstd!seq.impl&%2.skip. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_add. FuelId)
(declare-const fuel%vstd!seq.Seq.last. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_empty. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_subrange_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_two_subranges_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_index1. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_add_index2. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.add_empty_left. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.add_empty_right. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.contains. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.drop_last. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.fold_left. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%20.view. FuelId)
(declare-const fuel%vstd!view.impl&%26.view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%vstd!view.impl&%48.view. FuelId)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.ghost_serialize.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.ghost_serialize.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.ghost_serialize.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.ghost_serialize.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.ghost_serialize.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.ghost_serialize.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.ghost_serialize.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.view_equal.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.is_marshalable.
 FuelId
)
(declare-const fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.ghost_serialize.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!std_specs.vec.impl&%0.spec_index. fuel%vstd!std_specs.vec.axiom_spec_len.
  fuel%vstd!std_specs.vec.axiom_vec_index_decreases. fuel%vstd!std_specs.vec.axiom_vec_has_resolved.
  fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view. fuel%vstd!function.axiom_fn_mut_call_requires.
  fuel%vstd!function.axiom_fn_mut_call_ensures. fuel%vstd!iset.lemma_iset_ext_equal.
  fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index. fuel%vstd!map.axiom_map_index_decreases.
  fuel%vstd!map.axiom_map_decreases_to_entry. fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep.
  fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.impl&%2.spec_index_range_from. fuel%vstd!seq.impl&%2.spec_index_range_to.
  fuel%vstd!seq.impl&%2.spec_index_range. fuel%vstd!seq.impl&%2.take. fuel%vstd!seq.impl&%2.skip.
  fuel%vstd!seq.impl&%2.spec_add. fuel%vstd!seq.Seq.last. fuel%vstd!seq.lemma_seq_index_decreases.
  fuel%vstd!seq.lemma_seq_subrange_decreases. fuel%vstd!seq.lemma_seq_empty. fuel%vstd!seq.lemma_seq_ext_equal.
  fuel%vstd!seq.lemma_seq_ext_equal_deep. fuel%vstd!seq.lemma_seq_subrange_len. fuel%vstd!seq.lemma_seq_subrange_index.
  fuel%vstd!seq.lemma_seq_two_subranges_index. fuel%vstd!seq.lemma_seq_add_len. fuel%vstd!seq.lemma_seq_add_index1.
  fuel%vstd!seq.lemma_seq_add_index2. fuel%vstd!seq_lib.impl&%0.add_empty_left. fuel%vstd!seq_lib.impl&%0.add_empty_right.
  fuel%vstd!seq_lib.impl&%0.contains. fuel%vstd!seq_lib.impl&%0.drop_last. fuel%vstd!seq_lib.impl&%0.fold_left.
  fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split. fuel%vstd!set.Set.contains. fuel%vstd!set.axiom_set_ext_equal.
  fuel%vstd!set.axiom_set_ext_equal_deep. fuel%vstd!set.axiom_set_decreases_to_member.
  fuel%vstd!view.impl&%0.view. fuel%vstd!view.impl&%2.view. fuel%vstd!view.impl&%4.view.
  fuel%vstd!view.impl&%6.view. fuel%vstd!view.impl&%16.view. fuel%vstd!view.impl&%18.view.
  fuel%vstd!view.impl&%20.view. fuel%vstd!view.impl&%26.view. fuel%vstd!view.impl&%30.view.
  fuel%vstd!view.impl&%48.view. fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.ghost_serialize.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.ghost_serialize.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.ghost_serialize.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.ghost_serialize.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.ghost_serialize.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.ghost_serialize.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.ghost_serialize.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.view_equal.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.is_marshalable.
  fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.ghost_serialize.
  fuel%vstd!array.group_array_axioms. fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas.
  fuel%vstd!iset.group_iset_lemmas. fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq.
  fuel%vstd!laws_eq.u8_laws.group_laws_eq. fuel%vstd!laws_eq.i8_laws.group_laws_eq.
  fuel%vstd!laws_eq.u16_laws.group_laws_eq. fuel%vstd!laws_eq.i16_laws.group_laws_eq.
  fuel%vstd!laws_eq.u32_laws.group_laws_eq. fuel%vstd!laws_eq.i32_laws.group_laws_eq.
  fuel%vstd!laws_eq.u64_laws.group_laws_eq. fuel%vstd!laws_eq.i64_laws.group_laws_eq.
  fuel%vstd!laws_eq.u128_laws.group_laws_eq. fuel%vstd!laws_eq.i128_laws.group_laws_eq.
  fuel%vstd!laws_eq.usize_laws.group_laws_eq. fuel%vstd!laws_eq.isize_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.
  fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties. fuel%vstd!layout.group_layout_axioms.
  fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms. fuel%vstd!mut_ref.group_mut_ref_axioms.
  fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas. fuel%vstd!seq_lib.group_filter_ensures.
  fuel%vstd!seq_lib.group_seq_lib_default. fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default.
  fuel%vstd!slice.group_slice_axioms. fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.axiom_map_decreases_to_entry.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_empty.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_subrange_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_two_subranges_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index1.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_add_index2.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.add_empty_left.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.add_empty_right.)
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
  (and
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_spec_len.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_index_decreases.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
   (fuel_bool_default fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%core!clone.Clone. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Copy. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%verus_builtin!Integer. (Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
 (Dcr Type) Bool
)
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-sort alloc!alloc.Global. 0)
(declare-sort alloc!vec.Vec<u8./alloc!alloc.Global.>. 0)
(declare-sort alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
 0
)
(declare-sort vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
 0
)
(declare-sort vstd!seq.Seq<u8.>. 0)
(declare-sort vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
 0
)
(declare-sort IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
 0
)
(declare-datatypes ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
   0
  ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
   0
  ) (tuple%0. 0) (tuple%2. 0)
 ) (((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV
    (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/?k
     IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
    ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/?v
     alloc!vec.Vec<u8./alloc!alloc.Global.>.
   ))
  ) ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey
    (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/?ukey
     Int
   ))
  ) ((tuple%0./tuple%0)) ((tuple%2./tuple%2 (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1
     Poly
)))))
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
 IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
 alloc!vec.Vec<u8./alloc!alloc.Global.>.
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.)
 Int
)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-fun TYPE%fun%2. (Dcr Type Dcr Type Dcr Type) Type)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-fun TYPE%alloc!vec.Vec. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-const TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
 Type
)
(declare-const TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
 Type
)
(declare-const TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
 Type
)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-fun Poly%fun%2. (%%Function%%) Poly)
(declare-fun %Poly%fun%2. (Poly) %%Function%%)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (alloc!vec.Vec<u8./alloc!alloc.Global.>.)
 Poly
)
(declare-fun %Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (Poly) alloc!vec.Vec<u8./alloc!alloc.Global.>.)
(declare-fun Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
 (alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.)
 Poly
)
(declare-fun %Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
 (Poly) alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
)
(declare-fun Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
 (vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
 (Poly) vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
)
(declare-fun Poly%vstd!seq.Seq<u8.>. (vstd!seq.Seq<u8.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<u8.>. (Poly) vstd!seq.Seq<u8.>.)
(declare-fun Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
 (vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
 (Poly) vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
)
(declare-fun Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.)
 Poly
)
(declare-fun %Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
 (Poly) IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
)
(declare-fun Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
 Poly
)
(declare-fun %Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
 (Poly) IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
)
(declare-fun Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.)
 Poly
)
(declare-fun %Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
 (Poly) IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%2. (Poly%fun%2. x)))
   :pattern ((Poly%fun%2. x))
   :qid internal_crate__fun__2_box_axiom_definition
   :skolemid skolem_internal_crate__fun__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    Poly
   )
  ) (!
   (=>
    (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
    (= x (Poly%fun%2. (%Poly%fun%2. x)))
   )
   :pattern ((has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&)))
   :qid internal_crate__fun__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__2_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (x
    %%Function%%
   )
  ) (!
   (=>
    (forall ((T%0 Poly) (T%1 Poly)) (!
      (=>
       (and
        (has_type T%0 T%0&)
        (has_type T%1 T%1&)
       )
       (has_type (%%apply%%0 x T%0 T%1) T%2&)
      )
      :pattern ((has_type (%%apply%%0 x T%0 T%1) T%2&))
      :qid internal_crate__fun__2_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__2_constructor_inner_definition
    ))
    (has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
   )
   :pattern ((has_type (Poly%fun%2. (mk_fun x)) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&.
      T%2&
   )))
   :qid internal_crate__fun__2_constructor_definition
   :skolemid skolem_internal_crate__fun__2_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (has_type (%%apply%%0 x T%0 T%1) T%2&)
   )
   :pattern ((%%apply%%0 x T%0 T%1) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&.
      T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_apply_definition
   :skolemid skolem_internal_crate__fun__2_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (T%0
    Poly
   ) (T%1 Poly) (x %%Function%%)
  ) (!
   (=>
    (and
     (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type T%0 T%0&)
     (has_type T%1 T%1&)
    )
    (height_lt (height (%%apply%%0 x T%0 T%1)) (height (fun_from_recursive_field (Poly%fun%2.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0 T%1)) (has_type (Poly%fun%2. x) (TYPE%fun%2. T%0&.
      T%0& T%1&. T%1& T%2&. T%2&
   )))
   :qid internal_crate__fun__2_height_apply_definition
   :skolemid skolem_internal_crate__fun__2_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%2&. Dcr) (T%2& Type) (deep
    Bool
   ) (x Poly) (y Poly)
  ) (!
   (=>
    (and
     (has_type x (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (has_type y (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&))
     (forall ((T%0 Poly) (T%1 Poly)) (!
       (=>
        (and
         (has_type T%0 T%0&)
         (has_type T%1 T%1&)
        )
        (ext_eq deep T%2& (%%apply%%0 (%Poly%fun%2. x) T%0 T%1) (%%apply%%0 (%Poly%fun%2. y)
          T%0 T%1
       )))
       :pattern ((ext_eq deep T%2& (%%apply%%0 (%Poly%fun%2. x) T%0 T%1) (%%apply%%0 (%Poly%fun%2.
           y
          ) T%0 T%1
       )))
       :qid internal_crate__fun__2_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__2_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%2. T%0&. T%0& T%1&. T%1& T%2&. T%2&) x y))
   :qid internal_crate__fun__2_ext_equal_definition
   :skolemid skolem_internal_crate__fun__2_ext_equal_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x alloc!vec.Vec<u8./alloc!alloc.Global.>.)) (!
   (= x (%Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
      x
   )))
   :pattern ((Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. x))
   :qid internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_box_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.))
    (= x (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (%Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
       x
   ))))
   :pattern ((has_type x (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.)))
   :qid internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_unbox_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!vec.Vec<u8./alloc!alloc.Global.>.)) (!
   (has_type (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. x) (TYPE%alloc!vec.Vec. $ (
      UINT 8
     ) $ TYPE%alloc!alloc.Global.
   ))
   :pattern ((has_type (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. x) (TYPE%alloc!vec.Vec.
      $ (UINT 8) $ TYPE%alloc!alloc.Global.
   )))
   :qid internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_has_type_always_definition
   :skolemid skolem_internal_alloc__vec__Vec<u8./alloc!alloc.Global.>_has_type_always_definition
)))
(assert
 (forall ((x alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.))
  (!
   (= x (%Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
     (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
      x
   )))
   :pattern ((Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
     x
   ))
   :qid internal_alloc__vec__Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>_box_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      $ TYPE%alloc!alloc.Global.
    ))
    (= x (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
      (%Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
       x
   ))))
   :pattern ((has_type x (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      $ TYPE%alloc!alloc.Global.
   )))
   :qid internal_alloc__vec__Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>_unbox_axiom_definition
   :skolemid skolem_internal_alloc__vec__Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.))
  (!
   (has_type (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
     x
    ) (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
     $ TYPE%alloc!alloc.Global.
   ))
   :pattern ((has_type (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
      x
     ) (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      $ TYPE%alloc!alloc.Global.
   )))
   :qid internal_alloc__vec__Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>_has_type_always_definition
   :skolemid skolem_internal_alloc__vec__Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
     (Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
     x
   ))
   :qid internal_vstd__map__Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      $ (TYPE%vstd!seq.Seq. $ (UINT 8))
    ))
    (= x (Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
      (%Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      $ (TYPE%vstd!seq.Seq. $ (UINT 8))
   )))
   :qid internal_vstd__map__Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
     x
    ) (TYPE%vstd!map.Map. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
     $ (TYPE%vstd!seq.Seq. $ (UINT 8))
   ))
   :pattern ((has_type (Poly%vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
      x
     ) (TYPE%vstd!map.Map. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      $ (TYPE%vstd!seq.Seq. $ (UINT 8))
   )))
   :qid internal_vstd__map__Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (= x (%Poly%vstd!seq.Seq<u8.>. (Poly%vstd!seq.Seq<u8.>. x)))
   :pattern ((Poly%vstd!seq.Seq<u8.>. x))
   :qid internal_vstd__seq__Seq<u8.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (UINT 8)))
    (= x (Poly%vstd!seq.Seq<u8.>. (%Poly%vstd!seq.Seq<u8.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<u8.>.)) (!
   (has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8)))
   :pattern ((has_type (Poly%vstd!seq.Seq<u8.>. x) (TYPE%vstd!seq.Seq. $ (UINT 8))))
   :qid internal_vstd__seq__Seq<u8.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<u8.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
     (Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
     x
   ))
   :qid internal_vstd__seq__Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.))
    (= x (Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
      (%Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)))
   :qid internal_vstd__seq__Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
     x
    ) (TYPE%vstd!seq.Seq. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>.
      x
     ) (TYPE%vstd!seq.Seq. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
   ))
   :qid internal_vstd__seq__Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.>_has_type_always_definition
)))
(assert
 (forall ((x IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.))
  (!
   (= x (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
     (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      x
   )))
   :pattern ((Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
     x
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap_box_axiom_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.)
    (= x (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
       x
   ))))
   :pattern ((has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap_unbox_axiom_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap_unbox_axiom_definition
)))
(assert
 (forall ((x IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.))
  (!
   (has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
     x
    ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
   )
   :pattern ((has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      x
     ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap_has_type_always_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap_has_type_always_definition
)))
(assert
 (forall ((x IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.))
  (!
   (= x (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
     (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      x
   )))
   :pattern ((Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
     x
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyKV_box_axiom_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyKV_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
    (= x (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
       x
   ))))
   :pattern ((has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyKV_unbox_axiom_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyKV_unbox_axiom_definition
)))
(assert
 (forall ((_k! IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.)
   (_v! alloc!vec.Vec<u8./alloc!alloc.Global.>.)
  ) (!
   (=>
    (has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      _k!
     ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
    )
    (has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV
       _k! _v!
      )
     ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
   ))
   :pattern ((has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV
       _k! _v!
      )
     ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV_constructor_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV_constructor_definition
)))
(assert
 (forall ((x IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.))
  (!
   (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
     x
    ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/?k
     x
   ))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
     x
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k_accessor_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
    (has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
       (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
        x
      ))
     ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
   ))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
     (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      x
     )
    ) (has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
   )
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k_invariant_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k_invariant_definition
)))
(assert
 (forall ((x IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.))
  (!
   (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
     x
    ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/?v
     x
   ))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
     x
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v_accessor_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v_accessor_definition
)))
(assert
 (forall ((x IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.))
  (!
   (= x (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
     (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      x
   )))
   :pattern ((Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
     x
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__SHTKey_box_axiom_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__SHTKey_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.)
    (= x (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
       x
   ))))
   :pattern ((has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__SHTKey_unbox_axiom_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__SHTKey_unbox_axiom_definition
)))
(assert
 (forall ((_ukey! Int)) (!
   (=>
    (uInv 64 _ukey!)
    (has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey
       _ukey!
      )
     ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
   ))
   :pattern ((has_type (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey
       _ukey!
      )
     ) TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey_constructor_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey_constructor_definition
)))
(assert
 (forall ((x IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.))
  (!
   (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
     x
    ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/?ukey
     x
   ))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
     x
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey_accessor_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.)
    (uInv 64 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
      (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
       x
   ))))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
     (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      x
     )
    ) (has_type x TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.)
   )
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey_invariant_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey_invariant_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!clone.Clone. Self%&. Self%&)
    (sized Self%&.)
   )
   :pattern ((tr_bound%core!clone.Clone. Self%&. Self%&))
   :qid internal_core__clone__Clone_trait_type_bounds_definition
   :skolemid skolem_internal_core__clone__Clone_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%core!marker.Copy. Self%&. Self%&)
    (tr_bound%core!clone.Clone. Self%&. Self%&)
   )
   :pattern ((tr_bound%core!marker.Copy. Self%&. Self%&))
   :qid internal_core__marker__Copy_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Copy_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%verus_builtin!Integer. Self%&. Self%&)
    (tr_bound%core!marker.Copy. Self%&. Self%&)
   )
   :pattern ((tr_bound%verus_builtin!Integer. Self%&. Self%&))
   :qid internal_verus_builtin__Integer_trait_type_bounds_definition
   :skolemid skolem_internal_verus_builtin__Integer_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__vec__VecAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__vec__VecAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
     Self%&. Self%&
    )
    (sized Self%&.)
   )
   :pattern ((tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
     Self%&. Self%&
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__Marshalable_trait_type_bounds_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__Marshalable_trait_type_bounds_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)) (TYPE%vstd!seq.Seq.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__8_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 8)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 8)) (UINT 8))
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 64)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 64)) (UINT 64))
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST (proj%%vstd!view.View./V
       A1&. A1&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&) (proj%%vstd!view.View./V
       A1&. A1&
      ) (proj%vstd!view.View./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.Seq.subrange.? (Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index_range.? (Dcr Type Dcr Type Dcr Type Poly Poly
  Poly
 ) Poly
)
(declare-fun vstd!seq.Seq.empty.? (Dcr Type) Poly)
(declare-fun vstd!seq.Seq.add.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_add.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.drop_last.? (Dcr Type Poly) Poly)
(declare-fun vstd!seq.Seq.last.? (Dcr Type Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.fold_left.? (Dcr Type Dcr Type Poly Poly Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.rec%fold_left.? (Dcr Type Dcr Type Poly Poly Poly
  Fuel
 ) Poly
)
(declare-fun vstd!seq.impl&%2.skip.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index_range_from.? (Dcr Type Dcr Type Poly Poly)
 Poly
)
(declare-fun vstd!seq.impl&%2.take.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index_range_to.? (Dcr Type Dcr Type Poly Poly)
 Poly
)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!std_specs.vec.spec_vec_len.? (Dcr Type Dcr Type Poly) Int)
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)
(declare-fun vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type
  Poly Poly
 ) Poly
)
(declare-fun vstd!std_specs.vec.VecAdditionalSpecFns.spec_index%default%.? (Dcr Type
  Dcr Type Poly Poly
 ) Poly
)
(declare-fun vstd!bytes.spec_u64_to_le_bytes.? (Poly) vstd!seq.Seq<u8.>.)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.view.?
 (Poly) vstd!map.Map<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./vstd!seq.Seq<u8.>.>.
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
 (Poly) alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
 (Poly) tuple%2.
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
 (Dcr Type Poly) Poly
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable%default%.?
 (Dcr Type Poly) Poly
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
 (Dcr Type Poly) Poly
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize%default%.?
 (Dcr Type Poly) Poly
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
 (Dcr Type Poly Poly) Poly
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal%default%.?
 (Dcr Type Poly Poly) Poly
)
(declare-fun vstd!seq_lib.impl&%0.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.?
 (Poly Poly) Bool
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.?
 (Poly) Bool
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?
 (Poly) Int
)
(declare-fun IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?
 (Poly) Int
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (tr_bound%core!clone.Clone. $ INT)
)
(assert
 (tr_bound%core!marker.Copy. $ INT)
)
(assert
 (tr_bound%verus_builtin!Integer. $ INT)
)
(declare-fun req%vstd!seq.Seq.subrange. (Dcr Type Poly Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (= (req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!) (=>
     %%global_location_label%%2
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I start_inclusive!)))
       (let
        ((tmp%%$2 (%I end_exclusive!)))
        (let
         ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& self!)))
         (and
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
          )
          (<= tmp%%$2 tmp%%$3)
   )))))))
   :pattern ((req%vstd!seq.Seq.subrange. A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_req__vstd!seq.Seq.subrange._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.subrange._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (start_inclusive! Poly) (end_exclusive! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type start_inclusive! INT)
     (has_type end_exclusive! INT)
    )
    (has_type (vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!) (
      TYPE%vstd!seq.Seq. A&. A&
   )))
   :pattern ((vstd!seq.Seq.subrange.? A&. A& self! start_inclusive! end_exclusive!))
   :qid internal_vstd!seq.Seq.subrange.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.subrange.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index_range. (Dcr Type Dcr Type Dcr Type Poly
  Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (J&. Dcr) (J& Type) (self! Poly) (
    i! Poly
   ) (j! Poly)
  ) (!
   (= (req%vstd!seq.impl&%2.spec_index_range. A&. A& I&. I& J&. J& self! i! j!) (=>
     %%global_location_label%%3
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (%I j!)))
        (let
         ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& self!)))
         (and
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
          )
          (<= tmp%%$2 tmp%%$3)
   )))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index_range. A&. A& I&. I& J&. J& self! i! j!))
   :qid internal_req__vstd!seq.impl&__2.spec_index_range._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index_range._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index_range.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index_range.)
  (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (J&. Dcr) (J& Type) (self! Poly) (
     i! Poly
    ) (j! Poly)
   ) (!
    (= (vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!) (vstd!seq.Seq.subrange.?
      A&. A& self! i! j!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!))
    :qid internal_vstd!seq.impl&__2.spec_index_range.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (J&. Dcr) (J& Type) (self! Poly) (
    i! Poly
   ) (j! Poly)
  ) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! I&)
     (has_type j! J&)
    )
    (has_type (vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!) (
      TYPE%vstd!seq.Seq. A&. A&
   )))
   :pattern ((vstd!seq.impl&%2.spec_index_range.? A&. A& I&. I& J&. J& self! i! j!))
   :qid internal_vstd!seq.impl&__2.spec_index_range.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly) (j! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
      (has_type j! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I i!)))
          (let
           ((tmp%%$2 (%I j!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (< (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (vstd!seq.Seq.len.?
         A&. A& s!
      )))
      (height_lt (height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.subrange.? A&. A& s! i! j!)))
    :qid user_vstd__seq__lemma_seq_subrange_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_decreases_0
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (has_type (vstd!seq.Seq.empty.? A&. A&) (TYPE%vstd!seq.Seq. A&. A&))
   :pattern ((vstd!seq.Seq.empty.? A&. A&))
   :qid internal_vstd!seq.Seq.empty.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.empty.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_empty.)
  (forall ((A&. Dcr) (A& Type)) (!
    (=>
     (sized A&.)
     (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)) 0)
    )
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.empty.? A&. A&)))
    :qid user_vstd__seq__lemma_seq_empty_0
    :skolemid skolem_user_vstd__seq__lemma_seq_empty_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I j!)))
         (let
          ((tmp%%$2 (%I k!)))
          (let
           ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
           (and
            (and
             (<= tmp%%$ tmp%%$1)
             (<= tmp%%$1 tmp%%$2)
            )
            (<= tmp%%$2 tmp%%$3)
      ))))))
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)) (Sub (%I k!)
        (%I j!)
    ))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!)))
    :qid user_vstd__seq__lemma_seq_subrange_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_subrange_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$1 (%I j!)))
          (let
           ((tmp%%$2 (%I k!)))
           (let
            ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
            (and
             (and
              (<= tmp%%$ tmp%%$1)
              (<= tmp%%$1 tmp%%$2)
             )
             (<= tmp%%$2 tmp%%$3)
       ))))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$5 (%I i!)))
         (let
          ((tmp%%$6 (Sub (%I k!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$5)
           (< tmp%%$5 tmp%%$6)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!) (vstd!seq.Seq.index.?
        A&. A& s! (I (Add (%I i!) (%I j!)))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k!) i!))
    :qid user_vstd__seq__lemma_seq_subrange_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_subrange_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_two_subranges_index.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (j! Poly) (k1! Poly) (k2! Poly) (i! Poly))
   (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type j! INT)
      (has_type k1! INT)
      (has_type k2! INT)
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized A&.)
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I j!)))
            (let
             ((tmp%%$2 (%I k1!)))
             (let
              ((tmp%%$3 (vstd!seq.Seq.len.? A&. A& s!)))
              (and
               (and
                (<= tmp%%$ tmp%%$1)
                (<= tmp%%$1 tmp%%$2)
               )
               (<= tmp%%$2 tmp%%$3)
         ))))))
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$5 (%I j!)))
           (let
            ((tmp%%$6 (%I k2!)))
            (let
             ((tmp%%$7 (vstd!seq.Seq.len.? A&. A& s!)))
             (and
              (and
               (<= tmp%%$ tmp%%$5)
               (<= tmp%%$5 tmp%%$6)
              )
              (<= tmp%%$6 tmp%%$7)
        ))))))
        (let
         ((tmp%%$ 0))
         (let
          ((tmp%%$9 (%I i!)))
          (let
           ((tmp%%$10 (Sub (%I k1!) (%I j!))))
           (and
            (<= tmp%%$ tmp%%$9)
            (< tmp%%$9 tmp%%$10)
       )))))
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$12 (%I i!)))
         (let
          ((tmp%%$13 (Sub (%I k2!) (%I j!))))
          (and
           (<= tmp%%$ tmp%%$12)
           (< tmp%%$12 tmp%%$13)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!) (vstd!seq.Seq.index.?
        A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k2!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.subrange.? A&. A& s! j! k1!) i!)
     (vstd!seq.Seq.subrange.? A&. A& s! j! k2!)
    )
    :qid user_vstd__seq__lemma_seq_two_subranges_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_two_subranges_index_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type rhs! (TYPE%vstd!seq.Seq. A&. A&))
    )
    (has_type (vstd!seq.Seq.add.? A&. A& self! rhs!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.add.? A&. A& self! rhs!))
   :qid internal_vstd!seq.Seq.add.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.add.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_len.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!)) (nClip (Add (vstd!seq.Seq.len.?
          A&. A& s1!
         ) (vstd!seq.Seq.len.? A&. A& s2!)
    )))))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!)))
    :qid user_vstd__seq__lemma_seq_add_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_index1.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (< (%I i!) (vstd!seq.Seq.len.? A&. A& s1!))
      )
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!) (vstd!seq.Seq.index.?
        A&. A& s1! i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!))
    :qid user_vstd__seq__lemma_seq_add_index1_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_index1_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_add_index2.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ (vstd!seq.Seq.len.? A&. A& s1!)))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (nClip (Add (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!)))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!) (vstd!seq.Seq.index.?
        A&. A& s2! (I (Sub (%I i!) (vstd!seq.Seq.len.? A&. A& s1!)))
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.add.? A&. A& s1! s2!) i!))
    :qid user_vstd__seq__lemma_seq_add_index2_0
    :skolemid skolem_user_vstd__seq__lemma_seq_add_index2_0
))))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_add.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_add.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
    (= (vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!) (vstd!seq.Seq.add.? A&. A& self!
      rhs!
    ))
    :pattern ((vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!))
    :qid internal_vstd!seq.impl&__2.spec_add.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_add.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (rhs! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type rhs! (TYPE%vstd!seq.Seq. A&. A&))
    )
    (has_type (vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.spec_add.? A&. A& self! rhs!))
   :qid internal_vstd!seq.impl&__2.spec_add.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_add.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.add_empty_left.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (and
       (sized A&.)
       (= (vstd!seq.Seq.len.? A&. A& a!) 0)
      )
      (= (vstd!seq.Seq.add.? A&. A& a! b!) b!)
    ))
    :pattern ((vstd!seq.Seq.add.? A&. A& a! b!))
    :qid user_vstd__seq_lib__impl&%0__add_empty_left_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__add_empty_left_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.add_empty_right.)
  (forall ((A&. Dcr) (A& Type) (a! Poly) (b! Poly)) (!
    (=>
     (and
      (has_type a! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (and
       (sized A&.)
       (= (vstd!seq.Seq.len.? A&. A& b!) 0)
      )
      (= (vstd!seq.Seq.add.? A&. A& a! b!) a!)
    ))
    :pattern ((vstd!seq.Seq.add.? A&. A& a! b!))
    :qid user_vstd__seq_lib__impl&%0__add_empty_right_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__add_empty_right_0
))))
(declare-fun req%vstd!seq_lib.impl&%0.drop_last. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (= (req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!) (=>
     %%global_location_label%%4
     (>= (vstd!seq.Seq.len.? A&. A& self!) 1)
   ))
   :pattern ((req%vstd!seq_lib.impl&%0.drop_last. A&. A& self!))
   :qid internal_req__vstd!seq_lib.impl&__0.drop_last._definition
   :skolemid skolem_internal_req__vstd!seq_lib.impl&__0.drop_last._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.drop_last.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.drop_last.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (vstd!seq.Seq.subrange.? A&. A&
      self! (I 0) (I (Sub (vstd!seq.Seq.len.? A&. A& self!) 1))
    ))
    :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
    :qid internal_vstd!seq_lib.impl&__0.drop_last.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq_lib.impl&%0.drop_last.? A&. A& self!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq_lib.impl&%0.drop_last.? A&. A& self!))
   :qid internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.drop_last.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.last. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (= (req%vstd!seq.Seq.last. A&. A& self!) (=>
     %%global_location_label%%5
     (< 0 (vstd!seq.Seq.len.? A&. A& self!))
   ))
   :pattern ((req%vstd!seq.Seq.last. A&. A& self!))
   :qid internal_req__vstd!seq.Seq.last._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.last._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.Seq.last.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.Seq.last.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq.Seq.last.? A&. A& self!) (vstd!seq.Seq.index.? A&. A& self! (I (Sub (vstd!seq.Seq.len.?
         A&. A& self!
        ) 1
    ))))
    :pattern ((vstd!seq.Seq.last.? A&. A& self!))
    :qid internal_vstd!seq.Seq.last.?_definition
    :skolemid skolem_internal_vstd!seq.Seq.last.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq.Seq.last.? A&. A& self!) A&)
   )
   :pattern ((vstd!seq.Seq.last.? A&. A& self!))
   :qid internal_vstd!seq.Seq.last.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.last.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.fold_left.)
)
(declare-const fuel_nat%vstd!seq_lib.impl&%0.fold_left. Fuel)
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (= (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%) (vstd!seq_lib.impl&%0.rec%fold_left.?
     A&. A& B&. B& self! b! f! zero
   ))
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%))
   :qid internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_zero_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_zero_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (=>
    (and
     (sized A&.)
     (sized B&.)
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (= (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! (succ fuel%)) (
      ite
      (= (vstd!seq.Seq.len.? A&. A& self!) 0)
      b!
      (%%apply%%0 (%Poly%fun%2. f!) (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& (
         vstd!seq_lib.impl&%0.drop_last.? A&. A& self!
        ) b! f! fuel%
       ) (vstd!seq.Seq.last.? A&. A& self!)
   ))))
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! (succ fuel%)))
   :qid internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_body_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left._fuel_to_body_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.fold_left.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly))
   (!
    (=>
     (and
      (sized A&.)
      (sized B&.)
      (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! B&)
      (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
     )
     (= (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!) (vstd!seq_lib.impl&%0.rec%fold_left.?
       A&. A& B&. B& self! b! f! (succ fuel_nat%vstd!seq_lib.impl&%0.fold_left.)
    )))
    :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!))
    :qid internal_vstd!seq_lib.impl&__0.fold_left.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly))
  (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!) B&)
   )
   :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!))
   :qid internal_vstd!seq_lib.impl&__0.fold_left.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.fold_left.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
    fuel% Fuel
   )
  ) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type b! B&)
     (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
    )
    (has_type (vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%) B&)
   )
   :pattern ((vstd!seq_lib.impl&%0.rec%fold_left.? A&. A& B&. B& self! b! f! fuel%))
   :qid internal_vstd!seq_lib.impl&__0.rec__fold_left.?_pre_post_rec_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.rec__fold_left.?_pre_post_rec_definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.skip.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.skip.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.skip.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      n! (I (vstd!seq.Seq.len.? A&. A& self!))
    ))
    :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.skip.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.skip.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.skip.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.skip.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.skip.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index_range_from. (Dcr Type Dcr Type Poly Poly)
 Bool
)
(declare-const %%global_location_label%%6 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index_range_from. A&. A& I&. I& self! i!) (=>
     %%global_location_label%%6
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (<= tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index_range_from. A&. A& I&. I& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index_range_from._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index_range_from._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index_range_from.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index_range_from.)
  (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!) (vstd!seq.Seq.subrange.?
      A&. A& self! i! (I (vstd!seq.Seq.len.? A&. A& self!))
    ))
    :pattern ((vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index_range_from.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_from.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (I&. Dcr) (I& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! I&)
    )
    (has_type (vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!) (TYPE%vstd!seq.Seq.
      A&. A&
   )))
   :pattern ((vstd!seq.impl&%2.spec_index_range_from.? A&. A& I&. I& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index_range_from.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_from.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.take.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.take.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
    (= (vstd!seq.impl&%2.take.? A&. A& self! n!) (vstd!seq.Seq.subrange.? A&. A& self!
      (I 0) n!
    ))
    :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
    :qid internal_vstd!seq.impl&__2.take.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.take.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (n! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type n! INT)
    )
    (has_type (vstd!seq.impl&%2.take.? A&. A& self! n!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.impl&%2.take.? A&. A& self! n!))
   :qid internal_vstd!seq.impl&__2.take.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.take.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index_range_to. (Dcr Type Dcr Type Poly Poly)
 Bool
)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (J&. Dcr) (J& Type) (self! Poly) (j! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index_range_to. A&. A& J&. J& self! j!) (=>
     %%global_location_label%%7
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I j!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (<= tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index_range_to. A&. A& J&. J& self! j!))
   :qid internal_req__vstd!seq.impl&__2.spec_index_range_to._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index_range_to._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index_range_to.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index_range_to.)
  (forall ((A&. Dcr) (A& Type) (J&. Dcr) (J& Type) (self! Poly) (j! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!) (vstd!seq.Seq.subrange.?
      A&. A& self! (I 0) j!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!))
    :qid internal_vstd!seq.impl&__2.spec_index_range_to.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_to.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (J&. Dcr) (J& Type) (self! Poly) (j! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type j! J&)
    )
    (has_type (vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!) (TYPE%vstd!seq.Seq.
      A&. A&
   )))
   :pattern ((vstd!seq.impl&%2.spec_index_range_to.? A&. A& J&. J& self! j!))
   :qid internal_vstd!seq.impl&__2.spec_index_range_to.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index_range_to.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.lemma_fold_left_split.)
  (forall ((A&. Dcr) (A& Type) (B&. Dcr) (B& Type) (self! Poly) (b! Poly) (f! Poly) (
     k! Poly
    )
   ) (!
    (=>
     (and
      (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type b! B&)
      (has_type f! (TYPE%fun%2. B&. B& A&. A& B&. B&))
      (has_type k! INT)
     )
     (=>
      (and
       (and
        (sized A&.)
        (sized B&.)
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I k!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (<= tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
         k! (I (vstd!seq.Seq.len.? A&. A& self!))
        ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&. A& self!
          (I 0) k!
         ) b! f!
        ) f!
       ) (vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& self! b! f!)
    )))
    :pattern ((vstd!seq_lib.impl&%0.fold_left.? A&. A& B&. B& (vstd!seq.Seq.subrange.? A&.
       A& self! (I 0) k!
      ) b! f!
    ))
    :qid user_vstd__seq_lib__impl&%0__lemma_fold_left_split_0
    :skolemid skolem_user_vstd__seq_lib__impl&%0__lemma_fold_left_split_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%8
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%9
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_decreases_to_entry.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
           K& V&. V& m! key!
        )))
       ) (height m!)
    )))
    :pattern ((height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
         K& V&. V& m! key!
    )))))
    :qid user_vstd__map__axiom_map_decreases_to_entry_0
    :skolemid skolem_user_vstd__map__axiom_map_decreases_to_entry_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
   (=>
    (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
    (uInv SZ (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   )
   :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
   :qid internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.vec.spec_vec_len.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_vstd__view__impl&__8_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__8_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_spec_len.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& A&. A&))
     (=>
      (and
       (and
        (sized T&.)
        (sized A&.)
       )
       (tr_bound%core!alloc.Allocator. A&. A&)
      )
      (= (vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!) (vstd!seq.Seq.len.? T&. T&
        (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& A&. A&) v!)
    ))))
    :pattern ((vstd!std_specs.vec.spec_vec_len.? T&. T& A&. A& v!))
    :qid user_vstd__std_specs__vec__axiom_spec_len_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_spec_len_0
))))
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)
(declare-fun req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. (Dcr Type Dcr
  Type Poly Poly
 ) Bool
)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self!
     i!
    ) (=>
     %%global_location_label%%10
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!std_specs.vec.VecAdditionalSpecFns.spec_index. Self%&. Self%& T&.
     T& self! i!
   ))
   :qid internal_req__vstd!std_specs.vec.VecAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!std_specs.vec.VecAdditionalSpecFns.spec_index._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? Self%&. Self%& T&.
      T& self! i!
     ) T&
   ))
   :pattern ((vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? Self%&. Self%& T&.
     T& self! i!
   ))
   :qid internal_vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.vec.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.impl&%0.spec_index.)
  (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized A&.)
      (tr_bound%core!alloc.Allocator. A&. A&)
     )
     (= (vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? $ (TYPE%alloc!vec.Vec. T&.
        T& A&. A&
       ) T&. T& self! i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T&
         A&. A&
        ) self!
       ) i!
    )))
    :pattern ((vstd!std_specs.vec.VecAdditionalSpecFns.spec_index.? $ (TYPE%alloc!vec.Vec.
       T&. T& A&. A&
      ) T&. T& self! i!
    ))
    :qid internal_vstd!std_specs.vec.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!std_specs.vec.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. $ (TYPE%alloc!vec.Vec. T&. T& A&.
      A&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.vec.VecAdditionalSpecFns. $ (TYPE%alloc!vec.Vec.
      T&. T& A&. A&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__vec__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__vec__impl&__0_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (v! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type v! (TYPE%alloc!vec.Vec. A&. A& $ TYPE%alloc!alloc.Global.))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? A&. A& $ TYPE%alloc!alloc.Global. v!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
           A&. A& $ TYPE%alloc!alloc.Global.
          ) v!
         ) i!
        )
       ) (height v!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
         A&. A& $ TYPE%alloc!alloc.Global.
        ) v!
       ) i!
    )))
    :qid user_vstd__std_specs__vec__axiom_vec_index_decreases_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (vec! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type vec! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
      (has_type i! INT)
     )
     (=>
      (sized T&.)
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? T&. T& $ TYPE%alloc!alloc.Global. vec!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
            T&. T& $ TYPE%alloc!alloc.Global.
           ) vec!
          ) i!
    ))))))
    :pattern ((has_resolved $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) vec!)
     (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
        TYPE%alloc!alloc.Global.
       ) vec!
      ) i!
    ))
    :qid user_vstd__std_specs__vec__axiom_vec_has_resolved_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_has_resolved_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.vec.axiom_vec_decreases_to_view.)
  (forall ((T&. Dcr) (T& Type) (v! Poly)) (!
    (=>
     (has_type v! (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.))
     (=>
      (sized T&.)
      (height_lt (height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
         v!
        )
       ) (height v!)
    )))
    :pattern ((height (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
       v!
    )))
    :qid user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
    :skolemid skolem_user_vstd__std_specs__vec__axiom_vec_decreases_to_view_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!clone.Clone. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%core!marker.Copy. $ TYPE%tuple%0.)
)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!clone.Clone. T%0&. T%0&)
     (tr_bound%core!clone.Clone. T%1&. T%1&)
    )
    (tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!clone.Clone. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Clone2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Clone2_trait_impl_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (=>
    (and
     (tr_bound%core!marker.Copy. T%0&. T%0&)
     (tr_bound%core!marker.Copy. T%1&. T%1&)
    )
    (tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((tr_bound%core!marker.Copy. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Copy2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Copy2_trait_impl_definition
)))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
      self!
     ) (tuple%2./tuple%2 (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
       (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
        (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
         self!
       ))
      ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.)
       (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
         (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
          self!
    ))))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__1.view.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__1.view.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.)
    (has_type (Poly%tuple%2. (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
       self!
      )
     ) (TYPE%tuple%2. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      $ (TYPE%vstd!seq.Seq. $ (UINT 8))
   )))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
     self!
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__1.view.?_pre_post_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__1.view.?_pre_post_definition
)))
(declare-fun ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.lemma_to_vec_view.
 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
  IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
 ) Bool
)
(assert
 (forall ((self! IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.)
   (other! IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.)
  ) (!
   (= (ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.lemma_to_vec_view.
     self! other!
    ) (and
     (= (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.view.?
        (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
         self!
        )
       ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.view.?
        (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
         other!
       ))
      ) (= (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
         $ TYPE%alloc!alloc.Global.
        ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
          (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
           self!
        )))
       ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
         $ TYPE%alloc!alloc.Global.
        ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
          (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
           other!
     ))))))
     (= (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.view.?
        (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
         self!
        )
       ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.view.?
        (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
         other!
       ))
      ) (and
       (= (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
         $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
          (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
           (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
            self!
         )))
        ) (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
         $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
          (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
           (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
            other!
       )))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                  (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                   (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
                    self!
              ))))))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
             (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
              (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                $ TYPE%alloc!alloc.Global.
               ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                 (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
                  self!
               )))
              ) i$
             )
            ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
             (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
              (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                $ TYPE%alloc!alloc.Global.
               ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                 (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
                  other!
               )))
              ) i$
         )))))
         :pattern ((vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             $ TYPE%alloc!alloc.Global.
            ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
             (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
              (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
               self!
            )))
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             $ TYPE%alloc!alloc.Global.
            ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
             (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
              (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
               other!
            )))
           ) i$
         ))
         :qid user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap__lemma_to_vec_view_0
         :skolemid skolem_user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap__lemma_to_vec_view_0
   ))))))
   :pattern ((ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.lemma_to_vec_view.
     self! other!
   ))
   :qid internal_ens__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__0.lemma_to_vec_view._definition
   :skolemid skolem_internal_ens__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__0.lemma_to_vec_view._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      Self%&. Self%& self!
     ) BOOL
   ))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
     Self%&. Self%& self!
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?_pre_post_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?_pre_post_definition
)))
(declare-fun req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.
 (Dcr Type Poly) Bool
)
(declare-const %%global_location_label%%11 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (= (req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.
     Self%&. Self%& self!
    ) (=>
     %%global_location_label%%11
     (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
       Self%&. Self%& self!
   ))))
   :pattern ((req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.
     Self%&. Self%& self!
   ))
   :qid internal_req__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize._definition
   :skolemid skolem_internal_req__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      Self%&. Self%& self!
     ) (TYPE%vstd!seq.Seq. $ (UINT 8))
   ))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
     Self%&. Self%& self!
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?_pre_post_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (other! Poly)) (!
   (=>
    (and
     (has_type self! Self%&)
     (has_type other! Self%&)
    )
    (has_type (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      Self%&. Self%& self! other!
     ) BOOL
   ))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
     Self%&. Self%& self! other!
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?_pre_post_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?_pre_post_definition
)))
(declare-fun req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
 (Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%12 Bool)
(declare-const %%global_location_label%%13 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly) (other! Poly)) (!
   (= (req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
     Self%&. Self%& self! other!
    ) (and
     (=>
      %%global_location_label%%12
      (not (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
         Self%&. Self%& self! other!
     ))))
     (=>
      %%global_location_label%%13
      (<= (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
         Self%&. Self%& self!
        )
       ) (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
         Self%&. Self%& other!
   ))))))
   :pattern ((req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
     Self%&. Self%& self! other!
   ))
   :qid internal_req__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of._definition
   :skolemid skolem_internal_req__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of._definition
)))
(declare-fun ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
 (Bool Dcr Type Poly Poly) Bool
)
(assert
 (forall ((default_ensures Bool) (Self%&. Dcr) (Self%& Type) (self! Poly) (other! Poly))
  (!
   (= (ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
     default_ensures Self%&. Self%& self! other!
    ) (not (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
       Self%&. Self%& self!
      ) (vstd!seq.Seq.subrange.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
        Self%&. Self%& other!
       ) (I 0) (I (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
          Self%&. Self%& self!
   )))))))
   :pattern ((ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
     default_ensures Self%&. Self%& self! other!
   ))
   :qid internal_ens__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of._definition
   :skolemid skolem_internal_ens__IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (needle! Poly)) (!
    (= (vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!) (exists ((i$ Poly)) (!
       (and
        (has_type i$ INT)
        (and
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? A&. A& self! i$) needle!)
       ))
       :pattern ((vstd!seq.Seq.index.? A&. A& self! i$))
       :qid user_vstd__seq_lib__impl&%0__contains_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__contains_0
    )))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!))
    :qid internal_vstd!seq_lib.impl&__0.contains.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.contains.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%20.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%20.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 8) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 8) self!))
    :qid internal_vstd!view.impl&__20.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__20.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%26.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%26.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 64) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 64) self!))
    :qid internal_vstd!view.impl&__26.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__26.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%48.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%48.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
     )
     (= (vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!) (Poly%tuple%2.
       (tuple%2./tuple%2 (vstd!view.View.view.? A0&. A0& (tuple%2./tuple%2/0 (%Poly%tuple%2.
           self!
         ))
        ) (vstd!view.View.view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!))
    :qid internal_vstd!view.impl&__48.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__48.view.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.)
  (forall ((a! Poly) (b! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.?
      a! b!
     ) (< (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
       (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
        (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
          (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           a!
       ))))
      ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
       (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
        (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
          (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           b!
    )))))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.?
      a! b!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.)
  (forall ((v! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.?
      v!
     ) (forall ((i$ Poly) (j$ Poly)) (!
       (=>
        (and
         (has_type i$ INT)
         (has_type j$ INT)
        )
        (=>
         (and
          (and
           (<= 0 (%I i$))
           (< (Add (%I i$) 1) (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             $ TYPE%alloc!alloc.Global. v!
          )))
          (= (%I j$) (Add (%I i$) 1))
         )
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.?
          (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             $ TYPE%alloc!alloc.Global.
            ) v!
           ) i$
          ) (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             $ TYPE%alloc!alloc.Global.
            ) v!
           ) j$
       ))))
       :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeykvlt.?
         (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
          (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            $ TYPE%alloc!alloc.Global.
           ) v!
          ) i$
         ) (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
          (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            $ TYPE%alloc!alloc.Global.
           ) v!
          ) j$
       )))
       :qid user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__spec_sorted_keys_0
       :skolemid skolem_user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__spec_sorted_keys_0
    )))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.?
      v!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.?_definition
))))
(assert
 (tr_bound%vstd!view.View. $ (UINT 64))
)
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.view_equal.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ (UINT 64) self! other!
     ) (B (= self! other!))
    )
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ (UINT 64) self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__6.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__6.view_equal.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.is_marshalable.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.is_marshalable.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ (UINT 64) self!
     ) (B true)
    )
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ (UINT 64) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__6.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__6.is_marshalable.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.ghost_serialize.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%6.ghost_serialize.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (UINT 64) self!
     ) (Poly%vstd!seq.Seq<u8.>. (vstd!bytes.spec_u64_to_le_bytes.? self!))
    )
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (UINT 64) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__6.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__6.ghost_serialize.?_definition
))))
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.view_equal.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ USIZE self! other!
     ) (B (= self! other!))
    )
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ USIZE self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__7.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__7.view_equal.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.is_marshalable.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.is_marshalable.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ USIZE self!
     ) (B (<= (%I self!) 18446744073709551615))
    )
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ USIZE self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__7.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__7.is_marshalable.?_definition
))))
(assert
 (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
  $ (UINT 64)
))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.ghost_serialize.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%7.ghost_serialize.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ USIZE self!
     ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (UINT 64) (I (uClip 64 (%I self!)))
    ))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ USIZE self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__7.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__7.ghost_serialize.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.view_equal.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) self! other!
     ) (B (= (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.)
        self!
       ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.)
        other!
    ))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__8.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__8.view_equal.?_definition
))))
(assert
 (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
  $ USIZE
))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.is_marshalable.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.is_marshalable.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) self!
     ) (B (and
       (<= (vstd!seq.Seq.len.? $ (UINT 8) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ (UINT
            8
           ) $ TYPE%alloc!alloc.Global.
          ) self!
         )
        ) (- (uHi SZ) 1)
       )
       (<= (Add (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
           $ USIZE (I (uClip SZ (vstd!seq.Seq.len.? $ (UINT 8) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                $ (UINT 8) $ TYPE%alloc!alloc.Global.
               ) self!
          )))))
         ) (vstd!seq.Seq.len.? $ (UINT 8) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ (UINT
             8
            ) $ TYPE%alloc!alloc.Global.
           ) self!
         ))
        ) (- (uHi SZ) 1)
    ))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__8.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__8.is_marshalable.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.ghost_serialize.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%8.ghost_serialize.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) self!
     ) (vstd!seq.Seq.add.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
       $ USIZE (I (uClip SZ (vstd!seq.Seq.len.? $ (UINT 8) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
            $ (UINT 8) $ TYPE%alloc!alloc.Global.
           ) self!
       ))))
      ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.)
       self!
    )))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__8.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__8.ghost_serialize.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.view_equal.)
  (forall ((T&. Dcr) (T& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       T&. T&
     ))
     (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
       $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) self! other!
      ) (B (let
        ((s$ (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
           self!
        )))
        (let
         ((o$ (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
            other!
         )))
         (and
          (= (vstd!seq.Seq.len.? T&. T& s$) (vstd!seq.Seq.len.? T&. T& o$))
          (forall ((i$ Poly)) (!
            (=>
             (has_type i$ INT)
             (=>
              (let
               ((tmp%%$ 0))
               (let
                ((tmp%%$1 (%I i$)))
                (let
                 ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& s$)))
                 (and
                  (<= tmp%%$ tmp%%$1)
                  (< tmp%%$1 tmp%%$2)
              ))))
              (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
                T&. T& (vstd!seq.Seq.index.? T&. T& s$ i$) (vstd!seq.Seq.index.? T&. T& o$ i$)
            ))))
            :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
              T&. T& (vstd!seq.Seq.index.? T&. T& s$ i$) (vstd!seq.Seq.index.? T&. T& o$ i$)
            ))
            :qid user_alloc__vec__Vec__view_equal_0
            :skolemid skolem_user_alloc__vec__Vec__view_equal_0
    ))))))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__9.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__9.view_equal.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.is_marshalable.)
)
(declare-fun %%lambda%%0 (Dcr Type Dcr Type) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (acc$ Poly)
   (x$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) acc$ x$) (I (Add
      (%I acc$) (vstd!seq.Seq.len.? %%hole%%2 %%hole%%3 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
        %%hole%%0 %%hole%%1 x$
   )))))
   :pattern ((%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) acc$ x$))
)))
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.is_marshalable.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       T&. T&
     ))
     (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
       $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) self!
      ) (B (and
        (and
         (<= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. T&. T& $
             TYPE%alloc!alloc.Global.
            ) self!
           )
          ) (- (uHi SZ) 1)
         )
         (forall ((x$ Poly)) (!
           (=>
            (has_type x$ T&)
            (=>
             (vstd!seq_lib.impl&%0.contains.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                T&. T& $ TYPE%alloc!alloc.Global.
               ) self!
              ) x$
             )
             (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
               T&. T& x$
           ))))
           :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
             T&. T& x$
           ))
           :qid user_alloc__vec__Vec__is_marshalable_0
           :skolemid skolem_user_alloc__vec__Vec__is_marshalable_0
        )))
        (<= (Add (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
            $ USIZE (I (uClip SZ (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
                 T&. T& $ TYPE%alloc!alloc.Global.
                ) self!
           )))))
          ) (%I (vstd!seq_lib.impl&%0.fold_left.? T&. T& $ INT (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
              T&. T& $ TYPE%alloc!alloc.Global.
             ) self!
            ) (I 0) (Poly%fun%2. (mk_fun (%%lambda%%0 T&. T& $ (UINT 8))))
          ))
         ) (- (uHi SZ) 1)
    )))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__9.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__9.is_marshalable.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.ghost_serialize.)
)
(declare-fun %%lambda%%1 (Dcr Type Dcr Type) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (acc$ Poly)
   (x$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%1 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) acc$ x$) (vstd!seq.Seq.add.?
     %%hole%%2 %%hole%%3 acc$ (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      %%hole%%0 %%hole%%1 x$
   )))
   :pattern ((%%apply%%0 (%%lambda%%1 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3) acc$ x$))
)))
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%9.ghost_serialize.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       T&. T&
     ))
     (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
       $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) self!
      ) (vstd!seq.Seq.add.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
        $ USIZE (I (uClip SZ (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec.
             T&. T& $ TYPE%alloc!alloc.Global.
            ) self!
        ))))
       ) (vstd!seq_lib.impl&%0.fold_left.? T&. T& $ (TYPE%vstd!seq.Seq. $ (UINT 8)) (vstd!view.View.view.?
         $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) self!
        ) (vstd!seq.Seq.empty.? $ (UINT 8)) (Poly%fun%2. (mk_fun (%%lambda%%1 T&. T& $ (UINT
            8
    ))))))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__9.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__9.ghost_serialize.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.view_equal.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (self! Poly) (other! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       T&. T&
      )
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       U&. U&
     ))
     (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
       (DST U&.) (TYPE%tuple%2. T&. T& U&. U&) self! other!
      ) (B (and
        (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
          T&. T& (tuple%2./tuple%2/0 (%Poly%tuple%2. self!)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
            other!
        ))))
        (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
          U&. U& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
            other!
    ))))))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      (DST U&.) (TYPE%tuple%2. T&. T& U&. U&) self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__10.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__10.view_equal.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.is_marshalable.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.is_marshalable.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       T&. T&
      )
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       U&. U&
     ))
     (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
       (DST U&.) (TYPE%tuple%2. T&. T& U&. U&) self!
      ) (B (and
        (and
         (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
           T&. T& (tuple%2./tuple%2/0 (%Poly%tuple%2. self!))
         ))
         (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
           U&. U& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!))
        )))
        (<= (nClip (Add (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
             T&. T& (tuple%2./tuple%2/0 (%Poly%tuple%2. self!))
            )
           ) (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
             U&. U& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!))
          )))
         ) (- (uHi SZ) 1)
    )))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      (DST U&.) (TYPE%tuple%2. T&. T& U&. U&) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__10.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__10.is_marshalable.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.ghost_serialize.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%10.ghost_serialize.)
  (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (sized U&.)
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       T&. T&
      )
      (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
       U&. U&
     ))
     (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
       (DST U&.) (TYPE%tuple%2. T&. T& U&. U&) self!
      ) (vstd!seq.Seq.add.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
        T&. T& (tuple%2./tuple%2/0 (%Poly%tuple%2. self!))
       ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
        U&. U& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!))
    ))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      (DST U&.) (TYPE%tuple%2. T&. T& U&. U&) self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__10.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__10.ghost_serialize.?_definition
))))
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.)
  (forall ((no%param Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?
      no%param
     ) 1048576
    )
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?
      no%param
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?_definition
))))
(assert
 (forall ((no%param Poly)) (!
   (=>
    (has_type no%param INT)
    (uInv SZ (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?
      no%param
   )))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?
     no%param
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?_pre_post_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.view_equal.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      self! other!
     ) (B (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.view.?
        self!
       ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.view.?
        other!
    ))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__11.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__11.view_equal.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?
      self!
     ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
      (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
       self!
    )))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.)
    (uInv 64 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?
      self!
   )))
   :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?
     self!
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?_pre_post_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.view_equal.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      self! other!
     ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ (UINT 64) (I (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?
        self!
       )
      ) (I (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%12.forward_bijection_for_view_equality_do_not_use_for_anything_else.?
        other!
    ))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__13.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__13.view_equal.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.is_marshalable.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.is_marshalable.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      self!
     ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ (UINT 64) (I (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
        (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
         self!
    )))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__13.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__13.is_marshalable.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.ghost_serialize.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%13.ghost_serialize.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      self!
     ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (UINT 64) (I (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey./SHTKey/ukey
        (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
         self!
    )))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__13.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__13.ghost_serialize.?_definition
))))
(assert
 (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
  $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
))
(assert
 (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
  $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.)
))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.view_equal.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.view_equal.)
  (forall ((self! Poly) (other! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      self! other!
     ) (B (and
       (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
         $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
         (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
          (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
           (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            self!
          ))
         ) (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
          (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
           (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            other!
       )))))
       (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
         $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
          (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
           (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            self!
          ))
         ) (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>. (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
           (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            other!
    ))))))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      self! other!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__14.view_equal.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__14.view_equal.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.is_marshalable.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.is_marshalable.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      self!
     ) (B (and
       (and
        (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
          $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
          (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
           (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
            (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             self!
        )))))
        (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
          $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
           (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
            (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             self!
       ))))))
       (<= (nClip (Add (nClip (Add 0 (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
              $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
              (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
               (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
                (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 self!
           ))))))
          ) (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
            $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
             (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
              (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
               self!
         ))))))
        ) (- (uHi SZ) 1)
    ))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__14.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__14.is_marshalable.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.ghost_serialize.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%14.ghost_serialize.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      self!
     ) (vstd!seq.Seq.add.? $ (UINT 8) (vstd!seq.Seq.add.? $ (UINT 8) (vstd!seq.Seq.empty.?
        $ (UINT 8)
       ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
        $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
        (Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!SHTKey.
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/k
          (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           self!
       ))))
      ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
       $ (TYPE%alloc!vec.Vec. $ (UINT 8) $ TYPE%alloc!alloc.Global.) (Poly%alloc!vec.Vec<u8./alloc!alloc.Global.>.
        (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./CKeyKV/v
         (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
          self!
    ))))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__14.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__14.ghost_serialize.?_definition
))))
(assert
 (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
  $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (and
     (sized T&.)
     (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
      T&. T&
    ))
    (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
     $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
   ))
   :pattern ((tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
     $ (TYPE%alloc!vec.Vec. T&. T& $ TYPE%alloc!alloc.Global.)
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__impl&__9_trait_impl_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__impl&__9_trait_impl_definition
)))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.is_marshalable.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.is_marshalable.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      self!
     ) (B (and
       (and
        (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
          $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           $ TYPE%alloc!alloc.Global.
          ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
           (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
            self!
        ))))
        (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!spec_sorted_keys.?
         (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
          (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
           self!
       ))))
       (<= (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
          $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
           $ TYPE%alloc!alloc.Global.
          ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
           (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
            self!
         )))
        ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!ckeyhashmap_max_serialized_size.?
         (I 0)
    )))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.is_marshalable.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__11.is_marshalable.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__11.is_marshalable.?_definition
))))
(assert
 (fuel_bool_default fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.ghost_serialize.)
)
(assert
 (=>
  (fuel_bool fuel%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%11.ghost_serialize.)
  (forall ((self! Poly)) (!
    (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      self!
     ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
       $ TYPE%alloc!alloc.Global.
      ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
       (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
        self!
    ))))
    :pattern ((IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
      $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
      self!
    ))
    :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__11.ghost_serialize.?_definition
    :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&__11.ghost_serialize.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 8))
)
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__48_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__48_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__15_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__15_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ USIZE)
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 8))
)
(assert
 (tr_bound%core!clone.Clone. $ (UINT 64))
)
(assert
 (tr_bound%core!clone.Clone. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!clone.Clone. (REF T&.) T&)
   :pattern ((tr_bound%core!clone.Clone. (REF T&.) T&))
   :qid internal_core__clone__impls__impl&__6_trait_impl_definition
   :skolemid skolem_internal_core__clone__impls__impl&__6_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__35_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__35_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!clone.Clone. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__32_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized A&.)
     (tr_bound%core!clone.Clone. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
     (tr_bound%core!clone.Clone. A&. A&)
    )
    (tr_bound%core!clone.Clone. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&))
   )
   :pattern ((tr_bound%core!clone.Clone. $ (TYPE%alloc!vec.Vec. T&. T& A&. A&)))
   :qid internal_alloc__vec__impl&__12_trait_impl_definition
   :skolemid skolem_internal_alloc__vec__impl&__12_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!clone.Clone. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__7_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__7_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!clone.Clone. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!clone.Clone. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__9_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__9_trait_impl_definition
)))
(assert
 (tr_bound%core!clone.Clone. $ NAT)
)
(assert
 (tr_bound%core!marker.Copy. $ USIZE)
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 8))
)
(assert
 (tr_bound%core!marker.Copy. $ (UINT 64))
)
(assert
 (tr_bound%core!marker.Copy. $ BOOL)
)
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (tr_bound%core!marker.Copy. (REF T&.) T&)
   :pattern ((tr_bound%core!marker.Copy. (REF T&.) T&))
   :qid internal_core__marker__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__marker__impl&__4_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (sized A&.)
    (tr_bound%core!marker.Copy. (GHOST A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (GHOST A&.) A&))
   :qid internal_verus_builtin__impl&__8_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__8_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Copy. A&. A&)
    )
    (tr_bound%core!marker.Copy. (TRACKED A&.) A&)
   )
   :pattern ((tr_bound%core!marker.Copy. (TRACKED A&.) A&))
   :qid internal_verus_builtin__impl&__10_trait_impl_definition
   :skolemid skolem_internal_verus_builtin__impl&__10_trait_impl_definition
)))
(assert
 (tr_bound%core!marker.Copy. $ NAT)
)
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(assert
 (tr_bound%verus_builtin!Integer. $ (UINT 8))
)
(assert
 (tr_bound%verus_builtin!Integer. $ (UINT 64))
)
(assert
 (tr_bound%verus_builtin!Integer. $ USIZE)
)
(assert
 (tr_bound%verus_builtin!Integer. $ NAT)
)
(assert
 (forall ((T&. Dcr) (T& Type) (U&. Dcr) (U& Type)) (!
   (=>
    (and
     (sized T&.)
     (sized U&.)
     (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
      T&. T&
     )
     (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
      U&. U&
    ))
    (tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
     (DST U&.) (TYPE%tuple%2. T&. T& U&. U&)
   ))
   :pattern ((tr_bound%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.
     (DST U&.) (TYPE%tuple%2. T&. T& U&. U&)
   ))
   :qid internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__impl&__10_trait_impl_definition
   :skolemid skolem_internal_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__impl&__10_trait_impl_definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! Poly)
(declare-const other! Poly)
(declare-const tmp%1 Bool)
(declare-const tmp%2 Poly)
(declare-const tmp%3 Poly)
(declare-const tmp%4 Bool)
(declare-const tmp%5 Bool)
(declare-const tmp%6 Bool)
(declare-const tmp%7 Bool)
(declare-const tmp%8 Poly)
(declare-const tmp%9 Poly)
(declare-const i@ Int)
(assert
 fuel_defaults
)
(assert
 (has_type self! TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.)
)
(assert
 (has_type other! TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.)
)
(assert
 (not (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
    $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
    self! other!
))))
(assert
 (<= (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
    $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
    self!
   )
  ) (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
    $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
    other!
))))
(declare-fun %%choose%%0 (Type Int Int Dcr Type Poly Dcr Type Poly Dcr Type Poly Dcr
  Type Poly
 ) Poly
)
(assert
 (forall ((%%hole%%0 Type) (%%hole%%1 Int) (%%hole%%2 Int) (%%hole%%3 Dcr) (%%hole%%4
    Type
   ) (%%hole%%5 Poly) (%%hole%%6 Dcr) (%%hole%%7 Type) (%%hole%%8 Poly) (%%hole%%9 Dcr)
   (%%hole%%10 Type) (%%hole%%11 Poly) (%%hole%%12 Dcr) (%%hole%%13 Type) (%%hole%%14
    Poly
   )
  ) (!
   (=>
    (exists ((i$1 Poly)) (!
      (and
       (has_type i$1 %%hole%%0)
       (and
        (let
         ((tmp%%$ %%hole%%2))
         (let
          ((tmp%%$4 (%I i$1)))
          (let
           ((tmp%%$5 %%hole%%1))
           (and
            (<= tmp%%$ tmp%%$4)
            (< tmp%%$4 tmp%%$5)
        ))))
        (not (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
           (vstd!seq.Seq.index.? %%hole%%3 %%hole%%4 %%hole%%5 i$1)
          ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
           (vstd!seq.Seq.index.? %%hole%%6 %%hole%%7 %%hole%%8 i$1)
      )))))
      :pattern ((vstd!seq.Seq.index.? %%hole%%9 %%hole%%10 %%hole%%11 i$1))
      :pattern ((vstd!seq.Seq.index.? %%hole%%12 %%hole%%13 %%hole%%14 i$1))
      :qid user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap__lemma_serialization_is_not_a_prefix_of_1
      :skolemid skolem_user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap__lemma_serialization_is_not_a_prefix_of_1
    ))
    (exists ((i$1 Poly)) (!
      (and
       (and
        (has_type i$1 %%hole%%0)
        (and
         (let
          ((tmp%%$ %%hole%%2))
          (let
           ((tmp%%$4 (%I i$1)))
           (let
            ((tmp%%$5 %%hole%%1))
            (and
             (<= tmp%%$ tmp%%$4)
             (< tmp%%$4 tmp%%$5)
         ))))
         (not (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
            (vstd!seq.Seq.index.? %%hole%%3 %%hole%%4 %%hole%%5 i$1)
           ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
            (vstd!seq.Seq.index.? %%hole%%6 %%hole%%7 %%hole%%8 i$1)
       )))))
       (= (%%choose%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 %%hole%%5 %%hole%%6
         %%hole%%7 %%hole%%8 %%hole%%9 %%hole%%10 %%hole%%11 %%hole%%12 %%hole%%13 %%hole%%14
        ) i$1
      ))
      :pattern ((vstd!seq.Seq.index.? %%hole%%9 %%hole%%10 %%hole%%11 i$1))
      :pattern ((vstd!seq.Seq.index.? %%hole%%12 %%hole%%13 %%hole%%14 i$1))
   )))
   :pattern ((%%choose%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 %%hole%%5
     %%hole%%6 %%hole%%7 %%hole%%8 %%hole%%9 %%hole%%10 %%hole%%11 %%hole%%12 %%hole%%13
     %%hole%%14
)))))
(declare-const %%switch_label%%0 Bool)
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(declare-const %%location_label%%3 Bool)
(declare-const %%location_label%%4 Bool)
(declare-const %%location_label%%5 Bool)
(declare-const %%location_label%%6 Bool)
(declare-const %%location_label%%7 Bool)
(assert
 (not (=>
   (ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.lemma_to_vec_view.
    (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
     self!
    ) (%Poly%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
     other!
   ))
   (=>
    (= tmp%1 (not (= (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
         $ TYPE%alloc!alloc.Global.
        ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
          self!
        ))
       ) (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
         $ TYPE%alloc!alloc.Global.
        ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
          other!
    ))))))
    (and
     (=>
      %%location_label%%0
      tmp%1
     )
     (=>
      tmp%1
      (or
       (and
        (=>
         (not (= (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
             (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
              self!
            ))
           ) (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
            $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
             (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
              other!
         )))))
         (=>
          (= tmp%2 (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
            (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
             self!
          )))
          (=>
           (= tmp%3 (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
             (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
              other!
           )))
           (and
            (=>
             %%location_label%%1
             (req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
              $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
               $ TYPE%alloc!alloc.Global.
              ) tmp%2 tmp%3
            ))
            (=>
             (ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
              false $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
               $ TYPE%alloc!alloc.Global.
              ) tmp%2 tmp%3
             )
             %%switch_label%%0
        )))))
        (=>
         (not (not (= (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
              (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
               self!
             ))
            ) (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
             $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
              (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
               other!
         ))))))
         (=>
          (= tmp%4 (exists ((i$ Poly)) (!
             (and
              (has_type i$ INT)
              (and
               (let
                ((tmp%%$ 0))
                (let
                 ((tmp%%$1 (%I i$)))
                 (let
                  ((tmp%%$2 (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                     $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                      (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                       self!
                  )))))
                  (and
                   (<= tmp%%$ tmp%%$1)
                   (< tmp%%$1 tmp%%$2)
               ))))
               (not (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
                  (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                     $ TYPE%alloc!alloc.Global.
                    ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                     (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                      self!
                    ))
                   ) i$
                  )
                 ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
                  (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                     $ TYPE%alloc!alloc.Global.
                    ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                     (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                      other!
                    ))
                   ) i$
             ))))))
             :pattern ((vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
               (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 $ TYPE%alloc!alloc.Global.
                ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                  self!
                ))
               ) i$
             ))
             :pattern ((vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
               (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 $ TYPE%alloc!alloc.Global.
                ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                 (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                  other!
                ))
               ) i$
             ))
             :qid user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap__lemma_serialization_is_not_a_prefix_of_0
             :skolemid skolem_user_IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of__CKeyHashMap__lemma_serialization_is_not_a_prefix_of_0
          )))
          (and
           (=>
            %%location_label%%2
            tmp%4
           )
           (=>
            tmp%4
            (=>
             (= i@ (%I (as_type (%%choose%%0 INT (vstd!std_specs.vec.spec_vec_len.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                  $ TYPE%alloc!alloc.Global. (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                   (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                    self!
                  ))
                 ) 0 $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   $ TYPE%alloc!alloc.Global.
                  ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                   (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                    self!
                  ))
                 ) $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   $ TYPE%alloc!alloc.Global.
                  ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                   (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                    other!
                  ))
                 ) $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   $ TYPE%alloc!alloc.Global.
                  ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                   (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                    self!
                  ))
                 ) $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                 (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   $ TYPE%alloc!alloc.Global.
                  ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                   (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                    other!
                 )))
                ) INT
             )))
             (=>
              (= tmp%5 (not (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
                  (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                     $ TYPE%alloc!alloc.Global.
                    ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                     (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                      self!
                    ))
                   ) (I i@)
                  )
                 ) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%1.view.?
                  (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                   (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                     $ TYPE%alloc!alloc.Global.
                    ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                     (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                      other!
                    ))
                   ) (I i@)
              )))))
              (and
               (=>
                %%location_label%%3
                tmp%5
               )
               (=>
                tmp%5
                (=>
                 (= tmp%6 (not (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
                     $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                     (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                      (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                        $ TYPE%alloc!alloc.Global.
                       ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                        (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                         self!
                       ))
                      ) (I i@)
                     ) (vstd!seq.Seq.index.? $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                      (vstd!view.View.view.? $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                        $ TYPE%alloc!alloc.Global.
                       ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                        (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                         other!
                       ))
                      ) (I i@)
                 )))))
                 (and
                  (=>
                   %%location_label%%4
                   tmp%6
                  )
                  (=>
                   tmp%6
                   (=>
                    (= tmp%7 (not (%B (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.view_equal.?
                        $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                         $ TYPE%alloc!alloc.Global.
                        ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                          self!
                         )
                        ) (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                          other!
                    ))))))
                    (and
                     (=>
                      %%location_label%%5
                      tmp%7
                     )
                     (=>
                      tmp%7
                      (=>
                       (= tmp%8 (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                         (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                          self!
                       )))
                       (=>
                        (= tmp%9 (Poly%alloc!vec.Vec<IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV./alloc!alloc.Global.>.
                          (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!impl&%0.spec_to_vec.?
                           other!
                        )))
                        (and
                         (=>
                          %%location_label%%6
                          (req%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
                           $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                            $ TYPE%alloc!alloc.Global.
                           ) tmp%8 tmp%9
                         ))
                         (=>
                          (ens%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.lemma_serialization_is_not_a_prefix_of.
                           false $ (TYPE%alloc!vec.Vec. $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyKV.
                            $ TYPE%alloc!alloc.Global.
                           ) tmp%8 tmp%9
                          )
                          %%switch_label%%0
       )))))))))))))))))))
       (and
        (not %%switch_label%%0)
        (=>
         %%location_label%%7
         (not (= (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
            $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
            self!
           ) (vstd!seq.Seq.subrange.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
             $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
             other!
            ) (I 0) (I (vstd!seq.Seq.len.? $ (UINT 8) (IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!Marshalable.ghost_serialize.?
               $ TYPE%IR__marshal_ironsht_specific_v__impl2__lemma_serialization_is_not_a_prefix_of!CKeyHashMap.
               self!
)))))))))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
