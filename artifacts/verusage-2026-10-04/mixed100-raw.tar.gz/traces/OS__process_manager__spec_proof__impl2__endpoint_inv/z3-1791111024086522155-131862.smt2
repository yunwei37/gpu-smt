(set-option :auto_config false)
(set-option :smt.mbqi false)
(set-option :smt.case_split 3)
(set-option :smt.qi.eager_threshold 100.0)
(set-option :smt.delay_units true)
(set-option :smt.arith.solver 2)
(set-option :smt.arith.nl false)
(set-option :pi.enabled false)
(set-option :rewriter.sort_disjunctions false)
(declare-sort %%Function%% 0)
(declare-sort FuelId 0)
(declare-sort Fuel 0)
(declare-const zero Fuel)
(declare-fun succ (Fuel) Fuel)
(declare-fun fuel_bool (FuelId) Bool)
(declare-fun fuel_bool_default (FuelId) Bool)
(declare-const fuel_defaults Bool)
(assert
 (=>
  fuel_defaults
  (forall ((id FuelId)) (!
    (= (fuel_bool id) (fuel_bool_default id))
    :pattern ((fuel_bool id))
    :qid prelude_fuel_defaults
    :skolemid skolem_prelude_fuel_defaults
))))
(declare-datatypes ((fndef 0)) (((fndef_singleton))))
(declare-sort Poly 0)
(declare-sort Height 0)
(declare-fun I (Int) Poly)
(declare-fun B (Bool) Poly)
(declare-fun R (Real) Poly)
(declare-fun F (fndef) Poly)
(declare-fun %I (Poly) Int)
(declare-fun %B (Poly) Bool)
(declare-fun %R (Poly) Real)
(declare-fun %F (Poly) fndef)
(declare-sort Type 0)
(declare-const BOOL Type)
(declare-const INT Type)
(declare-const NAT Type)
(declare-const REAL Type)
(declare-const CHAR Type)
(declare-const USIZE Type)
(declare-const ISIZE Type)
(declare-const TYPE%tuple%0. Type)
(declare-fun UINT (Int) Type)
(declare-fun SINT (Int) Type)
(declare-fun FLOAT (Int) Type)
(declare-fun CONST_INT (Int) Type)
(declare-fun CONST_BOOL (Bool) Type)
(declare-sort Dcr 0)
(declare-const $ Dcr)
(declare-const $slice Dcr)
(declare-const $dyn Dcr)
(declare-fun DST (Dcr) Dcr)
(declare-fun REF (Dcr) Dcr)
(declare-fun BOX (Dcr Type Dcr) Dcr)
(declare-fun RC (Dcr Type Dcr) Dcr)
(declare-fun ARC (Dcr Type Dcr) Dcr)
(declare-fun GHOST (Dcr) Dcr)
(declare-fun TRACKED (Dcr) Dcr)
(declare-fun NEVER (Dcr) Dcr)
(declare-fun CONST_PTR (Dcr) Dcr)
(declare-fun ARRAY (Dcr Type Dcr Type) Type)
(declare-fun MUTREF (Dcr Type) Type)
(declare-fun SLICE (Dcr Type) Type)
(declare-const STRSLICE Type)
(declare-const ALLOCATOR_GLOBAL Type)
(declare-fun PTR (Dcr Type) Type)
(declare-fun has_type (Poly Type) Bool)
(declare-fun sized (Dcr) Bool)
(declare-fun as_type (Poly Type) Poly)
(declare-fun mk_fun (%%Function%%) %%Function%%)
(declare-fun const_int (Type) Int)
(declare-fun const_bool (Type) Bool)
(declare-fun mut_ref_current% (Poly) Poly)
(declare-fun mut_ref_future% (Poly) Poly)
(declare-fun mut_ref_update_current% (Poly Poly) Poly)
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_current% (mut_ref_update_current% m arg)) arg)
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_current
   :skolemid skolem_prelude_mut_ref_update_current_current
)))
(assert
 (forall ((m Poly) (arg Poly)) (!
   (= (mut_ref_future% (mut_ref_update_current% m arg)) (mut_ref_future% m))
   :pattern ((mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_current_future
   :skolemid skolem_prelude_mut_ref_update_current_future
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_current% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_current% m))
   :qid prelude_mut_ref_current_has_type
   :skolemid skolem_prelude_mut_ref_current_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type)) (!
   (=>
    (has_type m (MUTREF d t))
    (has_type (mut_ref_future% m) t)
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_future% m))
   :qid prelude_mut_ref_future_has_type
   :skolemid skolem_prelude_mut_ref_future_has_type
)))
(assert
 (forall ((m Poly) (d Dcr) (t Type) (arg Poly)) (!
   (=>
    (and
     (has_type m (MUTREF d t))
     (has_type arg t)
    )
    (has_type (mut_ref_update_current% m arg) (MUTREF d t))
   )
   :pattern ((has_type m (MUTREF d t)) (mut_ref_update_current% m arg))
   :qid prelude_mut_ref_update_has_type
   :skolemid skolem_prelude_mut_ref_update_has_type
)))
(assert
 (forall ((d Dcr)) (!
   (=>
    (sized d)
    (sized (DST d))
   )
   :pattern ((sized (DST d)))
   :qid prelude_sized_decorate_struct_inherit
   :skolemid skolem_prelude_sized_decorate_struct_inherit
)))
(assert
 (forall ((d Dcr)) (!
   (sized (REF d))
   :pattern ((sized (REF d)))
   :qid prelude_sized_decorate_ref
   :skolemid skolem_prelude_sized_decorate_ref
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (BOX d t d2))
   :pattern ((sized (BOX d t d2)))
   :qid prelude_sized_decorate_box
   :skolemid skolem_prelude_sized_decorate_box
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (RC d t d2))
   :pattern ((sized (RC d t d2)))
   :qid prelude_sized_decorate_rc
   :skolemid skolem_prelude_sized_decorate_rc
)))
(assert
 (forall ((d Dcr) (t Type) (d2 Dcr)) (!
   (sized (ARC d t d2))
   :pattern ((sized (ARC d t d2)))
   :qid prelude_sized_decorate_arc
   :skolemid skolem_prelude_sized_decorate_arc
)))
(assert
 (forall ((d Dcr)) (!
   (sized (GHOST d))
   :pattern ((sized (GHOST d)))
   :qid prelude_sized_decorate_ghost
   :skolemid skolem_prelude_sized_decorate_ghost
)))
(assert
 (forall ((d Dcr)) (!
   (sized (TRACKED d))
   :pattern ((sized (TRACKED d)))
   :qid prelude_sized_decorate_tracked
   :skolemid skolem_prelude_sized_decorate_tracked
)))
(assert
 (forall ((d Dcr)) (!
   (sized (NEVER d))
   :pattern ((sized (NEVER d)))
   :qid prelude_sized_decorate_never
   :skolemid skolem_prelude_sized_decorate_never
)))
(assert
 (forall ((d Dcr)) (!
   (sized (CONST_PTR d))
   :pattern ((sized (CONST_PTR d)))
   :qid prelude_sized_decorate_const_ptr
   :skolemid skolem_prelude_sized_decorate_const_ptr
)))
(assert
 (sized $)
)
(assert
 (forall ((i Int)) (!
   (= i (const_int (CONST_INT i)))
   :pattern ((CONST_INT i))
   :qid prelude_type_id_const_int
   :skolemid skolem_prelude_type_id_const_int
)))
(assert
 (forall ((b Bool)) (!
   (= b (const_bool (CONST_BOOL b)))
   :pattern ((CONST_BOOL b))
   :qid prelude_type_id_const_bool
   :skolemid skolem_prelude_type_id_const_bool
)))
(assert
 (forall ((b Bool)) (!
   (has_type (B b) BOOL)
   :pattern ((has_type (B b) BOOL))
   :qid prelude_has_type_bool
   :skolemid skolem_prelude_has_type_bool
)))
(assert
 (forall ((r Real)) (!
   (has_type (R r) REAL)
   :pattern ((has_type (R r) REAL))
   :qid prelude_has_type_real
   :skolemid skolem_prelude_has_type_real
)))
(assert
 (forall ((x Poly) (t Type)) (!
   (and
    (has_type (as_type x t) t)
    (=>
     (has_type x t)
     (= x (as_type x t))
   ))
   :pattern ((as_type x t))
   :qid prelude_as_type
   :skolemid skolem_prelude_as_type
)))
(assert
 (forall ((x %%Function%%)) (!
   (= (mk_fun x) x)
   :pattern ((mk_fun x))
   :qid prelude_mk_fun
   :skolemid skolem_prelude_mk_fun
)))
(assert
 (forall ((x Bool)) (!
   (= x (%B (B x)))
   :pattern ((B x))
   :qid prelude_unbox_box_bool
   :skolemid skolem_prelude_unbox_box_bool
)))
(assert
 (forall ((x Int)) (!
   (= x (%I (I x)))
   :pattern ((I x))
   :qid prelude_unbox_box_int
   :skolemid skolem_prelude_unbox_box_int
)))
(assert
 (forall ((x Real)) (!
   (= x (%R (R x)))
   :pattern ((R x))
   :qid prelude_unbox_box_real
   :skolemid skolem_prelude_unbox_box_real
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x BOOL)
    (= x (B (%B x)))
   )
   :pattern ((has_type x BOOL))
   :qid prelude_box_unbox_bool
   :skolemid skolem_prelude_box_unbox_bool
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x INT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x INT))
   :qid prelude_box_unbox_int
   :skolemid skolem_prelude_box_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (= x (I (%I x)))
   )
   :pattern ((has_type x NAT))
   :qid prelude_box_unbox_nat
   :skolemid skolem_prelude_box_unbox_nat
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_box_unbox_usize
   :skolemid skolem_prelude_box_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (= x (I (%I x)))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_box_unbox_isize
   :skolemid skolem_prelude_box_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_box_unbox_uint
   :skolemid skolem_prelude_box_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_box_unbox_sint
   :skolemid skolem_prelude_box_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (= x (I (%I x)))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_box_unbox_float
   :skolemid skolem_prelude_box_unbox_float
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (= x (I (%I x)))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_box_unbox_char
   :skolemid skolem_prelude_box_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x REAL)
    (= x (R (%R x)))
   )
   :pattern ((has_type x REAL))
   :qid prelude_box_unbox_real
   :skolemid skolem_prelude_box_unbox_real
)))
(declare-fun ext_eq (Bool Type Poly Poly) Bool)
(assert
 (forall ((deep Bool) (t Type) (x Poly) (y Poly)) (!
   (= (= x y) (ext_eq deep t x y))
   :pattern ((ext_eq deep t x y))
   :qid prelude_ext_eq
   :skolemid skolem_prelude_ext_eq
)))
(declare-const SZ Int)
(assert
 (or
  (= SZ 32)
  (= SZ 64)
))
(declare-fun uHi (Int) Int)
(declare-fun iLo (Int) Int)
(declare-fun iHi (Int) Int)
(assert
 (= (uHi 8) 256)
)
(assert
 (= (uHi 16) 65536)
)
(assert
 (= (uHi 32) 4294967296)
)
(assert
 (= (uHi 64) 18446744073709551616)
)
(assert
 (= (uHi 128) (+ 1 340282366920938463463374607431768211455))
)
(assert
 (= (iLo 8) (- 128))
)
(assert
 (= (iLo 16) (- 32768))
)
(assert
 (= (iLo 32) (- 2147483648))
)
(assert
 (= (iLo 64) (- 9223372036854775808))
)
(assert
 (= (iLo 128) (- 170141183460469231731687303715884105728))
)
(assert
 (= (iHi 8) 128)
)
(assert
 (= (iHi 16) 32768)
)
(assert
 (= (iHi 32) 2147483648)
)
(assert
 (= (iHi 64) 9223372036854775808)
)
(assert
 (= (iHi 128) 170141183460469231731687303715884105728)
)
(declare-fun nClip (Int) Int)
(declare-fun uClip (Int Int) Int)
(declare-fun iClip (Int Int) Int)
(declare-fun charClip (Int) Int)
(assert
 (forall ((i Int)) (!
   (and
    (<= 0 (nClip i))
    (=>
     (<= 0 i)
     (= i (nClip i))
   ))
   :pattern ((nClip i))
   :qid prelude_nat_clip
   :skolemid skolem_prelude_nat_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= 0 (uClip bits i))
    (< (uClip bits i) (uHi bits))
    (=>
     (and
      (<= 0 i)
      (< i (uHi bits))
     )
     (= i (uClip bits i))
   ))
   :pattern ((uClip bits i))
   :qid prelude_u_clip
   :skolemid skolem_prelude_u_clip
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (and
    (<= (iLo bits) (iClip bits i))
    (< (iClip bits i) (iHi bits))
    (=>
     (and
      (<= (iLo bits) i)
      (< i (iHi bits))
     )
     (= i (iClip bits i))
   ))
   :pattern ((iClip bits i))
   :qid prelude_i_clip
   :skolemid skolem_prelude_i_clip
)))
(assert
 (forall ((i Int)) (!
   (and
    (or
     (and
      (<= 0 (charClip i))
      (<= (charClip i) 55295)
     )
     (and
      (<= 57344 (charClip i))
      (<= (charClip i) 1114111)
    ))
    (=>
     (or
      (and
       (<= 0 i)
       (<= i 55295)
      )
      (and
       (<= 57344 i)
       (<= i 1114111)
     ))
     (= i (charClip i))
   ))
   :pattern ((charClip i))
   :qid prelude_char_clip
   :skolemid skolem_prelude_char_clip
)))
(declare-fun uInv (Int Int) Bool)
(declare-fun iInv (Int Int) Bool)
(declare-fun charInv (Int) Bool)
(assert
 (forall ((bits Int) (i Int)) (!
   (= (uInv bits i) (and
     (<= 0 i)
     (< i (uHi bits))
   ))
   :pattern ((uInv bits i))
   :qid prelude_u_inv
   :skolemid skolem_prelude_u_inv
)))
(assert
 (forall ((bits Int) (i Int)) (!
   (= (iInv bits i) (and
     (<= (iLo bits) i)
     (< i (iHi bits))
   ))
   :pattern ((iInv bits i))
   :qid prelude_i_inv
   :skolemid skolem_prelude_i_inv
)))
(assert
 (forall ((i Int)) (!
   (= (charInv i) (or
     (and
      (<= 0 i)
      (<= i 55295)
     )
     (and
      (<= 57344 i)
      (<= i 1114111)
   )))
   :pattern ((charInv i))
   :qid prelude_char_inv
   :skolemid skolem_prelude_char_inv
)))
(assert
 (forall ((x Int)) (!
   (has_type (I x) INT)
   :pattern ((has_type (I x) INT))
   :qid prelude_has_type_int
   :skolemid skolem_prelude_has_type_int
)))
(assert
 (forall ((x Int)) (!
   (=>
    (<= 0 x)
    (has_type (I x) NAT)
   )
   :pattern ((has_type (I x) NAT))
   :qid prelude_has_type_nat
   :skolemid skolem_prelude_has_type_nat
)))
(assert
 (forall ((x Int)) (!
   (=>
    (uInv SZ x)
    (has_type (I x) USIZE)
   )
   :pattern ((has_type (I x) USIZE))
   :qid prelude_has_type_usize
   :skolemid skolem_prelude_has_type_usize
)))
(assert
 (forall ((x Int)) (!
   (=>
    (iInv SZ x)
    (has_type (I x) ISIZE)
   )
   :pattern ((has_type (I x) ISIZE))
   :qid prelude_has_type_isize
   :skolemid skolem_prelude_has_type_isize
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (UINT bits))
   )
   :pattern ((has_type (I x) (UINT bits)))
   :qid prelude_has_type_uint
   :skolemid skolem_prelude_has_type_uint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (iInv bits x)
    (has_type (I x) (SINT bits))
   )
   :pattern ((has_type (I x) (SINT bits)))
   :qid prelude_has_type_sint
   :skolemid skolem_prelude_has_type_sint
)))
(assert
 (forall ((bits Int) (x Int)) (!
   (=>
    (uInv bits x)
    (has_type (I x) (FLOAT bits))
   )
   :pattern ((has_type (I x) (FLOAT bits)))
   :qid prelude_has_type_float
   :skolemid skolem_prelude_has_type_float
)))
(assert
 (forall ((x Int)) (!
   (=>
    (charInv x)
    (has_type (I x) CHAR)
   )
   :pattern ((has_type (I x) CHAR))
   :qid prelude_has_type_char
   :skolemid skolem_prelude_has_type_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x NAT)
    (<= 0 (%I x))
   )
   :pattern ((has_type x NAT))
   :qid prelude_unbox_int
   :skolemid skolem_prelude_unbox_int
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x USIZE)
    (uInv SZ (%I x))
   )
   :pattern ((has_type x USIZE))
   :qid prelude_unbox_usize
   :skolemid skolem_prelude_unbox_usize
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x CHAR)
    (charInv (%I x))
   )
   :pattern ((has_type x CHAR))
   :qid prelude_unbox_char
   :skolemid skolem_prelude_unbox_char
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x ISIZE)
    (iInv SZ (%I x))
   )
   :pattern ((has_type x ISIZE))
   :qid prelude_unbox_isize
   :skolemid skolem_prelude_unbox_isize
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (UINT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (UINT bits)))
   :qid prelude_unbox_uint
   :skolemid skolem_prelude_unbox_uint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (SINT bits))
    (iInv bits (%I x))
   )
   :pattern ((has_type x (SINT bits)))
   :qid prelude_unbox_sint
   :skolemid skolem_prelude_unbox_sint
)))
(assert
 (forall ((bits Int) (x Poly)) (!
   (=>
    (has_type x (FLOAT bits))
    (uInv bits (%I x))
   )
   :pattern ((has_type x (FLOAT bits)))
   :qid prelude_unbox_float
   :skolemid skolem_prelude_unbox_float
)))
(declare-fun Add (Int Int) Int)
(declare-fun Sub (Int Int) Int)
(declare-fun Mul (Int Int) Int)
(declare-fun EucDiv (Int Int) Int)
(declare-fun EucMod (Int Int) Int)
(declare-fun RAdd (Real Real) Real)
(declare-fun RSub (Real Real) Real)
(declare-fun RMul (Real Real) Real)
(declare-fun RDiv (Real Real) Real)
(assert
 (forall ((x Int) (y Int)) (!
   (= (Add x y) (+ x y))
   :pattern ((Add x y))
   :qid prelude_add
   :skolemid skolem_prelude_add
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Sub x y) (- x y))
   :pattern ((Sub x y))
   :qid prelude_sub
   :skolemid skolem_prelude_sub
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (Mul x y) (* x y))
   :pattern ((Mul x y))
   :qid prelude_mul
   :skolemid skolem_prelude_mul
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucDiv x y) (div x y))
   :pattern ((EucDiv x y))
   :qid prelude_eucdiv
   :skolemid skolem_prelude_eucdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (= (EucMod x y) (mod x y))
   :pattern ((EucMod x y))
   :qid prelude_eucmod
   :skolemid skolem_prelude_eucmod
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RAdd x y) (+ x y))
   :pattern ((RAdd x y))
   :qid prelude_radd
   :skolemid skolem_prelude_radd
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RSub x y) (- x y))
   :pattern ((RSub x y))
   :qid prelude_rsub
   :skolemid skolem_prelude_rsub
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RMul x y) (* x y))
   :pattern ((RMul x y))
   :qid prelude_rmul
   :skolemid skolem_prelude_rmul
)))
(assert
 (forall ((x Real) (y Real)) (!
   (= (RDiv x y) (/ x y))
   :pattern ((RDiv x y))
   :qid prelude_rdiv
   :skolemid skolem_prelude_rdiv
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (<= 0 y)
    )
    (<= 0 (Mul x y))
   )
   :pattern ((Mul x y))
   :qid prelude_mul_nats
   :skolemid skolem_prelude_mul_nats
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucDiv x y))
     (<= (EucDiv x y) x)
   ))
   :pattern ((EucDiv x y))
   :qid prelude_div_unsigned_in_bounds
   :skolemid skolem_prelude_div_unsigned_in_bounds
)))
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (and
     (<= 0 x)
     (< 0 y)
    )
    (and
     (<= 0 (EucMod x y))
     (< (EucMod x y) y)
   ))
   :pattern ((EucMod x y))
   :qid prelude_mod_unsigned_in_bounds
   :skolemid skolem_prelude_mod_unsigned_in_bounds
)))
(declare-fun bitxor (Poly Poly) Int)
(declare-fun bitand (Poly Poly) Int)
(declare-fun bitor (Poly Poly) Int)
(declare-fun bitshr (Poly Poly) Int)
(declare-fun bitshl (Poly Poly) Int)
(declare-fun bitnot (Poly) Int)
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitxor x y))
   )
   :pattern ((uClip bits (bitxor x y)))
   :qid prelude_bit_xor_u_inv
   :skolemid skolem_prelude_bit_xor_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitxor x y))
   )
   :pattern ((iClip bits (bitxor x y)))
   :qid prelude_bit_xor_i_inv
   :skolemid skolem_prelude_bit_xor_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitor x y))
   )
   :pattern ((uClip bits (bitor x y)))
   :qid prelude_bit_or_u_inv
   :skolemid skolem_prelude_bit_or_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitor x y))
   )
   :pattern ((iClip bits (bitor x y)))
   :qid prelude_bit_or_i_inv
   :skolemid skolem_prelude_bit_or_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (uInv bits (%I y))
    )
    (uInv bits (bitand x y))
   )
   :pattern ((uClip bits (bitand x y)))
   :qid prelude_bit_and_u_inv
   :skolemid skolem_prelude_bit_and_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (iInv bits (%I y))
    )
    (iInv bits (bitand x y))
   )
   :pattern ((iClip bits (bitand x y)))
   :qid prelude_bit_and_i_inv
   :skolemid skolem_prelude_bit_and_i_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (uInv bits (%I x))
     (<= 0 (%I y))
    )
    (uInv bits (bitshr x y))
   )
   :pattern ((uClip bits (bitshr x y)))
   :qid prelude_bit_shr_u_inv
   :skolemid skolem_prelude_bit_shr_u_inv
)))
(assert
 (forall ((x Poly) (y Poly) (bits Int)) (!
   (=>
    (and
     (iInv bits (%I x))
     (<= 0 (%I y))
    )
    (iInv bits (bitshr x y))
   )
   :pattern ((iClip bits (bitshr x y)))
   :qid prelude_bit_shr_i_inv
   :skolemid skolem_prelude_bit_shr_i_inv
)))
(declare-fun singular_mod (Int Int) Int)
(assert
 (forall ((x Int) (y Int)) (!
   (=>
    (not (= y 0))
    (= (EucMod x y) (singular_mod x y))
   )
   :pattern ((singular_mod x y))
   :qid prelude_singularmod
   :skolemid skolem_prelude_singularmod
)))
(declare-fun has_resolved (Dcr Type Poly) Bool)
(declare-fun closure_req (Type Dcr Type Poly Poly) Bool)
(declare-fun closure_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun default_ens (Type Dcr Type Poly Poly Poly) Bool)
(declare-fun height (Poly) Height)
(declare-fun height_lt (Height Height) Bool)
(declare-fun fun_from_recursive_field (Poly) Poly)
(declare-fun check_decrease_height (Poly Poly Bool) Bool)
(assert
 (forall ((cur Poly) (prev Poly) (otherwise Bool)) (!
   (= (check_decrease_height cur prev otherwise) (or
     (height_lt (height cur) (height prev))
     (and
      (= (height cur) (height prev))
      otherwise
   )))
   :pattern ((check_decrease_height cur prev otherwise))
   :qid prelude_check_decrease_height
   :skolemid skolem_prelude_check_decrease_height
)))
(assert
 (forall ((cur Int) (prev Int)) (!
   (= (height_lt (height (I cur)) (height (I prev))) (and
     (<= 0 cur)
     (< cur prev)
   ))
   :pattern ((height_lt (height (I cur)) (height (I prev))))
   :qid prelude_check_decrease_int_height
   :skolemid skolem_prelude_check_decrease_int_height
)))
(assert
 (forall ((x Height) (y Height)) (!
   (= (height_lt x y) (and
     ((_ partial-order 0) x y)
     (not (= x y))
   ))
   :pattern ((height_lt x y))
   :qid prelude_height_lt
   :skolemid skolem_prelude_height_lt
)))
(declare-const fuel%vstd!std_specs.option.impl&%0.is_Some. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.is_None. FuelId)
(declare-const fuel%vstd!std_specs.option.impl&%0.arrow_0. FuelId)
(declare-const fuel%vstd!std_specs.option.spec_unwrap. FuelId)
(declare-const fuel%vstd!array.array_view. FuelId)
(declare-const fuel%vstd!array.impl&%0.view. FuelId)
(declare-const fuel%vstd!array.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!array.lemma_array_index. FuelId)
(declare-const fuel%vstd!array.array_len_matches_n. FuelId)
(declare-const fuel%vstd!array.axiom_array_ext_equal. FuelId)
(declare-const fuel%vstd!array.axiom_array_has_resolved. FuelId)
(declare-const fuel%vstd!array.axiom_array_decreases_to_seq. FuelId)
(declare-const fuel%vstd!array.lemma_array_index_decreases. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_requires. FuelId)
(declare-const fuel%vstd!function.axiom_fn_mut_call_ensures. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal. FuelId)
(declare-const fuel%vstd!iset.lemma_iset_ext_equal_deep. FuelId)
(declare-const fuel%vstd!map.impl&%0.spec_index. FuelId)
(declare-const fuel%vstd!map.axiom_map_index_decreases. FuelId)
(declare-const fuel%vstd!map.axiom_map_decreases_to_entry. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal. FuelId)
(declare-const fuel%vstd!map.axiom_map_ext_equal_deep. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%1.arrow_0. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%6.is_init. FuelId)
(declare-const fuel%vstd!raw_ptr.impl&%6.value. FuelId)
(declare-const fuel%vstd!seq.impl&%2.spec_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_index_decreases. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_len. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_new_index. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal. FuelId)
(declare-const fuel%vstd!seq.lemma_seq_ext_equal_deep. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.contains. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.no_duplicates. FuelId)
(declare-const fuel%vstd!seq_lib.impl&%0.to_set_ensures. FuelId)
(declare-const fuel%vstd!set.Set.contains. FuelId)
(declare-const fuel%vstd!set.Set.subset_of. FuelId)
(declare-const fuel%vstd!set.impl&%0.finite. FuelId)
(declare-const fuel%vstd!set.impl&%0.disjoint. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal. FuelId)
(declare-const fuel%vstd!set.axiom_set_ext_equal_deep. FuelId)
(declare-const fuel%vstd!set.axiom_set_decreases_to_member. FuelId)
(declare-const fuel%vstd!set.lemma_set_contains_len. FuelId)
(declare-const fuel%vstd!simple_pptr.impl&%1.is_init. FuelId)
(declare-const fuel%vstd!simple_pptr.impl&%1.value. FuelId)
(declare-const fuel%vstd!view.impl&%0.view. FuelId)
(declare-const fuel%vstd!view.impl&%2.view. FuelId)
(declare-const fuel%vstd!view.impl&%4.view. FuelId)
(declare-const fuel%vstd!view.impl&%6.view. FuelId)
(declare-const fuel%vstd!view.impl&%14.view. FuelId)
(declare-const fuel%vstd!view.impl&%16.view. FuelId)
(declare-const fuel%vstd!view.impl&%18.view. FuelId)
(declare-const fuel%vstd!view.impl&%20.view. FuelId)
(declare-const fuel%vstd!view.impl&%26.view. FuelId)
(declare-const fuel%vstd!view.impl&%30.view. FuelId)
(declare-const fuel%vstd!view.impl&%36.view. FuelId)
(declare-const fuel%vstd!view.impl&%48.view. FuelId)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.container_dom.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.proc_dom.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.thread_dom.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.endpoint_dom.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.
 FuelId
)
(declare-const fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.
 FuelId
)
(declare-const fuel%vstd!array.group_array_axioms. FuelId)
(declare-const fuel%vstd!function.group_function_axioms. FuelId)
(declare-const fuel%vstd!imap.group_imap_lemmas. FuelId)
(declare-const fuel%vstd!iset.group_iset_lemmas. FuelId)
(declare-const fuel%vstd!laws_cmp.group_laws_cmp. FuelId)
(declare-const fuel%vstd!laws_eq.bool_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i16_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i32_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i64_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.u128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.i128_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.usize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.isize_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. FuelId)
(declare-const fuel%vstd!laws_eq.group_laws_eq. FuelId)
(declare-const fuel%vstd!layout.group_align_properties. FuelId)
(declare-const fuel%vstd!layout.group_layout_axioms. FuelId)
(declare-const fuel%vstd!map.group_map_lemmas. FuelId)
(declare-const fuel%vstd!multiset.group_multiset_axioms. FuelId)
(declare-const fuel%vstd!mut_ref.group_mut_ref_axioms. FuelId)
(declare-const fuel%vstd!raw_ptr.group_raw_ptr_axioms. FuelId)
(declare-const fuel%vstd!seq.group_seq_lemmas. FuelId)
(declare-const fuel%vstd!seq_lib.group_filter_ensures. FuelId)
(declare-const fuel%vstd!seq_lib.group_seq_lib_default. FuelId)
(declare-const fuel%vstd!set.group_set_lemmas. FuelId)
(declare-const fuel%vstd!set_lib.group_set_lib_default. FuelId)
(declare-const fuel%vstd!slice.group_slice_axioms. FuelId)
(declare-const fuel%vstd!string.group_string_axioms. FuelId)
(declare-const fuel%vstd!std_specs.bits.group_bits_axioms. FuelId)
(declare-const fuel%vstd!std_specs.control_flow.group_control_flow_axioms. FuelId)
(declare-const fuel%vstd!std_specs.fmt.group_fmt_axioms. FuelId)
(declare-const fuel%vstd!std_specs.iter.group_iter_axioms. FuelId)
(declare-const fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms. FuelId)
(declare-const fuel%vstd!std_specs.btree.group_btree_axioms. FuelId)
(declare-const fuel%vstd!std_specs.hash.group_hash_axioms. FuelId)
(declare-const fuel%vstd!std_specs.range.group_range_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vec.group_vec_axioms. FuelId)
(declare-const fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. FuelId)
(declare-const fuel%vstd!std_specs.nonzero.group_nonzero_axioms. FuelId)
(declare-const fuel%vstd!group_vstd_default. FuelId)
(assert
 (distinct fuel%vstd!std_specs.option.impl&%0.is_Some. fuel%vstd!std_specs.option.impl&%0.is_None.
  fuel%vstd!std_specs.option.impl&%0.arrow_0. fuel%vstd!std_specs.option.spec_unwrap.
  fuel%vstd!array.array_view. fuel%vstd!array.impl&%0.view. fuel%vstd!array.impl&%2.spec_index.
  fuel%vstd!array.lemma_array_index. fuel%vstd!array.array_len_matches_n. fuel%vstd!array.axiom_array_ext_equal.
  fuel%vstd!array.axiom_array_has_resolved. fuel%vstd!array.axiom_array_decreases_to_seq.
  fuel%vstd!array.lemma_array_index_decreases. fuel%vstd!function.axiom_fn_mut_call_requires.
  fuel%vstd!function.axiom_fn_mut_call_ensures. fuel%vstd!iset.lemma_iset_ext_equal.
  fuel%vstd!iset.lemma_iset_ext_equal_deep. fuel%vstd!map.impl&%0.spec_index. fuel%vstd!map.axiom_map_index_decreases.
  fuel%vstd!map.axiom_map_decreases_to_entry. fuel%vstd!map.axiom_map_ext_equal. fuel%vstd!map.axiom_map_ext_equal_deep.
  fuel%vstd!raw_ptr.impl&%1.arrow_0. fuel%vstd!raw_ptr.impl&%6.is_init. fuel%vstd!raw_ptr.impl&%6.value.
  fuel%vstd!seq.impl&%2.spec_index. fuel%vstd!seq.lemma_seq_index_decreases. fuel%vstd!seq.lemma_seq_new_len.
  fuel%vstd!seq.lemma_seq_new_index. fuel%vstd!seq.lemma_seq_ext_equal. fuel%vstd!seq.lemma_seq_ext_equal_deep.
  fuel%vstd!seq_lib.impl&%0.contains. fuel%vstd!seq_lib.impl&%0.no_duplicates. fuel%vstd!seq_lib.impl&%0.to_set_ensures.
  fuel%vstd!set.Set.contains. fuel%vstd!set.Set.subset_of. fuel%vstd!set.impl&%0.finite.
  fuel%vstd!set.impl&%0.disjoint. fuel%vstd!set.axiom_set_ext_equal. fuel%vstd!set.axiom_set_ext_equal_deep.
  fuel%vstd!set.axiom_set_decreases_to_member. fuel%vstd!set.lemma_set_contains_len.
  fuel%vstd!simple_pptr.impl&%1.is_init. fuel%vstd!simple_pptr.impl&%1.value. fuel%vstd!view.impl&%0.view.
  fuel%vstd!view.impl&%2.view. fuel%vstd!view.impl&%4.view. fuel%vstd!view.impl&%6.view.
  fuel%vstd!view.impl&%14.view. fuel%vstd!view.impl&%16.view. fuel%vstd!view.impl&%18.view.
  fuel%vstd!view.impl&%20.view. fuel%vstd!view.impl&%26.view. fuel%vstd!view.impl&%30.view.
  fuel%vstd!view.impl&%36.view. fuel%vstd!view.impl&%48.view. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.container_dom.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.proc_dom. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.thread_dom.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.endpoint_dom. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf. fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.
  fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid. fuel%vstd!array.group_array_axioms.
  fuel%vstd!function.group_function_axioms. fuel%vstd!imap.group_imap_lemmas. fuel%vstd!iset.group_iset_lemmas.
  fuel%vstd!laws_cmp.group_laws_cmp. fuel%vstd!laws_eq.bool_laws.group_laws_eq. fuel%vstd!laws_eq.u8_laws.group_laws_eq.
  fuel%vstd!laws_eq.i8_laws.group_laws_eq. fuel%vstd!laws_eq.u16_laws.group_laws_eq.
  fuel%vstd!laws_eq.i16_laws.group_laws_eq. fuel%vstd!laws_eq.u32_laws.group_laws_eq.
  fuel%vstd!laws_eq.i32_laws.group_laws_eq. fuel%vstd!laws_eq.u64_laws.group_laws_eq.
  fuel%vstd!laws_eq.i64_laws.group_laws_eq. fuel%vstd!laws_eq.u128_laws.group_laws_eq.
  fuel%vstd!laws_eq.i128_laws.group_laws_eq. fuel%vstd!laws_eq.usize_laws.group_laws_eq.
  fuel%vstd!laws_eq.isize_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq. fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.
  fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq. fuel%vstd!laws_eq.group_laws_eq. fuel%vstd!layout.group_align_properties.
  fuel%vstd!layout.group_layout_axioms. fuel%vstd!map.group_map_lemmas. fuel%vstd!multiset.group_multiset_axioms.
  fuel%vstd!mut_ref.group_mut_ref_axioms. fuel%vstd!raw_ptr.group_raw_ptr_axioms. fuel%vstd!seq.group_seq_lemmas.
  fuel%vstd!seq_lib.group_filter_ensures. fuel%vstd!seq_lib.group_seq_lib_default.
  fuel%vstd!set.group_set_lemmas. fuel%vstd!set_lib.group_set_lib_default. fuel%vstd!slice.group_slice_axioms.
  fuel%vstd!string.group_string_axioms. fuel%vstd!std_specs.bits.group_bits_axioms.
  fuel%vstd!std_specs.control_flow.group_control_flow_axioms. fuel%vstd!std_specs.fmt.group_fmt_axioms.
  fuel%vstd!std_specs.iter.group_iter_axioms. fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.
  fuel%vstd!std_specs.btree.group_btree_axioms. fuel%vstd!std_specs.hash.group_hash_axioms.
  fuel%vstd!std_specs.range.group_range_axioms. fuel%vstd!std_specs.vec.group_vec_axioms.
  fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms. fuel%vstd!std_specs.nonzero.group_nonzero_axioms.
  fuel%vstd!group_vstd_default.
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!array.group_array_axioms.)
  (and
   (fuel_bool_default fuel%vstd!array.array_len_matches_n.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index.)
   (fuel_bool_default fuel%vstd!array.axiom_array_ext_equal.)
   (fuel_bool_default fuel%vstd!array.axiom_array_has_resolved.)
   (fuel_bool_default fuel%vstd!array.axiom_array_decreases_to_seq.)
   (fuel_bool_default fuel%vstd!array.lemma_array_index_decreases.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!function.group_function_axioms.)
  (and
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_requires.)
   (fuel_bool_default fuel%vstd!function.axiom_fn_mut_call_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal.)
   (fuel_bool_default fuel%vstd!iset.lemma_iset_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
  (and
   (fuel_bool_default fuel%vstd!laws_eq.bool_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i16_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i32_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i64_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.u128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.i128_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.usize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.isize_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_1_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_2_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_3_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_4_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_5_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_6_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_7_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_8_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_9_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_10_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_11_laws.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_eq.tuple_12_laws.group_laws_eq.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
  (fuel_bool_default fuel%vstd!layout.group_align_properties.)
))
(assert
 (=>
  (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!map.axiom_map_index_decreases.)
   (fuel_bool_default fuel%vstd!map.axiom_map_decreases_to_entry.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal.)
   (fuel_bool_default fuel%vstd!map.axiom_map_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!seq.lemma_seq_index_decreases.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_len.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_new_index.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal.)
   (fuel_bool_default fuel%vstd!seq.lemma_seq_ext_equal_deep.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
  (and
   (fuel_bool_default fuel%vstd!seq_lib.impl&%0.to_set_ensures.)
   (fuel_bool_default fuel%vstd!seq_lib.group_filter_ensures.)
)))
(assert
 (=>
  (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
  (and
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal.)
   (fuel_bool_default fuel%vstd!set.axiom_set_ext_equal_deep.)
   (fuel_bool_default fuel%vstd!set.axiom_set_decreases_to_member.)
   (fuel_bool_default fuel%vstd!set.lemma_set_contains_len.)
)))
(assert
 (fuel_bool_default fuel%vstd!group_vstd_default.)
)
(assert
 (=>
  (fuel_bool_default fuel%vstd!group_vstd_default.)
  (and
   (fuel_bool_default fuel%vstd!seq.group_seq_lemmas.)
   (fuel_bool_default fuel%vstd!seq_lib.group_seq_lib_default.)
   (fuel_bool_default fuel%vstd!map.group_map_lemmas.)
   (fuel_bool_default fuel%vstd!set.group_set_lemmas.)
   (fuel_bool_default fuel%vstd!imap.group_imap_lemmas.)
   (fuel_bool_default fuel%vstd!iset.group_iset_lemmas.)
   (fuel_bool_default fuel%vstd!set_lib.group_set_lib_default.)
   (fuel_bool_default fuel%vstd!multiset.group_multiset_axioms.)
   (fuel_bool_default fuel%vstd!function.group_function_axioms.)
   (fuel_bool_default fuel%vstd!laws_eq.group_laws_eq.)
   (fuel_bool_default fuel%vstd!laws_cmp.group_laws_cmp.)
   (fuel_bool_default fuel%vstd!slice.group_slice_axioms.)
   (fuel_bool_default fuel%vstd!array.group_array_axioms.)
   (fuel_bool_default fuel%vstd!string.group_string_axioms.)
   (fuel_bool_default fuel%vstd!raw_ptr.group_raw_ptr_axioms.)
   (fuel_bool_default fuel%vstd!layout.group_layout_axioms.)
   (fuel_bool_default fuel%vstd!mut_ref.group_mut_ref_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.range.group_range_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.bits.group_bits_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.control_flow.group_control_flow_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.fmt.group_fmt_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.manually_drop.group_manually_drop_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.iter.group_iter_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vec.group_vec_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.vecdeque.group_vec_dequeue_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.hash.group_hash_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.btree.group_btree_axioms.)
   (fuel_bool_default fuel%vstd!std_specs.nonzero.group_nonzero_axioms.)
)))
(declare-fun tr_bound%vstd!array.ArrayAdditionalSpecFns. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%vstd!view.View. (Dcr Type) Bool)
(declare-fun tr_bound%core!marker.Tuple. (Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnOnce. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.FnMut. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!ops.function.Fn. (Dcr Type Dcr Type) Bool)
(declare-fun tr_bound%core!alloc.Allocator. (Dcr Type) Bool)
(declare-fun tr_bound%vstd!std_specs.option.OptionAdditionalFns. (Dcr Type Dcr Type)
 Bool
)
(declare-fun proj%%vstd!view.View./V (Dcr Type) Dcr)
(declare-fun proj%vstd!view.View./V (Dcr Type) Type)
(declare-fun proj%%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Dcr)
(declare-fun proj%core!ops.function.FnOnce./Output (Dcr Type Dcr Type) Type)
(declare-sort alloc!alloc.Global. 0)
(declare-sort vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
 0
)
(declare-sort vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
 0
)
(declare-sort vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
 0
)
(declare-sort vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
 0
)
(declare-sort vstd!seq.Seq<i32.>. 0)
(declare-sort vstd!seq.Seq<usize.>. 0)
(declare-sort vstd!seq.Seq<core!option.Option<usize.>.>. 0)
(declare-sort vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
 0
)
(declare-sort vstd!set.Set<usize.>. 0)
(declare-sort vstd!set.Set<tuple%2<usize./usize.>.>. 0)
(declare-sort vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
 0
)
(declare-sort vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
 0
)
(declare-sort vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
 0
)
(declare-sort vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
 0
)
(declare-datatypes ((core!option.Option. 0) (vstd!raw_ptr.MemContents. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
   0
  ) (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. 0) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
   0
  ) (tuple%0. 0) (tuple%2. 0)
 ) (((core!option.Option./None) (core!option.Option./Some (core!option.Option./Some/?0
     Poly
   ))
  ) ((vstd!raw_ptr.MemContents./Uninit) (vstd!raw_ptr.MemContents./Init (vstd!raw_ptr.MemContents./Init/?0
     Poly
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/?value
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/?next Int) (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/?prev
     Int
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList
    (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?ar
     %%Function%%
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?spec_seq
     Poly
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list
     vstd!seq.Seq<i32.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list_head
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list_tail
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list_len
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list
     vstd!seq.Seq<i32.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list_head
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list_tail
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list_len
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?size
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?arr_seq
     Poly
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?parent
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?parent_rev_ptr
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?children
     OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?depth
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?uppertree_seq
     vstd!seq.Seq<usize.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?subtree_set
     vstd!set.Set<usize.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?root_process
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_procs
     OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_endpoints
     vstd!set.Set<usize.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_threads
     vstd!set.Set<usize.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?quota
     OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_cpus
     OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?scheduler
     OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?can_have_children
     Bool
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?owning_container
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?rev_ptr
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?pcid Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?ioid core!option.Option.)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?owned_threads
     OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?parent core!option.Option.)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?parent_rev_ptr
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?children
     OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?uppertree_seq
     vstd!seq.Seq<usize.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?subtree_set
     vstd!set.Set<usize.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?depth Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?dmd_paging_mode
     OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/?owning_container
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/?active Bool) (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/?current_thread
     core!option.Option.
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?queue
     OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?queue_state
     OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?rf_counter
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?owning_threads
     vstd!set.Set<tuple%2<usize./usize.>.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?owning_container
     Int
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager
    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?root_container
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?container_perms
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?process_perms
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?thread_perms
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?endpoint_perms
     vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?cpu_list
     OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?owning_container
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?owning_proc
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?state OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?proc_rev_ptr
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?scheduler_rev_ptr
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?blocking_endpoint_ptr
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?blocking_endpoint_index
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?endpoint_rev_ptr
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?running_cpu
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?endpoint_descriptors
     OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?ipc_payload
     OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?error_code
     core!option.Option.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?trap_frame
     OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/?va
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/?len Int)
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/?va_range
     OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
    )
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/?endpoint_index
     Int
    )
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/?bus
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/?dev Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/?fun Int)
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/?vaddr
     Int
    )
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Empty)
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./SCHEDULED) (
    OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./BLOCKED
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./RUNNING)
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState./RECEIVE) (
    OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState./SEND
   )
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize
    (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/?value
     Int
    )
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize
    (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize/?value
     vstd!seq.Seq<usize.>.
    )
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize
    (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/?value1
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/?value2
     Int
    )
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize
    (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/?value1
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/?value2
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/?value3
     Int
    )
   ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./ErrorNoQuota)
   (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./ErrorVaInUse)
   (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./CpuIdle) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./Error)
   (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./Else) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./NoQuota)
   (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./VaInUse)
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode./NoDMDPG)
   (OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode./DirectParentPrc)
   (OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode./AllParentProc)
   (OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode./AllParentContainer)
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption
    (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/?reg
     OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/?exists
     Bool
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r15
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r14
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r13
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r12
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rbp
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rbx
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r11
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r10
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r9 Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r8 Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rcx Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rdx Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rsi Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rdi Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rax Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?error_code
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rip
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?cs Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?flags
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rsp
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?ss Int)
   )
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/?seq
     Poly
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/?ar %%Function%%)
   )
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/?data
     OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/?len Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/?set vstd!set.Set<usize.>.)
   )
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/?start
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/?len
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/?view
     vstd!seq.Seq<usize.>.
   ))
  ) ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?mem_4k
     Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?mem_2m Int)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?mem_1g Int) (
     OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?pcid Int
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?ioid Int)
   )
  ) ((tuple%0./tuple%0)) ((tuple%2./tuple%2 (tuple%2./tuple%2/?0 Poly) (tuple%2./tuple%2/?1
     Poly
)))))
(declare-fun core!option.Option./Some/0 (Dcr Type core!option.Option.) Poly)
(declare-fun vstd!raw_ptr.MemContents./Init/0 (Dcr Type vstd!raw_ptr.MemContents.)
 Poly
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Node.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Node.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Node.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) %%Function%%
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Poly
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) vstd!seq.Seq<i32.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) vstd!seq.Seq<i32.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Poly
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/uppertree_seq
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) vstd!seq.Seq<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/subtree_set
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/can_have_children
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/uppertree_seq
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) vstd!seq.Seq<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/subtree_set
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/dmd_paging_mode
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.) OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/active
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.) OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_state
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.) OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.) vstd!set.Set<tuple%2<usize./usize.>.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.) OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize/value
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) vstd!seq.Seq<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg
 (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.) OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/exists
 (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Array.) Poly
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Array.) %%Function%%
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.) OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/set
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start
 (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len
 (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/view
 (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.) vstd!seq.Seq<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.) Int
)
(declare-fun tuple%2./tuple%2/0 (tuple%2.) Poly)
(declare-fun tuple%2./tuple%2/1 (tuple%2.) Poly)
(declare-fun TYPE%fun%1. (Dcr Type Dcr Type) Type)
(declare-const TYPE%alloc!alloc.Global. Type)
(declare-fun TYPE%core!option.Option. (Dcr Type) Type)
(declare-fun TYPE%vstd!iset.ISet. (Dcr Type) Type)
(declare-fun TYPE%vstd!map.Map. (Dcr Type Dcr Type) Type)
(declare-fun TYPE%vstd!raw_ptr.MemContents. (Dcr Type) Type)
(declare-fun TYPE%vstd!seq.Seq. (Dcr Type) Type)
(declare-fun TYPE%vstd!set.Set. (Dcr Type) Type)
(declare-fun TYPE%vstd!simple_pptr.PointsTo. (Dcr Type) Type)
(declare-fun TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. (Dcr Type)
 Type
)
(declare-fun TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
 (Dcr Type Dcr Type) Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. Type)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. Type)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
 Type
)
(declare-fun TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Dcr
  Type Dcr Type
 ) Type
)
(declare-fun TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (
  Dcr Type
 ) Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
 Type
)
(declare-const TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. Type)
(declare-fun TYPE%tuple%2. (Dcr Type Dcr Type) Type)
(declare-fun Poly%fun%1. (%%Function%%) Poly)
(declare-fun %Poly%fun%1. (Poly) %%Function%%)
(declare-fun Poly%array%. (%%Function%%) Poly)
(declare-fun %Poly%array%. (Poly) %%Function%%)
(declare-fun Poly%alloc!alloc.Global. (alloc!alloc.Global.) Poly)
(declare-fun %Poly%alloc!alloc.Global. (Poly) alloc!alloc.Global.)
(declare-fun Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
 (vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
 (Poly) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
)
(declare-fun Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
 (vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
 (Poly) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
)
(declare-fun Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
 (vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
 (Poly) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
)
(declare-fun Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
 (vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.)
 Poly
)
(declare-fun %Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
 (Poly) vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
)
(declare-fun Poly%vstd!seq.Seq<i32.>. (vstd!seq.Seq<i32.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<i32.>. (Poly) vstd!seq.Seq<i32.>.)
(declare-fun Poly%vstd!seq.Seq<usize.>. (vstd!seq.Seq<usize.>.) Poly)
(declare-fun %Poly%vstd!seq.Seq<usize.>. (Poly) vstd!seq.Seq<usize.>.)
(declare-fun Poly%vstd!seq.Seq<core!option.Option<usize.>.>. (vstd!seq.Seq<core!option.Option<usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!seq.Seq<core!option.Option<usize.>.>. (Poly) vstd!seq.Seq<core!option.Option<usize.>.>.)
(declare-fun Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
 (vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.) Poly
)
(declare-fun %Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
 (Poly) vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
)
(declare-fun Poly%vstd!set.Set<usize.>. (vstd!set.Set<usize.>.) Poly)
(declare-fun %Poly%vstd!set.Set<usize.>. (Poly) vstd!set.Set<usize.>.)
(declare-fun Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (vstd!set.Set<tuple%2<usize./usize.>.>.)
 Poly
)
(declare-fun %Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (Poly) vstd!set.Set<tuple%2<usize./usize.>.>.)
(declare-fun Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
 (vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.)
 Poly
)
(declare-fun %Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
 (Poly) vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
)
(declare-fun Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
 (vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.)
 Poly
)
(declare-fun %Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
 (Poly) vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
)
(declare-fun Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
 (vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.)
 Poly
)
(declare-fun %Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
 (Poly) vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
)
(declare-fun Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
 (vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.)
 Poly
)
(declare-fun %Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
 (Poly) vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
)
(declare-fun Poly%core!option.Option. (core!option.Option.) Poly)
(declare-fun %Poly%core!option.Option. (Poly) core!option.Option.)
(declare-fun Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents.) Poly)
(declare-fun %Poly%vstd!raw_ptr.MemContents. (Poly) vstd!raw_ptr.MemContents.)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. (OS__process_manager__spec_proof__impl2__endpoint_inv!Node.)
 Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. (Poly)
 OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Container.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
 Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (
  Poly
 ) OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
 Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (Poly)
 OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (
  OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
 ) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
 Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (Poly)
 OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)
 Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly)
 OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (
  OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
 ) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.) Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
 (Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
)
(declare-fun Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
 Poly
)
(declare-fun %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. (Poly)
 OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
)
(declare-fun Poly%tuple%0. (tuple%0.) Poly)
(declare-fun %Poly%tuple%0. (Poly) tuple%0.)
(declare-fun Poly%tuple%2. (tuple%2.) Poly)
(declare-fun %Poly%tuple%2. (Poly) tuple%2.)
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%fun%1. (Poly%fun%1. x)))
   :pattern ((Poly%fun%1. x))
   :qid internal_crate__fun__1_box_axiom_definition
   :skolemid skolem_internal_crate__fun__1_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%fun%1. (%Poly%fun%1. x)))
   )
   :pattern ((has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_unbox_axiom_definition
   :skolemid skolem_internal_crate__fun__1_unbox_axiom_definition
)))
(declare-fun %%apply%%0 (%%Function%% Poly) Poly)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x %%Function%%)) (!
   (=>
    (forall ((T%0 Poly)) (!
      (=>
       (has_type T%0 T%0&)
       (has_type (%%apply%%0 x T%0) T%1&)
      )
      :pattern ((has_type (%%apply%%0 x T%0) T%1&))
      :qid internal_crate__fun__1_constructor_inner_definition
      :skolemid skolem_internal_crate__fun__1_constructor_inner_definition
    ))
    (has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
   )
   :pattern ((has_type (Poly%fun%1. (mk_fun x)) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__fun__1_constructor_definition
   :skolemid skolem_internal_crate__fun__1_constructor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (has_type (%%apply%%0 x T%0) T%1&)
   )
   :pattern ((%%apply%%0 x T%0) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&.
      T%1&
   )))
   :qid internal_crate__fun__1_apply_definition
   :skolemid skolem_internal_crate__fun__1_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (T%0 Poly) (x %%Function%%))
  (!
   (=>
    (and
     (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type T%0 T%0&)
    )
    (height_lt (height (%%apply%%0 x T%0)) (height (fun_from_recursive_field (Poly%fun%1.
        (mk_fun x)
   )))))
   :pattern ((height (%%apply%%0 x T%0)) (has_type (Poly%fun%1. x) (TYPE%fun%1. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_crate__fun__1_height_apply_definition
   :skolemid skolem_internal_crate__fun__1_height_apply_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%fun%1. T%0&. T%0& T%1&. T%1&))
     (forall ((T%0 Poly)) (!
       (=>
        (has_type T%0 T%0&)
        (ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1. y) T%0))
       )
       :pattern ((ext_eq deep T%1& (%%apply%%0 (%Poly%fun%1. x) T%0) (%%apply%%0 (%Poly%fun%1.
           y
          ) T%0
       )))
       :qid internal_crate__fun__1_inner_ext_equal_definition
       :skolemid skolem_internal_crate__fun__1_inner_ext_equal_definition
    )))
    (ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%fun%1. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_crate__fun__1_ext_equal_definition
   :skolemid skolem_internal_crate__fun__1_ext_equal_definition
)))
(assert
 (forall ((x %%Function%%)) (!
   (= x (%Poly%array%. (Poly%array%. x)))
   :pattern ((Poly%array%. x))
   :qid internal_crate__array___box_axiom_definition
   :skolemid skolem_internal_crate__array___box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (ARRAY T&. T& N&. N&))
    (= x (Poly%array%. (%Poly%array%. x)))
   )
   :pattern ((has_type x (ARRAY T&. T& N&. N&)))
   :qid internal_crate__array___unbox_axiom_definition
   :skolemid skolem_internal_crate__array___unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (= x (%Poly%alloc!alloc.Global. (Poly%alloc!alloc.Global. x)))
   :pattern ((Poly%alloc!alloc.Global. x))
   :qid internal_alloc__alloc__Global_box_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%alloc!alloc.Global.)
    (= x (Poly%alloc!alloc.Global. (%Poly%alloc!alloc.Global. x)))
   )
   :pattern ((has_type x TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_unbox_axiom_definition
   :skolemid skolem_internal_alloc__alloc__Global_unbox_axiom_definition
)))
(assert
 (forall ((x alloc!alloc.Global.)) (!
   (has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.)
   :pattern ((has_type (Poly%alloc!alloc.Global. x) TYPE%alloc!alloc.Global.))
   :qid internal_alloc__alloc__Global_has_type_always_definition
   :skolemid skolem_internal_alloc__alloc__Global_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)))
    (= x (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
      (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
   ))))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.))
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.))
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)))
    (= x (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
      (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
   ))))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.))
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.))
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)))
    (= x (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
      (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
   ))))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.))
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.))
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.))
  (!
   (= x (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
      x
   )))
   :pattern ((Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
     x
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)))
    (= x (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
      (%Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
   ))))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.))
  (!
   (has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
     x
    ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.))
   )
   :pattern ((has_type (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
      x
     ) (TYPE%vstd!map.Map. $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.))
   ))
   :qid internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__map__Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<i32.>.)) (!
   (= x (%Poly%vstd!seq.Seq<i32.>. (Poly%vstd!seq.Seq<i32.>. x)))
   :pattern ((Poly%vstd!seq.Seq<i32.>. x))
   :qid internal_vstd__seq__Seq<i32.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<i32.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (SINT 32)))
    (= x (Poly%vstd!seq.Seq<i32.>. (%Poly%vstd!seq.Seq<i32.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (SINT 32))))
   :qid internal_vstd__seq__Seq<i32.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<i32.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<i32.>.)) (!
   (has_type (Poly%vstd!seq.Seq<i32.>. x) (TYPE%vstd!seq.Seq. $ (SINT 32)))
   :pattern ((has_type (Poly%vstd!seq.Seq<i32.>. x) (TYPE%vstd!seq.Seq. $ (SINT 32))))
   :qid internal_vstd__seq__Seq<i32.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<i32.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (= x (%Poly%vstd!seq.Seq<usize.>. (Poly%vstd!seq.Seq<usize.>. x)))
   :pattern ((Poly%vstd!seq.Seq<usize.>. x))
   :qid internal_vstd__seq__Seq<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ USIZE))
    (= x (Poly%vstd!seq.Seq<usize.>. (%Poly%vstd!seq.Seq<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<usize.>.)) (!
   (has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE))
   :pattern ((has_type (Poly%vstd!seq.Seq<usize.>. x) (TYPE%vstd!seq.Seq. $ USIZE)))
   :qid internal_vstd__seq__Seq<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<core!option.Option<usize.>.>.)) (!
   (= x (%Poly%vstd!seq.Seq<core!option.Option<usize.>.>. (Poly%vstd!seq.Seq<core!option.Option<usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!seq.Seq<core!option.Option<usize.>.>. x))
   :qid internal_vstd__seq__Seq<core!option.Option<usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<core!option.Option<usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ (TYPE%core!option.Option. $ USIZE)))
    (= x (Poly%vstd!seq.Seq<core!option.Option<usize.>.>. (%Poly%vstd!seq.Seq<core!option.Option<usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ (TYPE%core!option.Option. $ USIZE))))
   :qid internal_vstd__seq__Seq<core!option.Option<usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<core!option.Option<usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<core!option.Option<usize.>.>.)) (!
   (has_type (Poly%vstd!seq.Seq<core!option.Option<usize.>.>. x) (TYPE%vstd!seq.Seq. $
     (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!seq.Seq<core!option.Option<usize.>.>. x) (TYPE%vstd!seq.Seq.
      $ (TYPE%core!option.Option. $ USIZE)
   )))
   :qid internal_vstd__seq__Seq<core!option.Option<usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<core!option.Option<usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.))
  (!
   (= x (%Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
     (Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>. x)
   ))
   :pattern ((Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
     x
   ))
   :qid internal_vstd__seq__Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>_box_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!seq.Seq. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.))
    (= x (Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
      (%Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>. x)
   )))
   :pattern ((has_type x (TYPE%vstd!seq.Seq. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)))
   :qid internal_vstd__seq__Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.))
  (!
   (has_type (Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
     x
    ) (TYPE%vstd!seq.Seq. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
   )
   :pattern ((has_type (Poly%vstd!seq.Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>.
      x
     ) (TYPE%vstd!seq.Seq. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
   ))
   :qid internal_vstd__seq__Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>_has_type_always_definition
   :skolemid skolem_internal_vstd__seq__Seq<OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (= x (%Poly%vstd!set.Set<usize.>. (Poly%vstd!set.Set<usize.>. x)))
   :pattern ((Poly%vstd!set.Set<usize.>. x))
   :qid internal_vstd__set__Set<usize.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. $ USIZE))
    (= x (Poly%vstd!set.Set<usize.>. (%Poly%vstd!set.Set<usize.>. x)))
   )
   :pattern ((has_type x (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<usize.>.)) (!
   (has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE))
   :pattern ((has_type (Poly%vstd!set.Set<usize.>. x) (TYPE%vstd!set.Set. $ USIZE)))
   :qid internal_vstd__set__Set<usize.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<usize.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!set.Set<tuple%2<usize./usize.>.>.)) (!
   (= x (%Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
      x
   )))
   :pattern ((Poly%vstd!set.Set<tuple%2<usize./usize.>.>. x))
   :qid internal_vstd__set__Set<tuple__2<usize./usize.>.>_box_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<tuple__2<usize./usize.>.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!set.Set. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)))
    (= x (Poly%vstd!set.Set<tuple%2<usize./usize.>.>. (%Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!set.Set. (DST $) (TYPE%tuple%2. $ USIZE $ USIZE))))
   :qid internal_vstd__set__Set<tuple__2<usize./usize.>.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__set__Set<tuple__2<usize./usize.>.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!set.Set<tuple%2<usize./usize.>.>.)) (!
   (has_type (Poly%vstd!set.Set<tuple%2<usize./usize.>.>. x) (TYPE%vstd!set.Set. (DST $)
     (TYPE%tuple%2. $ USIZE $ USIZE)
   ))
   :pattern ((has_type (Poly%vstd!set.Set<tuple%2<usize./usize.>.>. x) (TYPE%vstd!set.Set.
      (DST $) (TYPE%tuple%2. $ USIZE $ USIZE)
   )))
   :qid internal_vstd__set__Set<tuple__2<usize./usize.>.>_has_type_always_definition
   :skolemid skolem_internal_vstd__set__Set<tuple__2<usize./usize.>.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.))
  (!
   (= x (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
     (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
      x
   )))
   :pattern ((Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
     x
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>_box_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.))
    (= x (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
      (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.))
  (!
   (has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
     x
    ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :pattern ((has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.
      x
     ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>_has_type_always_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.))
  (!
   (= x (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
     (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
      x
   )))
   :pattern ((Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
     x
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>_box_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.))
    (= x (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
      (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.))
  (!
   (has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
     x
    ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
   )
   :pattern ((has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.
      x
     ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>_has_type_always_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.))
  (!
   (= x (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
     (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
      x
   )))
   :pattern ((Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
     x
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>_box_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.))
    (= x (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
      (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.))
  (!
   (has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
     x
    ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :pattern ((has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.
      x
     ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>_has_type_always_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>_has_type_always_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.))
  (!
   (= x (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
     (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
      x
   )))
   :pattern ((Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
     x
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>_box_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.))
    (= x (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
      (%Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
       x
   ))))
   :pattern ((has_type x (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>_unbox_axiom_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>_unbox_axiom_definition
)))
(assert
 (forall ((x vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.))
  (!
   (has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
     x
    ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :pattern ((has_type (Poly%vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.
      x
     ) (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   ))
   :qid internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>_has_type_always_definition
   :skolemid skolem_internal_vstd__simple_pptr__PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>_has_type_always_definition
)))
(assert
 (forall ((x core!option.Option.)) (!
   (= x (%Poly%core!option.Option. (Poly%core!option.Option. x)))
   :pattern ((Poly%core!option.Option. x))
   :qid internal_core__option__Option_box_axiom_definition
   :skolemid skolem_internal_core__option__Option_box_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (= x (Poly%core!option.Option. (%Poly%core!option.Option. x)))
   )
   :pattern ((has_type x (TYPE%core!option.Option. V&. V&)))
   :qid internal_core__option__Option_unbox_axiom_definition
   :skolemid skolem_internal_core__option__Option_unbox_axiom_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type)) (!
   (has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
     V&. V&
   ))
   :pattern ((has_type (Poly%core!option.Option. core!option.Option./None) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./None_constructor_definition
   :skolemid skolem_internal_core!option.Option./None_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (_0! Poly)) (!
   (=>
    (has_type _0! V&)
    (has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :pattern ((has_type (Poly%core!option.Option. (core!option.Option./Some _0!)) (TYPE%core!option.Option.
      V&. V&
   )))
   :qid internal_core!option.Option./Some_constructor_definition
   :skolemid skolem_internal_core!option.Option./Some_constructor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (= (core!option.Option./Some/0 V&. V& x) (core!option.Option./Some/?0 x))
   )
   :pattern ((core!option.Option./Some/0 V&. V& x))
   :qid internal_core!option.Option./Some/0_accessor_definition
   :skolemid skolem_internal_core!option.Option./Some/0_accessor_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%core!option.Option. V&. V&))
    (has_type (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) V&)
   )
   :pattern ((core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x)) (has_type
     x (TYPE%core!option.Option. V&. V&)
   ))
   :qid internal_core!option.Option./Some/0_invariant_definition
   :skolemid skolem_internal_core!option.Option./Some/0_invariant_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (x core!option.Option.)) (!
   (=>
    (is-core!option.Option./Some x)
    (height_lt (height (core!option.Option./Some/0 V&. V& x)) (height (Poly%core!option.Option.
       x
   ))))
   :pattern ((height (core!option.Option./Some/0 V&. V& x)))
   :qid prelude_datatype_height_core!option.Option./Some/0
   :skolemid skolem_prelude_datatype_height_core!option.Option./Some/0
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./None (%Poly%core!option.Option. x))
     (is-core!option.Option./None (%Poly%core!option.Option. y))
    )
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./None_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./None_ext_equal_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (deep Bool) (x Poly) (y Poly)) (!
   (=>
    (and
     (has_type x (TYPE%core!option.Option. V&. V&))
     (has_type y (TYPE%core!option.Option. V&. V&))
     (is-core!option.Option./Some (%Poly%core!option.Option. x))
     (is-core!option.Option./Some (%Poly%core!option.Option. y))
     (ext_eq deep V& (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. x))
      (core!option.Option./Some/0 V&. V& (%Poly%core!option.Option. y))
    ))
    (ext_eq deep (TYPE%core!option.Option. V&. V&) x y)
   )
   :pattern ((ext_eq deep (TYPE%core!option.Option. V&. V&) x y))
   :qid internal_core!option.Option./Some_ext_equal_definition
   :skolemid skolem_internal_core!option.Option./Some_ext_equal_definition
)))
(assert
 (forall ((x vstd!raw_ptr.MemContents.)) (!
   (= x (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. x)))
   :pattern ((Poly%vstd!raw_ptr.MemContents. x))
   :qid internal_vstd__raw_ptr__MemContents_box_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__MemContents_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (= x (Poly%vstd!raw_ptr.MemContents. (%Poly%vstd!raw_ptr.MemContents. x)))
   )
   :pattern ((has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&)))
   :qid internal_vstd__raw_ptr__MemContents_unbox_axiom_definition
   :skolemid skolem_internal_vstd__raw_ptr__MemContents_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (has_type (Poly%vstd!raw_ptr.MemContents. vstd!raw_ptr.MemContents./Uninit) (TYPE%vstd!raw_ptr.MemContents.
     T&. T&
   ))
   :pattern ((has_type (Poly%vstd!raw_ptr.MemContents. vstd!raw_ptr.MemContents./Uninit)
     (TYPE%vstd!raw_ptr.MemContents. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.MemContents./Uninit_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Uninit_constructor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_0! Poly)) (!
   (=>
    (has_type _0! T&)
    (has_type (Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents./Init _0!)) (TYPE%vstd!raw_ptr.MemContents.
      T&. T&
   )))
   :pattern ((has_type (Poly%vstd!raw_ptr.MemContents. (vstd!raw_ptr.MemContents./Init _0!))
     (TYPE%vstd!raw_ptr.MemContents. T&. T&)
   ))
   :qid internal_vstd!raw_ptr.MemContents./Init_constructor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init_constructor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x vstd!raw_ptr.MemContents.)) (!
   (=>
    (is-vstd!raw_ptr.MemContents./Init x)
    (= (vstd!raw_ptr.MemContents./Init/0 T&. T& x) (vstd!raw_ptr.MemContents./Init/?0 x))
   )
   :pattern ((vstd!raw_ptr.MemContents./Init/0 T&. T& x))
   :qid internal_vstd!raw_ptr.MemContents./Init/0_accessor_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init/0_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (has_type (vstd!raw_ptr.MemContents./Init/0 T&. T& (%Poly%vstd!raw_ptr.MemContents.
       x
      )
     ) T&
   ))
   :pattern ((vstd!raw_ptr.MemContents./Init/0 T&. T& (%Poly%vstd!raw_ptr.MemContents.
      x
     )
    ) (has_type x (TYPE%vstd!raw_ptr.MemContents. T&. T&))
   )
   :qid internal_vstd!raw_ptr.MemContents./Init/0_invariant_definition
   :skolemid skolem_internal_vstd!raw_ptr.MemContents./Init/0_invariant_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x vstd!raw_ptr.MemContents.)) (!
   (=>
    (is-vstd!raw_ptr.MemContents./Init x)
    (height_lt (height (vstd!raw_ptr.MemContents./Init/0 T&. T& x)) (height (Poly%vstd!raw_ptr.MemContents.
       x
   ))))
   :pattern ((height (vstd!raw_ptr.MemContents./Init/0 T&. T& x)))
   :qid prelude_datatype_height_vstd!raw_ptr.MemContents./Init/0
   :skolemid skolem_prelude_datatype_height_vstd!raw_ptr.MemContents./Init/0
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Node.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Node_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Node_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&. T&))
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
       x
   ))))
   :pattern ((has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
      T&. T&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Node_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Node_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (_value! core!option.Option.) (_next! Int) (_prev! Int))
  (!
   (=>
    (and
     (has_type (Poly%core!option.Option. _value!) (TYPE%core!option.Option. T&. T&))
     (iInv 32 _next!)
     (iInv 32 _prev!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node
       _value! _next! _prev!
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&. T&)
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node _value! _next! _prev!)
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&. T&)
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Node.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/?value
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&. T&))
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. x)
      )
     ) (TYPE%core!option.Option. T&. T&)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
      x
     )
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&.
      T&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Node.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/?next
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&. T&))
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
       x
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
      x
     )
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&.
      T&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/next_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Node.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/?prev
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&. T&))
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
       x
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
      x
     )
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&.
      T&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/prev_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Node.)) (!
   (=>
    (is-OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node x)
    (height_lt (height (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value
        x
      ))
     ) (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. x))
   ))
   :pattern ((height (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value
       x
   ))))
   :qid prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value
   :skolemid skolem_prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!Node./Node/value
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
     (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   ))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__StaticLinkedList_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__StaticLinkedList_box_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (
       %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x
   ))))
   :pattern ((has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__StaticLinkedList_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__StaticLinkedList_unbox_axiom_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (_ar! %%Function%%) (_spec_seq! Poly)
   (_value_list! vstd!seq.Seq<i32.>.) (_value_list_head! Int) (_value_list_tail! Int)
   (_value_list_len! Int) (_free_list! vstd!seq.Seq<i32.>.) (_free_list_head! Int) (
    _free_list_tail! Int
   ) (_free_list_len! Int) (_size! Int) (_arr_seq! Poly)
  ) (!
   (=>
    (and
     (has_type (Poly%array%. _ar!) (ARRAY $ (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
        T&. T&
       ) N&. N&
     ))
     (has_type _spec_seq! (TYPE%vstd!seq.Seq. T&. T&))
     (iInv 32 _value_list_head!)
     (iInv 32 _value_list_tail!)
     (uInv SZ _value_list_len!)
     (iInv 32 _free_list_head!)
     (iInv 32 _free_list_tail!)
     (uInv SZ _free_list_len!)
     (uInv SZ _size!)
     (has_type _arr_seq! (TYPE%vstd!seq.Seq. $ (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
        T&. T&
    ))))
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList
       _ar! _spec_seq! _value_list! _value_list_head! _value_list_tail! _value_list_len!
       _free_list! _free_list_head! _free_list_tail! _free_list_len! _size! _arr_seq!
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. T&.
      T& N&. N&
   )))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList
       _ar! _spec_seq! _value_list! _value_list_head! _value_list_tail! _value_list_len!
       _free_list! _free_list_head! _free_list_tail! _free_list_len! _size! _arr_seq!
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. T&.
      T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?ar
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (Poly%array%. (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
      )
     ) (ARRAY $ (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node. T&. T&)
      N&. N&
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?spec_seq
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
     ) (TYPE%vstd!seq.Seq. T&. T&)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list_head
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_head_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list_tail
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_tail_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?value_list_len
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/value_list_len_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list_head
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_head_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list_tail
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_tail_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?free_list_len
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/free_list_len_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?size
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/size_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/?arr_seq
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq_accessor_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
     ) (TYPE%vstd!seq.Seq. $ (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Node.
       T&. T&
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (=>
    (is-OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList
     x
    )
    (height_lt (height (Poly%array%. (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
        x
      ))
     ) (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       x
   ))))
   :pattern ((height (Poly%array%. (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
       x
   ))))
   :qid prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
   :skolemid skolem_prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/ar
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (=>
    (is-OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList
     x
    )
    (height_lt (height (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
       x
      )
     ) (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       x
   ))))
   :pattern ((height (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
      x
   )))
   :qid prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
   :skolemid skolem_prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.))
  (!
   (=>
    (is-OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList
     x
    )
    (height_lt (height (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
       x
      )
     ) (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       x
   ))))
   :pattern ((height (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
      x
   )))
   :qid prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
   :skolemid skolem_prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/arr_seq
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Container_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Container_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Container_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Container_unbox_axiom_definition
)))
(assert
 (forall ((_parent! core!option.Option.) (_parent_rev_ptr! core!option.Option.) (_children!
    OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
   ) (_depth! Int) (_uppertree_seq! vstd!seq.Seq<usize.>.) (_subtree_set! vstd!set.Set<usize.>.)
   (_root_process! core!option.Option.) (_owned_procs! OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.)
   (_owned_endpoints! vstd!set.Set<usize.>.) (_owned_threads! vstd!set.Set<usize.>.)
   (_quota! OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.) (_owned_cpus!
    OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
   ) (_scheduler! OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.)
   (_can_have_children! Bool)
  ) (!
   (=>
    (and
     (has_type (Poly%core!option.Option. _parent!) (TYPE%core!option.Option. $ USIZE))
     (has_type (Poly%core!option.Option. _parent_rev_ptr!) (TYPE%core!option.Option. $ (
        SINT 32
     )))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       _children!
      ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
       $ (CONST_INT 10)
     ))
     (uInv SZ _depth!)
     (has_type (Poly%core!option.Option. _root_process!) (TYPE%core!option.Option. $ USIZE))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       _owned_procs!
      ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
       $ (CONST_INT 10)
     ))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. _quota!)
      TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
     )
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. _owned_cpus!)
      (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. $ (CONST_INT 32))
     )
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       _scheduler!
      ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
       $ (CONST_INT 10)
    )))
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container
       _parent! _parent_rev_ptr! _children! _depth! _uppertree_seq! _subtree_set! _root_process!
       _owned_procs! _owned_endpoints! _owned_threads! _quota! _owned_cpus! _scheduler!
       _can_have_children!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container _parent!
       _parent_rev_ptr! _children! _depth! _uppertree_seq! _subtree_set! _root_process!
       _owned_procs! _owned_endpoints! _owned_threads! _quota! _owned_cpus! _scheduler!
       _can_have_children!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?parent
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?parent_rev_ptr
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) (TYPE%core!option.Option. $ (SINT 32))
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/parent_rev_ptr_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?children
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
      $ (CONST_INT 10)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?depth
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/uppertree_seq
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?uppertree_seq
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/uppertree_seq
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/uppertree_seq_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/uppertree_seq_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/subtree_set
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?subtree_set
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/subtree_set
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/subtree_set_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/subtree_set_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?root_process
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_procs
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
      $ (CONST_INT 10)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_endpoints
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_threads
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?quota
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/quota_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?owned_cpus
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. $ (CONST_INT
       32
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?scheduler
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
      $ (CONST_INT 10)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/can_have_children
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/?can_have_children
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/can_have_children
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/can_have_children_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/can_have_children_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Process_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Process_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Process_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Process_unbox_axiom_definition
)))
(assert
 (forall ((_owning_container! Int) (_rev_ptr! Int) (_pcid! Int) (_ioid! core!option.Option.)
   (_owned_threads! OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.)
   (_parent! core!option.Option.) (_parent_rev_ptr! core!option.Option.) (_children!
    OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
   ) (_uppertree_seq! vstd!seq.Seq<usize.>.) (_subtree_set! vstd!set.Set<usize.>.) (
    _depth! Int
   ) (_dmd_paging_mode! OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.)
  ) (!
   (=>
    (and
     (uInv SZ _owning_container!)
     (iInv 32 _rev_ptr!)
     (uInv SZ _pcid!)
     (has_type (Poly%core!option.Option. _ioid!) (TYPE%core!option.Option. $ USIZE))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       _owned_threads!
      ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
       $ (CONST_INT 128)
     ))
     (has_type (Poly%core!option.Option. _parent!) (TYPE%core!option.Option. $ USIZE))
     (has_type (Poly%core!option.Option. _parent_rev_ptr!) (TYPE%core!option.Option. $ (
        SINT 32
     )))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       _children!
      ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
       $ (CONST_INT 10)
     ))
     (uInv SZ _depth!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process
       _owning_container! _rev_ptr! _pcid! _ioid! _owned_threads! _parent! _parent_rev_ptr!
       _children! _uppertree_seq! _subtree_set! _depth! _dmd_paging_mode!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process _owning_container!
       _rev_ptr! _pcid! _ioid! _owned_threads! _parent! _parent_rev_ptr! _children! _uppertree_seq!
       _subtree_set! _depth! _dmd_paging_mode!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?owning_container
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?rev_ptr x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?pcid x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?ioid x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?owned_threads
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
      $ (CONST_INT 128)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?parent x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?parent_rev_ptr
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
      )
     ) (TYPE%core!option.Option. $ (SINT 32))
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/parent_rev_ptr_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?children
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
        x
      ))
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
      $ (CONST_INT 10)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/uppertree_seq
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?uppertree_seq
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/uppertree_seq
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/uppertree_seq_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/uppertree_seq_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/subtree_set
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?subtree_set
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/subtree_set
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/subtree_set_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/subtree_set_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?depth x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/dmd_paging_mode
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/?dmd_paging_mode
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/dmd_paging_mode
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/dmd_paging_mode_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/dmd_paging_mode_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Cpu_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Cpu_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Cpu_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Cpu_unbox_axiom_definition
)))
(assert
 (forall ((_owning_container! Int) (_active! Bool) (_current_thread! core!option.Option.))
  (!
   (=>
    (and
     (uInv SZ _owning_container!)
     (has_type (Poly%core!option.Option. _current_thread!) (TYPE%core!option.Option. $ USIZE))
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu
       _owning_container! _active! _current_thread!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu _owning_container!
       _active! _current_thread!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/?owning_container
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/active x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/?active
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/active x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/active_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/active_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/?current_thread x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Endpoint_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Endpoint_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Endpoint_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Endpoint_unbox_axiom_definition
)))
(assert
 (forall ((_queue! OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.)
   (_queue_state! OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.)
   (_rf_counter! Int) (_owning_threads! vstd!set.Set<tuple%2<usize./usize.>.>.) (_owning_container!
    Int
   )
  ) (!
   (=>
    (and
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       _queue!
      ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
       $ (CONST_INT 128)
     ))
     (uInv SZ _rf_counter!)
     (uInv SZ _owning_container!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint
       _queue! _queue_state! _rf_counter! _owning_threads! _owning_container!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint _queue! _queue_state!
       _rf_counter! _owning_threads! _owning_container!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?queue x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
        x
      ))
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. $ USIZE
      $ (CONST_INT 128)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_state
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?queue_state
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_state
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_state_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue_state_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?rf_counter
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?owning_threads
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/?owning_container
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager_unbox_axiom_definition
)))
(assert
 (forall ((_root_container! Int) (_container_perms! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.)
   (_process_perms! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.)
   (_thread_perms! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.)
   (_endpoint_perms! vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.)
   (_cpu_list! OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)
  ) (!
   (=>
    (and
     (uInv SZ _root_container!)
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. _cpu_list!)
      (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
       $ (CONST_INT 32)
    )))
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager
       _root_container! _container_perms! _process_perms! _thread_perms! _endpoint_perms!
       _cpu_list!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager
       _root_container! _container_perms! _process_perms! _thread_perms! _endpoint_perms!
       _cpu_list!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?root_container
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?container_perms
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?process_perms
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?thread_perms
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?endpoint_perms
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/?cpu_list
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
      $ (CONST_INT 32)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Thread_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Thread_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Thread_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Thread_unbox_axiom_definition
)))
(assert
 (forall ((_owning_container! Int) (_owning_proc! Int) (_state! OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.)
   (_proc_rev_ptr! Int) (_scheduler_rev_ptr! core!option.Option.) (_blocking_endpoint_ptr!
    core!option.Option.
   ) (_blocking_endpoint_index! core!option.Option.) (_endpoint_rev_ptr! core!option.Option.)
   (_running_cpu! core!option.Option.) (_endpoint_descriptors! OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)
   (_ipc_payload! OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   (_error_code! core!option.Option.) (_trap_frame! OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.)
  ) (!
   (=>
    (and
     (uInv SZ _owning_container!)
     (uInv SZ _owning_proc!)
     (iInv 32 _proc_rev_ptr!)
     (has_type (Poly%core!option.Option. _scheduler_rev_ptr!) (TYPE%core!option.Option.
       $ (SINT 32)
     ))
     (has_type (Poly%core!option.Option. _blocking_endpoint_ptr!) (TYPE%core!option.Option.
       $ USIZE
     ))
     (has_type (Poly%core!option.Option. _blocking_endpoint_index!) (TYPE%core!option.Option.
       $ USIZE
     ))
     (has_type (Poly%core!option.Option. _endpoint_rev_ptr!) (TYPE%core!option.Option. $
       (SINT 32)
     ))
     (has_type (Poly%core!option.Option. _running_cpu!) (TYPE%core!option.Option. $ USIZE))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. _endpoint_descriptors!)
      (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. $ (TYPE%core!option.Option.
        $ USIZE
       ) $ (CONST_INT 128)
     ))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. _ipc_payload!)
      TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
     )
     (has_type (Poly%core!option.Option. _error_code!) (TYPE%core!option.Option. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.))
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
       _trap_frame!
      ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
    ))
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread
       _owning_container! _owning_proc! _state! _proc_rev_ptr! _scheduler_rev_ptr! _blocking_endpoint_ptr!
       _blocking_endpoint_index! _endpoint_rev_ptr! _running_cpu! _endpoint_descriptors!
       _ipc_payload! _error_code! _trap_frame!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread _owning_container!
       _owning_proc! _state! _proc_rev_ptr! _scheduler_rev_ptr! _blocking_endpoint_ptr!
       _blocking_endpoint_index! _endpoint_rev_ptr! _running_cpu! _endpoint_descriptors!
       _ipc_payload! _error_code! _trap_frame!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?owning_container
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?owning_proc
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state x) (
     OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?state x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?proc_rev_ptr
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?scheduler_rev_ptr
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) (TYPE%core!option.Option. $ (SINT 32))
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?blocking_endpoint_ptr
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?blocking_endpoint_index
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?endpoint_rev_ptr
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) (TYPE%core!option.Option. $ (SINT 32))
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?running_cpu
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) (TYPE%core!option.Option. $ USIZE)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?endpoint_descriptors
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. $ (TYPE%core!option.Option.
       $ USIZE
      ) $ (CONST_INT 128)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?ipc_payload
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?error_code
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
      )
     ) (TYPE%core!option.Option. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/error_code_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/?trap_frame
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
        x
      ))
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/trap_frame_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__IPCPayLoad_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__IPCPayLoad_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__IPCPayLoad_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__IPCPayLoad_unbox_axiom_definition
)))
(assert
 (forall ((_va! Int) (_len! Int)) (!
   (=>
    (and
     (uInv SZ _va!)
     (uInv SZ _len!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message
       _va! _len!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message _va! _len!)
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/?va x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/va_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/?len x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Message/len_invariant_definition
)))
(assert
 (forall ((_va_range! OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.))
  (!
   (=>
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. _va_range!)
     TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages
       _va_range!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages _va_range!)
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/?va_range
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range_invariant_definition
)))
(assert
 (forall ((_endpoint_index! Int)) (!
   (=>
    (uInv SZ _endpoint_index!)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint
       _endpoint_index!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint _endpoint_index!)
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/?endpoint_index
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Endpoint/endpoint_index_invariant_definition
)))
(assert
 (forall ((_bus! Int) (_dev! Int) (_fun! Int)) (!
   (=>
    (and
     (uInv 8 _bus!)
     (uInv 8 _dev!)
     (uInv 8 _fun!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci
       _bus! _dev! _fun!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci _bus! _dev!
       _fun!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus x) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/?bus
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (uInv 8 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus (
       %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/bus_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev x) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/?dev
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (uInv 8 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev (
       %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/dev_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun x) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/?fun
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (uInv 8 (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun (
       %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pci/fun_invariant_definition
)))
(assert
 (forall ((_vaddr! Int)) (!
   (=>
    (uInv SZ _vaddr!)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault
       _vaddr!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault _vaddr!)
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/?vaddr
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./PageFault/vaddr_invariant_definition
)))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Empty)
  TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ThreadState_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ThreadState_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ThreadState_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ThreadState_unbox_axiom_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.)) (!
   (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState. x)
    TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
   )
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
      x
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ThreadState_has_type_always_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ThreadState_has_type_always_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.))
  (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__EndpointState_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__EndpointState_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__EndpointState_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__EndpointState_unbox_axiom_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.))
  (!
   (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
     x
    ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
   )
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
      x
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!EndpointState.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__EndpointState_has_type_always_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__EndpointState_has_type_always_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__RetValueType_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__RetValueType_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__RetValueType_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__RetValueType_unbox_axiom_definition
)))
(assert
 (forall ((_value! Int)) (!
   (=>
    (uInv SZ _value!)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize _value!)
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize _value!)
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/?value
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessUsize/value_invariant_definition
)))
(assert
 (forall ((_value! vstd!seq.Seq<usize.>.)) (!
   (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
     (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize
      _value!
     )
    ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   )
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize
       _value!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize/value
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize/?value
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize/value
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize/value_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessSeqUsize/value_accessor_definition
)))
(assert
 (forall ((_value1! Int) (_value2! Int)) (!
   (=>
    (and
     (uInv SZ _value1!)
     (uInv SZ _value2!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize
       _value1! _value2!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize
       _value1! _value2!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/?value1
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value1_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/?value2
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessPairUsize/value2_invariant_definition
)))
(assert
 (forall ((_value1! Int) (_value2! Int) (_value3! Int)) (!
   (=>
    (and
     (uInv SZ _value1!)
     (uInv SZ _value2!)
     (uInv SZ _value3!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize
       _value1! _value2! _value3!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize
       _value1! _value2! _value3!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/?value1
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value1_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/?value2
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value2_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)) (
   !
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/?value3
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./SuccessThreeUsize/value3_invariant_definition
)))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./ErrorNoQuota
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./ErrorVaInUse
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./CpuIdle
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./Error
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./Else
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./NoQuota
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
))
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
   OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType./VaInUse
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!RetValueType.
))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.))
  (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
     (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode. x)
   ))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__DemandPagingMode_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__DemandPagingMode_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode. (
       %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode. x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__DemandPagingMode_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__DemandPagingMode_unbox_axiom_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.))
  (!
   (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
     x
    ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
   )
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
      x
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!DemandPagingMode.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__DemandPagingMode_has_type_always_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__DemandPagingMode_has_type_always_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.))
  (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption. (
      Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption. x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__TrapFrameOption_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__TrapFrameOption_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__TrapFrameOption_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__TrapFrameOption_unbox_axiom_definition
)))
(assert
 (forall ((_reg! OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.) (_exists!
    Bool
   )
  ) (!
   (=>
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. _reg!)
     TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption
       _reg! _exists!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption
       _reg! _exists!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/?reg
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.)
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption. x)
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/reg_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption.))
  (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/exists
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/?exists
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/exists
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/exists_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!TrapFrameOption./TrapFrameOption/exists_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Registers_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Registers_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Registers_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Registers_unbox_axiom_definition
)))
(assert
 (forall ((_r15! Int) (_r14! Int) (_r13! Int) (_r12! Int) (_rbp! Int) (_rbx! Int) (_r11!
    Int
   ) (_r10! Int) (_r9! Int) (_r8! Int) (_rcx! Int) (_rdx! Int) (_rsi! Int) (_rdi! Int)
   (_rax! Int) (_error_code! Int) (_rip! Int) (_cs! Int) (_flags! Int) (_rsp! Int) (
    _ss! Int
   )
  ) (!
   (=>
    (and
     (uInv 64 _r15!)
     (uInv 64 _r14!)
     (uInv 64 _r13!)
     (uInv 64 _r12!)
     (uInv 64 _rbp!)
     (uInv 64 _rbx!)
     (uInv 64 _r11!)
     (uInv 64 _r10!)
     (uInv 64 _r9!)
     (uInv 64 _r8!)
     (uInv 64 _rcx!)
     (uInv 64 _rdx!)
     (uInv 64 _rsi!)
     (uInv 64 _rdi!)
     (uInv 64 _rax!)
     (uInv 64 _error_code!)
     (uInv 64 _rip!)
     (uInv 64 _cs!)
     (uInv 64 _flags!)
     (uInv 64 _rsp!)
     (uInv 64 _ss!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers
       _r15! _r14! _r13! _r12! _rbp! _rbx! _r11! _r10! _r9! _r8! _rcx! _rdx! _rsi! _rdi!
       _rax! _error_code! _rip! _cs! _flags! _rsp! _ss!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers _r15! _r14!
       _r13! _r12! _rbp! _rbx! _r11! _r10! _r9! _r8! _rcx! _rdx! _rsi! _rdi! _rax! _error_code!
       _rip! _cs! _flags! _rsp! _ss!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r15 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r15_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r14 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r14_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r13 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r13_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r12 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r12_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rbp x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbp_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rbx x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rbx_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r11 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r11_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r10 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r10_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r9 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r9_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8 x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?r8 x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/r8_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rcx x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rcx_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rdx x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdx_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rsi x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsi_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rdi x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rdi_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rax x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rax_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?error_code
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/error_code_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rip x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rip_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?cs x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/cs_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?flags
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/flags_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?rsp x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/rsp_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/?ss x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
    (uInv 64 (OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Registers.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Registers./Registers/ss_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Array_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Array_box_axiom_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&. A&
      N&. N&
    ))
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
       x
   ))))
   :pattern ((has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
      A&. A& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Array_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Array_unbox_axiom_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (_seq! Poly) (_ar! %%Function%%))
  (!
   (=>
    (and
     (has_type _seq! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type (Poly%array%. _ar!) (ARRAY A&. A& N&. N&))
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array
       _seq! _ar!
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&. A& N&. N&)
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array _seq! _ar!)
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&. A& N&. N&)
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/?seq
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq_accessor_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&. A&
      N&. N&
    ))
    (has_type (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
       x
      )
     ) (TYPE%vstd!seq.Seq. A&. A&)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
      x
     )
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&.
      A& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/?ar
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar_accessor_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&. A&
      N&. N&
    ))
    (has_type (Poly%array%. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. x)
      )
     ) (ARRAY A&. A& N&. N&)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
      x
     )
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&.
      A& N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)) (!
   (=>
    (is-OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array x)
    (height_lt (height (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
       x
      )
     ) (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. x))
   ))
   :pattern ((height (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
      x
   )))
   :qid prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
   :skolemid skolem_prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)) (!
   (=>
    (is-OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array x)
    (height_lt (height (Poly%array%. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar
        x
      ))
     ) (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. x))
   ))
   :pattern ((height (Poly%array%. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar
       x
   ))))
   :qid prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar
   :skolemid skolem_prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/ar
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ArraySet_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ArraySet_box_axiom_definition
)))
(assert
 (forall ((N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. N&.
      N&
    ))
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
       x
   ))))
   :pattern ((has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
      N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ArraySet_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__ArraySet_unbox_axiom_definition
)))
(assert
 (forall ((N&. Dcr) (N& Type) (_data! OS__process_manager__spec_proof__impl2__endpoint_inv!Array.)
   (_len! Int) (_set! vstd!set.Set<usize.>.)
  ) (!
   (=>
    (and
     (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. _data!)
      (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. $ BOOL N&. N&)
     )
     (uInv SZ _len!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet
       _data! _len! _set!
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. N&. N&)
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet _data! _len!
       _set!
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. N&. N&)
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/?data x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data_accessor_definition
)))
(assert
 (forall ((N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. N&.
      N&
    ))
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. x)
      )
     ) (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. $ BOOL N&. N&)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
      N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/?len x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len_accessor_definition
)))
(assert
 (forall ((N&. Dcr) (N& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. N&.
      N&
    ))
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. x)
    ) (has_type x (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.
      N&. N&
   )))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/len_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/set x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/?set x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/set
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/set_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/set_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet.)) (!
   (=>
    (is-OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet x)
    (height_lt (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
       (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data x)
      )
     ) (height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. x))
   ))
   :pattern ((height (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data x)
   )))
   :qid prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data
   :skolemid skolem_prelude_datatype_height_OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet./ArraySet/data
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__VaRange4K_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__VaRange4K_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__VaRange4K_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__VaRange4K_unbox_axiom_definition
)))
(assert
 (forall ((_start! Int) (_len! Int) (_view! vstd!seq.Seq<usize.>.)) (!
   (=>
    (and
     (uInv SZ _start!)
     (uInv SZ _len!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K
       _start! _len! _view!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K _start!
       _len! _view!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/?start
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len x)
    (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/?len x)
   )
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/view
     x
    ) (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/?view
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/view
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/view_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/view_accessor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)) (!
   (= x (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
      x
   )))
   :pattern ((Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Quota_box_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Quota_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
    (= x (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
       x
   ))))
   :pattern ((has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Quota_unbox_axiom_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv__Quota_unbox_axiom_definition
)))
(assert
 (forall ((_mem_4k! Int) (_mem_2m! Int) (_mem_1g! Int) (_pcid! Int) (_ioid! Int)) (
   !
   (=>
    (and
     (uInv SZ _mem_4k!)
     (uInv SZ _mem_2m!)
     (uInv SZ _mem_1g!)
     (uInv SZ _pcid!)
     (uInv SZ _ioid!)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota
       _mem_4k! _mem_2m! _mem_1g! _pcid! _ioid!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
   ))
   :pattern ((has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
      (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota _mem_4k! _mem_2m!
       _mem_1g! _pcid! _ioid!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota_constructor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota_constructor_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?mem_4k
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_4k_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?mem_2m
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_2m_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?mem_1g
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g
     x
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x)
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g
     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x)
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/mem_1g_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?pcid
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
       x
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid (
      %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x
     )
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/pcid_invariant_definition
)))
(assert
 (forall ((x OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)) (!
   (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid x) (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/?ioid
     x
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid x))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid_accessor_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid_accessor_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.
       x
   ))))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid (
      %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota. x
     )
    ) (has_type x TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Quota.)
   )
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid_invariant_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!Quota./Quota/ioid_invariant_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (= x (%Poly%tuple%0. (Poly%tuple%0. x)))
   :pattern ((Poly%tuple%0. x))
   :qid internal_crate__tuple__0_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_box_axiom_definition
)))
(assert
 (forall ((x Poly)) (!
   (=>
    (has_type x TYPE%tuple%0.)
    (= x (Poly%tuple%0. (%Poly%tuple%0. x)))
   )
   :pattern ((has_type x TYPE%tuple%0.))
   :qid internal_crate__tuple__0_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__0_unbox_axiom_definition
)))
(assert
 (forall ((x tuple%0.)) (!
   (has_type (Poly%tuple%0. x) TYPE%tuple%0.)
   :pattern ((has_type (Poly%tuple%0. x) TYPE%tuple%0.))
   :qid internal_crate__tuple__0_has_type_always_definition
   :skolemid skolem_internal_crate__tuple__0_has_type_always_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= x (%Poly%tuple%2. (Poly%tuple%2. x)))
   :pattern ((Poly%tuple%2. x))
   :qid internal_crate__tuple__2_box_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_box_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (= x (Poly%tuple%2. (%Poly%tuple%2. x)))
   )
   :pattern ((has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__tuple__2_unbox_axiom_definition
   :skolemid skolem_internal_crate__tuple__2_unbox_axiom_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (_0! Poly) (_1! Poly)) (!
   (=>
    (and
     (has_type _0! T%0&)
     (has_type _1! T%1&)
    )
    (has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&. T%0& T%1&.
      T%1&
   )))
   :pattern ((has_type (Poly%tuple%2. (tuple%2./tuple%2 _0! _1!)) (TYPE%tuple%2. T%0&.
      T%0& T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2_constructor_definition
   :skolemid skolem_internal_tuple__2./tuple__2_constructor_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/0 x) (tuple%2./tuple%2/?0 x))
   :pattern ((tuple%2./tuple%2/0 x))
   :qid internal_tuple__2./tuple__2/0_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) T%0&)
   )
   :pattern ((tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/0_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/0_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (= (tuple%2./tuple%2/1 x) (tuple%2./tuple%2/?1 x))
   :pattern ((tuple%2./tuple%2/1 x))
   :qid internal_tuple__2./tuple__2/1_accessor_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_accessor_definition
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (x Poly)) (!
   (=>
    (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
    (has_type (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) T%1&)
   )
   :pattern ((tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (has_type x (TYPE%tuple%2. T%0&. T%0&
      T%1&. T%1&
   )))
   :qid internal_tuple__2./tuple__2/1_invariant_definition
   :skolemid skolem_internal_tuple__2./tuple__2/1_invariant_definition
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/0 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/0 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/0
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/0
)))
(assert
 (forall ((x tuple%2.)) (!
   (=>
    (is-tuple%2./tuple%2 x)
    (height_lt (height (tuple%2./tuple%2/1 x)) (height (Poly%tuple%2. x)))
   )
   :pattern ((height (tuple%2./tuple%2/1 x)))
   :qid prelude_datatype_height_tuple%2./tuple%2/1
   :skolemid skolem_prelude_datatype_height_tuple%2./tuple%2/1
)))
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type) (deep Bool) (x Poly) (y Poly))
  (!
   (=>
    (and
     (has_type x (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (has_type y (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
     (ext_eq deep T%0& (tuple%2./tuple%2/0 (%Poly%tuple%2. x)) (tuple%2./tuple%2/0 (%Poly%tuple%2.
        y
     )))
     (ext_eq deep T%1& (tuple%2./tuple%2/1 (%Poly%tuple%2. x)) (tuple%2./tuple%2/1 (%Poly%tuple%2.
        y
    ))))
    (ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y)
   )
   :pattern ((ext_eq deep (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&) x y))
   :qid internal_tuple__2./tuple__2_ext_equal_definition
   :skolemid skolem_internal_tuple__2./tuple__2_ext_equal_definition
)))
(declare-fun array_new (Dcr Type Int %%Function%%) Poly)
(declare-fun array_index (Dcr Type Dcr Type %%Function%% Poly) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (= (array_new Tdcr T N Fn) (Poly%array%. Fn))
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_array_new
   :skolemid skolem_prelude_array_new
)))
(declare-fun %%apply%%1 (%%Function%% Int) Poly)
(assert
 (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%)) (!
   (=>
    (forall ((i Int)) (!
      (=>
       (and
        (<= 0 i)
        (< i N)
       )
       (has_type (%%apply%%1 Fn i) T)
      )
      :pattern ((has_type (%%apply%%1 Fn i) T))
      :qid prelude_has_type_array_elts
      :skolemid skolem_prelude_has_type_array_elts
    ))
    (has_type (array_new Tdcr T N Fn) (ARRAY Tdcr T $ (CONST_INT N)))
   )
   :pattern ((array_new Tdcr T N Fn))
   :qid prelude_has_type_array_new
   :skolemid skolem_prelude_has_type_array_new
)))
(assert
 (forall ((Tdcr Dcr) (T Type) (Nd Dcr) (Ndcr Dcr) (N Type) (Fn %%Function%%) (i Poly))
  (!
   (=>
    (and
     (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr N))
     (has_type i INT)
    )
    (has_type (array_index Tdcr T Nd N Fn i) T)
   )
   :pattern ((array_index Tdcr T Nd N Fn i) (has_type (Poly%array%. Fn) (ARRAY Tdcr T Ndcr
      N
   )))
   :qid prelude_has_type_array_index
   :skolemid skolem_prelude_has_type_array_index
)))
(assert
 (!
  (forall ((Tdcr Dcr) (T Type) (N Int) (Fn %%Function%%) (i Int)) (!
    (= (array_index Tdcr T $ (CONST_INT N) Fn (I i)) (%%apply%%1 Fn i))
    :pattern ((array_new Tdcr T N Fn) (%%apply%%1 Fn i))
    :qid prelude_array_index_trigger
    :skolemid skolem_prelude_array_index_trigger
  ))
  :named
  prelude_axiom_array_index
))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&)
    (and
     (tr_bound%vstd!view.View. Self%&. Self%&)
     (and
      (= $ (proj%%vstd!view.View./V Self%&. Self%&))
      (= (TYPE%vstd!seq.Seq. T&. T&) (proj%vstd!view.View./V Self%&. Self%&))
     )
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__array__ArrayAdditionalSpecFns_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   (=>
    (tr_bound%vstd!view.View. Self%&. Self%&)
    (sized (proj%%vstd!view.View./V Self%&. Self%&))
   )
   :pattern ((tr_bound%vstd!view.View. Self%&. Self%&))
   :qid internal_vstd__view__View_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__view__View_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!marker.Tuple. Self%&. Self%&))
   :qid internal_core__marker__Tuple_trait_type_bounds_definition
   :skolemid skolem_internal_core__marker__Tuple_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
    (and
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (sized (proj%%core!ops.function.FnOnce./Output Self%&. Self%& Args&. Args&))
   ))
   :pattern ((tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnOnce_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnOnce_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnOnce. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__FnMut_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__FnMut_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (Args&. Dcr) (Args& Type)) (!
   (=>
    (tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&)
    (and
     (tr_bound%core!ops.function.FnMut. Self%&. Self%& Args&. Args&)
     (sized Args&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
   ))
   :pattern ((tr_bound%core!ops.function.Fn. Self%&. Self%& Args&. Args&))
   :qid internal_core__ops__function__Fn_trait_type_bounds_definition
   :skolemid skolem_internal_core__ops__function__Fn_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type)) (!
   true
   :pattern ((tr_bound%core!alloc.Allocator. Self%&. Self%&))
   :qid internal_core__alloc__Allocator_trait_type_bounds_definition
   :skolemid skolem_internal_core__alloc__Allocator_trait_type_bounds_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type)) (!
   (=>
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&)
    (and
     (sized Self%&.)
     (sized T&.)
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. Self%&. Self%& T&. T&))
   :qid internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
   :skolemid skolem_internal_vstd__std_specs__option__OptionAdditionalFns_trait_type_bounds_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (= (proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((proj%vstd!view.View./V $ (ARRAY T&. T& N&. N&)))
   :qid internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__array__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (REF A&.) A&) (proj%%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (REF A&.) A&) (proj%vstd!view.View./V A&. A&))
   )
   :pattern ((proj%vstd!view.View./V (REF A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__0_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (= (proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (= (proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&) (proj%vstd!view.View./V
      A&. A&
   )))
   :pattern ((proj%vstd!view.View./V (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__6_assoc_type_impl_false_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) $)
   )
   :pattern ((proj%%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_true_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (= (proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)) (TYPE%core!option.Option.
      T&. T&
   )))
   :pattern ((proj%vstd!view.View./V $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__14_assoc_type_impl_false_definition
)))
(assert
 (= (proj%%vstd!view.View./V $ TYPE%tuple%0.) $)
)
(assert
 (= (proj%vstd!view.View./V $ TYPE%tuple%0.) TYPE%tuple%0.)
)
(assert
 (= (proj%%vstd!view.View./V $ BOOL) $)
)
(assert
 (= (proj%vstd!view.View./V $ BOOL) BOOL)
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 8)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 8)) (UINT 8))
)
(assert
 (= (proj%%vstd!view.View./V $ (UINT 64)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (UINT 64)) (UINT 64))
)
(assert
 (= (proj%%vstd!view.View./V $ USIZE) $)
)
(assert
 (= (proj%vstd!view.View./V $ USIZE) USIZE)
)
(assert
 (= (proj%%vstd!view.View./V $ (SINT 32)) $)
)
(assert
 (= (proj%vstd!view.View./V $ (SINT 32)) (SINT 32))
)
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (DST (proj%%vstd!view.View./V
       A1&. A1&
   ))))
   :pattern ((proj%%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_true_definition
)))
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (= (proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)) (TYPE%tuple%2.
      (proj%%vstd!view.View./V A0&. A0&) (proj%vstd!view.View./V A0&. A0&) (proj%%vstd!view.View./V
       A1&. A1&
      ) (proj%vstd!view.View./V A1&. A1&)
   )))
   :pattern ((proj%vstd!view.View./V (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__vstd!view.View./V_vstd__view__impl&__48_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (REF F&.) F& A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__2_assoc_type_impl_false_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_true_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&) (proj%core!ops.function.FnOnce./Output
      F&. F& A&. A&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output $ (MUTREF F&. F&) A&. A&))
   :qid internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_core__ops__function__impls__impl&__4_assoc_type_impl_false_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
   :skolemid skolem_internal_proj____core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_true_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (= (proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&) (proj%core!ops.function.FnOnce./Output
      F&. F& Args&. Args&
   )))
   :pattern ((proj%core!ops.function.FnOnce./Output (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
   :skolemid skolem_internal_proj__core!ops.function.FnOnce./Output_alloc__boxed__impl&__31_assoc_type_impl_false_definition
)))
(declare-fun vstd!seq.Seq.len.? (Dcr Type Poly) Int)
(declare-fun vstd!seq.Seq.index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.impl&%2.spec_index.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq.Seq.new.? (Dcr Type Poly Poly) Poly)
(declare-fun vstd!seq_lib.impl&%0.to_set.? (Dcr Type Poly) Poly)
(declare-fun vstd!iset.ISet.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!set.impl&%0.to_iset.? (Dcr Type Poly) Poly)
(declare-fun vstd!set.Set.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!seq_lib.impl&%0.contains.? (Dcr Type Poly Poly) Bool)
(declare-fun vstd!map.impl&%0.dom.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!map.impl&%0.index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!map.impl&%0.spec_index.? (Dcr Type Dcr Type Poly Poly) Poly)
(declare-fun vstd!set.impl&%0.len.? (Dcr Type Poly) Int)
(declare-fun vstd!view.View.view.? (Dcr Type Poly) Poly)
(declare-fun vstd!view.View.view%default%.? (Dcr Type Poly) Poly)
(declare-fun vstd!array.array_view.? (Dcr Type Dcr Type Poly) Poly)
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index.? (Dcr Type Dcr Type Poly
  Poly
 ) Poly
)
(declare-fun vstd!array.ArrayAdditionalSpecFns.spec_index%default%.? (Dcr Type Dcr
  Type Poly Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_Some.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_Some%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_None.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.is_None%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0.? (Dcr Type Dcr Type
  Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.OptionAdditionalFns.arrow_0%default%.? (Dcr Type
  Dcr Type Poly
 ) Poly
)
(declare-fun vstd!std_specs.option.spec_unwrap.? (Dcr Type Poly) Poly)
(declare-fun vstd!simple_pptr.impl&%1.addr.? (Dcr Type Poly) Int)
(declare-fun vstd!simple_pptr.impl&%1.mem_contents.? (Dcr Type Poly) vstd!raw_ptr.MemContents.)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? (Dcr
  Type Dcr Type Poly
 ) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.? (
  Dcr Type Dcr Type Poly
 ) Poly
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.?
 (Dcr Type Dcr Type Poly) Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.?
 (Dcr Type Dcr Type Poly Poly) Int
)
(declare-fun vstd!raw_ptr.impl&%6.is_init.? (Dcr Type Poly) Bool)
(declare-fun vstd!simple_pptr.impl&%1.is_init.? (Dcr Type Poly) Bool)
(declare-fun vstd!raw_ptr.impl&%1.arrow_0.? (Dcr Type Poly) Poly)
(declare-fun vstd!raw_ptr.impl&%6.value.? (Dcr Type Poly) Poly)
(declare-fun vstd!simple_pptr.impl&%1.value.? (Dcr Type Poly) Poly)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.?
 (Dcr Type Dcr Type Poly) Bool
)
(declare-fun vstd!seq_lib.impl&%0.no_duplicates.? (Dcr Type Poly) Bool)
(declare-fun vstd!set.impl&%0.finite.? (Dcr Type Poly) Bool)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.container_dom.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.?
 (Poly Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.proc_dom.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.?
 (Poly Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.? (Dcr
  Type Dcr Type Poly
 ) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.?
 (Poly) core!option.Option.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK.? ()
 Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.?
 () Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.view.?
 (Poly) vstd!seq.Seq<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.view_match_spec.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.? (Poly)
 Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%39.wf.? (Dcr
  Type Poly
 ) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.?
 (Dcr Type Dcr Type Poly) Poly
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.? () Int)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%39.view.?
 (Dcr Type Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.?
 (Dcr Type Dcr Type Poly Poly) Poly
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.?
 (Poly) Bool
)
(declare-fun vstd!set.impl&%0.disjoint.? (Dcr Type Poly Poly) Bool)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.?
 (Poly) Bool
)
(declare-fun vstd!set.Set.subset_of.? (Dcr Type Poly Poly) Bool)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.?
 () Int
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.thread_dom.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.?
 (Poly Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_root_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_childern_parent_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!containers_linkedlist_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_childern_depth_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_subtree_set_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_uppertree_seq_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_subtree_set_exclusive.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_root_wf.? (
  Poly Poly Poly
 ) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_childern_parent_wf.?
 (Poly Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!procs_linkedlist_wf.?
 (Poly Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_childern_depth_wf.?
 (Poly Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_subtree_set_wf.?
 (Poly Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_uppertree_seq_wf.?
 (Poly Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_subtree_set_exclusive.?
 (Poly Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.? (
  Poly Poly Poly
 ) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.?
 (Poly Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.?
 (Poly) Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.? (Poly)
 Bool
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.endpoint_dom.?
 (Poly) vstd!set.Set<usize.>.
)
(declare-fun OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.?
 (Poly Poly) OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (<= 0 (vstd!seq.Seq.len.? A&. A& self!))
   )
   :pattern ((vstd!seq.Seq.len.? A&. A& self!))
   :qid internal_vstd!seq.Seq.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.len.?_pre_post_definition
)))
(declare-fun req%vstd!seq.Seq.index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%0 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.Seq.index. A&. A& self! i!) (=>
     %%global_location_label%%0
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.Seq.index. A&. A& self! i!))
   :qid internal_req__vstd!seq.Seq.index._definition
   :skolemid skolem_internal_req__vstd!seq.Seq.index._definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.Seq.index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.Seq.index.? A&. A& self! i!))
   :qid internal_vstd!seq.Seq.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.index.?_pre_post_definition
)))
(declare-fun req%vstd!seq.impl&%2.spec_index. (Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%1 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (= (req%vstd!seq.impl&%2.spec_index. A&. A& self! i!) (=>
     %%global_location_label%%1
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!seq.impl&%2.spec_index. A&. A& self! i!))
   :qid internal_req__vstd!seq.impl&__2.spec_index._definition
   :skolemid skolem_internal_req__vstd!seq.impl&__2.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!seq.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq.impl&%2.spec_index.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
    (= (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) (vstd!seq.Seq.index.? A&. A& self!
      i!
    ))
    :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
    :qid internal_vstd!seq.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (has_type i! INT)
    )
    (has_type (vstd!seq.impl&%2.spec_index.? A&. A& self! i!) A&)
   )
   :pattern ((vstd!seq.impl&%2.spec_index.? A&. A& self! i!))
   :qid internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.impl&__2.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_index_decreases.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? A&. A& s! i!)) (height s!))
    ))
    :pattern ((height (vstd!seq.Seq.index.? A&. A& s! i!)))
    :qid user_vstd__seq__lemma_seq_index_decreases_0
    :skolemid skolem_user_vstd__seq__lemma_seq_index_decreases_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
   (=>
    (and
     (has_type len! NAT)
     (has_type f! (TYPE%fun%1. $ INT A&. A&))
    )
    (has_type (vstd!seq.Seq.new.? A&. A& len! f!) (TYPE%vstd!seq.Seq. A&. A&))
   )
   :pattern ((vstd!seq.Seq.new.? A&. A& len! f!))
   :qid internal_vstd!seq.Seq.new.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq.Seq.new.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_len.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
     )
     (=>
      (sized A&.)
      (= (vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)) (%I len!))
    ))
    :pattern ((vstd!seq.Seq.len.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!)))
    :qid user_vstd__seq__lemma_seq_new_len_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_new_index.)
  (forall ((A&. Dcr) (A& Type) (len! Poly) (f! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type len! NAT)
      (has_type f! (TYPE%fun%1. $ INT A&. A&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized A&.)
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (%I len!)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!) (%%apply%%0
        (%Poly%fun%1. f!) i!
    ))))
    :pattern ((vstd!seq.Seq.index.? A&. A& (vstd!seq.Seq.new.? A&. A& len! f!) i!))
    :qid user_vstd__seq__lemma_seq_new_index_0
    :skolemid skolem_user_vstd__seq__lemma_seq_new_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (= (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2! i$))
          ))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq.lemma_seq_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!seq.Seq. A&. A&))
      (has_type s2! (TYPE%vstd!seq.Seq. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!) (and
        (= (vstd!seq.Seq.len.? A&. A& s1!) (vstd!seq.Seq.len.? A&. A& s2!))
        (forall ((i$ Poly)) (!
          (=>
           (has_type i$ INT)
           (=>
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& s1!)))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
            ))))
            (ext_eq true A& (vstd!seq.Seq.index.? A&. A& s1! i$) (vstd!seq.Seq.index.? A&. A& s2!
              i$
          ))))
          :pattern ((vstd!seq.Seq.index.? A&. A& s1! i$))
          :pattern ((vstd!seq.Seq.index.? A&. A& s2! i$))
          :qid user_vstd__seq__lemma_seq_ext_equal_deep_0
          :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!seq.Seq. A&. A&) s1! s2!))
    :qid user_vstd__seq__lemma_seq_ext_equal_deep_1
    :skolemid skolem_user_vstd__seq__lemma_seq_ext_equal_deep_1
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
    (has_type (vstd!seq_lib.impl&%0.to_set.? A&. A& self!) (TYPE%vstd!set.Set. A&. A&))
   )
   :pattern ((vstd!seq_lib.impl&%0.to_set.? A&. A& self!))
   :qid internal_vstd!seq_lib.impl&__0.to_set.?_pre_post_definition
   :skolemid skolem_internal_vstd!seq_lib.impl&__0.to_set.?_pre_post_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (has_type (vstd!set.impl&%0.to_iset.? A&. A& self!) (TYPE%vstd!iset.ISet. A&. A&))
   )
   :pattern ((vstd!set.impl&%0.to_iset.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.to_iset.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!set.Set.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (a! Poly)) (!
    (= (vstd!set.Set.contains.? A&. A& self! a!) (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.?
       A&. A& self!
      ) a!
    ))
    :pattern ((vstd!set.Set.contains.? A&. A& self! a!))
    :qid internal_vstd!set.Set.contains.?_definition
    :skolemid skolem_internal_vstd!set.Set.contains.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.contains.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.contains.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (needle! Poly)) (!
    (= (vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!) (exists ((i$ Poly)) (!
       (and
        (has_type i$ INT)
        (and
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
         ))))
         (= (vstd!seq.Seq.index.? A&. A& self! i$) needle!)
       ))
       :pattern ((vstd!seq.Seq.index.? A&. A& self! i$))
       :qid user_vstd__seq_lib__impl&%0__contains_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__contains_0
    )))
    :pattern ((vstd!seq_lib.impl&%0.contains.? A&. A& self! needle!))
    :qid internal_vstd!seq_lib.impl&__0.contains.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.contains.?_definition
))))
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.to_set_ensures.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (has_type self! (TYPE%vstd!seq.Seq. A&. A&))
     (=>
      (sized A&.)
      (and
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
              A&. A& self!
             )
            ) (vstd!seq.Seq.index.? A&. A& self! i$)
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
             A&. A& self!
            )
           ) (vstd!seq.Seq.index.? A&. A& self! i$)
         ))
         :qid user_vstd__seq_lib__impl&%0__to_set_ensures_0
         :skolemid skolem_user_vstd__seq_lib__impl&%0__to_set_ensures_0
       ))
       (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
              A&. A& self!
             )
            ) a$
           ) (vstd!seq_lib.impl&%0.contains.? A&. A& self! a$)
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& (vstd!seq_lib.impl&%0.to_set.?
             A&. A& self!
            )
           ) a$
         ))
         :qid user_vstd__seq_lib__impl&%0__to_set_ensures_1
         :skolemid skolem_user_vstd__seq_lib__impl&%0__to_set_ensures_1
    )))))
    :pattern ((vstd!seq_lib.impl&%0.to_set.? A&. A& self!))
    :qid user_vstd__seq_lib__impl&%0__to_set_ensures_2
    :skolemid skolem_user_vstd__seq_lib__impl&%0__to_set_ensures_2
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
    (has_type (vstd!map.impl&%0.dom.? K&. K& V&. V& self!) (TYPE%vstd!set.Set. K&. K&))
   )
   :pattern ((vstd!map.impl&%0.dom.? K&. K& V&. V& self!))
   :qid internal_vstd!map.impl&__0.dom.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.dom.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%2 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%2
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.index._definition
)))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.index.?_pre_post_definition
)))
(declare-fun req%vstd!map.impl&%0.spec_index. (Dcr Type Dcr Type Poly Poly) Bool)
(declare-const %%global_location_label%%3 Bool)
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (= (req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!) (=>
     %%global_location_label%%3
     (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
        K&. K& V&. V& self!
       )
      ) key!
   )))
   :pattern ((req%vstd!map.impl&%0.spec_index. K&. K& V&. V& self! key!))
   :qid internal_req__vstd!map.impl&__0.spec_index._definition
   :skolemid skolem_internal_req__vstd!map.impl&__0.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%vstd!map.impl&%0.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!map.impl&%0.spec_index.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
    (= (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) (vstd!map.impl&%0.index.?
      K&. K& V&. V& self! key!
    ))
    :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
    :qid internal_vstd!map.impl&__0.spec_index.?_definition
    :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_definition
))))
(assert
 (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (self! Poly) (key! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%vstd!map.Map. K&. K& V&. V&))
     (has_type key! K&)
    )
    (has_type (vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!) V&)
   )
   :pattern ((vstd!map.impl&%0.spec_index.? K&. K& V&. V& self! key!))
   :qid internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!map.impl&__0.spec_index.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_index_decreases.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)) (height m!))
    ))
    :pattern ((height (vstd!map.impl&%0.index.? K&. K& V&. V& m! key!)))
    :qid user_vstd__map__axiom_map_index_decreases_0
    :skolemid skolem_user_vstd__map__axiom_map_index_decreases_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_decreases_to_entry.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m! Poly) (key! Poly)) (!
    (=>
     (and
      (has_type m! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type key! K&)
     )
     (=>
      (and
       (and
        (sized K&.)
        (sized V&.)
       )
       (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
          K&. K& V&. V& m!
         )
        ) key!
      ))
      (height_lt (height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
           K& V&. V& m! key!
        )))
       ) (height m!)
    )))
    :pattern ((height (Poly%tuple%2. (tuple%2./tuple%2 key! (vstd!map.impl&%0.index.? K&.
         K& V&. V& m! key!
    )))))
    :qid user_vstd__map__axiom_map_decreases_to_entry_0
    :skolemid skolem_user_vstd__map__axiom_map_decreases_to_entry_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq false (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (= (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.? K&. K&
              V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_0
    ))))))
    :pattern ((ext_eq false (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!map.axiom_map_ext_equal_deep.)
  (forall ((K&. Dcr) (K& Type) (V&. Dcr) (V& Type) (m1! Poly) (m2! Poly)) (!
    (=>
     (and
      (has_type m1! (TYPE%vstd!map.Map. K&. K& V&. V&))
      (has_type m2! (TYPE%vstd!map.Map. K&. K& V&. V&))
     )
     (=>
      (and
       (sized K&.)
       (sized V&.)
      )
      (= (ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!) (and
        (ext_eq true (TYPE%vstd!set.Set. K&. K&) (vstd!map.impl&%0.dom.? K&. K& V&. V& m1!)
         (vstd!map.impl&%0.dom.? K&. K& V&. V& m2!)
        )
        (forall ((k$ Poly)) (!
          (=>
           (has_type k$ K&)
           (=>
            (vstd!iset.ISet.contains.? K&. K& (vstd!set.impl&%0.to_iset.? K&. K& (vstd!map.impl&%0.dom.?
               K&. K& V&. V& m1!
              )
             ) k$
            )
            (ext_eq true V& (vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$) (vstd!map.impl&%0.index.?
              K&. K& V&. V& m2! k$
          ))))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m1! k$))
          :pattern ((vstd!map.impl&%0.index.? K&. K& V&. V& m2! k$))
          :qid user_vstd__map__axiom_map_ext_equal_deep_0
          :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_0
    ))))))
    :pattern ((ext_eq true (TYPE%vstd!map.Map. K&. K& V&. V&) m1! m2!))
    :qid user_vstd__map__axiom_map_ext_equal_deep_1
    :skolemid skolem_user_vstd__map__axiom_map_ext_equal_deep_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!) a$) (
            vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s1!)
           a$
         ))
         :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
           a$
         ))
         :qid user_vstd__set__axiom_set_ext_equal_0
         :skolemid skolem_user_vstd__set__axiom_set_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_1
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!set.Set. A&. A&))
      (has_type s2! (TYPE%vstd!set.Set. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!set.Set.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!set.Set. A&. A&) s1! s2!))
    :qid user_vstd__set__axiom_set_ext_equal_deep_0
    :skolemid skolem_user_vstd__set__axiom_set_ext_equal_deep_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!set.axiom_set_decreases_to_member.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (height_lt (height a!) (height s!))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (height a!)
    )
    :qid user_vstd__set__axiom_set_decreases_to_member_0
    :skolemid skolem_user_vstd__set__axiom_set_decreases_to_member_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!set.Set. A&. A&))
    (<= 0 (vstd!set.impl&%0.len.? A&. A& self!))
   )
   :pattern ((vstd!set.impl&%0.len.? A&. A& self!))
   :qid internal_vstd!set.impl&__0.len.?_pre_post_definition
   :skolemid skolem_internal_vstd!set.impl&__0.len.?_pre_post_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!set.lemma_set_contains_len.)
  (forall ((A&. Dcr) (A& Type) (s! Poly) (a! Poly)) (!
    (=>
     (and
      (has_type s! (TYPE%vstd!set.Set. A&. A&))
      (has_type a! A&)
     )
     (=>
      (and
       (sized A&.)
       (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!) a!)
      )
      (not (= (vstd!set.impl&%0.len.? A&. A& s!) 0))
    ))
    :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s!)
      a!
     ) (vstd!set.impl&%0.len.? A&. A& s!)
    )
    :qid user_vstd__set__lemma_set_contains_len_0
    :skolemid skolem_user_vstd__set__lemma_set_contains_len_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (forall ((a$ Poly)) (!
         (=>
          (has_type a$ A&)
          (= (vstd!iset.ISet.contains.? A&. A& s1! a$) (vstd!iset.ISet.contains.? A&. A& s2!
            a$
         )))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s1! a$))
         :pattern ((vstd!iset.ISet.contains.? A&. A& s2! a$))
         :qid user_vstd__iset__lemma_iset_ext_equal_0
         :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_0
    )))))
    :pattern ((ext_eq false (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_1
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!iset.lemma_iset_ext_equal_deep.)
  (forall ((A&. Dcr) (A& Type) (s1! Poly) (s2! Poly)) (!
    (=>
     (and
      (has_type s1! (TYPE%vstd!iset.ISet. A&. A&))
      (has_type s2! (TYPE%vstd!iset.ISet. A&. A&))
     )
     (=>
      (sized A&.)
      (= (ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!) (ext_eq false (TYPE%vstd!iset.ISet.
         A&. A&
        ) s1! s2!
    ))))
    :pattern ((ext_eq true (TYPE%vstd!iset.ISet. A&. A&) s1! s2!))
    :qid user_vstd__iset__lemma_iset_ext_equal_deep_0
    :skolemid skolem_user_vstd__iset__lemma_iset_ext_equal_deep_0
))))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__4_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__4_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_requires.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly)) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_req F& Args&. Args& (mut_ref_current% f!) args!)
      )
      (closure_req (MUTREF F&. F&) Args&. Args& f! args!)
    ))
    :pattern ((closure_req (MUTREF F&. F&) Args&. Args& f! args!))
    :qid user_vstd__function__axiom_fn_mut_call_requires_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_requires_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!function.axiom_fn_mut_call_ensures.)
  (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (f! Poly) (args! Poly) (output!
     Poly
    )
   ) (!
    (=>
     (and
      (has_type f! (MUTREF F&. F&))
      (has_type args! Args&)
      (has_type output! (proj%core!ops.function.FnOnce./Output F&. F& Args&. Args&))
     )
     (=>
      (and
       (and
        (and
         (and
          (sized Args&.)
          (sized F&.)
         )
         (tr_bound%core!marker.Tuple. Args&. Args&)
        )
        (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
       )
       (closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!)
      )
      (and
       (closure_ens F& Args&. Args& (mut_ref_current% f!) args! output!)
       (= (mut_ref_current% f!) (mut_ref_future% f!))
    )))
    :pattern ((closure_ens (MUTREF F&. F&) Args&. Args& f! args! output!))
    :qid user_vstd__function__axiom_fn_mut_call_ensures_0
    :skolemid skolem_user_vstd__function__axiom_fn_mut_call_ensures_0
))))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!view.View.view.? Self%&. Self%& self!) (proj%vstd!view.View./V Self%&.
      Self%&
   )))
   :pattern ((vstd!view.View.view.? Self%&. Self%& self!))
   :qid internal_vstd!view.View.view.?_pre_post_definition
   :skolemid skolem_internal_vstd!view.View.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.array_view.)
)
(declare-fun %%lambda%%0 (Dcr Type Dcr Type %%Function%%) %%Function%%)
(assert
 (forall ((%%hole%%0 Dcr) (%%hole%%1 Type) (%%hole%%2 Dcr) (%%hole%%3 Type) (%%hole%%4
    %%Function%%
   ) (i$ Poly)
  ) (!
   (= (%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4) i$)
    (array_index %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4 i$)
   )
   :pattern ((%%apply%%0 (%%lambda%%0 %%hole%%0 %%hole%%1 %%hole%%2 %%hole%%3 %%hole%%4)
     i$
)))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (= (vstd!array.array_view.? T&. T& N&. N& a!) (vstd!seq.Seq.new.? T&. T& (I (const_int
        N&
       )
      ) (Poly%fun%1. (mk_fun (%%lambda%%0 T&. T& N&. N& (%Poly%array%. a!))))
    ))
    :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
    :qid internal_vstd!array.array_view.?_definition
    :skolemid skolem_internal_vstd!array.array_view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
   (=>
    (has_type a! (ARRAY T&. T& N&. N&))
    (has_type (vstd!array.array_view.? T&. T& N&. N& a!) (TYPE%vstd!seq.Seq. T&. T&))
   )
   :pattern ((vstd!array.array_view.? T&. T& N&. N& a!))
   :qid internal_vstd!array.array_view.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.array_view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%0.view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!) (vstd!array.array_view.? T&.
       T& N&. N& self!
    )))
    :pattern ((vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!))
    :qid internal_vstd!array.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!array.impl&__0.view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (ARRAY T&. T& N&. N&)))
   :qid internal_vstd__array__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__0_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!array.array_len_matches_n.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (ar! Poly)) (!
    (=>
     (has_type ar! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) ar!))
       (const_int N&)
    )))
    :pattern ((vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
       ar!
    )))
    :qid user_vstd__array__array_len_matches_n_0
    :skolemid skolem_user_vstd__array__array_len_matches_n_0
))))
(declare-fun req%vstd!array.ArrayAdditionalSpecFns.spec_index. (Dcr Type Dcr Type Poly
  Poly
 ) Bool
)
(declare-const %%global_location_label%%4 Bool)
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (= (req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T& self! i!)
    (=>
     %%global_location_label%%4
     (let
      ((tmp%%$ 0))
      (let
       ((tmp%%$1 (%I i!)))
       (let
        ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? Self%&. Self%& self!))))
        (and
         (<= tmp%%$ tmp%%$1)
         (< tmp%%$1 tmp%%$2)
   ))))))
   :pattern ((req%vstd!array.ArrayAdditionalSpecFns.spec_index. Self%&. Self%& T&. T&
     self! i!
   ))
   :qid internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
   :skolemid skolem_internal_req__vstd!array.ArrayAdditionalSpecFns.spec_index._definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly) (i! Poly)) (
   !
   (=>
    (and
     (has_type self! Self%&)
     (has_type i! INT)
    )
    (has_type (vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
      i!
     ) T&
   ))
   :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? Self%&. Self%& T&. T& self!
     i!
   ))
   :qid internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
   :skolemid skolem_internal_vstd!array.ArrayAdditionalSpecFns.spec_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!array.impl&%2.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!array.impl&%2.spec_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (i! Poly)) (!
    (=>
     (and
      (sized T&.)
      (uInv SZ (const_int N&))
     )
     (= (vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&. T& self!
       i!
      ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) self!)
       i!
    )))
    :pattern ((vstd!array.ArrayAdditionalSpecFns.spec_index.? $ (ARRAY T&. T& N&. N&) T&.
      T& self! i!
    ))
    :qid internal_vstd!array.impl&__2.spec_index.?_definition
    :skolemid skolem_internal_vstd!array.impl&__2.spec_index.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type)) (!
   (=>
    (and
     (sized T&.)
     (uInv SZ (const_int N&))
    )
    (tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&. T&)
   )
   :pattern ((tr_bound%vstd!array.ArrayAdditionalSpecFns. $ (ARRAY T&. T& N&. N&) T&.
     T&
   ))
   :qid internal_vstd__array__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__array__impl&__2_trait_impl_definition
)))
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)
        i!
       ) (vstd!seq.Seq.index.? T&. T& (vstd!array.array_view.? T&. T& N&. N& a!) i!)
    )))
    :pattern ((array_index T&. T& N&. N& (%Poly%array%. a!) i!))
    :qid user_vstd__array__lemma_array_index_0
    :skolemid skolem_user_vstd__array__lemma_array_index_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_ext_equal.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a1! Poly) (a2! Poly)) (!
    (=>
     (and
      (has_type a1! (ARRAY T&. T& N&. N&))
      (has_type a2! (ARRAY T&. T& N&. N&))
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (= (ext_eq false (ARRAY T&. T& N&. N&) a1! a2!) (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (const_int N&)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a1!)
             i$
            ) (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a2!)
             i$
         ))))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a1!
           ) i$
         ))
         :pattern ((vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&)
            a2!
           ) i$
         ))
         :qid user_vstd__array__axiom_array_ext_equal_0
         :skolemid skolem_user_vstd__array__axiom_array_ext_equal_0
    )))))
    :pattern ((ext_eq false (ARRAY T&. T& N&. N&) a1! a2!))
    :qid user_vstd__array__axiom_array_ext_equal_1
    :skolemid skolem_user_vstd__array__axiom_array_ext_equal_1
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_has_resolved.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (array! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type array! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (=>
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (const_int N&)))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
       ))))
       (=>
        (has_resolved $ (ARRAY T&. T& N&. N&) array!)
        (has_resolved T&. T& (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&.
            T& N&. N&
           ) array!
          ) i!
    ))))))
    :pattern ((has_resolved $ (ARRAY T&. T& N&. N&) array!) (vstd!seq.Seq.index.? T&. T&
      (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) array!) i!
    ))
    :qid user_vstd__array__axiom_array_has_resolved_0
    :skolemid skolem_user_vstd__array__axiom_array_has_resolved_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.axiom_array_decreases_to_seq.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly)) (!
    (=>
     (has_type a! (ARRAY T&. T& N&. N&))
     (=>
      (and
       (sized T&.)
       (uInv SZ (const_int N&))
      )
      (height_lt (height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)) (height a!))
    ))
    :pattern ((height (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!)))
    :qid user_vstd__array__axiom_array_decreases_to_seq_0
    :skolemid skolem_user_vstd__array__axiom_array_decreases_to_seq_0
))))
(assert
 (=>
  (fuel_bool fuel%vstd!array.lemma_array_index_decreases.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (a! Poly) (i! Poly)) (!
    (=>
     (and
      (has_type a! (ARRAY T&. T& N&. N&))
      (has_type i! INT)
     )
     (=>
      (and
       (and
        (sized T&.)
        (uInv SZ (const_int N&))
       )
       (let
        ((tmp%%$ 0))
        (let
         ((tmp%%$1 (%I i!)))
         (let
          ((tmp%%$2 (vstd!seq.Seq.len.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T& N&. N&) a!))))
          (and
           (<= tmp%%$ tmp%%$1)
           (< tmp%%$1 tmp%%$2)
      )))))
      (height_lt (height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
           N&. N&
          ) a!
         ) i!
        )
       ) (height a!)
    )))
    :pattern ((height (vstd!seq.Seq.index.? T&. T& (vstd!view.View.view.? $ (ARRAY T&. T&
         N&. N&
        ) a!
       ) i!
    )))
    :qid user_vstd__array__lemma_array_index_decreases_0
    :skolemid skolem_user_vstd__array__lemma_array_index_decreases_0
))))
(assert
 (tr_bound%core!marker.Tuple. $ TYPE%tuple%0.)
)
(assert
 (forall ((T%0&. Dcr) (T%0& Type) (T%1&. Dcr) (T%1& Type)) (!
   (tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&))
   :pattern ((tr_bound%core!marker.Tuple. (DST T%1&.) (TYPE%tuple%2. T%0&. T%0& T%1&. T%1&)))
   :qid internal_crate__impl_tuple&__Tuple2_trait_impl_definition
   :skolemid skolem_internal_crate__impl_tuple&__Tuple2_trait_impl_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.is_Some.? Self%&. Self%& T&. T&
      self!
     ) BOOL
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_Some.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.is_Some.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.is_Some.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.is_None.? Self%&. Self%& T&. T&
      self!
     ) BOOL
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_None.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.is_None.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.is_None.?_pre_post_definition
)))
(assert
 (forall ((Self%&. Dcr) (Self%& Type) (T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! Self%&)
    (has_type (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
      self!
     ) T&
   ))
   :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? Self%&. Self%& T&. T&
     self!
   ))
   :qid internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.OptionAdditionalFns.arrow_0.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.arrow_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.arrow_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (core!option.Option./Some/0 T&. T& (%Poly%core!option.Option. self!))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.arrow_0.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.arrow_0.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.is_Some.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.is_Some.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.is_Some.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (B (is-core!option.Option./Some (%Poly%core!option.Option. self!)))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_Some.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.is_Some.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.is_Some.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.impl&%0.is_None.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.impl&%0.is_None.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!std_specs.option.OptionAdditionalFns.is_None.? $ (TYPE%core!option.Option.
        T&. T&
       ) T&. T& self!
      ) (B (is-core!option.Option./None (%Poly%core!option.Option. self!)))
    ))
    :pattern ((vstd!std_specs.option.OptionAdditionalFns.is_None.? $ (TYPE%core!option.Option.
       T&. T&
      ) T&. T& self!
    ))
    :qid internal_vstd!std_specs.option.impl&__0.is_None.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.impl&__0.is_None.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option. T&.
      T&
     ) T&. T&
   ))
   :pattern ((tr_bound%vstd!std_specs.option.OptionAdditionalFns. $ (TYPE%core!option.Option.
      T&. T&
     ) T&. T&
   ))
   :qid internal_vstd__std_specs__option__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__std_specs__option__impl&__0_trait_impl_definition
)))
(declare-fun req%vstd!std_specs.option.spec_unwrap. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%5 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (= (req%vstd!std_specs.option.spec_unwrap. T&. T& option!) (=>
     %%global_location_label%%5
     (is-core!option.Option./Some (%Poly%core!option.Option. option!))
   ))
   :pattern ((req%vstd!std_specs.option.spec_unwrap. T&. T& option!))
   :qid internal_req__vstd!std_specs.option.spec_unwrap._definition
   :skolemid skolem_internal_req__vstd!std_specs.option.spec_unwrap._definition
)))
(assert
 (fuel_bool_default fuel%vstd!std_specs.option.spec_unwrap.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!std_specs.option.spec_unwrap.)
  (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
    (= (vstd!std_specs.option.spec_unwrap.? T&. T& option!) (core!option.Option./Some/0
      T&. T& (%Poly%core!option.Option. option!)
    ))
    :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
    :qid internal_vstd!std_specs.option.spec_unwrap.?_definition
    :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (option! Poly)) (!
   (=>
    (has_type option! (TYPE%core!option.Option. T&. T&))
    (has_type (vstd!std_specs.option.spec_unwrap.? T&. T& option!) T&)
   )
   :pattern ((vstd!std_specs.option.spec_unwrap.? T&. T& option!))
   :qid internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
   :skolemid skolem_internal_vstd!std_specs.option.spec_unwrap.?_pre_post_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (uInv SZ (vstd!simple_pptr.impl&%1.addr.? V&. V& self!))
   )
   :pattern ((vstd!simple_pptr.impl&%1.addr.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.addr.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.addr.?_pre_post_definition
)))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (has_type (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? V&.
       V& self!
      )
     ) (TYPE%vstd!raw_ptr.MemContents. V&. V&)
   ))
   :pattern ((vstd!simple_pptr.impl&%1.mem_contents.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.mem_contents.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.mem_contents.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.? T&. T& N&.
      N& self!
     ) (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. self!)
    ))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.? T&.
      T& N&. N& self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.view.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.view.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (has_type (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.? T&.
      T& N&. N& self!
     ) (TYPE%vstd!seq.Seq. T&. T&)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.? T&.
     T& N&. N& self!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.view.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.? T&. T&
      N&. N& self!
     ) (uClip SZ (vstd!seq.Seq.len.? T&. T& (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
        T&. T& N&. N& self!
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.?
      T&. T& N&. N& self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.spec_len.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.spec_len.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
      T&. T& N&. N&
    ))
    (uInv SZ (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.? T&.
      T& N&. N& self!
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.?
     T&. T& N&. N& self!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.spec_len.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.spec_len.?_pre_post_definition
)))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%6 Bool)
(declare-const %%global_location_label%%7 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (v! Poly)) (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.
     T&. T& N&. N& self! v!
    ) (and
     (=>
      %%global_location_label%%6
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? T&. T& N&. N& self!)
     )
     (=>
      %%global_location_label%%7
      (vstd!seq_lib.impl&%0.contains.? T&. T& (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
        T&. T& N&. N& self!
       ) v!
   ))))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.
     T&. T& N&. N& self! v!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.get_node_ref._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.get_node_ref._definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly) (v! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
       T&. T& N&. N&
     ))
     (has_type v! T&)
    )
    (iInv 32 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.?
      T&. T& N&. N& self! v!
   )))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.?
     T&. T& N&. N& self! v!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.get_node_ref.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.get_node_ref.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%6.is_init.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%6.is_init.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!raw_ptr.impl&%6.is_init.? T&. T& self!) (is-vstd!raw_ptr.MemContents./Init
      (%Poly%vstd!raw_ptr.MemContents. self!)
    ))
    :pattern ((vstd!raw_ptr.impl&%6.is_init.? T&. T& self!))
    :qid internal_vstd!raw_ptr.impl&__6.is_init.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__6.is_init.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!simple_pptr.impl&%1.is_init.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!simple_pptr.impl&%1.is_init.)
  (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
    (= (vstd!simple_pptr.impl&%1.is_init.? V&. V& self!) (is-vstd!raw_ptr.MemContents./Init
      (vstd!simple_pptr.impl&%1.mem_contents.? V&. V& self!)
    ))
    :pattern ((vstd!simple_pptr.impl&%1.is_init.? V&. V& self!))
    :qid internal_vstd!simple_pptr.impl&__1.is_init.?_definition
    :skolemid skolem_internal_vstd!simple_pptr.impl&__1.is_init.?_definition
))))
(declare-fun req%vstd!raw_ptr.impl&%1.arrow_0. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%8 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (= (req%vstd!raw_ptr.impl&%1.arrow_0. T&. T& self!) (=>
     %%global_location_label%%8
     (is-vstd!raw_ptr.MemContents./Init (%Poly%vstd!raw_ptr.MemContents. self!))
   ))
   :pattern ((req%vstd!raw_ptr.impl&%1.arrow_0. T&. T& self!))
   :qid internal_req__vstd!raw_ptr.impl&__1.arrow_0._definition
   :skolemid skolem_internal_req__vstd!raw_ptr.impl&__1.arrow_0._definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%1.arrow_0.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%1.arrow_0.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!) (vstd!raw_ptr.MemContents./Init/0
      T&. T& (%Poly%vstd!raw_ptr.MemContents. self!)
    ))
    :pattern ((vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!))
    :qid internal_vstd!raw_ptr.impl&__1.arrow_0.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__1.arrow_0.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (has_type (vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!) T&)
   )
   :pattern ((vstd!raw_ptr.impl&%1.arrow_0.? T&. T& self!))
   :qid internal_vstd!raw_ptr.impl&__1.arrow_0.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.impl&__1.arrow_0.?_pre_post_definition
)))
(declare-fun req%vstd!raw_ptr.impl&%6.value. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%9 Bool)
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (= (req%vstd!raw_ptr.impl&%6.value. T&. T& self!) (=>
     %%global_location_label%%9
     (is-vstd!raw_ptr.MemContents./Init (%Poly%vstd!raw_ptr.MemContents. self!))
   ))
   :pattern ((req%vstd!raw_ptr.impl&%6.value. T&. T& self!))
   :qid internal_req__vstd!raw_ptr.impl&__6.value._definition
   :skolemid skolem_internal_req__vstd!raw_ptr.impl&__6.value._definition
)))
(assert
 (fuel_bool_default fuel%vstd!raw_ptr.impl&%6.value.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!raw_ptr.impl&%6.value.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (= (vstd!raw_ptr.impl&%6.value.? T&. T& self!) (vstd!raw_ptr.MemContents./Init/0 T&.
      T& (%Poly%vstd!raw_ptr.MemContents. self!)
    ))
    :pattern ((vstd!raw_ptr.impl&%6.value.? T&. T& self!))
    :qid internal_vstd!raw_ptr.impl&__6.value.?_definition
    :skolemid skolem_internal_vstd!raw_ptr.impl&__6.value.?_definition
))))
(assert
 (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!raw_ptr.MemContents. T&. T&))
    (has_type (vstd!raw_ptr.impl&%6.value.? T&. T& self!) T&)
   )
   :pattern ((vstd!raw_ptr.impl&%6.value.? T&. T& self!))
   :qid internal_vstd!raw_ptr.impl&__6.value.?_pre_post_definition
   :skolemid skolem_internal_vstd!raw_ptr.impl&__6.value.?_pre_post_definition
)))
(declare-fun req%vstd!simple_pptr.impl&%1.value. (Dcr Type Poly) Bool)
(declare-const %%global_location_label%%10 Bool)
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (= (req%vstd!simple_pptr.impl&%1.value. V&. V& self!) (=>
     %%global_location_label%%10
     (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? V&. V&
       self!
   ))))
   :pattern ((req%vstd!simple_pptr.impl&%1.value. V&. V& self!))
   :qid internal_req__vstd!simple_pptr.impl&__1.value._definition
   :skolemid skolem_internal_req__vstd!simple_pptr.impl&__1.value._definition
)))
(assert
 (fuel_bool_default fuel%vstd!simple_pptr.impl&%1.value.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!simple_pptr.impl&%1.value.)
  (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
    (= (vstd!simple_pptr.impl&%1.value.? V&. V& self!) (vstd!raw_ptr.MemContents./Init/0
      V&. V& (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
         V&. V& self!
    )))))
    :pattern ((vstd!simple_pptr.impl&%1.value.? V&. V& self!))
    :qid internal_vstd!simple_pptr.impl&__1.value.?_definition
    :skolemid skolem_internal_vstd!simple_pptr.impl&__1.value.?_definition
))))
(assert
 (forall ((V&. Dcr) (V& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%vstd!simple_pptr.PointsTo. V&. V&))
    (has_type (vstd!simple_pptr.impl&%1.value.? V&. V& self!) V&)
   )
   :pattern ((vstd!simple_pptr.impl&%1.value.? V&. V& self!))
   :qid internal_vstd!simple_pptr.impl&__1.value.?_pre_post_definition
   :skolemid skolem_internal_vstd!simple_pptr.impl&__1.value.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.)
  (forall ((T&. Dcr) (T& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? T&. T& N&.
      N& self!
     ) (forall ((i$ Poly) (j$ Poly)) (!
       (=>
        (and
         (has_type i$ INT)
         (has_type j$ INT)
        )
        (=>
         (and
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.? T&.
                 T& N&. N& self!
              )))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I j$)))
             (let
              ((tmp%%$5 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.? T&.
                 T& N&. N& self!
              )))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
          )))))
          (not (= i$ j$))
         )
         (not (= (vstd!seq.Seq.index.? T&. T& (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. self!)
            ) i$
           ) (vstd!seq.Seq.index.? T&. T& (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. self!)
            ) j$
       )))))
       :pattern ((vstd!seq.Seq.index.? T&. T& (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. self!)
         ) i$
        ) (vstd!seq.Seq.index.? T&. T& (OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList./StaticLinkedList/spec_seq
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. self!)
         ) j$
       ))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__StaticLinkedList__unique_0
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__StaticLinkedList__unique_0
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? T&.
      T& N&. N& self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.unique.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__1.unique.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!seq_lib.impl&%0.no_duplicates.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!seq_lib.impl&%0.no_duplicates.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!seq_lib.impl&%0.no_duplicates.? A&. A& self!) (forall ((i$ Poly) (j$ Poly))
      (!
       (=>
        (and
         (has_type i$ INT)
         (has_type j$ INT)
        )
        (=>
         (and
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (vstd!seq.Seq.len.? A&. A& self!)))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I j$)))
             (let
              ((tmp%%$5 (vstd!seq.Seq.len.? A&. A& self!)))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
          )))))
          (not (= i$ j$))
         )
         (not (= (vstd!seq.Seq.index.? A&. A& self! i$) (vstd!seq.Seq.index.? A&. A& self! j$)))
       ))
       :pattern ((vstd!seq.Seq.index.? A&. A& self! i$) (vstd!seq.Seq.index.? A&. A& self!
         j$
       ))
       :qid user_vstd__seq_lib__impl&%0__no_duplicates_0
       :skolemid skolem_user_vstd__seq_lib__impl&%0__no_duplicates_0
    )))
    :pattern ((vstd!seq_lib.impl&%0.no_duplicates.? A&. A& self!))
    :qid internal_vstd!seq_lib.impl&__0.no_duplicates.?_definition
    :skolemid skolem_internal_vstd!seq_lib.impl&__0.no_duplicates.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!set.impl&%0.finite.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.impl&%0.finite.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (= (vstd!set.impl&%0.finite.? A&. A& self!) true)
    :pattern ((vstd!set.impl&%0.finite.? A&. A& self!))
    :qid internal_vstd!set.impl&__0.finite.?_definition
    :skolemid skolem_internal_vstd!set.impl&__0.finite.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.)
  (forall ((container_perms! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.? container_perms!)
     (and
      (and
       (and
        (and
         (and
          (and
           (and
            (forall ((c_ptr$ Poly)) (!
              (=>
               (has_type c_ptr$ USIZE)
               (=>
                (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   container_perms!
                  )
                 ) c_ptr$
                )
                (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   container_perms! c_ptr$
              )))))
              :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                  container_perms!
                 )
                ) c_ptr$
              ))
              :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_0
              :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_0
            ))
            (forall ((c_ptr$ Poly)) (!
              (=>
               (has_type c_ptr$ USIZE)
               (=>
                (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   container_perms!
                  )
                 ) c_ptr$
                )
                (= (vstd!simple_pptr.impl&%1.addr.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   container_perms! c_ptr$
                  )
                 ) (%I c_ptr$)
              )))
              :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                  container_perms!
                 )
                ) c_ptr$
              ))
              :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_1
              :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_1
           )))
           (forall ((c_ptr$ Poly)) (!
             (=>
              (has_type c_ptr$ USIZE)
              (=>
               (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                  container_perms!
                 )
                ) c_ptr$
               )
               (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
                 10
                ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                     (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                        container_perms! c_ptr$
             )))))))))))
             :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 container_perms!
                )
               ) c_ptr$
             ))
             :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_2
             :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_2
          )))
          (forall ((c_ptr$ Poly)) (!
            (=>
             (has_type c_ptr$ USIZE)
             (=>
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 container_perms!
                )
               ) c_ptr$
              )
              (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $ USIZE $ (
                CONST_INT 10
               ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                       container_perms! c_ptr$
            )))))))))))
            :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                container_perms!
               )
              ) c_ptr$
            ))
            :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_3
            :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_3
         )))
         (forall ((c_ptr$ Poly)) (!
           (=>
            (has_type c_ptr$ USIZE)
            (=>
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                container_perms!
               )
              ) c_ptr$
             )
             (vstd!seq_lib.impl&%0.no_duplicates.? $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/uppertree_seq
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      container_perms! c_ptr$
           )))))))))))
           :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
               container_perms!
              )
             ) c_ptr$
           ))
           :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_4
           :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_4
        )))
        (forall ((c_ptr$ Poly)) (!
          (=>
           (has_type c_ptr$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
               container_perms!
              )
             ) c_ptr$
            )
            (= (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
               $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/children
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                       container_perms! c_ptr$
               ))))))))
              ) c_ptr$
             ) false
          )))
          :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              container_perms!
             )
            ) c_ptr$
          ))
          :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_5
          :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_5
       )))
       (forall ((c_ptr$ Poly)) (!
         (=>
          (has_type c_ptr$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              container_perms!
             )
            ) c_ptr$
           )
           (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/subtree_set
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    container_perms! c_ptr$
         )))))))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
             container_perms!
            )
           ) c_ptr$
         ))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_6
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_6
      )))
      (forall ((c_ptr$ Poly)) (!
        (=>
         (has_type c_ptr$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
             container_perms!
            )
           ) c_ptr$
          )
          (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/uppertree_seq
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    container_perms! c_ptr$
            ))))))))
           ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/depth
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
               (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                  container_perms! c_ptr$
        ))))))))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
            container_perms!
           )
          ) c_ptr$
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_7
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__container_perms_wf_7
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.?
      container_perms!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.?
      self!
     ) (OS__process_manager__spec_proof__impl2__endpoint_inv!container_perms_wf.? (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_perms_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_perms_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.container_dom.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.container_dom.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.container_dom.? self!)
     (%Poly%vstd!set.Set<usize.>. (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
       ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    )))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.container_dom.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.container_dom.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.container_dom.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.)
  (forall ((self! Poly) (c_ptr! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.?
      self! c_ptr!
     ) (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
        (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )
           ) c_ptr!
    )))))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.?
      self! c_ptr!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_container.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_container.?_definition
))))
(assert
 (forall ((self! Poly) (c_ptr! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
     (has_type c_ptr! USIZE)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.?
       self! c_ptr!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_container.?
     self! c_ptr!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_container.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_container.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.)
  (forall ((proc_perms! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.? proc_perms!)
     (and
      (and
       (and
        (and
         (and
          (and
           (and
            (forall ((p_ptr$ Poly)) (!
              (=>
               (has_type p_ptr$ USIZE)
               (=>
                (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   proc_perms!
                  )
                 ) p_ptr$
                )
                (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   proc_perms! p_ptr$
              )))))
              :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                  proc_perms!
                 )
                ) p_ptr$
              ))
              :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_0
              :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_0
            ))
            (forall ((p_ptr$ Poly)) (!
              (=>
               (has_type p_ptr$ USIZE)
               (=>
                (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   proc_perms!
                  )
                 ) p_ptr$
                )
                (= (vstd!simple_pptr.impl&%1.addr.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   proc_perms! p_ptr$
                  )
                 ) (%I p_ptr$)
              )))
              :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                  proc_perms!
                 )
                ) p_ptr$
              ))
              :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_1
              :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_1
           )))
           (forall ((p_ptr$ Poly)) (!
             (=>
              (has_type p_ptr$ USIZE)
              (=>
               (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                  proc_perms!
                 )
                ) p_ptr$
               )
               (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
                 10
                ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                     (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                        proc_perms! p_ptr$
             )))))))))))
             :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                 proc_perms!
                )
               ) p_ptr$
             ))
             :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_2
             :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_2
          )))
          (forall ((p_ptr$ Poly)) (!
            (=>
             (has_type p_ptr$ USIZE)
             (=>
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                 proc_perms!
                )
               ) p_ptr$
              )
              (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $ USIZE $ (
                CONST_INT 10
               ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                       proc_perms! p_ptr$
            )))))))))))
            :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                proc_perms!
               )
              ) p_ptr$
            ))
            :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_3
            :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_3
         )))
         (forall ((p_ptr$ Poly)) (!
           (=>
            (has_type p_ptr$ USIZE)
            (=>
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                proc_perms!
               )
              ) p_ptr$
             )
             (vstd!seq_lib.impl&%0.no_duplicates.? $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/uppertree_seq
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                      proc_perms! p_ptr$
           )))))))))))
           :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
               proc_perms!
              )
             ) p_ptr$
           ))
           :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_4
           :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_4
        )))
        (forall ((p_ptr$ Poly)) (!
          (=>
           (has_type p_ptr$ USIZE)
           (=>
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
               proc_perms!
              )
             ) p_ptr$
            )
            (= (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
               $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/children (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!map.impl&%0.index.?
                       $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                       proc_perms! p_ptr$
               ))))))))
              ) p_ptr$
             ) false
          )))
          :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
              proc_perms!
             )
            ) p_ptr$
          ))
          :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_5
          :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_5
       )))
       (forall ((p_ptr$ Poly)) (!
         (=>
          (has_type p_ptr$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
              proc_perms!
             )
            ) p_ptr$
           )
           (vstd!set.impl&%0.finite.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/subtree_set
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                    proc_perms! p_ptr$
         )))))))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
             proc_perms!
            )
           ) p_ptr$
         ))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_6
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_6
      )))
      (forall ((p_ptr$ Poly)) (!
        (=>
         (has_type p_ptr$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
             proc_perms!
            )
           ) p_ptr$
          )
          (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/uppertree_seq
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                    proc_perms! p_ptr$
            ))))))))
           ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/depth (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
             (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
              (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!map.impl&%0.index.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                  proc_perms! p_ptr$
        ))))))))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
            proc_perms!
           )
          ) p_ptr$
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_7
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__proc_perms_wf_7
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.? proc_perms!))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.? self!)
     (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_perms_wf.? (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.proc_perms_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.proc_perms_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.proc_dom.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.proc_dom.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.proc_dom.? self!)
     (%Poly%vstd!set.Set<usize.>. (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
       ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    )))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.proc_dom.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.proc_dom.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.proc_dom.?_definition
))))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%11 Bool)
(declare-const %%global_location_label%%12 Bool)
(assert
 (forall ((self! Poly) (proc_ptr! Poly)) (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.
     self! proc_ptr!
    ) (and
     (=>
      %%global_location_label%%11
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.? self!)
     )
     (=>
      %%global_location_label%%12
      (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
         $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        )))
       ) proc_ptr!
   ))))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.
     self! proc_ptr!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_proc._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_proc._definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.)
  (forall ((self! Poly) (proc_ptr! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.? self!
      proc_ptr!
     ) (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
        (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )
           ) proc_ptr!
    )))))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.?
      self! proc_ptr!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_proc.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_proc.?_definition
))))
(assert
 (forall ((self! Poly) (proc_ptr! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
     (has_type proc_ptr! USIZE)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.?
       self! proc_ptr!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_proc.?
     self! proc_ptr!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_proc.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_proc.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.?
      self!
     ) (forall ((p_ptr$ Poly)) (!
       (=>
        (has_type p_ptr$ USIZE)
        (=>
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) p_ptr$
         )
         (and
          (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
            128
           ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) p_ptr$
          )))))))))
          (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $ USIZE $ (
            CONST_INT 128
           ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) p_ptr$
       ))))))))))))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE
         $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) p_ptr$
       ))))))))))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $
         USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) p_ptr$
       ))))))))))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__process_fields_wf_0
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__process_fields_wf_0
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_fields_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_fields_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.)
  (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.? A&. A& N&. N&
      self!
     ) (= (vstd!seq.Seq.len.? A&. A& (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. self!)
       )
      ) (const_int N&)
    ))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.? A&. A&
      N&. N& self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.?
      self!
     ) (ite
      (is-OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.
        self!
      ))
      (let
       ((va_range$ (OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad./Pages/va_range
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. self!)
       )))
       (core!option.Option./Some (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.
         va_range$
      )))
      core!option.Option./None
    ))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__13.spec_get_payload_as_va_range.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__13.spec_get_payload_as_va_range.?_definition
))))
(assert
 (forall ((self! Poly)) (!
   (=>
    (has_type self! TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad.)
    (has_type (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.?
       self!
      )
     ) (TYPE%core!option.Option. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K.)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.?
     self!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__13.spec_get_payload_as_va_range.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__13.spec_get_payload_as_va_range.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK.)
  (= OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK.? 281474976706560)
))
(assert
 (uInv 64 OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK.?)
)
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.)
  (= OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.? 1)
))
(assert
 (uInv SZ OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.?)
)
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.)
  (forall ((va! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.? va!) (
      and
      (= (uClip SZ (bitand (I (%I va!)) (I (uClip SZ (uClip 64 (bitnot (I OS__process_manager__spec_proof__impl2__endpoint_inv!MEM_4k_MASK.?)))))))
       0
      )
      (>= (uClip 64 (bitand (I (uClip 64 (bitshr (I (uClip 64 (%I va!))) (I 39)))) (I 511)))
       (uClip 64 OS__process_manager__spec_proof__impl2__endpoint_inv!KERNEL_MEM_END_L4INDEX.?)
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.?
      va!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.? self!) (and
      (and
       (and
        (and
         (and
          (< (Add (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. self!)
            ) (Mul (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. self!)
             ) 4096
            )
           ) (- (uHi SZ) 1)
          )
          (OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.? (I (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/start
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. self!)
         ))))
         (= (vstd!seq.Seq.len.? $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.view.?
             self!
           ))
          ) (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len (
            %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. self!
        ))))
        (vstd!seq_lib.impl&%0.no_duplicates.? $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.view.?
           self!
       ))))
       (forall ((i$ Poly)) (!
         (=>
          (has_type i$ INT)
          (=>
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I i$)))
             (let
              ((tmp%%$2 (OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K./VaRange4K/len
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. self!)
              )))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (OS__process_manager__spec_proof__impl2__endpoint_inv!spec_va_4k_valid.? (vstd!seq.Seq.index.?
             $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.view.?
               self!
              )
             ) i$
         ))))
         :pattern ((vstd!seq.Seq.index.? $ USIZE (Poly%vstd!seq.Seq<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.view.?
             self!
            )
           ) i$
         ))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__VaRange4K__wf_0
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__VaRange4K__wf_0
      )))
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.view_match_spec.? self!)
    ))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.? self!))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__43.wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__43.wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.?
      self!
     ) (forall ((t_ptr$ Poly)) (!
       (=>
        (has_type t_ptr$ USIZE)
        (=>
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) t_ptr$
         )
         (and
          (and
           (and
            (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )
               ) t_ptr$
            )))
            (= (vstd!simple_pptr.impl&%1.addr.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )
               ) t_ptr$
              )
             ) (%I t_ptr$)
           ))
           (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.? $ (TYPE%core!option.Option.
             $ USIZE
            ) $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
          ))))))))))
          (=>
           (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.?
             (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) t_ptr$
           ))))))))))
           (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%43.wf.? (core!option.Option./Some/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!VaRange4K. (%Poly%core!option.Option.
              (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%13.spec_get_payload_as_va_range.?
                (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!IPCPayLoad. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/ipc_payload
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                     (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                         (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                         )
                        ) t_ptr$
       )))))))))))))))))
       :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
           $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
          )))
         ) t_ptr$
       ))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_perms_wf_0
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_perms_wf_0
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_perms_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_perms_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.?
      self!
     ) (forall ((e_ptr$ Poly)) (!
       (=>
        (has_type e_ptr$ USIZE)
        (=>
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) e_ptr$
         )
         (and
          (and
           (and
            (and
             (and
              (is-vstd!raw_ptr.MemContents./Init (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) e_ptr$
              )))
              (= (vstd!simple_pptr.impl&%1.addr.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) e_ptr$
                )
               ) (%I e_ptr$)
             ))
             (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
               128
              ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) e_ptr$
            ))))))))))
            (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $ USIZE $ (
              CONST_INT 128
             ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) e_ptr$
           ))))))))))
           (vstd!set.impl&%0.finite.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) e_ptr$
          ))))))))))
          (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/rf_counter
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
               (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                   )
                  ) e_ptr$
            ))))))
           ) (vstd!set.impl&%0.len.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) e_ptr$
       )))))))))))))
       :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
           $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
          )))
         ) e_ptr$
       ))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_perms_wf_0
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_perms_wf_0
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoint_perms_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoint_perms_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.?
      self!
     ) (forall ((c_ptr$ Poly)) (!
       (=>
        (has_type c_ptr$ USIZE)
        (=>
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) c_ptr$
         )
         (and
          (and
           (and
            (and
             (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%39.wf.? $ (CONST_INT 32)
              (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) c_ptr$
             )))))))))
             (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
               10
              ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) c_ptr$
            ))))))))))
            (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $ USIZE $ (
              CONST_INT 10
             ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) c_ptr$
           ))))))))))
           (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
             10
            ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) c_ptr$
          ))))))))))
          (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $ USIZE $ (
            CONST_INT 10
           ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) c_ptr$
       ))))))))))))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%39.wf.? $ (CONST_INT
          32
         ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
       ))))))))))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE
         $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
       ))))))))))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE
         $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
       ))))))))))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $
         USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
       ))))))))))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.unique.? $
         USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
       ))))))))))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__container_fields_wf_0
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__container_fields_wf_0
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_fields_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_fields_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.)
  (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.? A&. A& N&.
      N& self!
     ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
       self!
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.? A&.
      A& N&. N& self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.view.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.view.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly)) (!
   (=>
    (has_type self! (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&.
      A& N&. N&
    ))
    (has_type (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.? A&.
      A& N&. N& self!
     ) (TYPE%vstd!seq.Seq. A&. A&)
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.view.? A&.
     A& N&. N& self!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.view.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.view.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.)
  (= OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.? 32)
))
(assert
 (uInv SZ OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.?)
)
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf.? self!)
     (and
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.wf.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
       $ (CONST_INT 32) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
      )))
      (forall ((cpu_i$ Poly)) (!
        (=>
         (has_type cpu_i$ USIZE)
         (=>
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$1 (%I cpu_i$)))
             (let
              ((tmp%%$2 OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.?))
              (and
               (<= tmp%%$ tmp%%$1)
               (< tmp%%$1 tmp%%$2)
           ))))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/active (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
              (vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                 (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) cpu_i$
             ))
            ) false
          ))
          (is-core!option.Option./None (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
               )))
              ) cpu_i$
        ))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/active (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
           (vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
              (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) cpu_i$
        ))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) cpu_i$
        ))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__cpus_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__cpus_wf_0
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf.? self!))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.cpus_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.cpus_wf.?_definition
))))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.
 (Dcr Type Dcr Type Poly Poly) Bool
)
(declare-const %%global_location_label%%13 Bool)
(declare-const %%global_location_label%%14 Bool)
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly) (i! Poly)) (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index. A&.
     A& N&. N& self! i!
    ) (and
     (=>
      %%global_location_label%%13
      (= (vstd!seq.Seq.len.? A&. A& (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. self!)
        )
       ) (const_int N&)
     ))
     (=>
      %%global_location_label%%14
      (let
       ((tmp%%$ 0))
       (let
        ((tmp%%$1 (%I i!)))
        (let
         ((tmp%%$2 (const_int N&)))
         (and
          (<= tmp%%$ tmp%%$1)
          (< tmp%%$1 tmp%%$2)
   )))))))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.
     A&. A& N&. N& self! i!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.spec_index._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.spec_index._definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.)
  (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly) (i! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.? A&.
      A& N&. N& self! i!
     ) (vstd!seq.Seq.index.? A&. A& (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. self!)
      ) i!
    ))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.?
      A&. A& N&. N& self! i!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.spec_index.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.spec_index.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type) (N&. Dcr) (N& Type) (self! Poly) (i! Poly)) (!
   (=>
    (and
     (has_type self! (TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. A&.
       A& N&. N&
     ))
     (has_type i! INT)
    )
    (has_type (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.?
      A&. A& N&. N& self! i!
     ) A&
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%38.spec_index.?
     A&. A& N&. N& self! i!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.spec_index.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__38.spec_index.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.?
      self!
     ) (and
      (forall ((cpu_i$ Poly)) (!
        (=>
         (has_type cpu_i$ USIZE)
         (=>
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I cpu_i$)))
            (let
             ((tmp%%$2 OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.?))
             (and
              (<= tmp%%$ tmp%%$1)
              (< tmp%%$1 tmp%%$2)
          ))))
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )))
                ) cpu_i$
           )))))
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%39.view.? $ (CONST_INT
                32
               ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
                           $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                            )))
                           ) cpu_i$
             ))))))))))))))
            ) cpu_i$
        ))))
        :pattern ((vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
            (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) cpu_i$
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__container_cpu_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__container_cpu_wf_0
      ))
      (forall ((c_ptr$ Poly) (cpu_i$ Poly)) (!
        (=>
         (and
          (has_type c_ptr$ USIZE)
          (has_type cpu_i$ USIZE)
         )
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) c_ptr$
           )
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%39.view.? $ (CONST_INT
                32
               ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) c_ptr$
             ))))))))))
            ) cpu_i$
          ))
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I cpu_i$)))
             (let
              ((tmp%%$5 OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.?))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
           ))))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) cpu_i$
             ))
            ) (%I c_ptr$)
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%39.view.? $ (CONST_INT
              32
             ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ArraySet. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) c_ptr$
           ))))))))))
          ) cpu_i$
        ))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_cpus
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) c_ptr$
          ))))))
         ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) cpu_i$
        ))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__container_cpu_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__container_cpu_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_cpu_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_cpu_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!set.impl&%0.disjoint.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.impl&%0.disjoint.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
    (= (vstd!set.impl&%0.disjoint.? A&. A& self! s2!) (forall ((a$ Poly)) (!
       (=>
        (has_type a$ A&)
        (=>
         (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!) a$)
         (not (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$))
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!)
         a$
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
         a$
       ))
       :qid user_vstd__set__impl&%0__disjoint_0
       :skolemid skolem_user_vstd__set__impl&%0__disjoint_0
    )))
    :pattern ((vstd!set.impl&%0.disjoint.? A&. A& self! s2!))
    :qid internal_vstd!set.impl&__0.disjoint.?_definition
    :skolemid skolem_internal_vstd!set.impl&__0.disjoint.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.?
      self!
     ) (and
      (and
       (and
        (and
         (and
          (vstd!set.impl&%0.disjoint.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
            ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            ))
           ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
          ))))
          (vstd!set.impl&%0.disjoint.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
            ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            ))
           ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
         )))))
         (vstd!set.impl&%0.disjoint.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
           ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           ))
          ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        )))))
        (vstd!set.impl&%0.disjoint.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
           $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
          ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
           (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
          ))
         ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
          (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
           (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
       )))))
       (vstd!set.impl&%0.disjoint.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
          $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
         ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
         ))
        ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
      )))))
      (vstd!set.impl&%0.disjoint.? $ USIZE (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
         $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
        ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
         (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        ))
       ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
         (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    ))))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.memory_disjoint.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.memory_disjoint.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!set.Set.subset_of.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!set.Set.subset_of.)
  (forall ((A&. Dcr) (A& Type) (self! Poly) (s2! Poly)) (!
    (= (vstd!set.Set.subset_of.? A&. A& self! s2!) (forall ((a$ Poly)) (!
       (=>
        (has_type a$ A&)
        (=>
         (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!) a$)
         (vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!) a$)
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& self!)
         a$
       ))
       :pattern ((vstd!iset.ISet.contains.? A&. A& (vstd!set.impl&%0.to_iset.? A&. A& s2!)
         a$
       ))
       :qid user_vstd__set__Set__subset_of_0
       :skolemid skolem_user_vstd__set__Set__subset_of_0
    )))
    :pattern ((vstd!set.Set.subset_of.? A&. A& self! s2!))
    :qid internal_vstd!set.Set.subset_of.?_definition
    :skolemid skolem_internal_vstd!set.Set.subset_of.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.?
      self!
     ) (and
      (and
       (forall ((c_ptr$ Poly)) (!
         (=>
          (has_type c_ptr$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) c_ptr$
           )
           (vstd!set.Set.subset_of.? $ USIZE (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
              $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) c_ptr$
             )))))))))
            ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
         ))))))
         :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
         ))))))))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__processes_container_wf_0
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__processes_container_wf_0
       ))
       (forall ((c_ptr$ Poly) (child_p_ptr$ Poly)) (!
         (=>
          (and
           (has_type c_ptr$ USIZE)
           (has_type child_p_ptr$ USIZE)
          )
          (=>
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) c_ptr$
            )
            (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
              $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) c_ptr$
              ))))))))
             ) child_p_ptr$
           ))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) child_p_ptr$
             ))))))
            ) (%I c_ptr$)
         )))
         :pattern ((vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
            $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) c_ptr$
            ))))))))
           ) child_p_ptr$
         ))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__processes_container_wf_1
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__processes_container_wf_1
      )))
      (forall ((p_ptr$ Poly)) (!
        (=>
         (has_type p_ptr$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )))
           ) p_ptr$
          )
          (and
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) p_ptr$
            )))))))))
            (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
              $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                          $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                           (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                             (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                               )
                              ) p_ptr$
              ))))))))))))))))
             ) p_ptr$
           ))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.? $ USIZE
             $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                         $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                          (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                            (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                              )
                             ) p_ptr$
              )))))))))))))))
             ) p_ptr$
            ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/rev_ptr (
              %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) p_ptr$
        )))))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) p_ptr$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__processes_container_wf_2
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__processes_container_wf_2
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.processes_container_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.processes_container_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.?
      self!
     ) (and
      (forall ((p_ptr$ Poly) (child_t_ptr$ Poly)) (!
        (=>
         (and
          (has_type p_ptr$ USIZE)
          (has_type child_t_ptr$ USIZE)
         )
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) p_ptr$
           )
           (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
             $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) p_ptr$
             ))))))))
            ) child_t_ptr$
          ))
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) child_t_ptr$
           )
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) child_t_ptr$
             ))))))
            ) (%I p_ptr$)
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) p_ptr$
         ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) child_t_ptr$
        ))))))))
        :pattern ((vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
           $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) p_ptr$
           ))))))))
          ) child_t_ptr$
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_process_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_process_wf_0
      ))
      (forall ((t_ptr$ Poly)) (!
        (=>
         (has_type t_ptr$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )))
           ) t_ptr$
          )
          (and
           (and
            (and
             (and
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) t_ptr$
              )))))))))
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) t_ptr$
             ))))))))))
             (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
               $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                           $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                            (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                                )
                               ) t_ptr$
               ))))))))))))))))
              ) t_ptr$
            ))
            (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.? $ USIZE
              $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                          $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                           (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                             (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                               )
                              ) t_ptr$
               )))))))))))))))
              ) t_ptr$
             ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/proc_rev_ptr
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
           )))))))))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                        (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                            )
                           ) t_ptr$
             ))))))))))))))
            ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) t_ptr$
        )))))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) t_ptr$
        ))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/owned_threads
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_proc
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                     (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                         (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                         )
                        ) t_ptr$
        ))))))))))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_process_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_process_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_process_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_process_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.)
  (= OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.?
   128
)))
(assert
 (uInv SZ OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.?)
)
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.?
      self!
     ) (and
      (forall ((t_ptr$ Poly) (e_idx$ Poly)) (!
        (=>
         (and
          (has_type t_ptr$ USIZE)
          (has_type e_idx$ USIZE)
         )
         (=>
          (and
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) t_ptr$
            )
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I e_idx$)))
              (let
               ((tmp%%$2 OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.?))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
           )))))
           (is-core!option.Option./Some (%Poly%core!option.Option. (vstd!seq.Seq.index.? $ (TYPE%core!option.Option.
               $ USIZE
              ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                     (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                         (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                         )
                        ) t_ptr$
               )))))))))
              ) e_idx$
          ))))
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (vstd!seq.Seq.index.?
               $ (TYPE%core!option.Option. $ USIZE) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                      (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                          )
                         ) t_ptr$
                )))))))))
               ) e_idx$
           ))))
           (vstd!iset.ISet.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!set.impl&%0.to_iset.?
             (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (vstd!seq.Seq.index.?
                        $ (TYPE%core!option.Option. $ USIZE) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                           (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
                            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                               (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                                   )
                                  ) t_ptr$
                         )))))))))
                        ) e_idx$
             )))))))))))
            ) (Poly%tuple%2. (tuple%2./tuple%2 t_ptr$ e_idx$))
        ))))
        :pattern ((vstd!seq.Seq.index.? $ (TYPE%core!option.Option. $ USIZE) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
           )))))))))
          ) e_idx$
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_endpoint_descriptors_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_endpoint_descriptors_wf_0
      ))
      (forall ((e_ptr$ Poly) (t_ptr$ Poly) (e_idx$ Poly)) (!
        (=>
         (and
          (has_type e_ptr$ USIZE)
          (has_type t_ptr$ USIZE)
          (has_type e_idx$ USIZE)
         )
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) e_ptr$
           )
           (vstd!iset.ISet.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!set.impl&%0.to_iset.?
             (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) e_ptr$
             ))))))))
            ) (Poly%tuple%2. (tuple%2./tuple%2 t_ptr$ e_idx$))
          ))
          (and
           (and
            (and
             (let
              ((tmp%%$ 0))
              (let
               ((tmp%%$4 (%I e_idx$)))
               (let
                ((tmp%%$5 OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.?))
                (and
                 (<= tmp%%$ tmp%%$4)
                 (< tmp%%$4 tmp%%$5)
             ))))
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
               )))
              ) t_ptr$
            ))
            (is-core!option.Option./Some (%Poly%core!option.Option. (vstd!seq.Seq.index.? $ (TYPE%core!option.Option.
                $ USIZE
               ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                 (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                      (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                          )
                         ) t_ptr$
                )))))))))
               ) e_idx$
           ))))
           (= (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (vstd!seq.Seq.index.?
               $ (TYPE%core!option.Option. $ USIZE) (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                      (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                          )
                         ) t_ptr$
                )))))))))
               ) e_idx$
             ))
            ) e_ptr$
        ))))
        :pattern ((vstd!iset.ISet.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!set.impl&%0.to_iset.?
           (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) e_ptr$
           ))))))))
          ) (Poly%tuple%2. (tuple%2./tuple%2 t_ptr$ e_idx$))
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_endpoint_descriptors_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_endpoint_descriptors_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_endpoint_descriptors_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_endpoint_descriptors_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.?
      self!
     ) (and
      (forall ((t_ptr$ Poly)) (!
        (=>
         (has_type t_ptr$ USIZE)
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) t_ptr$
           )
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) t_ptr$
             ))))))
            ) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./BLOCKED
          ))
          (and
           (and
            (and
             (and
              (and
               (and
                (and
                 (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                      (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                          )
                         ) t_ptr$
                 ))))))))
                 (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                      (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                        (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                          )
                         ) t_ptr$
                )))))))))
                (let
                 ((tmp%%$ 0))
                 (let
                  ((tmp%%$1 (%I (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                           $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                            (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                                )
                               ) t_ptr$
                  )))))))))))))
                  (let
                   ((tmp%%$2 OS__process_manager__spec_proof__impl2__endpoint_inv!MAX_NUM_ENDPOINT_DESCRIPTORS.?))
                   (and
                    (<= tmp%%$ tmp%%$1)
                    (< tmp%%$1 tmp%%$2)
               )))))
               (= (%Poly%core!option.Option. (vstd!seq.Seq.index.? $ (TYPE%core!option.Option. $ USIZE)
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                    (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_descriptors
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                         (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                           (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                             )
                            ) t_ptr$
                   )))))))))
                  ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_index
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                         (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                           (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                             )
                            ) t_ptr$
                 )))))))))))
                ) (core!option.Option./Some (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option.
                   (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                        (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                            )
                           ) t_ptr$
              )))))))))))))
              (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) t_ptr$
             )))))))))
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
               )))
              ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                     (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                       (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                         (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                         )
                        ) t_ptr$
            ))))))))))))
            (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
              $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                      $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                         (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
                          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                                 )
                                ) t_ptr$
              ))))))))))))))))))
             ) t_ptr$
           ))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.? $ USIZE
             $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                     $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                           $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                            (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                              (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                                )
                               ) t_ptr$
              )))))))))))))))))
             ) t_ptr$
            ) (%I (core!option.Option./Some/0 $ (SINT 32) (%Poly%core!option.Option. (Poly%core!option.Option.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) t_ptr$
        )))))))))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) t_ptr$
        ))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) t_ptr$
        ))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/endpoint_rev_ptr
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) t_ptr$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_queue_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_queue_wf_0
      ))
      (forall ((e_ptr$ Poly) (t_ptr$ Poly)) (!
        (=>
         (and
          (has_type e_ptr$ USIZE)
          (has_type t_ptr$ USIZE)
         )
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) e_ptr$
           )
           (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
             $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                     $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) e_ptr$
             ))))))))
            ) t_ptr$
          ))
          (and
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) t_ptr$
            )
            (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/blocking_endpoint_ptr
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
              ))))))
             ) (core!option.Option./Some e_ptr$)
           ))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) t_ptr$
             ))))))
            ) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./BLOCKED
        ))))
        :pattern ((vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
           $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) e_ptr$
           ))))))))
          ) t_ptr$
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_queue_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_queue_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoints_queue_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoints_queue_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.?
      self!
     ) (and
      (forall ((c_ptr$ Poly) (child_e_ptr$ Poly)) (!
        (=>
         (and
          (has_type c_ptr$ USIZE)
          (has_type child_e_ptr$ USIZE)
         )
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) c_ptr$
           )
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) c_ptr$
             ))))))))
            ) child_e_ptr$
          ))
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) child_e_ptr$
           )
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) child_e_ptr$
             ))))))
            ) (%I c_ptr$)
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) c_ptr$
           ))))))))
          ) child_e_ptr$
        ))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_container_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_container_wf_0
      ))
      (forall ((e_ptr$ Poly)) (!
        (=>
         (has_type e_ptr$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )))
           ) e_ptr$
          )
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) e_ptr$
           )))))))))
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_endpoints
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                         $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                          (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                            (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                              )
                             ) e_ptr$
             ))))))))))))))))
            ) e_ptr$
        ))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) e_ptr$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_container_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_container_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoints_container_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoints_container_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.? self!)
     (and
      (forall ((t_ptr$ Poly)) (!
        (=>
         (has_type t_ptr$ USIZE)
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) t_ptr$
           )
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) t_ptr$
             ))))))
            ) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./SCHEDULED
          ))
          (and
           (and
            (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
              $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                          $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                           (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                             (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                               )
                              ) t_ptr$
              ))))))))))))))))
             ) t_ptr$
            )
            (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
           )))))))))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.get_node_ref.? $ USIZE
             $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                         $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                          (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                            (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                              )
                             ) t_ptr$
              )))))))))))))))
             ) t_ptr$
            ) (%I (core!option.Option./Some/0 $ (SINT 32) (%Poly%core!option.Option. (Poly%core!option.Option.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) t_ptr$
        )))))))))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/scheduler_rev_ptr
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) t_ptr$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__schedulers_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__schedulers_wf_0
      ))
      (forall ((c_ptr$ Poly) (t_ptr$ Poly)) (!
        (=>
         (and
          (has_type c_ptr$ USIZE)
          (has_type t_ptr$ USIZE)
         )
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) c_ptr$
           )
           (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
             $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) c_ptr$
             ))))))))
            ) t_ptr$
          ))
          (and
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) t_ptr$
            )
            (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
              ))))))
             ) (%I c_ptr$)
           ))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) t_ptr$
             ))))))
            ) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./SCHEDULED
        ))))
        :pattern ((vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
           $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/scheduler
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) c_ptr$
           ))))))))
          ) t_ptr$
        ))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) c_ptr$
         ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) t_ptr$
        ))))))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) c_ptr$
         ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
           (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
            (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) t_ptr$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__schedulers_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__schedulers_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.schedulers_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.schedulers_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf.? self!)
     (and
      (forall ((p_ptr_i$ Poly) (p_ptr_j$ Poly)) (!
        (=>
         (and
          (has_type p_ptr_i$ USIZE)
          (has_type p_ptr_j$ USIZE)
         )
         (=>
          (and
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) p_ptr_i$
            )
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) p_ptr_j$
           ))
           (not (= p_ptr_i$ p_ptr_j$))
          )
          (not (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) p_ptr_i$
             ))))))
            ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) p_ptr_j$
        )))))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) p_ptr_i$
          ))))))
         ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/pcid (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
           (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
            (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!map.impl&%0.index.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) p_ptr_j$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__pcid_ioid_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__pcid_ioid_wf_0
      ))
      (forall ((p_ptr_i$ Poly) (p_ptr_j$ Poly)) (!
        (=>
         (and
          (has_type p_ptr_i$ USIZE)
          (has_type p_ptr_j$ USIZE)
         )
         (=>
          (and
           (and
            (and
             (and
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) p_ptr_i$
              )
              (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) p_ptr_j$
             ))
             (not (= p_ptr_i$ p_ptr_j$))
            )
            (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) p_ptr_i$
           )))))))))
           (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) p_ptr_j$
          )))))))))
          (not (= (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!map.impl&%0.index.?
                      $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) p_ptr_i$
             )))))))))
            ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                 (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
                  (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                     $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!map.impl&%0.index.?
                      $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) p_ptr_j$
        ))))))))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) p_ptr_i$
          ))))))
         ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Process./Process/ioid (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
           (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.
            (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process. (vstd!map.impl&%0.index.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Process.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) p_ptr_j$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__pcid_ioid_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__pcid_ioid_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.pcid_ioid_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.pcid_ioid_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.? self!)
     (and
      (and
       (forall ((t_ptr$ Poly)) (!
         (=>
          (has_type t_ptr$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) t_ptr$
           )
           (= (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
             )))))))
            ) (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                    $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
              ))))))
             ) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./RUNNING
         ))))
         :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) t_ptr$
         ))))))))
         :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) t_ptr$
         ))))))))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_cpu_wf_0
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_cpu_wf_0
       ))
       (forall ((t_ptr$ Poly)) (!
         (=>
          (has_type t_ptr$ USIZE)
          (=>
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) t_ptr$
            )
            (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
           )))))))))
           (and
            (and
             (and
              (let
               ((tmp%%$ 0))
               (let
                ((tmp%%$1 (%I (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu (
                        %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                         $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                          (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                            (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                              )
                             ) t_ptr$
                )))))))))))))
                (let
                 ((tmp%%$2 OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.?))
                 (and
                  (<= tmp%%$ tmp%%$1)
                  (< tmp%%$1 tmp%%$2)
              ))))
              (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                   )))
                  ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu (
                       %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                         (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                           (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                             )
                            ) t_ptr$
             )))))))))))))))
             (= (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                   (vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                      (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )))
                    ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu (
                         %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                          $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                           (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                             (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                               )
                              ) t_ptr$
               )))))))))))))))
              ) t_ptr$
            ))
            (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )))
                ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu (
                     %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                      $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                       (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                         (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                          (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                           (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                           )
                          ) t_ptr$
              ))))))))))))
             ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
         )))))))))))
         :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) t_ptr$
         ))))))))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_cpu_wf_1
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_cpu_wf_1
      )))
      (forall ((cpu_i$ Poly)) (!
        (=>
         (has_type cpu_i$ USIZE)
         (=>
          (and
           (let
            ((tmp%%$ 0))
            (let
             ((tmp%%$4 (%I cpu_i$)))
             (let
              ((tmp%%$5 OS__process_manager__spec_proof__impl2__endpoint_inv!NUM_CPUS.?))
              (and
               (<= tmp%%$ tmp%%$4)
               (< tmp%%$4 tmp%%$5)
           ))))
           (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) cpu_i$
          )))))
          (and
           (and
            (and
             (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
                $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
               )))
              ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                   (vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                      (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )))
                    ) cpu_i$
             )))))))
             (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                          (vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                           (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                             (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                            )))
                           ) cpu_i$
            )))))))))))))))
            (= (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/running_cpu (
                  %Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                    (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                      (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                        )
                       ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                          (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                            (vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                             (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                               (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                              )))
                             ) cpu_i$
              )))))))))))))))
             ) cpu_i$
           ))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )))
               ) cpu_i$
             ))
            ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) (core!option.Option./Some/0 $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                        (vstd!seq.Seq.index.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu.
                         (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
                           (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                          )))
                         ) cpu_i$
        )))))))))))))))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu./Cpu/current_thread
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (vstd!seq.Seq.index.?
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Cpu. (OS__process_manager__spec_proof__impl2__endpoint_inv!Array./Array/seq
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Array.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/cpu_list
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) cpu_i$
        ))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_cpu_wf_2
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_cpu_wf_2
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_cpu_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_cpu_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.thread_dom.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.thread_dom.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.thread_dom.? self!)
     (%Poly%vstd!set.Set<usize.>. (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
       ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    )))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.thread_dom.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.thread_dom.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.thread_dom.?_definition
))))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%15 Bool)
(declare-const %%global_location_label%%16 Bool)
(assert
 (forall ((self! Poly) (thread_ptr! Poly)) (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.
     self! thread_ptr!
    ) (and
     (=>
      %%global_location_label%%15
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.? self!)
     )
     (=>
      %%global_location_label%%16
      (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
         $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        )))
       ) thread_ptr!
   ))))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.
     self! thread_ptr!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_thread._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_thread._definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.)
  (forall ((self! Poly) (thread_ptr! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.?
      self! thread_ptr!
     ) (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
        (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )
           ) thread_ptr!
    )))))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.?
      self! thread_ptr!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_thread.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_thread.?_definition
))))
(assert
 (forall ((self! Poly) (thread_ptr! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
     (has_type thread_ptr! USIZE)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.?
       self! thread_ptr!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_thread.?
     self! thread_ptr!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_thread.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_thread.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.?
      self!
     ) (and
      (and
       (forall ((c_ptr$ Poly)) (!
         (=>
          (has_type c_ptr$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) c_ptr$
           )
           (vstd!set.Set.subset_of.? $ USIZE (Poly%vstd!set.Set<usize.>. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) c_ptr$
             )))))))
            ) (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
         ))))))
         :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
         ))))))))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_container_wf_0
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_container_wf_0
       ))
       (forall ((c_ptr$ Poly) (t_ptr$ Poly)) (!
         (=>
          (and
           (has_type c_ptr$ USIZE)
           (has_type t_ptr$ USIZE)
          )
          (=>
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
              )))
             ) c_ptr$
            )
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                   (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                     (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                      (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                       )
                      ) c_ptr$
              ))))))))
             ) t_ptr$
           ))
           (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) t_ptr$
             ))))))
            ) (%I c_ptr$)
         )))
         :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
              (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                  )
                 ) c_ptr$
           ))))))
          ) (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
           (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                )
               ) t_ptr$
         ))))))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_container_wf_1
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_container_wf_1
      )))
      (forall ((t_ptr$ Poly)) (!
        (=>
         (has_type t_ptr$ USIZE)
         (=>
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )))
           ) t_ptr$
          )
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) t_ptr$
           )))))))))
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_threads
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
                         $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                          (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                            (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                              )
                             ) t_ptr$
             ))))))))))))))))
            ) t_ptr$
        ))))
        :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
           )))
          ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
               (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                   )
                  ) t_ptr$
        ))))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_container_wf_2
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__threads_container_wf_2
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_container_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.threads_container_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.)
  (forall ((root_container! Poly) (container_perms! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.? root_container!
      container_perms!
     ) (and
      (and
       (and
        (and
         (and
          (and
           (OS__process_manager__spec_proof__impl2__endpoint_inv!container_root_wf.? root_container!
            container_perms!
           )
           (OS__process_manager__spec_proof__impl2__endpoint_inv!container_childern_parent_wf.?
            root_container! container_perms!
          ))
          (OS__process_manager__spec_proof__impl2__endpoint_inv!containers_linkedlist_wf.? root_container!
           container_perms!
         ))
         (OS__process_manager__spec_proof__impl2__endpoint_inv!container_childern_depth_wf.?
          root_container! container_perms!
        ))
        (OS__process_manager__spec_proof__impl2__endpoint_inv!container_subtree_set_wf.? root_container!
         container_perms!
       ))
       (OS__process_manager__spec_proof__impl2__endpoint_inv!container_uppertree_seq_wf.?
        root_container! container_perms!
      ))
      (OS__process_manager__spec_proof__impl2__endpoint_inv!container_subtree_set_exclusive.?
       root_container! container_perms!
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.?
      root_container! container_perms!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.?
      self!
     ) (OS__process_manager__spec_proof__impl2__endpoint_inv!container_tree_wf.? (I (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/root_container
        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
       )
      ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_tree_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.container_tree_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.)
  (forall ((root_proc! Poly) (proc_tree_dom! Poly) (proc_perms! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.? root_proc!
      proc_tree_dom! proc_perms!
     ) (and
      (and
       (and
        (and
         (and
          (and
           (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_root_wf.? root_proc! proc_tree_dom!
            proc_perms!
           )
           (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_childern_parent_wf.? root_proc!
            proc_tree_dom! proc_perms!
          ))
          (OS__process_manager__spec_proof__impl2__endpoint_inv!procs_linkedlist_wf.? root_proc!
           proc_tree_dom! proc_perms!
         ))
         (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_childern_depth_wf.? root_proc!
          proc_tree_dom! proc_perms!
        ))
        (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_subtree_set_wf.? root_proc!
         proc_tree_dom! proc_perms!
       ))
       (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_uppertree_seq_wf.? root_proc!
        proc_tree_dom! proc_perms!
      ))
      (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_subtree_set_exclusive.?
       root_proc! proc_tree_dom! proc_perms!
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.? root_proc!
      proc_tree_dom! proc_perms!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.?_definition
))))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%17 Bool)
(declare-const %%global_location_label%%18 Bool)
(declare-const %%global_location_label%%19 Bool)
(assert
 (forall ((self! Poly) (container_ptr! Poly)) (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.
     self! container_ptr!
    ) (and
     (=>
      %%global_location_label%%17
      (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
         $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        )))
       ) container_ptr!
     ))
     (=>
      %%global_location_label%%18
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.?
       self!
     ))
     (=>
      %%global_location_label%%19
      (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
          $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
           (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
             (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
               )
              ) container_ptr!
   )))))))))))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.
     self! container_ptr!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_tree_wf._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_tree_wf._definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.)
  (forall ((self! Poly) (container_ptr! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.?
      self! container_ptr!
     ) (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.? (core!option.Option./Some/0
       $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) container_ptr!
       )))))))))
      ) (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
        $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
         (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) container_ptr!
       )))))))))
      ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
       (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
        (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_tree_wf.?
      self! container_ptr!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_tree_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_tree_wf.?_definition
))))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.
 (Poly) Bool
)
(declare-const %%global_location_label%%20 Bool)
(assert
 (forall ((self! Poly)) (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.
     self!
    ) (=>
     %%global_location_label%%20
     (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.?
      self!
   )))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.
     self!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_trees_wf._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_trees_wf._definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.?
      self!
     ) (and
      (forall ((c_ptr$ Poly)) (!
        (=>
         (has_type c_ptr$ USIZE)
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) c_ptr$
           )
           (is-core!option.Option./Some (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) c_ptr$
          )))))))))
          (OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.? (core!option.Option./Some/0
            $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) c_ptr$
            )))))))))
           ) (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
             $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) c_ptr$
            )))))))))
           ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        )))))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!proc_tree_wf.? (core!option.Option./Some/0
           $ USIZE (%Poly%core!option.Option. (Poly%core!option.Option. (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) c_ptr$
           )))))))))
          ) (vstd!seq_lib.impl&%0.to_set.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
            $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) c_ptr$
           )))))))))
          ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Process.>.>.
           (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/process_perms
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        ))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__process_trees_wf_0
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__process_trees_wf_0
      ))
      (forall ((c_ptr$ Poly)) (!
        (=>
         (has_type c_ptr$ USIZE)
         (=>
          (and
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
             )))
            ) c_ptr$
           )
           (is-core!option.Option./None (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) c_ptr$
          )))))))))
          (= (vstd!seq.Seq.len.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
             $ USIZE $ (CONST_INT 10) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                      )
                     ) c_ptr$
            )))))))))
           ) 0
        )))
        :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/root_process
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) c_ptr$
          ))))))
         ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/owned_procs
          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
            $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
             (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
               (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                  (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                 )
                ) c_ptr$
        ))))))))
        :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__process_trees_wf_1
        :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__process_trees_wf_1
    ))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_trees_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.process_trees_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.?
      self!
     ) (forall ((e_ptr$ Poly) (t_ptr$ Poly) (edp_idx$ Poly)) (!
       (=>
        (and
         (has_type e_ptr$ USIZE)
         (has_type t_ptr$ USIZE)
         (has_type edp_idx$ USIZE)
        )
        (=>
         (and
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )))
           ) e_ptr$
          )
          (vstd!iset.ISet.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!set.impl&%0.to_iset.?
            (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) e_ptr$
            ))))))))
           ) (Poly%tuple%2. (tuple%2./tuple%2 t_ptr$ edp_idx$))
         ))
         (or
          (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
               (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                   )
                  ) t_ptr$
            ))))))
           ) (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
               (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                   )
                  ) e_ptr$
          ))))))))
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (Poly%vstd!set.Set<usize.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Container./Container/subtree_set
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (vstd!raw_ptr.MemContents./Init/0
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container. (%Poly%vstd!raw_ptr.MemContents.
                 (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.
                   (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                     )
                    ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                         (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                           (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                             )
                            ) e_ptr$
            ))))))))))))))))
           ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                    )
                   ) t_ptr$
       ))))))))))))
       :pattern ((vstd!iset.ISet.contains.? (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (vstd!set.impl&%0.to_iset.?
          (DST $) (TYPE%tuple%2. $ USIZE $ USIZE) (Poly%vstd!set.Set<tuple%2<usize./usize.>.>.
           (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_threads
            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
              $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
               (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                 (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
                   )
                  ) e_ptr$
          ))))))))
         ) (Poly%tuple%2. (tuple%2./tuple%2 t_ptr$ edp_idx$))
       ))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_within_subtree_0
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoints_within_subtree_0
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoints_within_subtree.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.endpoints_within_subtree.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.? self!)
     (and
      (and
       (and
        (and
         (and
          (and
           (and
            (and
             (and
              (and
               (and
                (and
                 (and
                  (and
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.cpus_wf.? self!)
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_cpu_wf.? self!)
                  )
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.memory_disjoint.? self!)
                 )
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.processes_container_wf.?
                  self!
                ))
                (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_process_wf.?
                 self!
               ))
               (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_endpoint_descriptors_wf.?
                self!
              ))
              (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_queue_wf.?
               self!
             ))
             (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_container_wf.?
              self!
            ))
            (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.schedulers_wf.? self!)
           )
           (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.pcid_ioid_wf.? self!)
          )
          (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_cpu_wf.? self!)
         )
         (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_container_wf.?
          self!
        ))
        (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_tree_wf.?
         self!
       ))
       (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_trees_wf.? self!)
      )
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoints_within_subtree.?
       self!
    )))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.internal_wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.internal_wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.? self!) (and
      (and
       (and
        (and
         (and
          (and
           (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_perms_wf.?
            self!
           )
           (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.proc_perms_wf.? self!)
          )
          (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.threads_perms_wf.? self!)
         )
         (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.endpoint_perms_wf.?
          self!
        ))
        (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.container_fields_wf.?
         self!
       ))
       (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.process_fields_wf.?
        self!
      ))
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.internal_wf.? self!)
    ))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.? self!))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.wf.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__7.wf.?_definition
))))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.endpoint_dom.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.endpoint_dom.)
  (forall ((self! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.endpoint_dom.? self!)
     (%Poly%vstd!set.Set<usize.>. (vstd!map.impl&%0.dom.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo.
        $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
       ) (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
    )))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.endpoint_dom.?
      self!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.endpoint_dom.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.endpoint_dom.?_definition
))))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.
 (Poly Poly) Bool
)
(declare-const %%global_location_label%%21 Bool)
(declare-const %%global_location_label%%22 Bool)
(assert
 (forall ((self! Poly) (endpoint_ptr! Poly)) (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.
     self! endpoint_ptr!
    ) (and
     (=>
      %%global_location_label%%21
      (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.? self!)
     )
     (=>
      %%global_location_label%%22
      (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
         $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
         (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
           (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
        )))
       ) endpoint_ptr!
   ))))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.
     self! endpoint_ptr!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_endpoint._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_endpoint._definition
)))
(assert
 (fuel_bool_default fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.)
)
(assert
 (=>
  (fuel_bool fuel%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.)
  (forall ((self! Poly) (endpoint_ptr! Poly)) (!
    (= (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.?
      self! endpoint_ptr!
     ) (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
        (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
          (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. self!)
            )
           ) endpoint_ptr!
    )))))))
    :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.?
      self! endpoint_ptr!
    ))
    :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_endpoint.?_definition
    :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_endpoint.?_definition
))))
(assert
 (forall ((self! Poly) (endpoint_ptr! Poly)) (!
   (=>
    (and
     (has_type self! TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
     (has_type endpoint_ptr! USIZE)
    )
    (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.?
       self! endpoint_ptr!
      )
     ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
   ))
   :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%6.spec_get_endpoint.?
     self! endpoint_ptr!
   ))
   :qid internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_endpoint.?_pre_post_definition
   :skolemid skolem_internal_OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__6.spec_get_endpoint.?_pre_post_definition
)))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%0.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%0.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (REF A&.) A& self!) (vstd!view.View.view.? A&. A& self!))
    )
    :pattern ((vstd!view.View.view.? (REF A&.) A& self!))
    :qid internal_vstd!view.impl&__0.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__0.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%2.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%2.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (tr_bound%vstd!view.View. A&. A&)
     (= (vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (BOX $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__2.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__2.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%4.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%4.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (RC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__4.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__4.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%6.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%6.view.)
  (forall ((A&. Dcr) (A& Type) (self! Poly)) (!
    (=>
     (and
      (sized A&.)
      (tr_bound%vstd!view.View. A&. A&)
     )
     (= (vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!) (vstd!view.View.view.?
       A&. A& self!
    )))
    :pattern ((vstd!view.View.view.? (ARC $ TYPE%alloc!alloc.Global. A&.) A& self!))
    :qid internal_vstd!view.impl&__6.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__6.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%14.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%14.view.)
  (forall ((T&. Dcr) (T& Type) (self! Poly)) (!
    (=>
     (sized T&.)
     (= (vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!) self!)
    )
    :pattern ((vstd!view.View.view.? $ (TYPE%core!option.Option. T&. T&) self!))
    :qid internal_vstd!view.impl&__14.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__14.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%16.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%16.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ TYPE%tuple%0. self!) self!)
    :pattern ((vstd!view.View.view.? $ TYPE%tuple%0. self!))
    :qid internal_vstd!view.impl&__16.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__16.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%18.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%18.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ BOOL self!) self!)
    :pattern ((vstd!view.View.view.? $ BOOL self!))
    :qid internal_vstd!view.impl&__18.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__18.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%20.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%20.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 8) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 8) self!))
    :qid internal_vstd!view.impl&__20.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__20.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%26.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%26.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (UINT 64) self!) self!)
    :pattern ((vstd!view.View.view.? $ (UINT 64) self!))
    :qid internal_vstd!view.impl&__26.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__26.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%30.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%30.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ USIZE self!) self!)
    :pattern ((vstd!view.View.view.? $ USIZE self!))
    :qid internal_vstd!view.impl&__30.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__30.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%36.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%36.view.)
  (forall ((self! Poly)) (!
    (= (vstd!view.View.view.? $ (SINT 32) self!) self!)
    :pattern ((vstd!view.View.view.? $ (SINT 32) self!))
    :qid internal_vstd!view.impl&__36.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__36.view.?_definition
))))
(assert
 (fuel_bool_default fuel%vstd!view.impl&%48.view.)
)
(assert
 (=>
  (fuel_bool fuel%vstd!view.impl&%48.view.)
  (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type) (self! Poly)) (!
    (=>
     (and
      (sized A0&.)
      (sized A1&.)
      (tr_bound%vstd!view.View. A0&. A0&)
      (tr_bound%vstd!view.View. A1&. A1&)
     )
     (= (vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!) (Poly%tuple%2.
       (tuple%2./tuple%2 (vstd!view.View.view.? A0&. A0& (tuple%2./tuple%2/0 (%Poly%tuple%2.
           self!
         ))
        ) (vstd!view.View.view.? A1&. A1& (tuple%2./tuple%2/1 (%Poly%tuple%2. self!)))
    ))))
    :pattern ((vstd!view.View.view.? (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&) self!))
    :qid internal_vstd!view.impl&__48.view.?_definition
    :skolemid skolem_internal_vstd!view.impl&__48.view.?_definition
))))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (REF A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (REF A&.) A&))
   :qid internal_vstd__view__impl&__0_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__0_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%vstd!view.View. A&. A&)
    (tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (BOX $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__2_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (RC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__4_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__4_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%vstd!view.View. A&. A&)
    )
    (tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&)
   )
   :pattern ((tr_bound%vstd!view.View. (ARC $ TYPE%alloc!alloc.Global. A&.) A&))
   :qid internal_vstd__view__impl&__6_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__6_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type)) (!
   (=>
    (sized T&.)
    (tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&))
   )
   :pattern ((tr_bound%vstd!view.View. $ (TYPE%core!option.Option. T&. T&)))
   :qid internal_vstd__view__impl&__14_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__14_trait_impl_definition
)))
(assert
 (tr_bound%vstd!view.View. $ TYPE%tuple%0.)
)
(assert
 (tr_bound%vstd!view.View. $ BOOL)
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 8))
)
(assert
 (tr_bound%vstd!view.View. $ (UINT 64))
)
(assert
 (tr_bound%vstd!view.View. $ USIZE)
)
(assert
 (tr_bound%vstd!view.View. $ (SINT 32))
)
(assert
 (forall ((A0&. Dcr) (A0& Type) (A1&. Dcr) (A1& Type)) (!
   (=>
    (and
     (sized A0&.)
     (sized A1&.)
     (tr_bound%vstd!view.View. A0&. A0&)
     (tr_bound%vstd!view.View. A1&. A1&)
    )
    (tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&))
   )
   :pattern ((tr_bound%vstd!view.View. (DST A1&.) (TYPE%tuple%2. A0&. A0& A1&. A1&)))
   :qid internal_vstd__view__impl&__48_trait_impl_definition
   :skolemid skolem_internal_vstd__view__impl&__48_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__1_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__1_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.Fn. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (REF F&.) F& A&. A&))
   :qid internal_core__ops__function__impls__impl&__0_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__0_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnOnce. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnOnce. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__31_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__31_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.FnMut. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__32_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__32_trait_impl_definition
)))
(assert
 (forall ((Args&. Dcr) (Args& Type) (F&. Dcr) (F& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized Args&.)
     (sized A&.)
     (tr_bound%core!marker.Tuple. Args&. Args&)
     (tr_bound%core!ops.function.Fn. F&. F& Args&. Args&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&)
   )
   :pattern ((tr_bound%core!ops.function.Fn. (BOX A&. A& F&.) F& Args&. Args&))
   :qid internal_alloc__boxed__impl&__33_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__33_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type) (F&. Dcr) (F& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!marker.Tuple. A&. A&)
     (tr_bound%core!ops.function.FnMut. F&. F& A&. A&)
    )
    (tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&)
   )
   :pattern ((tr_bound%core!ops.function.FnMut. $ (MUTREF F&. F&) A&. A&))
   :qid internal_core__ops__function__impls__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__ops__function__impls__impl&__3_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. (REF A&.) A&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (REF A&.) A&))
   :qid internal_core__alloc__impl&__2_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__2_trait_impl_definition
)))
(assert
 (forall ((A&. Dcr) (A& Type)) (!
   (=>
    (tr_bound%core!alloc.Allocator. A&. A&)
    (tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&))
   )
   :pattern ((tr_bound%core!alloc.Allocator. $ (MUTREF A&. A&)))
   :qid internal_core__alloc__impl&__3_trait_impl_definition
   :skolemid skolem_internal_core__alloc__impl&__3_trait_impl_definition
)))
(assert
 (tr_bound%core!alloc.Allocator. $ TYPE%alloc!alloc.Global.)
)
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (BOX A&. A& T&.) T&))
   :qid internal_alloc__boxed__impl&__49_trait_impl_definition
   :skolemid skolem_internal_alloc__boxed__impl&__49_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (RC A&. A& T&.) T&))
   :qid internal_alloc__rc__impl&__116_trait_impl_definition
   :skolemid skolem_internal_alloc__rc__impl&__116_trait_impl_definition
)))
(assert
 (forall ((T&. Dcr) (T& Type) (A&. Dcr) (A& Type)) (!
   (=>
    (and
     (sized A&.)
     (tr_bound%core!alloc.Allocator. T&. T&)
     (tr_bound%core!alloc.Allocator. A&. A&)
    )
    (tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&)
   )
   :pattern ((tr_bound%core!alloc.Allocator. (ARC A&. A& T&.) T&))
   :qid internal_alloc__sync__impl&__118_trait_impl_definition
   :skolemid skolem_internal_alloc__sync__impl&__118_trait_impl_definition
)))
(declare-fun req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%8.endpoint_inv.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) Bool
)
(declare-const %%global_location_label%%23 Bool)
(assert
 (forall ((self! OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%8.endpoint_inv.
     self!
    ) (=>
     %%global_location_label%%23
     (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.? (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
       self!
   ))))
   :pattern ((req%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%8.endpoint_inv.
     self!
   ))
   :qid internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__8.endpoint_inv._definition
   :skolemid skolem_internal_req__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__8.endpoint_inv._definition
)))
(declare-fun ens%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%8.endpoint_inv.
 (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.) Bool
)
(assert
 (forall ((self! OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.))
  (!
   (= (ens%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%8.endpoint_inv.
     self!
    ) (and
     (forall ((e_ptr$ Poly)) (!
       (=>
        (has_type e_ptr$ USIZE)
        (=>
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                self!
           )))))
          ) e_ptr$
         )
         (and
          (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
            128
           ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                       self!
                    )))
                   ) e_ptr$
          )))))))))
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                 self!
            )))))
           ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
               $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                  (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                       self!
                    )))
                   ) e_ptr$
       ))))))))))))
       :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
           $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
           (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
             (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
               self!
          )))))
         ) e_ptr$
       ))
       :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE
         $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
            (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
             (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                     self!
                  )))
                 ) e_ptr$
       ))))))))))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_0
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_0
     ))
     (forall ((e_ptr$ Poly) (i$ Poly)) (!
       (=>
        (and
         (has_type e_ptr$ USIZE)
         (has_type i$ INT)
        )
        (=>
         (and
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                 self!
            )))))
           ) e_ptr$
          )
          (let
           ((tmp%%$ 0))
           (let
            ((tmp%%$1 (%I i$)))
            (let
             ((tmp%%$2 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.? $
                USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                 (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                   (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                    (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                       $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                        $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                        (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                         (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                          (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                            self!
                         )))
                        ) e_ptr$
             )))))))))))
             (and
              (<= tmp%%$ tmp%%$1)
              (< tmp%%$1 tmp%%$2)
         )))))
         (and
          (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                 self!
            )))))
           ) (vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
             $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                 (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                    $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                     $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                         self!
                      )))
                     ) e_ptr$
             ))))))))
            ) i$
          ))
          (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
             (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
              (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                      self!
                   )))
                  ) (vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
                    $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                       (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                        (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                           $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                                self!
                             )))
                            ) e_ptr$
                    ))))))))
                   ) i$
            )))))))
           ) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./BLOCKED
       ))))
       :pattern ((vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
          $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
           (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
             (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
              (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                      self!
                   )))
                  ) e_ptr$
          ))))))))
         ) i$
       ))
       :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_1
       :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_1
   ))))
   :pattern ((ens%OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%8.endpoint_inv.
     self!
   ))
   :qid internal_ens__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__8.endpoint_inv._definition
   :skolemid skolem_internal_ens__OS__process_manager__spec_proof__impl2__endpoint_inv!impl&__8.endpoint_inv._definition
)))
(push)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const self! OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.)
(declare-const tmp%1 Bool)
(assert
 fuel_defaults
)
(assert
 (has_type (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
   self!
  ) TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
))
(assert
 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%7.wf.? (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
   self!
)))
(declare-const %%location_label%%0 Bool)
(declare-const %%location_label%%1 Bool)
(declare-const %%location_label%%2 Bool)
(assert
 (not (=>
   (= tmp%1 (forall ((e_ptr$ Poly) (i$ Poly)) (!
      (=>
       (and
        (has_type e_ptr$ USIZE)
        (has_type i$ INT)
       )
       (=>
        (and
         (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
            $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
            (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
              (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                self!
           )))))
          ) e_ptr$
         )
         (let
          ((tmp%%$ 0))
          (let
           ((tmp%%$1 (%I i$)))
           (let
            ((tmp%%$2 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.? $
               USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                       $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                           self!
                        )))
                       ) e_ptr$
            )))))))))))
            (and
             (<= tmp%%$ tmp%%$1)
             (< tmp%%$1 tmp%%$2)
        )))))
        (vstd!seq_lib.impl&%0.contains.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
          $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
           (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
             (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
              (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                  $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                  (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                    (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                      self!
                   )))
                  ) e_ptr$
          ))))))))
         ) (vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
           $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                       self!
                    )))
                   ) e_ptr$
           ))))))))
          ) i$
      ))))
      :pattern ((vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
         $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
          (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
            (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
             (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                 $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                 (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                  (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                   (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                     self!
                  )))
                 ) e_ptr$
         ))))))))
        ) i$
      ))
      :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_4
      :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_4
   )))
   (and
    (=>
     %%location_label%%0
     tmp%1
    )
    (=>
     tmp%1
     (and
      (=>
       %%location_label%%1
       (forall ((e_ptr$ Poly)) (!
         (=>
          (has_type e_ptr$ USIZE)
          (=>
           (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                  self!
             )))))
            ) e_ptr$
           )
           (and
            (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE $ (CONST_INT
              128
             ) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList. (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                         self!
                      )))
                     ) e_ptr$
            )))))))))
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Container.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Container.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/container_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                   self!
              )))))
             ) (I (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/owning_container
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!raw_ptr.MemContents./Init/0
                 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (%Poly%vstd!raw_ptr.MemContents.
                  (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.? $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                    (vstd!map.impl&%0.index.? $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                     (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                      (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                       (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                         self!
                      )))
                     ) e_ptr$
         ))))))))))))
         :pattern ((vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
             $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
             (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
              (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
               (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                 self!
            )))))
           ) e_ptr$
         ))
         :pattern ((OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.wf.? $ USIZE
           $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
            (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
              (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
               (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                  $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                   $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                   (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                    (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                     (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                       self!
                    )))
                   ) e_ptr$
         ))))))))))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_2
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_2
      )))
      (=>
       %%location_label%%2
       (forall ((e_ptr$ Poly) (i$ Poly)) (!
         (=>
          (and
           (has_type e_ptr$ USIZE)
           (has_type i$ INT)
          )
          (=>
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                   self!
              )))))
             ) e_ptr$
            )
            (let
             ((tmp%%$ 0))
             (let
              ((tmp%%$1 (%I i$)))
              (let
               ((tmp%%$2 (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.spec_len.? $
                  USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                   (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                     (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                      (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                         $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                          $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                          (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                           (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                            (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                              self!
                           )))
                          ) e_ptr$
               )))))))))))
               (and
                (<= tmp%%$ tmp%%$1)
                (< tmp%%$1 tmp%%$2)
           )))))
           (and
            (vstd!iset.ISet.contains.? $ USIZE (vstd!set.impl&%0.to_iset.? $ USIZE (vstd!map.impl&%0.dom.?
               $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
               (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                 (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                   self!
              )))))
             ) (vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
               $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                  (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                   (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                      $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                       $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                       (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                        (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                         (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                           self!
                        )))
                       ) e_ptr$
               ))))))))
              ) i$
            ))
            (= (OS__process_manager__spec_proof__impl2__endpoint_inv!Thread./Thread/state (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
               (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.
                (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread. (vstd!map.impl&%0.index.?
                    $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Thread.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/thread_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                        self!
                     )))
                    ) (vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
                      $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
                       (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                         (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                          (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                             $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                              $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                              (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                               (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                                (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                                  self!
                               )))
                              ) e_ptr$
                      ))))))))
                     ) i$
              )))))))
             ) OS__process_manager__spec_proof__impl2__endpoint_inv!ThreadState./BLOCKED
         ))))
         :pattern ((vstd!seq.Seq.index.? $ USIZE (OS__process_manager__spec_proof__impl2__endpoint_inv!impl&%1.view.?
            $ USIZE $ (CONST_INT 128) (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!StaticLinkedList.
             (OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint./Endpoint/queue (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
               (vstd!raw_ptr.MemContents./Init/0 $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.
                (%Poly%vstd!raw_ptr.MemContents. (Poly%vstd!raw_ptr.MemContents. (vstd!simple_pptr.impl&%1.mem_contents.?
                   $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint. (vstd!map.impl&%0.index.?
                    $ USIZE $ (TYPE%vstd!simple_pptr.PointsTo. $ TYPE%OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.)
                    (Poly%vstd!map.Map<usize./vstd!simple_pptr.PointsTo<OS__process_manager__spec_proof__impl2__endpoint_inv!Endpoint.>.>.
                     (OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager./ProcessManager/endpoint_perms
                      (%Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager. (Poly%OS__process_manager__spec_proof__impl2__endpoint_inv!ProcessManager.
                        self!
                     )))
                    ) e_ptr$
            ))))))))
           ) i$
         ))
         :qid user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_3
         :skolemid skolem_user_OS__process_manager__spec_proof__impl2__endpoint_inv__ProcessManager__endpoint_inv_3
)))))))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
