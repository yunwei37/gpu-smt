(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ret@ (_ BitVec 64))
(assert
 (= (bvand ret@ (_ bv18446462598732844924 64)) ((_ zero_extend 63) (_ bv0 1)))
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (bvand ret@ ((_ zero_extend 1) (_ bv9223090561878069116 63))) ((_ zero_extend 63)
     (_ bv0 1)
)))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
