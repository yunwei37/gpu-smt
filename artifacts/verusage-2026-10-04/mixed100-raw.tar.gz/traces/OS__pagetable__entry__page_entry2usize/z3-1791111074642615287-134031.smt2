(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ghost_ret@ (_ BitVec 64))
(assert
 (= (bvand ghost_ret@ (_ bv18446462598732845054 64)) ((_ zero_extend 63) (_ bv0 1)))
)
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (bvand (bvor ghost_ret@ ((_ zero_extend 56) (_ bv128 8))) (_ bv18446462598732844926
      64
     )
    ) ((_ zero_extend 63) (_ bv0 1))
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
