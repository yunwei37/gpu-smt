(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ghost_ret@ (_ BitVec 64))
(declare-const ret@ (_ BitVec 64))
(declare-const ghost_write@ Bool)
(assert
 (and
  (= ghost_ret@ ret@)
  (= (not (= (bvand ret@ ((_ zero_extend 62) (_ bv2 2))) ((_ zero_extend 63) (_ bv0 1))))
   ghost_write@
)))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (not (= (bvand (bvor ret@ (_ bv9223372036854775808 64)) ((_ zero_extend 62) (_ bv2 2)))
      ((_ zero_extend 63) (_ bv0 1))
     )
    ) ghost_write@
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
