(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ghost_addr@ (_ BitVec 64))
(declare-const ret@ (_ BitVec 64))
(assert
 (and
  (= (bvand ghost_addr@ (_ bv18446462598732845055 64)) ((_ zero_extend 63) (_ bv0 1)))
  (= ghost_addr@ ret@)
))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (bvand (bvor ret@ ((_ zero_extend 63) (_ bv1 1))) ((_ zero_extend 16) (_ bv281474976706560
       48
     ))
    ) ghost_addr@
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
