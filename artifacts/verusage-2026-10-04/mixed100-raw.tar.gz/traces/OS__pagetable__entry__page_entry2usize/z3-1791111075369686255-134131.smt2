(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ghost_ret@ (_ BitVec 64))
(declare-const ret@ (_ BitVec 64))
(declare-const ghost_ps@ Bool)
(assert
 (and
  (= ghost_ret@ ret@)
  (= (not (= (bvand ret@ ((_ zero_extend 56) (_ bv128 8))) ((_ zero_extend 63) (_ bv0 1))))
   ghost_ps@
)))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (not (= (bvand (bvor ret@ ((_ zero_extend 61) (_ bv4 3))) ((_ zero_extend 56) (_ bv128
         8
       ))
      ) ((_ zero_extend 63) (_ bv0 1))
     )
    ) ghost_ps@
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
