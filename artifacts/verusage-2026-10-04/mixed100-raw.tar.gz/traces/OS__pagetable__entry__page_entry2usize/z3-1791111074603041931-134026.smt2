(declare-sort %%Function%% 0)
(get-info :all-statistics)

(echo "<<DONE>>")
(declare-const ghost_ret@ (_ BitVec 64))
(declare-const ret@ (_ BitVec 64))
(declare-const ghost_addr@ (_ BitVec 64))
(assert
 (and
  (= ghost_ret@ ret@)
  (= (bvand ghost_ret@ ((_ zero_extend 16) (_ bv281474976706560 48))) ghost_addr@)
))
(declare-const %%location_label%%0 Bool)
(assert
 (not (=>
   %%location_label%%0
   (= (bvand (bvor ret@ ((_ zero_extend 56) (_ bv128 8))) ((_ zero_extend 16) (_ bv281474976706560
       48
     ))
    ) ghost_addr@
))))
(get-info :all-statistics)

(echo "<<DONE>>")
(get-info :version)

(echo "<<DONE>>")
(set-option :rlimit 30000000)
(check-sat)

(echo "<<DONE>>")
(set-option :rlimit 0)
(get-info :all-statistics)

(echo "<<DONE>>")
