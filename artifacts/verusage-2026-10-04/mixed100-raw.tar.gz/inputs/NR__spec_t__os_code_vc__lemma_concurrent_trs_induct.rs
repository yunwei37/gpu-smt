use vstd::prelude::*;
use crate::defs::*;
use crate::theorem::RLbl;

fn main() {}

verus!{

global size_of usize == 8;

// File: spec_t/mmu/rl1.rs
pub mod rl1 {
use vstd::prelude::*;
use crate::{PTE, PTMem, rl3::Writes, Polarity, Core, aligned, Constants, Lbl, MASK_NEG_DIRTY_ACCESS, MemOp, LoadResult };

pub struct State {
    pub happy: bool,
    /// Byte-indexed physical (non-page-table) memory
    pub phys_mem: Seq<u8>,
    /// Page table memory
    pub pt_mem: PTMem,
    /// Per-node state (TLBs)
    pub tlbs: Map<Core, Map<usize, PTE>>,
    pub writes: Writes,
    /// Tracks the virtual addresses and entries for which we may see non-atomic results.
    /// If polarity is positive, translations may non-atomically fail.
    /// If polarity is negative, translations may non-atomically succeed.
    pub pending_maps: Map<usize, PTE>,
    pub pending_unmaps: Map<usize, PTE>,
    pub polarity: Polarity,
}
}

// File: spec_t/mmu/rl2.rs
pub mod rl2 {

use vstd::prelude::*;
use crate::{PTMem, PTE, Walk, Polarity, Constants, aligned, Core, rl3::Writes};
//use crate::SeqTupExt;

pub struct State {
    pub happy: bool,
    /// Byte-indexed physical (non-page-table) memory
    pub phys_mem: Seq<u8>,
    /// Page table memory
    pub pt_mem: PTMem,
    /// Per-node state (TLBs)
    pub tlbs: Map<Core, Map<usize, PTE>>,
    /// In-progress page table walks
    pub walks: Map<Core, Set<Walk>>,
    /// Store buffers
    pub sbuf: Map<Core, Seq<(usize, usize)>>,
    pub writes: Writes,
    pub polarity: Polarity,
    pub hist: History,
}

pub struct History {
    pub pending_maps: Map<usize, PTE>,
    pub pending_unmaps: Map<usize, PTE>,
}

impl State {

    pub open spec fn core_mem(self, core: Core) -> PTMem {
        self.pt_mem.write_seq(self.sbuf[core])
    }

    #[verifier(inline)]
    pub open spec fn writer_mem(self) -> PTMem {
        self.core_mem(self.writes.core)
    }

}


pub mod refinement {

    impl crate::rl2::State {

        pub open spec fn interp(self) -> crate::rl1::State {
            crate::rl1::State {
                happy: self.happy,
                pt_mem: self.writer_mem(),
                phys_mem: self.phys_mem,
                tlbs: self.tlbs,
                writes: self.writes,
                pending_maps: self.hist.pending_maps,
                pending_unmaps: self.hist.pending_unmaps,
                polarity: self.polarity,
            }
        }
    }

}
}


// File: spec_t/mmu/rl3.rs
pub mod rl3 {
use vstd::prelude::*;
use crate::{PTE, Walk, PTMem, Polarity, Constants, Core, Lbl};

pub struct State {
    /// Byte-indexed physical (non-page-table) memory
    phys_mem: Seq<u8>,
    /// Page table memory
    pt_mem: PTMem,
    /// Per-node state (TLBs)
    tlbs: Map<Core, Map<usize, PTE>>,
    /// In-progress page table walks
    walks: Map<Core, Set<Walk>>,
    /// Translation caches
    cache: Map<Core, Set<Walk>>,
    /// Store buffers
    sbuf: Map<Core, Seq<(usize, usize)>>,
}

pub struct Writes {
    /// Current writer core. If `all` is non-empty, all those writes were done by this core.
    pub core: Core,
    /// Tracks all writes that may cause stale reads due to TSO. Set of addresses. Gets cleared
    /// when the corresponding core drains its store buffer.
    pub tso: Set<usize>,
    /// Tracks staleness resulting from non-atomicity and translation caching. Cleared by invlpg if
    /// store buffers are empty.
    pub nonpos: Set<Core>,
}

pub enum Step {
    Invlpg,
    // Faulting memory op due to failed translation
    MemOpNoTr { walk: Walk, r: usize },
    // Memory op using a translation from the TLB
    MemOpTLB { tlb_va: usize },
    // Translation caching
    CacheFill { core: Core, walk: Walk },
    CacheUse { core: Core, walk: Walk },
    CacheEvict { core: Core, walk: Walk },
    // Non-atomic page table walks
    WalkInit { core: Core, vaddr: usize },
    WalkStep { core: Core, walk: Walk, r: usize },
    WalkAbort { core: Core, walk: Walk },
    TLBFill { core: Core, walk: Walk, r: usize },
    TLBEvict { core: Core, tlb_va: usize },
    // TSO, operations on page table memory
    Write,
    Writeback { core: Core },
    Read { r: usize },
    Barrier,
    Stutter,
}

	#[verifier::external_body]
pub closed spec fn step_Invlpg(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_MemOpNoTr(
    pre: State,
    post: State,
    c: Constants,
    walk: Walk,
    r: usize,
    lbl: Lbl,
) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_MemOpTLB(
    pre: State,
    post: State,
    c: Constants,
    tlb_va: usize,
    lbl: Lbl,
) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_CacheFill(pre: State, post: State, c: Constants, core: Core, walk: Walk, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_CacheUse(pre: State, post: State, c: Constants, core: Core, walk: Walk, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_CacheEvict(pre: State, post: State, c: Constants, core: Core, walk: Walk, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_WalkInit(pre: State, post: State, c: Constants, core: Core, vaddr: usize, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_WalkStep(
    pre: State,
    post: State,
    c: Constants,
    core: Core,
    walk: Walk,
    r: usize,
    lbl: Lbl
    ) -> bool
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub closed spec fn step_WalkAbort(
    pre: State,
    post: State,
    c: Constants,
    core: Core,
    walk: Walk,
    lbl: Lbl
    ) -> bool
	{
		unimplemented!()
	}

	#[verifier::external_body]
pub closed spec fn step_TLBFill(pre: State, post: State, c: Constants, core: Core, walk: Walk, r: usize, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_TLBEvict(pre: State, post: State, c: Constants, core: Core, tlb_va: usize, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_Write(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_Writeback(pre: State, post: State, c: Constants, core: Core, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_Read(pre: State, post: State, c: Constants, r: usize, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_Barrier(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
		unimplemented!()
	}


	#[verifier::external_body]
pub closed spec fn step_Stutter(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
		unimplemented!()
	}


pub open spec fn next_step(pre: State, post: State, c: Constants, step: Step, lbl: Lbl) -> bool {
    match step {
        //Step::ReadWrite { paddr, wr }    => step_ReadWrite(pre, post, c, paddr, wr, lbl),
        Step::Invlpg                       => step_Invlpg(pre, post, c, lbl),
        Step::MemOpNoTr { walk, r }        => step_MemOpNoTr(pre, post, c, walk, r, lbl),
        Step::MemOpTLB { tlb_va }          => step_MemOpTLB(pre, post, c, tlb_va, lbl),
        Step::CacheFill { core, walk }     => step_CacheFill(pre, post, c, core, walk, lbl),
        Step::CacheUse { core, walk }      => step_CacheUse(pre, post, c, core, walk, lbl),
        Step::CacheEvict { core, walk }    => step_CacheEvict(pre, post, c, core, walk, lbl),
        Step::WalkInit { core, vaddr }     => step_WalkInit(pre, post, c, core, vaddr, lbl),
        Step::WalkStep { core, walk, r }   => step_WalkStep(pre, post, c, core, walk, r, lbl),
        Step::WalkAbort { core, walk }     => step_WalkAbort(pre, post, c, core, walk, lbl),
        Step::TLBFill { core, walk, r }    => step_TLBFill(pre, post, c, core, walk, r, lbl),
        Step::TLBEvict { core, tlb_va }    => step_TLBEvict(pre, post, c, core, tlb_va, lbl),
        //Step::WalkDone { core, walk, r } => step_WalkDone(pre, post, c, core, walk, r, lbl),
        Step::Write                        => step_Write(pre, post, c, lbl),
        Step::Writeback { core }           => step_Writeback(pre, post, c, core, lbl),
        Step::Read { r }                   => step_Read(pre, post, c, r, lbl),
        Step::Barrier                      => step_Barrier(pre, post, c, lbl),
        Step::Stutter                      => step_Stutter(pre, post, c, lbl),
    }
}

pub open spec fn next(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    exists|step| next_step(pre, post, c, step, lbl)
}

pub mod refinement{

    impl crate::rl3::State {

	#[verifier::external_body]
        pub closed spec fn interp(self) -> crate::rl2::State {
		unimplemented!()
	}
    }

    pub mod to_rl1 {

        impl crate::rl3::State {

            pub open spec fn view(self) -> crate::rl1::State {
                self.interp().interp()
            }
        }
    }

}
}


// File: spec_t/mmu/pt_mem.rs
pub struct PTMem {
    pub mem: Map<usize, usize>,
    pub pml4: usize,
}

impl PTMem {

    pub open spec fn write(self, addr: usize, value: usize) -> PTMem {
        PTMem {
            mem: self.mem.insert(addr, value),
            pml4: self.pml4,
        }
    }

    pub open spec fn read(self, addr: usize) -> usize {
        self.mem[addr]
    }

    pub open spec fn write_seq(self, writes: Seq<(usize, usize)>) -> Self {
        writes.fold_left(self, |acc: PTMem, wr: (_, _)| acc.write(wr.0, wr.1))
    }

	#[verifier::external_body]
    pub open spec fn view(self) -> Map<usize,PTE> {
		unimplemented!()
	}


}



// File: spec_t/mmu/translation.rs
pub ghost enum GPDE {
    Directory {
        addr: usize,
        /// Present; must be 1 to map a page or reference a directory
        P: bool,
        /// Read/write; if 0, writes may not be allowed to the page controlled by this entry
        RW: bool,
        /// User/supervisor; user-mode accesses are not allowed to the page controlled by this entry
        US: bool,
        /// Page-level write-through
        PWT: bool,
        /// Page-level cache disable
        PCD: bool,
        ///// Accessed; indicates whether software has accessed the page referenced by this entry
        //A: bool,
        /// If IA32_EFER.NXE = 1, execute-disable (if 1, instruction fetches are not allowed from
        /// the page controlled by this entry); otherwise, reserved (must be 0)
        XD: bool,
    },
    Page {
        addr: usize,
        /// Present; must be 1 to map a page or reference a directory
        P: bool,
        /// Read/write; if 0, writes may not be allowed to the page controlled by this entry
        RW: bool,
        /// User/supervisor; if 0, user-mode accesses are not allowed to the page controlled by this entry
        US: bool,
        /// Page-level write-through
        PWT: bool,
        /// Page-level cache disable
        PCD: bool,
        ///// Accessed; indicates whether software has accessed the page referenced by this entry
        //A: bool,
        ///// Dirty; indicates whether software has written to the page referenced by this entry
        //D: bool,
        // /// Page size; must be 1 (otherwise, this entry references a directory)
        // PS: Option<bool>,
        // PS is entirely determined by the Page variant and the layer
        /// Global; if CR4.PGE = 1, determines whether the translation is global; ignored otherwise
        G: bool,
        /// Indirectly determines the memory type used to access the page referenced by this entry
        PAT: bool,
        /// If IA32_EFER.NXE = 1, execute-disable (if 1, instruction fetches are not allowed from
        /// the page controlled by this entry); otherwise, reserved (must be 0)
        XD: bool,
    },
    /// An `Invalid` entry is an entry that does not contain a valid mapping. I.e. the entry is
    /// either empty or has a bit set that the intel manual designates as must-be-zero. Both empty
    /// and invalid entries cause a page fault if used during translation.
    Invalid,
}

pub const MASK_FLAG_P: usize = bit!(0usize);

pub const MASK_FLAG_RW: usize = bit!(1usize);

pub const MASK_FLAG_US: usize = bit!(2usize);

pub const MASK_FLAG_PWT: usize = bit!(3usize);

pub const MASK_FLAG_PCD: usize = bit!(4usize);

pub const MASK_FLAG_XD: usize = bit!(63usize);

pub const MASK_PG_FLAG_G: usize = bit!(8usize);

pub const MASK_PG_FLAG_PAT: usize = bit!(12usize);

pub const MASK_L1_PG_FLAG_PS: usize = bit!(7usize);

pub const MASK_L2_PG_FLAG_PS: usize = bit!(7usize);

pub const MASK_L3_PG_FLAG_PAT: usize = bit!(7usize);

pub const MASK_DIRTY_ACCESS: usize = bit!(5) | bit!(6);
pub const MASK_NEG_DIRTY_ACCESS: usize = !MASK_DIRTY_ACCESS;

pub spec const MASK_ADDR_SPEC: usize = bitmask_inc!(12usize, MAX_PHYADDR_WIDTH - 1);

#[verifier::when_used_as_spec(MASK_ADDR_SPEC)]
pub exec const MASK_ADDR: usize ensures MASK_ADDR == MASK_ADDR_SPEC {
    proof {
        axiom_max_phyaddr_width_facts();
    }
    bitmask_inc!(12usize, MAX_PHYADDR_WIDTH - 1)
}

pub spec const MASK_L1_PG_ADDR_SPEC: usize = bitmask_inc!(30usize, MAX_PHYADDR_WIDTH - 1);
#[verifier::when_used_as_spec(MASK_L1_PG_ADDR_SPEC)]
pub exec const MASK_L1_PG_ADDR: usize ensures MASK_L1_PG_ADDR == MASK_L1_PG_ADDR_SPEC {
    proof {
        axiom_max_phyaddr_width_facts();
    }
    bitmask_inc!(30usize, MAX_PHYADDR_WIDTH - 1)
}


pub spec const MASK_L2_PG_ADDR_SPEC: usize = bitmask_inc!(21usize, MAX_PHYADDR_WIDTH - 1);
#[verifier::when_used_as_spec(MASK_L2_PG_ADDR_SPEC)]
pub exec const MASK_L2_PG_ADDR: usize ensures MASK_L2_PG_ADDR == MASK_L2_PG_ADDR_SPEC {
    proof {
        axiom_max_phyaddr_width_facts();
    }
    bitmask_inc!(21usize, MAX_PHYADDR_WIDTH - 1)
}


pub spec const MASK_L3_PG_ADDR_SPEC: usize = bitmask_inc!(12usize, MAX_PHYADDR_WIDTH - 1);

#[verifier::when_used_as_spec(MASK_L3_PG_ADDR_SPEC)]
pub exec const MASK_L3_PG_ADDR: usize ensures MASK_L3_PG_ADDR == MASK_L3_PG_ADDR_SPEC {
    proof {
        axiom_max_phyaddr_width_facts();
    }
    bitmask_inc!(12usize, MAX_PHYADDR_WIDTH - 1)
}

#[allow(unused_macros)]
macro_rules! l0_bits {
    ($addr:expr) => { ($addr & bitmask_inc!(39usize,47usize)) >> 39usize }
}

pub(crate) use l0_bits;

#[allow(unused_macros)]
macro_rules! l1_bits {
    ($addr:expr) => { ($addr & bitmask_inc!(30usize,38usize)) >> 30usize }
}

pub(crate) use l1_bits;

#[allow(unused_macros)]
macro_rules! l2_bits {
    ($addr:expr) => { ($addr & bitmask_inc!(21usize,29usize)) >> 21usize }
}

pub(crate) use l2_bits;

#[allow(unused_macros)]
macro_rules! l3_bits {
    ($addr:expr) => { ($addr & bitmask_inc!(12usize,20usize)) >> 12usize }
}

pub(crate) use l3_bits;

#[repr(transparent)]
pub struct PDE {
    pub entry: usize,
    pub layer: Ghost<nat>,
}

impl PDE {

    pub open spec fn view(self) -> GPDE {
        let v = self.entry;
        let P   = v & MASK_FLAG_P    == MASK_FLAG_P;
        let RW  = v & MASK_FLAG_RW   == MASK_FLAG_RW;
        let US  = v & MASK_FLAG_US   == MASK_FLAG_US;
        let PWT = v & MASK_FLAG_PWT  == MASK_FLAG_PWT;
        let PCD = v & MASK_FLAG_PCD  == MASK_FLAG_PCD;
        let XD  = v & MASK_FLAG_XD   == MASK_FLAG_XD;
        let G   = v & MASK_PG_FLAG_G == MASK_PG_FLAG_G;
        if v & MASK_FLAG_P == MASK_FLAG_P && self.all_mb0_bits_are_zero() {
            if self.layer == 0 {
                let addr = v & MASK_ADDR;
                GPDE::Directory { addr, P, RW, US, PWT, PCD, XD }
            } else if self.layer == 1 {
                if v & MASK_L1_PG_FLAG_PS == MASK_L1_PG_FLAG_PS {
                    // super page mapping
                    let addr = v & MASK_L1_PG_ADDR;
                    let PAT = v & MASK_PG_FLAG_PAT == MASK_PG_FLAG_PAT;
                    GPDE::Page { addr, P, RW, US, PWT, PCD, G, PAT, XD }
                } else {
                    let addr = v & MASK_ADDR;
                    GPDE::Directory { addr, P, RW, US, PWT, PCD, XD }
                }
            } else if self.layer == 2 {
                if v & MASK_L2_PG_FLAG_PS == MASK_L2_PG_FLAG_PS {
                    // huge page mapping
                    let addr = v & MASK_L2_PG_ADDR;
                    let PAT = v & MASK_PG_FLAG_PAT == MASK_PG_FLAG_PAT;
                    GPDE::Page { addr, P, RW, US, PWT, PCD, G, PAT, XD }
                } else {
                    let addr = v & MASK_ADDR;
                    GPDE::Directory { addr, P, RW, US, PWT, PCD, XD }
                }
            } else if self.layer == 3 {
                let addr = v & MASK_L3_PG_ADDR;
                let PAT = v & MASK_L3_PG_FLAG_PAT == MASK_L3_PG_FLAG_PAT;
                GPDE::Page { addr, P, RW, US, PWT, PCD, G, PAT, XD }
            } else {
                arbitrary()
            }
        } else {
            GPDE::Invalid
        }
    }

	#[verifier::external_body]
    pub open spec fn all_mb0_bits_are_zero(self) -> bool {
		unimplemented!()
	}


}



// File: spec_t/mmu/defs.rs
pub mod defs {
use vstd::prelude::*;
use crate::{PDE, MASK_NEG_DIRTY_ACCESS, MASK_PG_FLAG_PAT};

macro_rules! bitmask_inc {
    ($low:expr,$high:expr) => {
        (!(!0usize << (($high+1usize)-$low))) << $low
    }
}

pub(crate) use bitmask_inc;

macro_rules! bit {
    ($v:expr) => {
        1usize << $v
    }
}

pub(crate) use bit;


pub const X86_NUM_LAYERS: usize = 4;

pub const X86_NUM_ENTRIES: usize = 512;

#[verifier(external_body)]
pub const MAX_PHYADDR_WIDTH: usize = 52;

pub axiom fn axiom_max_phyaddr_width_facts()
    ensures
        32 <= MAX_PHYADDR_WIDTH <= 52,
;
pub spec const MAX_PHYADDR_SPEC: usize = ((1usize << MAX_PHYADDR_WIDTH) - 1usize) as usize;
#[verifier::when_used_as_spec(MAX_PHYADDR_SPEC)]
pub exec const MAX_PHYADDR: usize ensures MAX_PHYADDR == MAX_PHYADDR_SPEC {
    proof {
        axiom_max_phyaddr_width_facts();
    }
    assert(1usize << 32 == 0x100000000) by (compute);
    assert(forall|m:usize,n:usize|  n < m < 64 ==> 1usize << n < 1usize << m) by (bit_vector);
    (1usize << MAX_PHYADDR_WIDTH) - 1usize
}


pub const PAGE_SIZE: usize = 4096;

pub spec const X86_MAX_ENTRY_SIZE: nat = 512 * 512 * 512 * 4096;

pub const L3_ENTRY_SIZE: usize = PAGE_SIZE;

pub const L2_ENTRY_SIZE: usize = 512 * L3_ENTRY_SIZE;

pub const L1_ENTRY_SIZE: usize = 512 * L2_ENTRY_SIZE;

pub const L0_ENTRY_SIZE: usize = 512 * L1_ENTRY_SIZE;

pub open spec fn entry_base_from_index(base: nat, idx: nat, entry_size: nat) -> nat {
    base + idx * entry_size
}

pub open spec fn candidate_mapping_in_bounds(base: nat, pte: PTE) -> bool {
    base + pte.frame.size < x86_arch_spec.upper_vaddr(0, 0)
}

pub open spec fn candidate_mapping_in_bounds_pmem(c: crate::Constants, pte: PTE) -> bool {
    pte.frame.base + pte.frame.size <= c.range_mem.1
}

pub open spec fn candidate_mapping_overlaps_existing_vmem(
    mappings: Map<nat, PTE>,
    base: nat,
    pte: PTE,
) -> bool {
    exists|b: nat| {
        &&& #[trigger] mappings.contains_key(b)
        &&& overlap(
            MemRegion { base: base, size: pte.frame.size },
            MemRegion { base: b, size: mappings[b].frame.size },
        )
    }
}

pub open spec fn candidate_mapping_overlaps_existing_pmem(mappings: Map<nat, PTE>, pte: PTE) -> bool {
    exists|b: nat| #![auto] {
            &&& mappings.dom().contains(b)
            &&& overlap(pte.frame, mappings.index(b).frame)
        }
}

pub open spec(checked) fn aligned(addr: nat, size: nat) -> bool {
    addr % size == 0
}

pub open spec fn between(x: nat, a: nat, b: nat) -> bool {
    a <= x && x < b
}

#[derive(Copy, Clone)]
pub struct Core {
    pub node_id: nat,
    pub core_id: nat,
}

pub enum LoadResult {
    Pagefault,
    Value(Seq<u8>),
}

pub enum StoreResult {
    Pagefault,
    Ok,
}

#[allow(inconsistent_fields)]
pub enum MemOp {
    Load { is_exec: bool, size: nat, result: LoadResult },
    Store { new_value: Seq<u8>, result: StoreResult },
}

pub struct MemRegion {
    pub base: nat,
    pub size: nat,
}

impl MemRegion {

    pub open spec fn contains(self, addr: nat) -> bool {
        between(addr, self.base, self.base + self.size)
    }

}


pub open spec fn overlap(region1: MemRegion, region2: MemRegion) -> bool {
    if region1.base <= region2.base {
        region1.base == region2.base || region2.base < region1.base + region1.size
    } else {
        region1.base < region2.base + region2.size
    }
}

#[derive(Copy, Clone)]
pub struct Flags {
    pub is_writable: bool,
    pub is_supervisor: bool,
    pub disable_execute: bool,
}

pub struct PTE {
    pub frame: MemRegion,
    /// The `flags` field on a `PTE` denotes the combined flags of the entire
    /// translation path to the entry. (See page table walk definition in hardware model,
    /// `spec_t::hardware`.) However, because we always set the flags on directories to be
    /// permissive these flags also correspond to the flags that we set for the frame mapping
    /// corresponding to this `PTE`.
    pub flags: Flags,
}

pub ghost struct ArchLayer {
    /// Address space size mapped by a single entry at this layer
    pub entry_size: nat,
    /// Number of entries at this layer
    pub num_entries: nat,
}

pub ghost struct Arch {
    pub layers: Seq<ArchLayer>,
    // [512G, 1G  , 2M  , 4K  ]
    // [512 , 512 , 512 , 512 ]
}

impl Arch {

    pub open spec(checked) fn entry_size(self, layer: nat) -> nat
        recommends
            layer < self.layers.len(),
    {
        self.layers[layer as int].entry_size
    }

    pub open spec(checked) fn num_entries(self, layer: nat) -> nat
        recommends
            layer < self.layers.len(),
    {
        self.layers.index(layer as int).num_entries
    }

    pub open spec(checked) fn upper_vaddr(self, layer: nat, base: nat) -> nat
        recommends
            self.inv(),
            layer < self.layers.len(),
    {
        self.entry_base(layer, base, self.num_entries(layer))
    }

    pub open spec(checked) fn inv(&self) -> bool {
        &&& self.layers.len() <= X86_NUM_LAYERS
        &&& forall|i: nat|
            #![trigger self.entry_size(i)]
            #![trigger self.num_entries(i)]
            i < self.layers.len() ==> {
                &&& 0 < self.entry_size(i) <= X86_MAX_ENTRY_SIZE
                &&& 0 < self.num_entries(i) <= X86_NUM_ENTRIES
                &&& self.entry_size_is_next_layer_size(i)
            }
    }

    pub open spec(checked) fn entry_size_is_next_layer_size(self, i: nat) -> bool
        recommends
            i < self.layers.len(),
    {
        i + 1 < self.layers.len() ==> self.entry_size(i) == self.entry_size((i + 1) as nat)
            * self.num_entries((i + 1) as nat)
    }

    #[verifier(inline)]
    pub open spec(checked) fn entry_base(self, layer: nat, base: nat, idx: nat) -> nat
        recommends
            self.inv(),
            layer < self.layers.len(),
    {
        // base + idx * self.entry_size(layer)
        entry_base_from_index(base, idx, self.entry_size(layer))
    }

}


pub spec const x86_arch_spec: Arch = Arch {
    layers: seq![
        ArchLayer { entry_size: L0_ENTRY_SIZE as nat, num_entries: 512 },
        ArchLayer { entry_size: L1_ENTRY_SIZE as nat, num_entries: 512 },
        ArchLayer { entry_size: L2_ENTRY_SIZE as nat, num_entries: 512 },
        ArchLayer { entry_size: L3_ENTRY_SIZE as nat, num_entries: 512 },
    ],
};



pub open spec fn nat_keys<V>(m: Map<usize, V>) -> Map<nat, V> {
    Map::new(|k: nat| k <= usize::MAX && m.contains_key(k as usize), |k: nat| m[k as usize])
}
}

// File: impl_u/l2_impl.rs
impl PDE {

    pub open spec fn hp_pat_is_zero(self) -> bool {
        &&& self@ is Page && self.layer == 1 ==> self.entry & MASK_PG_FLAG_PAT == 0
        &&& self@ is Page && self.layer == 2 ==> self.entry & MASK_PG_FLAG_PAT == 0
    }

}


#[verifier::ext_equal]
pub struct PTDir {
    /// Region of physical memory in which this PTDir is stored
    pub region: MemRegion,
    pub entries: Seq<Option<PTDir>>,
    /// reflexive-transitive closure of `region` over `entries`
    pub used_regions: Set<MemRegion>,
}

pub mod PT {
use super::*;

pub open spec(checked) fn inv_and_nonempty(tok: WrappedTokenView, pt: PTDir) -> bool {
    &&& inv(tok, pt)
    // The overall invariant requires that there are no empty directories but this is not part of
    // `inv_at`, so we can still obtain `inv_at` for the whole page table during operations and use
    // it to derive the implementation VCs.
    &&& no_empty_directories(tok, pt, 0, tok.pt_mem.pml4)
}

pub open spec(checked) fn inv(tok: WrappedTokenView, pt: PTDir) -> bool {
    &&& pt.region.base == tok.pt_mem.pml4
    &&& inv_at(tok, pt, 0, tok.pt_mem.pml4)
}

pub open spec fn entry_at_spec(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize, i: nat) -> PDE {
    PDE {
        entry: tok.read(i as usize, pt.region),
        layer: Ghost(layer),
    }
}

pub open spec fn ghost_pt_matches_structure(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    forall|i: nat| #![trigger pt.entries[i as int], entry_at_spec(tok, pt, layer, ptr, i)@]
    i < X86_NUM_ENTRIES ==> {
        let entry = entry_at_spec(tok, pt, layer, ptr, i)@;
        entry is Directory <==> pt.entries[i as int] is Some
    }
}

pub open spec fn invalid_entries_are_zeroed(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    forall|i: nat| i < X86_NUM_ENTRIES ==>
        (#[trigger] entry_at_spec(tok, pt, layer, ptr, i))@ is Invalid ==> tok.regions[pt.region][i as int] == 0
}

pub open spec fn directories_obey_invariant_at(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool
    decreases X86_NUM_LAYERS - layer, 0nat
        when layer_in_range(layer)
{
    forall|i: nat| i < X86_NUM_ENTRIES ==> {
        (#[trigger] entry_at_spec(tok, pt, layer, ptr, i))@ matches GPDE::Directory { addr, ..}
            ==> inv_at(tok, pt.entries[i as int]->Some_0, layer + 1, addr)
    }
}

pub open spec fn no_empty_directories(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool
    decreases X86_NUM_LAYERS - layer
        when layer_in_range(layer)
{
    forall|i: nat| i < X86_NUM_ENTRIES ==> {
        (#[trigger] entry_at_spec(tok, pt, layer, ptr, i))@ matches GPDE::Directory { addr, ..}
            ==> {
                &&& !empty_at(tok, pt.entries[i as int]->Some_0, layer + 1, addr)
                &&& no_empty_directories(tok, pt.entries[i as int]->Some_0, layer + 1, addr)
            }
    }
}

pub open spec fn empty_at(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    forall|i: nat| #![auto] i < X86_NUM_ENTRIES ==> entry_at_spec(tok, pt, layer, ptr, i)@ is Invalid
}

pub open spec(checked) fn layer_in_range(layer: nat) -> bool {
    layer < X86_NUM_LAYERS
}

pub open spec(checked) fn inv_at(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool
    decreases X86_NUM_LAYERS - layer
{
    &&& aligned(ptr as nat, PAGE_SIZE as nat)
    &&& tok.regions.contains_key(pt.region)
    &&& pt.region.base == ptr
    &&& pt.region.size == PAGE_SIZE
    &&& tok.regions[pt.region].len() == pt.entries.len()
    &&& layer_in_range(layer)
    &&& pt.entries.len() == X86_NUM_ENTRIES
    &&& invalid_entries_are_zeroed(tok, pt, layer, ptr)
    &&& directories_obey_invariant_at(tok, pt, layer, ptr)
    &&& directories_have_flags(tok, pt, layer, ptr)
    &&& ghost_pt_matches_structure(tok, pt, layer, ptr)
    &&& ghost_pt_used_regions_rtrancl(tok, pt, layer, ptr)
    &&& ghost_pt_used_regions_pairwise_disjoint(tok, pt, layer, ptr)
    &&& ghost_pt_region_notin_used_regions(tok, pt, layer, ptr)
    &&& pt.used_regions.subset_of(tok.regions.dom())
    &&& hp_pat_is_zero(tok, pt, layer, ptr)
    &&& entry_mb0_bits_are_zero(tok, pt, layer, ptr)
}

pub open spec fn directories_have_flags(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    forall|i: nat| i < X86_NUM_ENTRIES ==> {
        (#[trigger] entry_at_spec(tok, pt, layer, ptr, i)@) matches GPDE::Directory { RW, US, XD, .. } ==> RW && US && !XD
    }
}

pub open spec fn entry_mb0_bits_are_zero(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    forall|i: nat| i < X86_NUM_ENTRIES ==>
        (#[trigger] entry_at_spec(tok, pt, layer, ptr, i)).all_mb0_bits_are_zero()
}

pub open spec fn hp_pat_is_zero(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    forall|i: nat| #![auto] i < X86_NUM_ENTRIES ==> entry_at_spec(tok, pt, layer, ptr, i).hp_pat_is_zero()
}

	#[verifier::external_body]
pub open spec fn ghost_pt_used_regions_pairwise_disjoint(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
		unimplemented!()
	}


pub open spec fn ghost_pt_region_notin_used_regions(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    forall|i: nat|
        i < pt.entries.len() && pt.entries[i as int] is Some
        ==> !(#[trigger] pt.entries[i as int]->Some_0.used_regions.contains(pt.region))
}

pub open spec fn ghost_pt_used_regions_rtrancl(tok: WrappedTokenView, pt: PTDir, layer: nat, ptr: usize) -> bool {
    // reflexive
    &&& pt.used_regions.contains(pt.region)
    // transitive
    &&& forall|i: nat, r: MemRegion| #![trigger pt.entries[i as int]->Some_0.used_regions.contains(r), pt.used_regions.contains(r)]
            i < pt.entries.len() && pt.entries[i as int] is Some &&
            pt.entries[i as int]->Some_0.used_regions.contains(r)
            ==> pt.used_regions.contains(r)
}
}

// File: impl_u/wrapped_token.rs
pub enum OpArgs {
    Map { base: usize, pte: PTE },
    Unmap { base: usize },
}

pub struct WrappedTokenView {
    pub orig_st: os::State,
    pub args: OpArgs,
    pub change_made: bool,
    pub regions: Map<MemRegion, Seq<usize>>,
    /// We also keep the flat memory directly because this is what the MMU's interpretation is
    /// defined on.
    pub pt_mem: crate::PTMem,
    // result is only relevant for mapping (TODO: and maybe we can get rid of it there?)
    pub result: Result<(),()>,
}

impl WrappedTokenView {

    pub open spec fn read(self, idx: usize, r: MemRegion) -> usize {
        self.regions[r][idx as int] & MASK_NEG_DIRTY_ACCESS
    }

    pub open spec fn regions_derived_from_view(self) -> bool {
        forall|r| self.regions.contains_key(r) ==> #[trigger] self.regions[r] == Seq::new(512, |i: int| self.pt_mem.mem[(r.base + i * 8) as usize])
    }

}



// File: spec_t/os.rs
pub mod os {
use vstd::prelude::*;
use crate::defs::*;
use crate::{rl3, RLbl};
use crate::os_ext;


pub struct Constants {
    /// Constants for mmu and os_ext state machines
    pub common: crate::Constants,
    //maps User Level Thread to its assigned core
    pub ult2core: Map<nat, Core>,
    //highest thread_id
    pub ult_no: nat,
}

pub struct State {
    pub mmu: crate::rl3::State,
    pub os_ext: os_ext::State,
    pub core_states: Map<Core, CoreState>,
    /// `sound` is a history variable. It doesn't affect the behavior of the state machine but is
    /// used in the refinement.
    pub sound: bool,
}

#[allow(inconsistent_fields)]
pub enum CoreState {
    Idle,
    MapWaiting { ult_id: nat, vaddr: nat, pte: PTE },
    MapExecuting { ult_id: nat, vaddr: nat, pte: PTE },
    MapDone { ult_id: nat, vaddr: nat, pte: PTE, result: Result<(), ()> },
    UnmapWaiting { ult_id: nat, vaddr: nat },
    UnmapExecuting { ult_id: nat, vaddr: nat, result: Option<Result<PTE, ()>> },
    UnmapOpDone { ult_id: nat, vaddr: nat, result: Result<PTE, ()> },
    UnmapShootdownWaiting { ult_id: nat, vaddr: nat, result: Result<PTE, ()> },
}

#[allow(inconsistent_fields)]
pub enum Step {
    MMU,
    MemOp { core: Core },
    ReadPTMem { core: Core, paddr: usize, value: usize },
    Barrier { core: Core },
    Invlpg { core: Core },
    // Map
    MapStart { core: Core },
    MapOpStart { core: Core },
    Allocate { core: Core, res: MemRegion },
    MapOpStutter { core: Core, paddr: usize, value: usize },
    MapOpChange { core: Core, paddr: usize, value: usize },
    MapNoOp { core: Core },
    MapEnd { core: Core },
    // Unmap
    UnmapStart { core: Core },
    UnmapOpStart { core: Core },
    Deallocate { core: Core, reg: MemRegion },
    UnmapOpChange { core: Core, paddr: usize, value: usize },
    UnmapOpStutter { core: Core, paddr: usize, value: usize },
    UnmapOpFail { core: Core },
    UnmapInitiateShootdown { core: Core },
    UnmapWaitShootdown { core: Core },
    AckShootdownIPI { core: Core },
    UnmapEnd { core: Core },
}

impl Constants {

    pub open spec fn valid_ult(self, ult_id: nat) -> bool {
        ult_id < self.ult_no
    }

    pub open spec fn valid_core(self, core: Core) -> bool {
        self.common.valid_core(core)
    }

}


pub open spec fn candidate_mapping_overlaps_inflight_pmem(
    pt: Map<nat, PTE>,
    inflightargs: Set<CoreState>,
    candidate: PTE,
) -> bool {
    exists|b: CoreState| #![auto] {
        &&& inflightargs.contains(b)
        &&& match b {
            CoreState::MapWaiting { vaddr, pte, .. }
            | CoreState::MapExecuting { vaddr, pte, .. }
            | CoreState::MapDone { vaddr, pte, .. } => {
                overlap(candidate.frame, pte.frame)
            },
            CoreState::UnmapWaiting { ult_id, vaddr }
            | CoreState::UnmapExecuting { ult_id, vaddr, result: None, .. } => {
                &&& pt.contains_key(vaddr)
                &&& overlap(candidate.frame, pt[vaddr].frame)
            },
            CoreState::UnmapExecuting { ult_id, vaddr, result: Some(result), .. }
            | CoreState::UnmapOpDone { ult_id, vaddr, result, .. }
            | CoreState::UnmapShootdownWaiting { ult_id, vaddr, result, .. } => {
                &&& result is Ok
                &&& overlap(candidate.frame, result.get_Ok_0().frame)
            },
            CoreState::Idle => false,
        }
    }
}

pub open spec fn inflight_vmem_region(pt: Map<nat, PTE>, core_state: CoreState) -> MemRegion
    recommends !(core_state is Idle)
{
    match core_state {
        CoreState::Idle => arbitrary(),
        CoreState::MapWaiting { vaddr, pte, .. }
        | CoreState::MapExecuting { vaddr, pte, .. }
        | CoreState::MapDone { vaddr, pte, .. } => {
            MemRegion { base: vaddr, size: pte.frame.size }
        }

        CoreState::UnmapWaiting { vaddr, .. }
        | CoreState::UnmapExecuting { vaddr, result: None, .. } => {
            let size = if pt.contains_key(vaddr) { pt[vaddr].frame.size } else { 0 };
            MemRegion { base: vaddr, size: size }
        }

        CoreState::UnmapExecuting { ult_id: ult_id2, vaddr, result: Some(result) }
        | CoreState::UnmapOpDone { ult_id: ult_id2, vaddr, result }
        | CoreState::UnmapShootdownWaiting { ult_id: ult_id2, vaddr, result } => {
            let size = if result is Ok { result.get_Ok_0().frame.size } else { 0 };
            MemRegion { base: vaddr, size: size }
        }
    }
}

pub open spec fn candidate_mapping_overlaps_inflight_vmem(
    pt: Map<nat, PTE>,
    inflightargs: Set<CoreState>,
    base: nat,
    candidate_size: nat,
) -> bool {
    exists|core_state: CoreState| #![auto] {
        &&& inflightargs.contains(core_state)
        &&& !(core_state is Idle)
        &&& overlap(
                inflight_vmem_region(pt, core_state),
                MemRegion { base: base, size: candidate_size },
            )
    }
}

pub open spec fn step_MMU(c: Constants, s1: State, s2: State, lbl: RLbl) -> bool {
    &&& lbl is Tau
    //mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Tau)
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_MemOp(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl matches RLbl::MemOp { thread_id, vaddr, op }
    &&& aligned(vaddr, 8)
    &&& core == c.ult2core[thread_id]
    &&& c.valid_ult(thread_id)
    &&& s1.core_states[core] is Idle
    //mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::MemOp(core, vaddr as usize, op))
    &&& s2.os_ext == s1.os_ext
    // FIXME(MB): This additional enabling condition here is kind of fishy
    &&& vaddr <= usize::MAX
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_ReadPTMem(c: Constants, s1: State, s2: State, core: Core, paddr: usize, value: usize, lbl: RLbl) -> bool {
    &&& lbl is Tau
    //mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Read(core, paddr, value))
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_Barrier(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl is Tau
    //mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Barrier(core))
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_Invlpg(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl is Tau
    &&& s1.os_ext.shootdown_vec.open_requests.contains(core)
    //mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Invlpg(core, s1.os_ext.shootdown_vec.vaddr as usize))
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_Map_sound(
    pt: Map<nat, PTE>,
    inflightargs: Set<CoreState>,
    vaddr: nat,
    pte: PTE,
) -> bool {
    &&& !candidate_mapping_overlaps_existing_pmem(pt, pte)
    &&& !candidate_mapping_overlaps_inflight_pmem(pt, inflightargs, pte)
    &&& !candidate_mapping_overlaps_inflight_vmem(pt, inflightargs, vaddr, pte.frame.size)
}

pub open spec fn step_Map_enabled(c: Constants, vaddr: nat, pte: PTE) -> bool {
    &&& aligned(vaddr, pte.frame.size)
    &&& aligned(pte.frame.base, pte.frame.size)
    &&& candidate_mapping_in_bounds(vaddr, pte)
    &&& candidate_mapping_in_bounds_pmem(c.common, pte)
    &&& {  // The size of the frame must be the entry_size of a layer that supports page mappings
        ||| pte.frame.size == L3_ENTRY_SIZE
        ||| pte.frame.size == L2_ENTRY_SIZE
        ||| pte.frame.size == L1_ENTRY_SIZE
    }
    //&&& pt_mem.alloc_available_pages() >= 3
}

pub open spec fn step_MapStart(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl matches RLbl::MapStart { thread_id, vaddr, pte }
    &&& core == c.ult2core[thread_id]
    //enabling conditions
    &&& c.valid_ult(thread_id)
    &&& s1.core_states[core] is Idle
    &&& step_Map_enabled(c, vaddr, pte)

    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::MapWaiting { ult_id: thread_id, vaddr, pte })
    &&& s2.sound == (s1.sound && step_Map_sound(s1.interp_pt_mem(), s1.core_states.values(), vaddr, pte))
}

pub open spec fn step_MapOpStart(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::MapWaiting { ult_id, vaddr, pte }

    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::AcquireLock { core })

    //new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::MapExecuting { ult_id, vaddr, pte })
    &&& s2.sound == s1.sound
}

pub open spec fn step_MapOpStutter(
    c: Constants,
    s1: State,
    s2: State,
    core: Core,
    paddr: usize,
    value: usize,
    lbl: RLbl,
) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] is MapExecuting
    &&& value & 1 == 1
    &&& s1.os_ext.is_in_allocated_region(paddr as nat)

    // mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Write(core, paddr, value))
    &&& s2.mmu@.happy == s1.mmu@.happy
    &&& s2.interp_pt_mem() == s1.interp_pt_mem()
    &&& s2.os_ext == s1.os_ext

    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_Allocate(c: Constants, s1: State, s2: State, core: Core, res: MemRegion, lbl: RLbl) -> bool {
    &&& lbl is Tau

    &&& c.valid_core(core)
    &&& s1.core_states[core] is MapExecuting

    //mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::Allocate { core, res })
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_MapOpChange(
    c: Constants,
    s1: State,
    s2: State,
    core: Core,
    paddr: usize,
    value: usize,
    lbl: RLbl,
) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::MapExecuting { ult_id, vaddr, pte }
    &&& !candidate_mapping_overlaps_existing_vmem(s1.interp_pt_mem(), vaddr, pte)
    &&& value & 1 == 1
    &&& s1.os_ext.is_in_allocated_region(paddr as nat)
    &&& s2.interp_pt_mem() == s1.interp_pt_mem().insert(vaddr, pte)

    // mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Write(core, paddr, value))
    &&& s2.mmu@.happy == s1.mmu@.happy
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::MapDone { ult_id, vaddr, pte, result: Ok(()) })
    &&& s1.sound == s2.sound
}

pub open spec fn step_MapNoOp(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::MapExecuting { ult_id, vaddr, pte }
    &&& candidate_mapping_overlaps_existing_vmem(s1.interp_pt_mem(), vaddr, pte)

    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::MapDone { ult_id, vaddr, pte, result: Err(()) })
    &&& s1.sound == s2.sound
}

pub open spec fn step_MapEnd(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl matches RLbl::MapEnd { thread_id, vaddr, result }
    // enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::MapDone { ult_id, vaddr: vaddr2, pte, result: result2 }
    &&& thread_id == ult_id && vaddr == vaddr2 && result == result2
    &&& s1.mmu@.writes.tso === set![]
    &&& s1.mmu@.pending_maps === map![]
    &&& s2.inv_impl() // impl invariant is re-established

    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::ReleaseLock { core })

    // new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::Idle)
    &&& s1.sound == s2.sound
}

pub open spec fn step_Unmap_sound(s1: State, vaddr: nat, pte_size: nat) -> bool {
    !candidate_mapping_overlaps_inflight_vmem(s1.interp_pt_mem(), s1.core_states.values(), vaddr, pte_size)
}

pub open spec fn step_Unmap_enabled(vaddr: nat) -> bool {
    &&& vaddr < x86_arch_spec.upper_vaddr(0, 0)
    &&& { // The given vaddr must be aligned to some valid page size
        ||| aligned(vaddr, L3_ENTRY_SIZE as nat)
        ||| aligned(vaddr, L2_ENTRY_SIZE as nat)
        ||| aligned(vaddr, L1_ENTRY_SIZE as nat)
    }
}

pub open spec fn step_UnmapStart(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl matches RLbl::UnmapStart { thread_id, vaddr }
    &&& {
    let pt = s1.interp_pt_mem();
    let pte_size = if pt.contains_key(vaddr) { pt[vaddr].frame.size } else { 0 };
    //enabling conditions
    &&& core == c.ult2core[thread_id]
    &&& c.valid_ult(thread_id)
    &&& s1.core_states[core] is Idle
    &&& step_Unmap_enabled(vaddr)
    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::UnmapWaiting { ult_id: thread_id, vaddr })
    &&& s2.sound == (s1.sound && step_Unmap_sound(s1, vaddr, pte_size))
    }
}

pub open spec fn step_UnmapOpStart(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::UnmapWaiting { ult_id, vaddr }
    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::AcquireLock { core })
    //new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::UnmapExecuting { ult_id, vaddr, result: None })
    &&& s2.sound == s1.sound
}

pub open spec fn step_Deallocate(c: Constants, s1: State, s2: State, core: Core, reg: MemRegion, lbl: RLbl) -> bool {
    &&& lbl is Tau

    &&& c.valid_core(core)
    &&& s1.core_states[core] is UnmapExecuting
    &&& forall|pa: usize|
            aligned(pa as nat, 8) && reg.contains(pa as nat)
                ==> #[trigger] s1.mmu@.pt_mem.read(pa) == 0

    //mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::Deallocate { core, reg })
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_UnmapOpChange(
    c: Constants,
    s1: State,
    s2: State,
    core: Core,
    paddr: usize,
    value: usize,
    lbl: RLbl,
) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::UnmapExecuting { ult_id, vaddr, result: None }
    &&& value & 1 == 0
    // mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Write(core, paddr, value))
    &&& s2.mmu@.happy == s1.mmu@.happy
    &&& s1.os_ext.is_in_allocated_region(paddr as nat)
    &&& s1.interp_pt_mem().contains_key(vaddr)
    &&& s2.interp_pt_mem() == s1.interp_pt_mem().remove(vaddr)
    &&& s2.core_states == s1.core_states.insert(
        core,
        CoreState::UnmapExecuting { ult_id, vaddr, result: Some(Ok(s1.interp_pt_mem()[vaddr])) }
    )

    &&& s2.os_ext == s1.os_ext
    &&& s2.sound == s1.sound
}

pub open spec fn step_UnmapOpStutter(
    c: Constants,
    s1: State,
    s2: State,
    core: Core,
    paddr: usize,
    value: usize,
    lbl: RLbl,
) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::UnmapExecuting { ult_id, vaddr, result: Some(res) }
    &&& value & 1 == 0
    &&& s1.os_ext.is_in_allocated_region(paddr as nat)
    &&& s2.interp_pt_mem() == s1.interp_pt_mem()
    // mmu statemachine steps
    &&& crate::rl3::next(s1.mmu, s2.mmu, c.common, crate::Lbl::Write(core, paddr, value))
    &&& s2.mmu@.happy == s1.mmu@.happy
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_UnmapOpFail(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::UnmapExecuting { ult_id, vaddr, result: None }
    &&& !s1.interp_pt_mem().contains_key(vaddr)
    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& s2.os_ext == s1.os_ext
    //new state
    &&& s2.core_states == s1.core_states.insert(
        core,
        CoreState::UnmapOpDone { ult_id, vaddr, result: Err(()) }
    )
    &&& s2.sound == s1.sound
}

pub open spec fn step_UnmapInitiateShootdown(
    c: Constants,
    s1: State,
    s2: State,
    core: Core,
    lbl: RLbl,
) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] matches CoreState::UnmapExecuting { ult_id, vaddr, result: Some(Ok(pte)) }
    &&& s1.mmu@.writes.tso === set![]
    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::InitShootdown { core, vaddr })
    //new state
    &&& s2.core_states == s1.core_states.insert(
        core,
        CoreState::UnmapShootdownWaiting { ult_id, vaddr, result: Ok(pte) },
    )
    &&& s2.sound == s1.sound
}

pub open spec fn step_AckShootdownIPI(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl matches RLbl::AckShootdownIPI { core: score } && score == core
    //enabling conditions
    &&& c.valid_core(core)
    &&& !s1.mmu@.writes.nonpos.contains(core)
    &&& !s1.mmu@.tlbs[core].contains_key(s1.os_ext.shootdown_vec.vaddr as usize)
    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::AckShootdown { core })
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_UnmapWaitShootdown(
    c: Constants,
    s1: State,
    s2: State,
    core: Core,
    lbl: RLbl,
) -> bool {
    &&& lbl is Tau
    //enabling conditions
    &&& c.valid_core(core)
    &&& s1.core_states[core] is UnmapShootdownWaiting
    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::WaitShootdown { core })
    //new state
    &&& s2.core_states == s1.core_states
    &&& s2.sound == s1.sound
}

pub open spec fn step_UnmapEnd(c: Constants, s1: State, s2: State, core: Core, lbl: RLbl) -> bool {
    &&& lbl matches RLbl::UnmapEnd { thread_id, vaddr, result }
    //enabling conditions
    &&& c.valid_core(core)
    &&& match s1.core_states[core] {
        CoreState::UnmapShootdownWaiting { result: r2, vaddr: v2, ult_id: id2, .. } => {
            &&& result is Ok
            &&& r2 is Ok
            &&& vaddr == v2
            &&& thread_id == id2
            &&& s1.os_ext.shootdown_vec.open_requests.is_empty()
        },
        CoreState::UnmapOpDone { result: r2, vaddr: v2, ult_id: id2, .. } => {
            &&& result is Err
            &&& r2 is Err
            &&& vaddr == v2
            &&& thread_id == id2
        },
        _ => false,
    }
    &&& s2.inv_impl() // impl invariant is re-established
    &&& s1.mmu@.writes.tso === set![]
    &&& s1.mmu@.writes.nonpos === set![]
    &&& s1.mmu@.pending_unmaps === map![]
    // mmu statemachine steps
    &&& s2.mmu == s1.mmu
    &&& os_ext::next(s1.os_ext, s2.os_ext, c.common, os_ext::Lbl::ReleaseLock { core })
    //new state
    &&& s2.core_states == s1.core_states.insert(core, CoreState::Idle)
    &&& s1.sound == s2.sound
}

pub open spec fn next_step(c: Constants, s1: State, s2: State, step: Step, lbl: RLbl) -> bool {
    match step {
        Step::MMU                                   => step_MMU(c, s1, s2, lbl),
        Step::MemOp { core }                        => step_MemOp(c, s1, s2, core, lbl),
        Step::ReadPTMem { core, paddr, value }      => step_ReadPTMem(c, s1, s2, core, paddr, value, lbl),
        Step::Barrier { core }                      => step_Barrier(c, s1, s2, core, lbl),
        Step::Invlpg { core }                       => step_Invlpg(c, s1, s2, core, lbl),
        //Map steps
        Step::MapStart { core }                     => step_MapStart(c, s1, s2, core, lbl),
        Step::MapOpStart { core }                   => step_MapOpStart(c, s1, s2, core, lbl),
        Step::Allocate { core, res }                => step_Allocate(c, s1, s2, core, res, lbl),
        Step::MapOpStutter { core, paddr, value }   => step_MapOpStutter(c, s1, s2, core, paddr, value, lbl),
        Step::MapOpChange { core, paddr, value }    => step_MapOpChange(c, s1, s2, core, paddr, value, lbl),
        Step::MapNoOp { core }                      => step_MapNoOp(c, s1, s2, core, lbl),
        Step::MapEnd { core }                       => step_MapEnd(c, s1, s2, core, lbl),
        //Unmap steps
        Step::UnmapStart { core }                   => step_UnmapStart(c, s1, s2, core, lbl),
        Step::UnmapOpStart { core }                 => step_UnmapOpStart(c, s1, s2, core, lbl),
        Step::Deallocate { core, reg }              => step_Deallocate(c, s1, s2, core, reg, lbl),
        Step::UnmapOpChange { core, paddr, value }  => step_UnmapOpChange(c, s1, s2, core, paddr, value, lbl),
        Step::UnmapOpStutter { core, paddr, value } => step_UnmapOpStutter(c, s1, s2, core, paddr, value, lbl),
        Step::UnmapOpFail { core }                  => step_UnmapOpFail(c, s1, s2, core, lbl),
        Step::UnmapInitiateShootdown { core }       => step_UnmapInitiateShootdown(c, s1, s2, core, lbl),
        Step::UnmapWaitShootdown { core }           => step_UnmapWaitShootdown(c, s1, s2, core, lbl),
        Step::AckShootdownIPI { core }              => step_AckShootdownIPI(c, s1, s2, core, lbl),
        Step::UnmapEnd { core }                     => step_UnmapEnd(c, s1, s2, core, lbl),
    }
}

impl State {

    pub open spec fn interp_pt_mem(self) -> Map<nat, PTE> {
        nat_keys(self.mmu@.pt_mem@)
    }

    pub open spec fn inv_impl(self) -> bool {
        self.os_ext.lock is None ==>
            forall|wtok: crate::WrappedTokenView| ({
                &&& wtok.pt_mem == self.mmu@.pt_mem
                &&& wtok.regions.dom() == self.os_ext.allocated
                &&& #[trigger] wtok.regions_derived_from_view()
            }) ==> exists|pt| crate::PT::inv_and_nonempty(wtok, pt)
    }

}
}


// File: spec_t/os_ext.rs
pub mod os_ext {
    use vstd::prelude::*;
    use crate::defs::*;
    use crate::Constants;


pub enum Lbl {
    Tau,
    AcquireLock { core: Core },
    ReleaseLock { core: Core },
    InitShootdown { core: Core, vaddr: nat },
    WaitShootdown { core: Core },
    AckShootdown { core: Core },
    Allocate { core: Core, res: MemRegion },
    Deallocate { core: Core, reg: MemRegion },
}

pub struct State {
    pub lock: Option<Core>,
    pub shootdown_vec: ShootdownVector,
    pub allocated: Set<MemRegion>,
}

pub struct ShootdownVector {
    pub vaddr: nat,
    pub open_requests: Set<Core>,
}

impl State {

    pub open spec fn disjoint_from_allocations(self, reg: MemRegion) -> bool {
        forall|reg2| #[trigger] self.allocated.contains(reg2) ==> !overlap(reg, reg2)
    }

    pub open spec fn is_in_allocated_region(self, pa: nat) -> bool {
        exists|r| #[trigger] self.allocated.contains(r) && r.base <= pa < r.base + r.size
    }

}


pub enum Step {
    AcquireLock,
    ReleaseLock,
    InitShootdown,
    WaitShootdown,
    AckShootdown,
    Allocate,
    Deallocate
}

pub open spec fn step_AcquireLock(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    &&& lbl matches Lbl::AcquireLock { core }

    &&& c.valid_core(core)
    &&& pre.lock is None

    &&& post == State {
        lock: Some(core),
        ..pre
    }
}

pub open spec fn step_ReleaseLock(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    &&& lbl matches Lbl::ReleaseLock { core }

    &&& c.valid_core(core)
    &&& pre.lock == Some(core)

    &&& post == State {
        lock: None,
        ..pre
    }
}

pub open spec fn step_InitShootdown(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    &&& lbl matches Lbl::InitShootdown { core, vaddr }

    &&& c.valid_core(core)
    &&& pre.shootdown_vec.open_requests === set![]

    &&& post == State {
        shootdown_vec: ShootdownVector {
            vaddr,
            open_requests: Set::new(|core| c.valid_core(core))
        },
        ..pre
    }
}

pub open spec fn step_WaitShootdown(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    &&& lbl matches Lbl::WaitShootdown { core }

    &&& c.valid_core(core)
    &&& pre.shootdown_vec.open_requests === set![]

    &&& post == pre
}

pub open spec fn step_AckShootdown(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    &&& lbl matches Lbl::AckShootdown { core }

    &&& c.valid_core(core)
    &&& pre.shootdown_vec.open_requests.contains(core)

    &&& post == State {
        shootdown_vec: ShootdownVector {
            open_requests: pre.shootdown_vec.open_requests.remove(core),
            ..pre.shootdown_vec
        },
        ..pre
    }
}

pub open spec fn step_Allocate(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    &&& lbl matches Lbl::Allocate { core, res }

    &&& c.valid_core(core)
    &&& pre.disjoint_from_allocations(res)
    &&& aligned(res.base, 4096)
    &&& c.in_ptmem_range(res.base, 4096)
    &&& res.size == 4096

    &&& post == State {
        allocated: pre.allocated.insert(res),
        ..pre
    }
}

pub open spec fn step_Deallocate(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    &&& lbl matches Lbl::Deallocate { core, reg }

    &&& c.valid_core(core)
    &&& pre.allocated.contains(reg)

    &&& post == State {
        allocated: pre.allocated.remove(reg),
        ..pre
    }
}

pub open spec fn next_step(pre: State, post: State, c: Constants, step: Step, lbl: Lbl) -> bool {
    match step {
        Step::AcquireLock   => step_AcquireLock(pre, post, c, lbl),
        Step::ReleaseLock   => step_ReleaseLock(pre, post, c, lbl),
        Step::InitShootdown => step_InitShootdown(pre, post, c, lbl),
        Step::WaitShootdown => step_WaitShootdown(pre, post, c, lbl),
        Step::AckShootdown  => step_AckShootdown(pre, post, c, lbl),
        Step::Allocate      => step_Allocate(pre, post, c, lbl),
        Step::Deallocate    => step_Deallocate(pre, post, c, lbl),
    }
}

pub open spec fn next(pre: State, post: State, c: Constants, lbl: Lbl) -> bool {
    exists|step| next_step(pre, post, c, step, lbl)
}
}

// File: spec_t/mmu/mod.rs
pub enum Polarity {
    Mapping,
    Unmapping,
    // Protect,
}

pub struct Walk {
    pub vaddr: usize,
    pub path: Seq<(usize, GPDE)>,
    pub complete: bool,
}

pub struct Constants {
    pub node_count: nat,
    pub core_count: nat,
    /// The range of memory used for the page table
    pub range_ptmem: (nat, nat),
    /// The range of memory used for the user memory
    pub range_mem: (nat, nat),
    pub phys_mem_size: nat,
}

impl Constants {

	#[verifier::external_body]
    pub open spec fn valid_core(self, core: Core) -> bool {
		unimplemented!()
	}


    pub open spec fn in_ptmem_range(self, addr: nat, size: nat) -> bool {
        &&& self.range_ptmem.0 <= addr
        &&& addr + size <= self.range_ptmem.1
    }

}


pub enum Lbl {
    /// Internal event
    Tau,
    /// Memory operation on non-page-table memory
    /// Core, virtual address, memory operation
    MemOp(Core, usize, MemOp),
    /// Write to page table memory.
    /// Core, physical address, written value
    Write(Core, usize, usize),
    /// Read from page table memory.
    /// Core, physical address, read value
    Read(Core, usize, usize),
    /// Invlpg instruction
    /// Core and virtual address
    Invlpg(Core, usize),
    /// Serializing instruction
    Barrier(Core),
}


// File: theorem.rs
pub mod theorem{
use vstd::prelude::*;
use crate::os;
use crate::defs::{ MemOp, PTE, Core };


pub enum RLbl {
    Tau,
    MemOp      { thread_id: nat, vaddr: nat, op: MemOp },
    MapStart   { thread_id: nat, vaddr: nat, pte: PTE },
    MapEnd     { thread_id: nat, vaddr: nat, result: Result<(), ()> },
    UnmapStart { thread_id: nat, vaddr: nat },
    UnmapEnd   { thread_id: nat, vaddr: nat, result: Result<(), ()> },
    AckShootdownIPI { core: Core },
}
}

// File: spec_t/os_code_vc.rs
pub mod os_code_vc{
use vstd::prelude::*;
use crate::os;
use crate::os_ext;
use crate::defs::{ Core};
use crate::theorem::RLbl;
use crate::rl3::refinement::to_rl1;

impl os::Step {

    pub open spec fn is_actor_step(self, c: Core) -> bool {
        match self {
            os::Step::MMU => false,
            os::Step::MemOp { core, .. } |
            os::Step::ReadPTMem { core, .. } |
            os::Step::Barrier { core, .. } |
            os::Step::Invlpg { core, .. } |
            os::Step::MapStart { core, .. } |
            os::Step::MapOpStart { core, .. } |
            os::Step::Allocate { core, .. } |
            os::Step::MapOpStutter { core, .. } |
            os::Step::MapOpChange { core, .. } |
            os::Step::MapNoOp { core, .. } |
            os::Step::MapEnd { core, .. } |
            os::Step::UnmapStart { core, .. } |
            os::Step::UnmapOpStart { core, .. } |
            os::Step::Deallocate { core, .. } |
            os::Step::UnmapOpChange { core, .. } |
            os::Step::UnmapOpStutter { core, .. } |
            os::Step::UnmapOpFail { core, .. } |
            os::Step::UnmapInitiateShootdown { core, .. } |
            os::Step::UnmapWaitShootdown { core } |
            os::Step::AckShootdownIPI { core, .. } |
            os::Step::UnmapEnd { core, .. } => core == c,
        }
    }

}


pub open spec fn concurrent_trs(pre: os::State, post: os::State, c: os::Constants, core: Core, pidx: nat) -> bool
    decreases pidx
{
    if pidx == 0 {
        post == pre
    } else {
        exists|state: os::State, step, lbl| {
            &&& concurrent_trs(pre, state, c, core, sub(pidx, 1)) 
            &&& os::next_step(c, state, post, step, lbl)
            &&& !step.is_actor_step(core)
        }
    }
}

#[verifier::spinoff_prover]
proof fn lemma_concurrent_trs_induct(pre: os::State, post: os::State, c: os::Constants, core: Core, pidx: nat, pred: spec_fn(os::State, os::State) -> bool)
    requires
        concurrent_trs(pre, post, c, core, pidx),
        forall|s| #[trigger] pred(s, s),
        forall|pre, mid, pidx, step, lbl, post|
            pred(pre, mid)
            && concurrent_trs(pre, mid, c, core, pidx)
            && os::next_step(c, mid, post, step, lbl)
            && !step.is_actor_step(core)
            ==> pred(pre, post)
    ensures pred(pre, post)
    decreases pidx
{
    if pre == post {
    } else {
        let (state, step, lbl): (os::State, os::Step, RLbl) = choose|state: os::State, step, lbl| {
            &&& concurrent_trs(pre, state, c, core, sub(pidx, 1)) 
            &&& os::next_step(c, state, post, step, lbl)
            &&& !step.is_actor_step(core)
        };
        lemma_concurrent_trs_induct(pre, state, c, core, sub(pidx, 1), pred);
    }
}
}

}
