use vstd::prelude::*;
use vstd::bytes::*;

fn main() {}

verus!{

// File: verus_extra/seq_lib_v.rs
	#[verifier::external_body]
pub proof fn lemma_seq_fold_left_append_right<A, B>(s: Seq<A>, prefix: Seq<B>, f: spec_fn(A) -> Seq<B>)
  requires s.len() > 0,
  ensures
    s.subrange(0, s.len() - 1).fold_left(prefix, |sb: Seq<B>, a: A| sb + f(a)) + f(s[s.len() - 1])
    ==
    s.fold_left(prefix, |sb: Seq<B>, a: A| sb + f(a))
	{
		unimplemented!()
	}


// File: marshal_v.rs
pub trait Marshalable : Sized {

  spec fn is_marshalable(&self) -> bool;

	#[verifier::external_body]
  spec fn ghost_serialize(&self) -> Seq<u8>
    recommends self.is_marshalable()
  {unimplemented!()}

	#[verifier::external_body]
  exec fn serialize(&self, data: &mut Vec<u8>)
    requires self.is_marshalable()
    ensures
      data@.len() >= old(data).len(),
      data@.subrange(0, old(data)@.len() as int) == old(data)@,
      data@.subrange(old(data)@.len() as int, data@.len() as int) == self.ghost_serialize()
  {unimplemented!()}

}


impl Marshalable for u64 {

  open spec fn is_marshalable(&self) -> bool {
    true
  }

  open spec fn ghost_serialize(&self) -> Seq<u8> {
    spec_u64_to_le_bytes(*self)
  }

	#[verifier::external_body]
  exec fn serialize(&self, data: &mut Vec<u8>)
	{
		unimplemented!()
	}

}


impl Marshalable for usize {

  open spec fn is_marshalable(&self) -> bool {
    &&& *self as int <= u64::MAX
  }

  open spec fn ghost_serialize(&self) -> Seq<u8> {
    (*self as u64).ghost_serialize()
  }

	#[verifier::external_body]
  exec fn serialize(&self, data: &mut Vec<u8>)
	{
		unimplemented!()
	}

}


impl Marshalable for Vec<u8> {

  open spec fn is_marshalable(&self) -> bool {
    self@.len() <= usize::MAX &&
    (self@.len() as usize).ghost_serialize().len() + self@.len() as int <= usize::MAX
  }

  open spec fn ghost_serialize(&self) -> Seq<u8> {
    (self@.len() as usize).ghost_serialize()
      + self@
  }

	#[verifier::external_body]
  exec fn serialize(&self, data: &mut Vec<u8>)
	{
		unimplemented!()
	}

}


impl<T: Marshalable> Marshalable for Vec<T> {

  open spec fn is_marshalable(&self) -> bool {
    &&& self@.len() <= usize::MAX
    &&& (forall |x: T| self@.contains(x) ==> #[trigger] x.is_marshalable())
    &&& (self@.len() as usize).ghost_serialize().len() +
        self@.fold_left(0, |acc: int, x: T| acc + x.ghost_serialize().len()) <= usize::MAX
  }

  open spec fn ghost_serialize(&self) -> Seq<u8> {
    (self@.len() as usize).ghost_serialize()
      + self@.fold_left(Seq::<u8>::empty(), |acc: Seq<u8>, x: T| acc + x.ghost_serialize())
  }

  #[verifier::spinoff_prover]
  exec fn serialize(&self, data: &mut Vec<u8>)
    // req, ens from trait
  {
    let self_len = self.len();
    self_len.serialize(data);
    let init: Ghost<int> = Ghost(self_len.ghost_serialize().len() as int);

    let mut i: usize = 0;

    proof {
      assert(
        data@.subrange(old(data)@.len() as int, data@.len() as int) =~= self.len().ghost_serialize() +
            self@.subrange(0, i as int).fold_left(Seq::<u8>::empty(), |acc: Seq<u8>, x: T| acc + x.ghost_serialize())
      );
    }

    while i < self.len()
      invariant
        i <= self.len(),
        data@.subrange(0, old(data)@.len() as int) == old(data)@,
        data@.subrange(old(data)@.len() as int, data@.len() as int) ==
          self.len().ghost_serialize() +
            self@.subrange(0, i as int).fold_left(Seq::<u8>::empty(), |acc: Seq<u8>, x: T| acc + x.ghost_serialize()),
        forall |x: T| self@.contains(x) ==> #[trigger] x.is_marshalable(),
        data@.len() >= old(data)@.len(),
      decreases
        self.len() - i
    {
      self[i].serialize(data);
      i = i + 1;

      proof {
        assert(data@.subrange(0, old(data)@.len() as int) =~= old(data)@);
        assert(data@.subrange(old(data)@.len() as int, data@.len() as int) ==
          self.len().ghost_serialize() +
            self@.subrange(0, i as int).fold_left(Seq::<u8>::empty(), |acc: Seq<u8>, x: T| acc + x.ghost_serialize())) by {
          let s = self@;
          let emp = Seq::<u8>::empty();
          let accf = |acc: Seq<u8>, x: T| acc + x.ghost_serialize();
          let f = |x: T| x.ghost_serialize();
          let t = s.subrange(0, i as int);

          assert(accf =~= (|acc: Seq<u8>, x: T| acc + f(x)));
          assert(t.subrange(0, t.len() - 1) =~= s.subrange(0, i - 1));
          lemma_seq_fold_left_append_right(t, emp, f);
          assert(
            data@.subrange(old(data)@.len() as int, data@.len() as int) =~= self.len().ghost_serialize() +
              s.subrange(0, (i - 1) as int).fold_left(emp, accf) +
              s.index((i - 1) as int).ghost_serialize()
          );
          assert(
            data@.subrange(old(data)@.len() as int, data@.len() as int) =~= self.len().ghost_serialize() +
              t.fold_left(emp, accf)
          );
        }
      }
    }

    proof {
      assert(self@ =~= self@.subrange(0, self@.len() as int));
    }
  }

}



}
