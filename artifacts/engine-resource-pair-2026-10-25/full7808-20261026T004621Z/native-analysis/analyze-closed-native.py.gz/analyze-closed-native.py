from pathlib import Path
import json,gzip,collections,datetime,subprocess
r=Path('/workspaces/repository');g=['git','-c','gc.auto=0','-c','maintenance.auto=false']
assert subprocess.check_output(g+['symbolic-ref','--short','HEAD'],cwd=r,text=True).strip()=='main'
b=r/'artifacts/engine-resource-pair-2026-10-25/full7808-20261026T004621Z';n=b/'native'
assert json.loads((n/'terminal.json').read_text())['state']=='complete'
out=b/'native-analysis';out.mkdir(exist_ok=True)
d=json.loads(gzip.decompress((n/'capture.json.gz').read_bytes()))
canonical=json.loads(gzip.decompress((r/'artifacts/engine-resource-profile-2026-10-25/population-inputs/all.json.gz').read_bytes()))
assert d['batch']==canonical
results=d['results'];assert len(results)==7808 and [x['id']for x in results]==[x['id']for x in canonical['candidates']]
assert len({x['id']for x in results})==7808 and not any(x['cached']or x['coalesced']for x in results)
oldpath=r/'artifacts/arithmetic-counterexample-2026-10-23/native-gpu-full-20261024T0913/off/results.jsonl.gz'
with gzip.open(oldpath,'rt')as f:old={x['proof_id']:x for x in map(json.loads,f)}
current={x['id']:x for x in results};assert set(old)==set(current)
labels={'valid':'accepted','lean_error':'rejected','timeout':'timeout','resource_failure':'resource_exhausted','timeout_error':'timeout'}
new_accept={x['id']for x in results if x['outcome']['status']=='accepted'}
old_accept={sid for sid,x in old.items()if x['status']=='valid'}
transitions=collections.Counter((labels.get(old[sid]['status'],old[sid]['status']),x['outcome']['status'])for sid,x in current.items())
changes=[dict(id=sid,old=old[sid]['status'],current=x['outcome']['status'])for sid,x in current.items()if labels.get(old[sid]['status'],old[sid]['status'])!=x['outcome']['status']]
attempts=[a for x in results for a in x['attempts']]
partial_resource_ids=json.loads((r/'artifacts/engine-resource-profile-2026-10-25/isolated42/original-outcomes.json').read_text())
resource42=[dict(id=x['source_id'],outcome=current[x['source_id']]['outcome']['status'],attempts=[dict(status=a['status'],exclusive=a['exclusive'],seconds=a['elapsed_seconds'],peak_rss_bytes=a['peak_rss_bytes'],preemption_rss_bytes=a['preemption_rss_bytes'])for a in current[x['source_id']]['attempts']])for x in partial_resource_ids]
resource_events=[dict(id=x['id'],attempt_index=i,status=a['status'],exclusive=a['exclusive'],preemption_rss_bytes=a['preemption_rss_bytes'],elapsed_seconds=a['elapsed_seconds'],processes=a['processes'])for x in results for i,a in enumerate(x['attempts'])if a['preemption_rss_bytes'] is not None]
snapshots=0;over=0;maxrss=0;maxleaders=0
for line in (n/'rss-cpu.jsonl').read_text().splitlines():
 s=json.loads(line);snapshots+=1;rss=s.get('aggregate_rss_bytes')
 if rss is not None:maxrss=max(maxrss,rss);over+=rss>48*1024**3
 maxleaders=max(maxleaders,len(s.get('registered_leaders',[])))
physical=collections.Counter()
for line in (n/'attempts.jsonl').read_text().splitlines():physical[json.loads(line)['outcome']['status']]+=1
terminal=json.loads((n/'terminal.json').read_text())
assert snapshots==terminal['observations']['retained_samples'] and maxrss<=terminal['observations']['sampled_peak_rss_bytes']
summary=dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),condition='native complete; prepared cell terminated ENOSPC,partial preserved',sources=7808,original_input_equal=True,
 resources=d['resources'],lifecycle_seconds=d['lifecycle_seconds'],external_cell_seconds=terminal['external_cell_seconds'],
 final_statuses=dict(collections.Counter(x['outcome']['status']for x in results)),
 final_attempt_statuses=dict(collections.Counter(a['status']for a in attempts)),physical_journal_statuses=dict(physical),
 sources_with_retry=sum(len(x['attempts'])>1 for x in results),watchdog_events=len(resource_events),
 exclusive_budget_failures=sum(x['outcome']['status']=='resource_exhausted'for x in results),
 sampled_peak_rss_bytes=terminal['observations']['sampled_peak_rss_bytes'],sampled_peak_GiB=terminal['observations']['sampled_peak_rss_bytes']/1024**3,retained_one_second_peak_rss_bytes=maxrss,samples=snapshots,samples_over_budget=over,max_registered_leaders=maxleaders,
 peak_excess_bytes=terminal['observations']['sampled_peak_rss_bytes']-48*1024**3,journal_errors=terminal['journal_errors'],monitor_peak_scope='All admission/watchdog observations; raw JSONL is thinned to at most one retained sample/second,so its maximum need not equal monitor peak.',
 old_status_scope='Historical2workers/24GiB AS per-process data; compare sets only,no time/speed inference.',
 accepted_missing_vs_old=sorted(old_accept-new_accept),accepted_added_vs_old=sorted(new_accept-old_accept),
 old_accepted=len(old_accept),current_accepted=len(new_accept),status_transitions=[dict(old=a,current=b,count=n)for(a,b),n in transitions.items()],
 historic42_current_statuses=dict(collections.Counter(x['outcome']for x in resource42)),
 native_backend_faults=[dict(id=x['id'],error_excerpt=(x['outcome']['error']or'')[:220],deep_simplex_stack_in_tail='simplexAlgorithm'in(x['outcome']['error']or''))for x in results if x['outcome']['status']=='backend_error'],
 pair_speedup=None,scope='Complete native cell. Actual preempted physical outcomes differ from final classification. One-second sampled watchdog can overshoot;not a hard48GiBquota. No prepared parity/result or performance conclusion.')
for name,obj in [('summary.json',summary),('status-changes-vs-historic.json',changes),('historic42-current.json',resource42),('watchdog-events.json',resource_events)]:
 (out/name).write_text(json.dumps(obj,indent=2)+chr(10))
# Closed native data only; preserve active originals byte-for-byte.
for name in ['attempts.jsonl','rss-cpu.jsonl']:
 data=(n/name).read_bytes();dest=n/(name+'.gz');assert not dest.exists()
 dest.write_bytes(gzip.compress(data,mtime=0));assert gzip.decompress(dest.read_bytes())==data
print(json.dumps(summary))
