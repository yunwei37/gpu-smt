#!/usr/bin/env python3
"""Capture complete original formal candidates through native/external checkers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import select
import signal
import subprocess
import time

from lean_capture_snapshot import dispose_worker, enable_owned_child_reaping
from lean_capture_warm import ResourceCapture
from analyze_lean_preparation import interpret


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ['input', 'tasks', 'native', 'reference', 'backend', 'workspace', 'sysroot', 'out']:
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--method', choices=['native', 'cpu', 'gpu'], required=True)
    ap.add_argument('--lean-path', required=True)
    ap.add_argument('--jobs', type=int, required=True)
    ap.add_argument('--resources', action='store_true')
    args = ap.parse_args()
    if args.jobs < 1:
        ap.error('positive native worker count required')
    inputs = [json.loads(line) for line in args.input.read_bytes().splitlines() if line.strip()]
    if not inputs or len({row['index'] for row in inputs}) != len(inputs):
        ap.error('nonempty source-native inputs with unique indices required')
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / 'input.jsonl').write_bytes(args.input.read_bytes())
    (args.out / 'tasks.json').write_bytes(args.tasks.read_bytes())
    (args.out / 'executed-capture.py').write_bytes(Path(__file__).read_bytes())
    env = dict(os.environ, LEAN_SYSROOT=str(args.sysroot), LEAN_PATH=args.lean_path,
               PATH=str(args.sysroot / 'bin') + ':' + os.environ.get('PATH', ''))
    for key in ['LEAN_NUM_THREADS', 'GPU_SMT_PARENT_PREPARATION', 'GPU_SMT_WORKER_RETIRE_AFTER',
                'GPU_SMT_PARENT_SEED_FIRST_HEADER', 'GPU_SMT_CHECKPOINT_INDEX',
                'GPU_SMT_CHECKPOINT_STAGE', 'GPU_SMT_NATIVE_PROFILER']:
        env.pop(key, None)
    if args.method != 'gpu':
        for key in list(env):
            if key.startswith('LEAN_GPU_'):
                env.pop(key)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    enable_owned_child_reaping()
    receipt = {'method': args.method, 'jobs': args.jobs, 'expected_inputs': len(inputs),
               'affinity': sorted(os.sched_getaffinity(0)),
               'input_sha256': hashlib.sha256(args.input.read_bytes()).hexdigest(),
               'native_sha256': hashlib.sha256(args.native.read_bytes()).hexdigest(),
               'reference_sha256': hashlib.sha256(args.reference.read_bytes()).hexdigest(),
               'environment': {key: value for key, value in env.items()
                               if key.startswith(('LEAN_', 'GPU_SMT_'))},
               'runtime': 'native default threads; unchanged original 300s candidate timeout',
               'boundary': 'complete source verification, setup/replacement/backend/fallback/EOF; not proving accuracy',
               'start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    (args.out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    events = (args.out / 'events.jsonl').open('x')
    results = (args.out / 'results.jsonl').open('x')
    monitor = ResourceCapture(args.out) if args.resources else None
    slots = [{'proc': None, 'used': 0, 'generation': 0, 'active': None, 'worker': worker}
             for worker in range(args.jobs)]
    source_cache = {}
    signals = []
    handlers = {sig: signal.signal(sig, lambda number, _: signals.append(number))
                for sig in [signal.SIGINT, signal.SIGTERM]}
    begin = time.monotonic_ns()
    completed = 0
    next_index = 0

    def event(kind, **fields):
        events.write(json.dumps({'event': kind, 'monotonic_ns': time.monotonic_ns(), **fields}) + '\n')
        events.flush()

    def close(slot, graceful):
        if slot['proc'] is None:
            return
        cleanup = dispose_worker(slot['proc'], slot['raw'], graceful)
        slot['raw'].close()
        slot['error'].close()
        event('worker_exit', worker=slot['worker'], pid=slot['proc'].pid,
              returncode=slot['proc'].returncode, cleanup=cleanup)
        slot['proc'] = None

    def start(slot):
        directory = args.out / f"worker-{slot['worker']:04d}-session-{slot['generation']:08d}"
        slot['generation'] += 1
        directory.mkdir()
        if args.method == 'native':
            command = [str(args.reference), 'full', '-', str(args.sysroot), str(len(inputs))]
        else:
            command = [str(args.native), 'external-prefix', '-', str(args.tasks.resolve()),
                       str(directory / 'witnesses'), str(args.sysroot), str(args.backend)]
        slot['raw'] = (directory / 'stdout.bin').open('xb', buffering=0)
        slot['error'] = (directory / 'stderr.bin').open('xb', buffering=0)
        slot['proc'] = subprocess.Popen(command, cwd=args.workspace, env=env,
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                       stderr=slot['error'], start_new_session=True, bufsize=0)
        os.set_blocking(slot['proc'].stdin.fileno(), False)
        os.set_blocking(slot['proc'].stdout.fileno(), False)
        slot['pending'] = b''
        event('worker_start', worker=slot['worker'], pid=slot['proc'].pid,
              command=command, directory=str(directory))

    def finish(slot, status, record=None, error=None):
        nonlocal completed
        job = slot['active']
        end = time.monotonic_ns()
        if status != 'response':
            close(slot, False)
        row = {'source_index': job['input']['index'], 'ordinal': job['ordinal'],
               'status': status, 'record': record, 'error': error,
               'admission_monotonic_ns': job['begin'], 'terminal_monotonic_ns': end,
               'seconds': (end - job['begin']) / 1e9, 'cached': False,
               'worker': slot['worker']}
        if status == 'response':
            if args.method == 'native':
                native = record.get('record', {}).get('native', {})
                frame = native.get('response')
                row['outcome'] = interpret(frame, {'status': 'response', 'error': None}, None, 'warm')['outcome']
            else:
                value = record['result']
                checked = (value.get('backend') or {}).get('checked') or {}
                if checked.get('code') == 3 and not value.get('native_fallback'):
                    row['outcome'] = 'backend_operational_failure'
                elif value.get('has_errors'):
                    row['outcome'] = 'rejected'
                elif value.get('has_sorry'):
                    row['outcome'] = 'incomplete'
                elif value.get('accepted'):
                    row['outcome'] = 'complete'
                else:
                    row['outcome'] = 'rejected'
            slot['used'] += 1
            if row['outcome'] == 'complete':
                source_cache[job['key']] = row
        else:
            row['outcome'] = status
        results.write(json.dumps(row) + '\n')
        results.flush()
        event('source_terminal', index=row['source_index'], status=status,
              outcome=row['outcome'], worker=slot['worker'])
        completed += 1
        slot['active'] = None

    try:
        while next_index < len(inputs) or any(slot['active'] for slot in slots):
            if monitor:
                monitor.sample()
            if signals:
                break
            for slot in slots:
                if slot['active'] is not None or next_index >= len(inputs):
                    continue
                item = inputs[next_index]
                started = time.monotonic_ns()
                key = (item['header'], item['code'])
                slot['active'] = {'input': item, 'ordinal': next_index, 'begin': started,
                                  'deadline': started + 300_000_000_000,
                                  'payload': (json.dumps(item, ensure_ascii=False) + '\n').encode(),
                                  'written': 0, 'key': key}
                next_index += 1
                if key in source_cache:
                    old = source_cache[key]
                    row = dict(old, source_index=item['index'], ordinal=slot['active']['ordinal'],
                               cached=True, cached_from_index=old['source_index'],
                               admission_monotonic_ns=started,
                               terminal_monotonic_ns=time.monotonic_ns(), seconds=0)
                    row['seconds'] = (row['terminal_monotonic_ns'] - started) / 1e9
                    results.write(json.dumps(row) + '\n')
                    results.flush()
                    completed += 1
                    slot['active'] = None
                    continue
                if slot['proc'] is None:
                    start(slot)
            live = [slot for slot in slots if slot['active'] is not None]
            if not live:
                continue
            readable, writable, _ = select.select(
                [slot['proc'].stdout for slot in live],
                [slot['proc'].stdin for slot in live
                 if slot['active']['written'] < len(slot['active']['payload'])], [], .05)
            for slot in live:
                proc, job = slot['proc'], slot['active']
                if time.monotonic_ns() >= job['deadline']:
                    finish(slot, 'timeout', error='original whole candidate deadline')
                    continue
                try:
                    if proc.stdin in writable:
                        try:
                            job['written'] += os.write(proc.stdin.fileno(), job['payload'][job['written']:])
                        except BlockingIOError:
                            pass
                    if proc.stdout not in readable:
                        continue
                    data = os.read(proc.stdout.fileno(), 65536)
                    if not data:
                        finish(slot, 'operational_failure', error='native/backend EOF before source terminal')
                        continue
                    slot['raw'].write(data)
                    slot['pending'] += data
                    while b'\n' in slot['pending']:
                        line, slot['pending'] = slot['pending'].split(b'\n', 1)
                        message = json.loads(line)
                        if args.method == 'native':
                            native = message.get('record', {}).get('native')
                            if not isinstance(native, dict):
                                finish(slot, 'adapter_error', record=message)
                                break
                            index = native.get('index')
                        else:
                            if 'index' not in message or 'result' not in message:
                                event('backend_stage', worker=slot['worker'], record=message)
                                continue
                            index = message['index']
                        if index != job['input']['index']:
                            raise ValueError('returned source index differs from actual input')
                        finish(slot, 'response', record=message)
                        break
                except (ValueError, KeyError, TypeError, BrokenPipeError, OSError) as error:
                    if slot['active'] is not None:
                        finish(slot, 'transport_error', error=str(error))
        for slot in slots:
            close(slot, not signals)
    finally:
        for slot in slots:
            if slot['proc'] is not None:
                close(slot, False)
        if monitor:
            monitor.close()
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
        receipt.update(finished_inputs=completed, signals=signals,
                       whole_capture_ns=time.monotonic_ns() - begin,
                       end_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
        (args.out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        events.close()
        results.close()
    return 0 if completed == len(inputs) and not signals else 1


if __name__ == '__main__':
    raise SystemExit(main())
