#!/usr/bin/env python3
"""Capture the offline prepared-parent qualification, retaining native bytes.

This is experiment acquisition, not a persistent worker or service. The parent
preparation is externally covered by the original 300s candidate budget. A
configured cancellation consumes only a native marker from this owned child.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import time
import traceback

from lean_capture_warm import ResourceCapture


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ['input', 'native', 'lake', 'sysroot', 'workspace', 'out']:
        ap.add_argument('--' + name, type=Path, required=True)
    ap.add_argument('--jobs', type=int, default=1)
    ap.add_argument('--warm-pool', action='store_true', help='finite seeded long-lived native worker mode')
    ap.add_argument('--retire-after',type=int,help='normal EOF replacement after this many worker responses')
    ap.add_argument('--parent-seed-first-header',action='store_true',help='prepare only first supplied public header, no future header lookahead')
    ap.add_argument('--resources', action='store_true')
    ap.add_argument('--parent-preparation', choices=['imports', 'header', 'header-cache', 'full'], default='imports')
    ap.add_argument('--native-runtime-default', action='store_true', help='use discovered native runtime threads for this declared acquisition')
    ap.add_argument('--lean-path', help='existing native dependency path; bypass Lake reconciliation')
    ap.add_argument('--cancel-index', type=int)
    ap.add_argument('--cancel-stage', choices=['frontend_begin', 'frontend_complete'])
    args = ap.parse_args()
    if args.jobs <= 0:
        ap.error('positive jobs required')
    if args.retire_after is not None and (args.retire_after<=0 or not args.warm_pool):
        ap.error('positive retirement requires warm pool')
    if (args.cancel_index is None) != (args.cancel_stage is None):
        ap.error('both cancellation identity and native stage are required')
    native, lake, sysroot, workspace = [x.resolve(strict=True) for x in
        [args.native, args.lake, args.sysroot, args.workspace]]
    data = args.input.read_bytes()
    inputs = [json.loads(x) for x in data.splitlines() if x.strip()]
    if not inputs or len({x['index'] for x in inputs}) != len(inputs):
        ap.error('nonempty unique native source identities required')
    if args.cancel_index is not None and args.cancel_index not in [x['index'] for x in inputs]:
        ap.error('cancellation identity not in original input')
    args.out.mkdir(parents=True, exist_ok=False)
    inp = (args.out / 'input.jsonl').resolve()
    inp.write_bytes(data)
    (args.out / 'executed-capture.py').write_bytes(Path(__file__).read_bytes())
    cmd = [str(native), str(inp), str(sysroot)] if args.lean_path else [str(lake), 'env', str(native), str(inp), str(sysroot)]
    if args.warm_pool:
        cmd = ([str(native), 'warm-pool', str(inp), str(sysroot), str(args.jobs)] if args.lean_path else
               [str(lake), 'env', str(native), 'warm-pool', str(inp), str(sysroot), str(args.jobs)])
    elif args.jobs != 1:
        cmd.append(str(args.jobs))
    env = dict(os.environ, LEAN_SYSROOT=str(sysroot),
               PATH=str(sysroot / 'bin') + ':' + os.environ.get('PATH', ''))
    if args.native_runtime_default:
        env.pop('LEAN_NUM_THREADS', None)
    env['GPU_SMT_PARENT_PREPARATION'] = args.parent_preparation
    for key in ['GPU_SMT_WORKER_RETIRE_AFTER','GPU_SMT_PARENT_SEED_FIRST_HEADER']:
        env.pop(key,None)
    if args.retire_after is not None:env['GPU_SMT_WORKER_RETIRE_AFTER']=str(args.retire_after)
    if args.parent_seed_first_header:env['GPU_SMT_PARENT_SEED_FIRST_HEADER']='1'
    if args.lean_path:
        env['LEAN_PATH'] = args.lean_path
    for key in ['GPU_SMT_CHECKPOINT_INDEX', 'GPU_SMT_CHECKPOINT_STAGE']:
        env.pop(key, None)
    if args.cancel_index is not None:
        env['GPU_SMT_CHECKPOINT_INDEX'] = str(args.cancel_index)
        env['GPU_SMT_CHECKPOINT_STAGE'] = args.cancel_stage
    receipt = dict(warm_pool=args.warm_pool, response_boundary='framed native response; worker remains alive' if args.warm_pool else 'disposable child exit', command=cmd, cwd=str(workspace), expected_inputs=len(inputs), jobs=args.jobs,
                   native_sha256=hashlib.file_digest(native.open('rb'), 'sha256').hexdigest(),
                   input_sha256=hashlib.sha256(data).hexdigest(),
                   affinity=sorted(os.sched_getaffinity(0)),
                   environment={k: env.get(k) for k in ['LEAN_SYSROOT', 'LEAN_NUM_THREADS',
                       'XDG_CACHE_HOME', 'GPU_SMT_CHECKPOINT_INDEX', 'GPU_SMT_CHECKPOINT_STAGE',
                       'GPU_SMT_PARENT_PREPARATION','GPU_SMT_WORKER_RETIRE_AFTER','GPU_SMT_PARENT_SEED_FIRST_HEADER', 'LEAN_PATH']},
                   start_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                   role='finite native acquisition; complete-command performance requires external driver clocks',
                   candidate_latency_scope='first candidate includes parent launch/preparation; later candidates native admission to parent terminal-message observation before payload decoding/persistence; not offered-load latency')
    receipt_path = args.out / 'receipt.json'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    signals = []
    old_handlers = {n: signal.signal(n, lambda number, _: signals.append(number))
                    for n in [signal.SIGINT, signal.SIGTERM]}
    resources = ResourceCapture(args.out) if args.resources else None
    begin = time.monotonic_ns()
    preparing = {-1: begin + 300_000_000_000}
    children = {}
    admitted = set()
    admission_times = {}
    returned = set()
    proc = None
    parent_pid = None
    pending = []
    cancelled = []
    records = []
    error = None
    reason = 'native_exit'
    selector = selectors.DefaultSelector()
    buffers = {'stdout': b'', 'stderr': b''}
    raw = {k: (args.out / (k + '.bin')).open('xb', buffering=0) for k in buffers}
    events = (args.out / 'capture-events.jsonl').open('x')
    parsed = (args.out / 'native-events.jsonl').open('x')
    results = (args.out / 'results.jsonl').open('x')

    def event(kind, **fields):
        events.write(json.dumps(dict(event=kind, monotonic_ns=time.monotonic_ns(), **fields)) + '\n')
        events.flush()

    def stopped_child(pid):
        try:
            text = Path('/proc/' + str(pid) + '/stat').read_text()
            fields = text[text.rfind(')') + 2:].split()
            return dict(pid=pid, state=fields[0], ppid=int(fields[1]), pgid=int(fields[2]),
                        tids=sorted(int(x.name) for x in Path('/proc/' + str(pid) + '/task').iterdir()))
        except FileNotFoundError:
            return None

    def consume(kind, line):
        nonlocal parent_pid
        observed_ns = time.monotonic_ns()
        try:
            item = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            if kind == 'stdout':
                raise ValueError('non-JSON native protocol stdout')
            return
        if not isinstance(item, dict):
            if kind == 'stdout':
                raise ValueError('non-object native protocol stdout')
            return
        if kind == 'stderr':
            if item.get('gpu_smt_checkpoint'):
                pending.append(item)
            return
        parsed.write(json.dumps(item) + '\n'); parsed.flush()
        if item.get('event') == 'initialized':
            parent_pid = item['parent_pid']
            if os.getpgid(parent_pid) != proc.pid:
                raise ValueError('native parent outside owned launch group')
        elif item.get('event') == 'admitted':
            ordinal = item['source_index']
            if not isinstance(ordinal, int) or ordinal < 0 or ordinal >= len(inputs) or ordinal in admitted:
                raise ValueError('duplicate admission or admission outside input')
            admitted.add(ordinal)
            preparing.pop(-1, None)
            admission_times[ordinal] = begin if ordinal == 0 else item['monotonic_ns']
            preparing[ordinal] = admission_times[ordinal] + 300_000_000_000
        elif item.get('event') == 'launched':
            ordinal, child_pid = item['source_index'], item['child_pid']
            if ordinal not in preparing or child_pid in children.values():
                raise ValueError('native launch identity mismatch')
            children[ordinal] = child_pid
            del preparing[ordinal]
        elif item.get('event') == 'candidate':
            ordinal = item['source_index']
            if ordinal not in admitted or ordinal in returned or children.get(ordinal) != item['child_pid']:
                raise ValueError('native candidate identity/count mismatch')
            returned.add(ordinal)
            row = dict(ordinal=ordinal, source_index=inputs[ordinal]['index'], native_event=item,
                       admission_monotonic_ns=admission_times[ordinal],
                       terminal_observed_monotonic_ns=observed_ns,
                       native_response=None, status='timeout' if item['timeout'] else 'unknown')
            payload = bytes.fromhex(item['stdout_hex'])
            (args.out / ('candidate-%08d.stdout.bin' % ordinal)).write_bytes(payload)
            if (item['returncode'] == 0 or (args.warm_pool and item.get('response_ready') is True and item['returncode'] is None)) and not any(item[k] for k in ['timeout', 'transport_error', 'interrupted']):
                try:
                    response = json.loads(payload)
                    if response['native']['index'] != row['source_index']:
                        raise ValueError('inner native source identity mismatch')
                    row['native_response'] = response
                    row['status'] = 'response'
                except (ValueError, KeyError, TypeError):
                    row['error'] = traceback.format_exc()
            if row['source_index'] in [x['source_index'] for x in cancelled]:
                row['status'] = 'cancelled' if item['returncode'] == 137 else 'unknown'
            records.append(row)
            results.write(json.dumps(row) + '\n'); results.flush()
            del children[ordinal]  # source identity, independent of completion order

    try:
        proc = subprocess.Popen(cmd, cwd=workspace, env=env, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                start_new_session=True, bufsize=0)
        event('launched', pid=proc.pid, pgid=proc.pid, begin_ns=begin)
        for kind, stream in [('stdout', proc.stdout), ('stderr', proc.stderr)]:
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, kind)
        while selector.get_map():
            if resources:
                resources.sample()
            if signals:
                reason = 'supervisor_signal'; break
            # The C timer owns active-child expiry/kill/reap and its terminal
            # record. Racing that timer would kill the reusable parent before
            # it can record timeout and admit the next original source row.
            if preparing and time.monotonic_ns() >= min(preparing.values()):
                reason = 'preparation_timeout'; break
            for key, _ in selector.select(.05):
                kind = key.data
                chunk = os.read(key.fileobj.fileno(), 65536)
                if not chunk:
                    selector.unregister(key.fileobj)
                    if buffers[kind] and kind == 'stdout':
                        raise ValueError('unterminated native protocol stdout')
                    continue
                raw[kind].write(chunk)
                buffers[kind] += chunk
                while b'\n' in buffers[kind]:
                    line, buffers[kind] = buffers[kind].split(b'\n', 1)
                    consume(kind, line)
            for marker in pending[:]:
                if marker.get('source_index') != args.cancel_index or marker.get('stage') != args.cancel_stage:
                    raise ValueError('unexpected native cancellation marker')
                child_pid = marker.get('pid')
                active = [ordinal for ordinal, pid in children.items() if pid == child_pid]
                if not active:
                    continue  # stdout launch and stderr marker may arrive in either order
                if inputs[active[0]]['index'] != marker['source_index']:
                    raise ValueError('checkpoint native source identity mismatch')
                observed = stopped_child(child_pid)
                if not observed or observed['state'] != 'T':
                    continue  # native flush precedes SIGSTOP
                if observed['ppid'] != parent_pid or observed['pgid'] != child_pid:
                    raise ValueError('checkpoint is not this native parent\'s owned child')
                if cancelled:
                    raise ValueError('duplicate cancellation marker')
                siblings = [stopped_child(pid) for pid in children.values() if pid != child_pid]
                siblings = [x for x in siblings if x and x['ppid'] == parent_pid and x['pgid'] == x['pid'] and x['state'] != 'Z']
                event('confirmed_stopped_child', marker=marker, observed=observed,
                      active_children=dict(children), live_siblings=siblings)
                os.killpg(child_pid, signal.SIGKILL)
                cancelled.append(dict(source_index=args.cancel_index, stage=args.cancel_stage,
                                      marker=marker, observed=observed))
                pending.remove(marker)
                event('owned_child_cancelled', pid=child_pid, source_index=args.cancel_index)
    except Exception:
        error = traceback.format_exc(); reason = 'capture_error'
    finally:
        if proc is not None:
            if reason == 'native_exit' and not selector.get_map():
                try:
                    deadline = min(preparing.values()) if preparing else None
                    proc.wait(timeout=None if deadline is None else max(0, (deadline - time.monotonic_ns()) / 1e9))
                except subprocess.TimeoutExpired:
                    reason = 'whole_candidate_timeout'
            if proc.poll() is None:
                if reason == 'native_exit':
                    reason = 'native_transport_closed_before_exit'
                for child_pid in list(children.values()):
                    observed = stopped_child(child_pid)
                    if observed and observed['ppid'] == parent_pid and observed['pgid'] == child_pid:
                        os.killpg(child_pid, signal.SIGKILL)
                        event('owned_child_cleanup', observed=observed)
                os.killpg(proc.pid, signal.SIGKILL)
            receipt['returncode'] = proc.wait()
        receipt.update(finish_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                       whole_process_elapsed_ns=time.monotonic_ns() - begin,
                       terminal_records=len(records), response_records=sum(x['status'] == 'response' for x in records),
                       cancelled=cancelled, pending_markers=pending, reason=reason, error=error,
                       active_children=children, unfinished_preparation=preparing,
                       signals=signals, load_average_end=os.getloadavg())
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        event('shutdown', receipt=str(receipt_path), reason=reason)
        for f in [*raw.values(), events, parsed, results]:
            f.close()
        selector.close()
        if resources:
            resources.close()
        for n, handler in old_handlers.items():
            signal.signal(n, handler)
    return 0 if receipt.get('returncode') == 0 and len(records) == len(inputs) and not error else 1


if __name__ == '__main__':
    raise SystemExit(main())
