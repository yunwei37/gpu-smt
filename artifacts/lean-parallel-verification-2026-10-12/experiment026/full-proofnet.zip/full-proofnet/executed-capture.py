#!/usr/bin/env python3
"""Serial capture of the pinned stock full-snapshot frontend, not a new service.

Retains native responses, whole request/process lifecycle clocks and owned
timeout outcomes. All tasks/samples remain in original order. Process retirement
reclaims that worker; it does not certify cancellation or kernel safety.
"""
import argparse
import ctypes
import resource
import json
import math
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time
import traceback

from lean_capture_warm import file_info, digest, DEFAULT_HEADER, ResourceCapture



def save(path, data):
    # Match prepared acquisition: exclusive capture files, ordinary close/flush,
    # without a per-request experimental fsync penalty on only one method.
    with path.open('xb') as stream:
        stream.write(data)



def enable_owned_child_reaping():
    # This finite acquisition becomes the Linux reaper of orphaned descendants
    # only so timeout disposal retains their wait-accounted CPU. No daemon or
    # persistent host setting is introduced. Ordinary lake/native launch stays.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err))


def dispose_worker(proc, output, graceful):
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    if graceful:
        # Native stdin EOF returns normally; Lake waits for its native child.
        # Do not kill Lake before its child CPU has propagated through wait.
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
    else:
        # Keep the leader PID reserved until this owned group is killed.
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    while True:
        readable, _, _ = select.select([proc.stdout], [], [], .05)
        if readable:
            tail = os.read(proc.stdout.fileno(), 65536)
            if not tail:
                break
            output.write(tail)
        elif proc.poll() is not None:
            break
    proc.wait()
    adopted = []
    while True:
        try:
            pid, status, usage = os.wait4(-proc.pid, 0)
        except ChildProcessError:
            break
        except InterruptedError:
            continue
        adopted.append(dict(pid=pid, wait_status=status,
            user_seconds=usage.ru_utime, system_seconds=usage.ru_stime))
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    if not proc.stdin.closed:
        proc.stdin.close()
    proc.stdout.close()
    return dict(graceful_eof=graceful, adopted_group_descendants=adopted,
        waited_children_cpu_seconds=(after.ru_utime + after.ru_stime) -
            (before.ru_utime + before.ru_stime))


def run_pool(args, codes, tasks, samples_per_task, command, env, native, lake, sysroot, workspace):
    """Finite parallel acquisition of the same stock stdin snapshot baseline."""
    args.out.mkdir(parents=True, exist_ok=False)
    save(args.out / 'codes.original.json', args.codes.read_bytes())
    save(args.out / 'tasks.original.json', args.tasks.read_bytes())
    save(args.out / 'executed-capture.py', Path(__file__).read_bytes())
    signals = []
    old = {n: signal.signal(n, lambda number, _: signals.append(number))
           for n in [signal.SIGTERM, signal.SIGINT]}
    slots = [dict(proc=None, used=0, generation=0, active=None, stdout=None, stderr=None)
             for _ in range(min(args.jobs, len(codes)))]
    completed = []
    resources = ResourceCapture(args.out) if args.resources else None
    sequence = 0
    with (args.out / 'events.jsonl').open('x') as events:
        def event(kind, **fields):
            nonlocal sequence
            events.write(json.dumps(dict(event=kind, sequence=sequence,
                wall_ns=time.time_ns(), monotonic_ns=time.monotonic_ns(), **fields), ensure_ascii=False) + '\n')
            sequence += 1
            events.flush()

        def close(slot, reason):
            proc = slot['proc']
            if proc is None:
                return
            cleanup = dispose_worker(proc, slot['stdout'], reason in ['retire_limit', 'shutdown'])
            slot['stdout'].close(); slot['stderr'].close()
            event('replacement', worker=slot['worker'], session=slot['generation'] - 1,
                  reason=reason, returncode=proc.returncode, **cleanup)
            slot.update(proc=None, stdout=None, stderr=None, used=0)

        def start(slot):
            session = args.out / ('worker-%04d-session-%08d' % (slot['worker'], slot['generation']))
            session.mkdir()
            slot['stdout'] = (session / 'stdout.bin').open('xb', buffering=0)
            slot['stderr'] = (session / 'stderr.bin').open('xb', buffering=0)
            try:
                proc = subprocess.Popen(command, cwd=workspace, env=env, stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE, stderr=slot['stderr'], start_new_session=True, bufsize=0)
            except Exception:
                slot['stdout'].close(); slot['stderr'].close()
                slot.update(stdout=None, stderr=None)
                raise
            slot['proc'] = proc
            os.set_blocking(proc.stdin.fileno(), False)
            os.set_blocking(proc.stdout.fileno(), False)
            event('launched', worker=slot['worker'], session=slot['generation'], pid=proc.pid, pgid=proc.pid)
            slot['generation'] += 1
            slot['used'] = 0

        def finish(slot, status, error=None, response=None):
            job = slot['active']
            if status != 'response':
                close(slot, status)
            end = time.monotonic_ns()
            save(job['folder'] / 'native-record.bin', job['raw'])
            if response and isinstance(response.get('record'), dict) and isinstance(response['record'].get('native'), dict):
                save(job['folder'] / 'response.bin', json.dumps(response['record']['native']['response'], ensure_ascii=False).encode())
            save(job['folder'] / 'result.json', json.dumps(dict(source_index=job['index'],
                worker=slot['worker'], session=slot['generation'] - 1, status=status, error=error,
                stdin_bytes_written=job['written'], invocation_elapsed_ns=end - job['begin'],
                native_operation_elapsed_ns=response.get('elapsed_ns') if response else None), indent=2).encode())
            event('whole_job_end', source_index=job['index'], worker=slot['worker'], status=status,
                  end_ns=end, invocation_elapsed_ns=end - job['begin'])
            completed.append(job['index'])
            slot['active'] = None
            if status == 'response':
                slot['used'] += 1

        event('run', command=command, cwd=str(workspace), count=len(codes), mode=args.mode,
            task_count=len(tasks), samples_per_task=samples_per_task, jobs=args.jobs,
            timeout_seconds=args.timeout, retire_after=args.retire_after,
            affinity=sorted(os.sched_getaffinity(0)), load_average_start=os.getloadavg(),
            environment={k: env.get(k) for k in ['PATH', 'LEAN_SYSROOT', 'LEAN_NUM_THREADS', 'XDG_CACHE_HOME', 'LEAN_PATH']},
            provenance={str(q): file_info(q) for q in [native, lake, Path(__file__),
                Path(__file__).with_name('lean_capture_warm.py'), sysroot / 'bin/lean',
                workspace / 'lean-toolchain', workspace / 'lake-manifest.json']},
            timing_scope='closed-loop complete source corpus through response/error and owned replacement/shutdown; no offered-load latency',
            scope='parallel stock full-snapshot baseline acquisition; no service memory guarantee')
        next_index = 0
        try:
            for worker, slot in enumerate(slots):
                slot['worker'] = worker
            while next_index < len(codes) or any(slot['active'] for slot in slots):
                if resources:
                    resources.sample()
                if signals:
                    break
                for slot in slots:
                    if slot['active'] is not None or next_index >= len(codes):
                        continue
                    index = next_index; next_index += 1
                    begin = time.monotonic_ns()
                    folder = args.out / ('request-%08d' % index); folder.mkdir()
                    payload = (json.dumps(dict(index=index, header=tasks[index // samples_per_task].get('header', DEFAULT_HEADER),
                        code=codes[index]['code']), ensure_ascii=False) + '\n').encode()
                    save(folder / 'stdin.bin', payload)
                    slot['active'] = dict(index=index, begin=begin, deadline=begin / 1e9 + args.timeout,
                        folder=folder, payload=payload, written=0, raw=b'')
                    event('whole_job_begin', source_index=index, worker=slot['worker'], begin_ns=begin,
                          deadline_ns=int(slot['active']['deadline'] * 1e9))
                    try:
                        if slot['proc'] and slot['used'] >= args.retire_after:
                            close(slot, 'retire_limit')
                        if slot['proc'] is None:
                            start(slot)
                    except Exception:
                        finish(slot, 'transport_error', traceback.format_exc())
                live = [slot for slot in slots if slot['active'] is not None]
                if not live:
                    continue
                readers = [slot['proc'].stdout for slot in live]
                writers = [slot['proc'].stdin for slot in live if slot['active']['written'] < len(slot['active']['payload'])]
                wait = min(.05, max(0, min(slot['active']['deadline'] for slot in live) - time.monotonic()))
                readable, writable, _ = select.select(readers, writers, [], wait)
                for slot in live:
                    proc, job = slot['proc'], slot['active']
                    try:
                        if time.monotonic() >= job['deadline']:
                            finish(slot, 'timeout', 'whole-candidate native deadline')
                            continue
                        if proc.stdin in writable:
                            try:
                                job['written'] += os.write(proc.stdin.fileno(), job['payload'][job['written']:])
                            except BlockingIOError:
                                pass
                        if proc.stdout not in readable:
                            continue
                        chunk = os.read(proc.stdout.fileno(), 65536)
                        if not chunk:
                            raise EOFError('native stdout closed before complete response')
                        slot['stdout'].write(chunk); job['raw'] += chunk
                        if b'\n' not in job['raw']:
                            continue
                        frame, tail = job['raw'].split(b'\n', 1)
                        if tail:
                            raise ValueError('extra native stdout after response')
                        response = json.loads(frame)
                        record = response.get('record') if isinstance(response, dict) else None
                        if not isinstance(record, dict):
                            raise ValueError('native response record is not an object')
                        native_record = record.get('native', record)
                        if not isinstance(native_record, dict) or native_record.get('index') != job['index']:
                            raise ValueError('native source index mismatch')
                        if 'native' not in record:
                            finish(slot, 'adapter_error', response=response)
                        else:
                            finish(slot, 'response', response=response)
                    except Exception:
                        finish(slot, 'transport_error', traceback.format_exc())
        finally:
            for slot in slots:
                if slot['active'] is not None:
                    finish(slot, 'interrupted', 'supervisor signal or acquisition exception')
                close(slot, 'shutdown')
            event('shutdown', completed=completed, not_admitted=list(range(next_index, len(codes))),
                  interrupted_signals=signals, load_average_end=os.getloadavg())
            if resources:
                resources.close()
            for number, handler in old.items():
                signal.signal(number, handler)
    return 0 if len(completed) == len(codes) and not signals else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--codes', type=Path, required=True)
    ap.add_argument('--tasks', type=Path, required=True)
    ap.add_argument('--native', type=Path, required=True)
    ap.add_argument('--lake', type=Path, required=True)
    ap.add_argument('--sysroot', type=Path, required=True)
    ap.add_argument('--workspace', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--jobs', type=int, default=1)
    ap.add_argument('--resources', action='store_true')
    ap.add_argument('--lean-path', help='existing dependency path; launch native without Lake reconciliation')
    ap.add_argument('--mode', choices=['full', 'imports'], default='full')
    ap.add_argument('--retire-after', type=int, default=256)
    ap.add_argument('--timeout', type=float, default=300)
    args = ap.parse_args()
    if args.jobs <= 0 or args.retire_after <= 0 or not math.isfinite(args.timeout) or args.timeout <= 0:
        ap.error('positive finite timeout and positive retirement count required')
    codes_bytes, tasks_bytes = args.codes.read_bytes(), args.tasks.read_bytes()
    codes, tasks = json.loads(codes_bytes), json.loads(tasks_bytes)
    if not isinstance(tasks, list) or not tasks or not isinstance(codes, list) or not codes or len(codes) % len(tasks):
        ap.error('positive original ordered task/sample groups required')
    width = len(codes) // len(tasks)
    for i, row in enumerate(codes):
        task = tasks[i // width]
        if not isinstance(row.get('code'), str) or row.get('name') != task.get('problem_id', task.get('name')) or \
                not isinstance(task.get('header', DEFAULT_HEADER), str):
            ap.error(f'original task/sample identity mismatch at {i}')
    native, lake, sysroot, workspace = [p.resolve(strict=True) for p in
        [args.native, args.lake, args.sysroot, args.workspace]]
    enable_owned_child_reaping()
    command = [str(native), args.mode, '-', str(sysroot), str(args.retire_after)]
    if not args.lean_path:
        command = [str(lake), 'env'] + command
    env = dict(os.environ, LEAN_SYSROOT=str(sysroot),
               PATH=str(sysroot / 'bin') + ':' + os.environ.get('PATH', ''))
    if args.lean_path:
        env['LEAN_PATH'] = args.lean_path
    if args.jobs != 1:
        raise SystemExit(run_pool(args, codes, tasks, width, command, env, native, lake, sysroot, workspace))
    args.out.mkdir(parents=True, exist_ok=False)
    save(args.out / 'codes.original.json', codes_bytes)
    save(args.out / 'tasks.original.json', tasks_bytes)
    interrupted = []
    old_handlers = {}
    for number in [signal.SIGTERM, signal.SIGINT]:
        old_handlers[number] = signal.signal(number, lambda n, _: interrupted.append(n))
    proc = None
    stdout = stderr = None
    generation = used = sequence = 0
    resources = ResourceCapture(args.out) if args.resources else None
    completed = []
    with (args.out / 'events.jsonl').open('x') as events:
        def event(kind, **fields):
            nonlocal sequence
            events.write(json.dumps(dict(event=kind, sequence=sequence, wall_ns=time.time_ns(),
                monotonic_ns=time.monotonic_ns(), **fields), ensure_ascii=False) + '\n')
            sequence += 1
            events.flush()

        def close(reason):
            nonlocal proc, stdout, stderr
            if proc is None:
                for stream in (stdout, stderr):
                    if stream is not None:
                        stream.close()
                stdout = stderr = None
                return
            cleanup = dispose_worker(proc, stdout, reason in ['retire_limit', 'shutdown'])
            stdout.close()
            stderr.close()
            event('replacement', reason=reason, session=generation - 1, returncode=proc.returncode, **cleanup)
            proc = stdout = stderr = None

        event('run', command=command, cwd=str(workspace), count=len(codes), mode=args.mode,
            task_count=len(tasks), samples_per_task=width, codes_sha256=digest(codes_bytes),
            tasks_sha256=digest(tasks_bytes), timeout_seconds=args.timeout, retire_after=args.retire_after,
            affinity=sorted(os.sched_getaffinity(0)), load_average_start=os.getloadavg(),
            environment={k: env.get(k) for k in ['PATH', 'LEAN_SYSROOT', 'LEAN_NUM_THREADS', 'XDG_CACHE_HOME', 'LEAN_PATH']},
            provenance={str(p): file_info(p) for p in [native, lake, Path(__file__),
                Path(__file__).with_name('lean_capture_warm.py'),
                sysroot / 'bin/lean', workspace / 'lean-toolchain', workspace / 'lake-manifest.json']},
            timing_scope='admission through response/error and synchronous owned cleanup; corpus includes persistence/startup/retirement/shutdown',
            scope='stock native snapshot baseline transport; no offered-load/concurrency or memory guarantee')
        try:
            for index, row in enumerate(codes):
                if interrupted:
                    event('not_launched', source_index=index, reason='supervisor_signal')
                    continue
                begin = time.monotonic_ns()
                deadline = begin / 1e9 + args.timeout
                event('whole_job_begin', source_index=index, begin_ns=begin, deadline_ns=int(deadline * 1e9))
                folder = args.out / f'request-{index:08d}'
                folder.mkdir()
                payload = (json.dumps(dict(index=index, header=tasks[index // width].get('header', DEFAULT_HEADER),
                    code=row['code']), ensure_ascii=False) + '\n').encode()
                save(folder / 'stdin.bin', payload)
                raw = b''
                response = None
                status = 'transport_error'
                error = None
                written = 0
                try:
                    if proc and used >= args.retire_after:
                        close('retire_limit')
                    if proc is None:
                        session = args.out / f'session-{generation:08d}'
                        session.mkdir()
                        stdout = (session / 'stdout.bin').open('xb', buffering=0)
                        stderr = (session / 'stderr.bin').open('xb', buffering=0)
                        proc = subprocess.Popen(command, cwd=workspace, env=env, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=stderr, start_new_session=True, bufsize=0)
                        os.set_blocking(proc.stdin.fileno(), False)
                        os.set_blocking(proc.stdout.fileno(), False)
                        event('launched', session=generation, pid=proc.pid, pgid=proc.pid)
                        generation += 1
                        used = 0
                    while written < len(payload) or b'\n' not in raw:
                        if resources:
                            resources.sample()
                        if interrupted:
                            status = 'interrupted'
                            raise InterruptedError('supervisor signal')
                        if time.monotonic() >= deadline:
                            status = 'timeout'
                            raise TimeoutError('whole-candidate native deadline')
                        readers, writers, _ = select.select([proc.stdout],
                            [proc.stdin] if written < len(payload) else [], [],
                            min(.05, max(0, deadline - time.monotonic())))
                        if writers:
                            try:
                                written += os.write(proc.stdin.fileno(), payload[written:])
                            except BlockingIOError:
                                pass
                        if readers:
                            chunk = os.read(proc.stdout.fileno(), 65536)
                            if not chunk:
                                raise EOFError('native stdout closed before complete response')
                            stdout.write(chunk)
                            raw += chunk
                    frame, tail = raw.split(b'\n', 1)
                    if tail:
                        raise ValueError('extra native stdout after response')
                    response = json.loads(frame)
                    if not isinstance(response, dict) or not isinstance(response.get('record'), dict):
                        raise ValueError('native response record is not an object')
                    record = response.get('record', {})
                    if 'native' in record and not isinstance(record['native'], dict):
                        raise ValueError('native observation is not an object')
                    if record.get('native', record).get('index') != index:
                        raise ValueError('native source index mismatch')
                    status = 'response' if 'native' in record else 'adapter_error'
                    used += 1
                    if status == 'adapter_error':
                        close('adapter_error')
                except Exception:
                    error = traceback.format_exc()
                    close(status)
                end = time.monotonic_ns()
                save(folder / 'native-record.bin', raw)
                if isinstance(response, dict) and isinstance(response.get('record'), dict) and \
                        isinstance(response['record'].get('native'), dict):
                    save(folder / 'response.bin', json.dumps(response['record']['native']['response'], ensure_ascii=False).encode())
                save(folder / 'result.json', json.dumps(dict(source_index=index, status=status,
                    error=error, stdin_bytes_written=written, invocation_elapsed_ns=end - begin,
                    native_operation_elapsed_ns=response.get('elapsed_ns') if isinstance(response, dict) else None,
                    session=generation - 1), indent=2).encode())
                event('whole_job_end', source_index=index, status=status, end_ns=end, invocation_elapsed_ns=end - begin)
                completed.append(index)
        finally:
            close('shutdown')
            if resources:
                resources.close()
            event('shutdown', completed=completed, interrupted_signals=interrupted,
                  load_average_end=os.getloadavg())
            for number, handler in old_handlers.items():
                signal.signal(number, handler)


if __name__ == '__main__':
    main()
