// Lean compiler output
// Module: Prepare
// Imports: Init Mathlib
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_Prepare_0__positions___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_compress(lean_object*);
LEAN_EXPORT lean_object* l___private_Prepare_0__positions(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* _lean_main(lean_object*);
static lean_object* l___private_Prepare_0__positions___closed__13;
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l___private_Prepare_0__positions___closed__8;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l___private_Prepare_0__positions___closed__15;
lean_object* l_Lean_Json_getObjValAs_x3f___at_Lean_JsonRpc_instFromJsonMessage___spec__3(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_Prepare_0__positions___spec__1(lean_object*, size_t, size_t, lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__9;
lean_object* l_Lean_Syntax_getPos_x3f(lean_object*, uint8_t);
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getTailPos_x3f(lean_object*, uint8_t);
static lean_object* l_main___closed__3;
static lean_object* l___private_Prepare_0__positions___closed__9;
lean_object* l_Lean_Json_getObjVal_x3f(lean_object*, lean_object*);
static lean_object* l___private_Prepare_0__positions___closed__7;
lean_object* lean_get_stdout(lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__10;
static lean_object* l___private_Prepare_0__positions___closed__2;
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__6;
size_t lean_usize_of_nat(lean_object*);
uint8_t l_String_isEmpty(lean_object*);
static lean_object* l___private_Prepare_0__positions___closed__12;
static lean_object* l_main___closed__1;
static lean_object* l___private_Prepare_0__positions___closed__14;
static lean_object* l_main___closed__5;
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_Prepare_0__positions___closed__5;
static lean_object* l_main___closed__4;
lean_object* lean_get_stdin(lean_object*);
static lean_object* l___private_Prepare_0__positions___closed__6;
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__5;
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___closed__2;
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8;
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__2;
static lean_object* l___private_Prepare_0__positions___closed__11;
lean_object* l_Array_append___rarg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Parser_runParserCategory(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1;
static lean_object* l___private_Prepare_0__positions___closed__3;
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__1___boxed(lean_object*, lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___closed__1;
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__3;
static lean_object* l___private_Prepare_0__positions___closed__1;
static lean_object* l___private_Prepare_0__positions___closed__10;
static lean_object* l___private_Prepare_0__positions___closed__4;
uint8_t l_List_elem___at___private_Mathlib_Tactic_Linter_HashCommandLinter_0__Mathlib_Linter_HashCommandLinter_allowed__commands___spec__3(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
lean_object* lean_array_uget(lean_object*, size_t);
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__1(lean_object*, lean_object*);
lean_object* l_IO_FS_Stream_putStrLn(lean_object*, lean_object*, lean_object*);
static lean_object* l_main___closed__2;
lean_object* lean_array_get_size(lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
lean_object* l_Lean_Json_parse(lean_object*);
lean_object* lean_import_modules(lean_object*, lean_object*, uint32_t, uint8_t, lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__7;
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__4;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_Prepare_0__positions___spec__1(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_3, x_2);
if (x_5 == 0)
{
return x_4;
}
else
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; size_t x_9; size_t x_10; 
x_6 = lean_array_uget(x_1, x_3);
x_7 = l___private_Prepare_0__positions(x_6);
x_8 = l_Array_append___rarg(x_4, x_7);
x_9 = 1;
x_10 = lean_usize_add(x_3, x_9);
x_3 = x_10;
x_4 = x_8;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; size_t x_6; size_t x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_5 = lean_array_get_size(x_1);
x_6 = lean_usize_of_nat(x_5);
lean_dec(x_5);
x_7 = 0;
x_8 = l_Array_forInUnsafe_loop___at___private_Prepare_0__positions___spec__1(x_1, x_6, x_7, x_3);
x_9 = lean_box(0);
x_10 = lean_apply_2(x_2, x_8, x_9);
return x_10;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_Prepare_0__positions___lambda__1___boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___private_Prepare_0__positions___closed__2;
x_2 = l___private_Prepare_0__positions___closed__1;
x_3 = lean_box(0);
x_4 = lean_apply_2(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("nlinarith!", 10);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l___private_Prepare_0__positions___closed__4;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("linarith!", 9);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Prepare_0__positions___closed__6;
x_2 = l___private_Prepare_0__positions___closed__5;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("nlinarith", 9);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Prepare_0__positions___closed__8;
x_2 = l___private_Prepare_0__positions___closed__7;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("linarith", 8);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Prepare_0__positions___closed__10;
x_2 = l___private_Prepare_0__positions___closed__9;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("start", 5);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("end", 3);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__14() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("tactic", 6);
return x_1;
}
}
static lean_object* _init_l___private_Prepare_0__positions___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_Prepare_0__positions(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 1)
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; uint8_t x_6; 
x_2 = lean_ctor_get(x_1, 2);
lean_inc(x_2);
x_3 = l___private_Prepare_0__positions___closed__2;
x_4 = lean_array_get_size(x_2);
x_5 = lean_unsigned_to_nat(0u);
x_6 = lean_nat_dec_lt(x_5, x_4);
lean_dec(x_4);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; 
lean_dec(x_1);
x_7 = l___private_Prepare_0__positions___closed__1;
x_8 = lean_box(0);
x_9 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_7, x_8);
lean_dec(x_2);
return x_9;
}
else
{
lean_object* x_10; 
x_10 = lean_array_fget(x_2, x_5);
if (lean_obj_tag(x_10) == 2)
{
uint8_t x_11; 
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_12 = lean_ctor_get(x_10, 1);
x_13 = lean_ctor_get(x_10, 0);
lean_dec(x_13);
x_14 = lean_box(0);
x_15 = l___private_Prepare_0__positions___closed__11;
x_16 = l_List_elem___at___private_Mathlib_Tactic_Linter_HashCommandLinter_0__Mathlib_Linter_HashCommandLinter_allowed__commands___spec__3(x_12, x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; 
lean_free_object(x_10);
lean_dec(x_12);
lean_dec(x_1);
x_17 = l___private_Prepare_0__positions___closed__1;
x_18 = lean_box(0);
x_19 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_17, x_18);
lean_dec(x_2);
return x_19;
}
else
{
uint8_t x_20; lean_object* x_21; 
x_20 = 0;
x_21 = l_Lean_Syntax_getPos_x3f(x_1, x_20);
if (lean_obj_tag(x_21) == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; 
lean_free_object(x_10);
lean_dec(x_12);
lean_dec(x_1);
x_22 = l___private_Prepare_0__positions___closed__1;
x_23 = lean_box(0);
x_24 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_22, x_23);
lean_dec(x_2);
return x_24;
}
else
{
uint8_t x_25; 
x_25 = !lean_is_exclusive(x_21);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_21, 0);
x_27 = l_Lean_Syntax_getTailPos_x3f(x_1, x_20);
if (lean_obj_tag(x_27) == 0)
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
lean_free_object(x_21);
lean_dec(x_26);
lean_free_object(x_10);
lean_dec(x_12);
x_28 = l___private_Prepare_0__positions___closed__1;
x_29 = lean_box(0);
x_30 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_28, x_29);
lean_dec(x_2);
return x_30;
}
else
{
uint8_t x_31; 
lean_dec(x_2);
x_31 = !lean_is_exclusive(x_27);
if (x_31 == 0)
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_32 = lean_ctor_get(x_27, 0);
x_33 = l_Lean_JsonNumber_fromNat(x_26);
lean_ctor_set_tag(x_27, 2);
lean_ctor_set(x_27, 0, x_33);
x_34 = l___private_Prepare_0__positions___closed__12;
lean_ctor_set_tag(x_10, 0);
lean_ctor_set(x_10, 1, x_27);
lean_ctor_set(x_10, 0, x_34);
x_35 = l_Lean_JsonNumber_fromNat(x_32);
lean_ctor_set_tag(x_21, 2);
lean_ctor_set(x_21, 0, x_35);
x_36 = l___private_Prepare_0__positions___closed__13;
x_37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_37, 0, x_36);
lean_ctor_set(x_37, 1, x_21);
x_38 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_38, 0, x_12);
x_39 = l___private_Prepare_0__positions___closed__14;
x_40 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_40, 0, x_39);
lean_ctor_set(x_40, 1, x_38);
x_41 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_41, 0, x_40);
lean_ctor_set(x_41, 1, x_14);
x_42 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_42, 0, x_37);
lean_ctor_set(x_42, 1, x_41);
x_43 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_43, 0, x_10);
lean_ctor_set(x_43, 1, x_42);
x_44 = l_Lean_Json_mkObj(x_43);
x_45 = l___private_Prepare_0__positions___closed__15;
x_46 = lean_array_push(x_45, x_44);
return x_46;
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
x_47 = lean_ctor_get(x_27, 0);
lean_inc(x_47);
lean_dec(x_27);
x_48 = l_Lean_JsonNumber_fromNat(x_26);
x_49 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_49, 0, x_48);
x_50 = l___private_Prepare_0__positions___closed__12;
lean_ctor_set_tag(x_10, 0);
lean_ctor_set(x_10, 1, x_49);
lean_ctor_set(x_10, 0, x_50);
x_51 = l_Lean_JsonNumber_fromNat(x_47);
lean_ctor_set_tag(x_21, 2);
lean_ctor_set(x_21, 0, x_51);
x_52 = l___private_Prepare_0__positions___closed__13;
x_53 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_53, 0, x_52);
lean_ctor_set(x_53, 1, x_21);
x_54 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_54, 0, x_12);
x_55 = l___private_Prepare_0__positions___closed__14;
x_56 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_56, 0, x_55);
lean_ctor_set(x_56, 1, x_54);
x_57 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_14);
x_58 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_58, 0, x_53);
lean_ctor_set(x_58, 1, x_57);
x_59 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_59, 0, x_10);
lean_ctor_set(x_59, 1, x_58);
x_60 = l_Lean_Json_mkObj(x_59);
x_61 = l___private_Prepare_0__positions___closed__15;
x_62 = lean_array_push(x_61, x_60);
return x_62;
}
}
}
else
{
lean_object* x_63; lean_object* x_64; 
x_63 = lean_ctor_get(x_21, 0);
lean_inc(x_63);
lean_dec(x_21);
x_64 = l_Lean_Syntax_getTailPos_x3f(x_1, x_20);
if (lean_obj_tag(x_64) == 0)
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; 
lean_dec(x_63);
lean_free_object(x_10);
lean_dec(x_12);
x_65 = l___private_Prepare_0__positions___closed__1;
x_66 = lean_box(0);
x_67 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_65, x_66);
lean_dec(x_2);
return x_67;
}
else
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; 
lean_dec(x_2);
x_68 = lean_ctor_get(x_64, 0);
lean_inc(x_68);
if (lean_is_exclusive(x_64)) {
 lean_ctor_release(x_64, 0);
 x_69 = x_64;
} else {
 lean_dec_ref(x_64);
 x_69 = lean_box(0);
}
x_70 = l_Lean_JsonNumber_fromNat(x_63);
if (lean_is_scalar(x_69)) {
 x_71 = lean_alloc_ctor(2, 1, 0);
} else {
 x_71 = x_69;
 lean_ctor_set_tag(x_71, 2);
}
lean_ctor_set(x_71, 0, x_70);
x_72 = l___private_Prepare_0__positions___closed__12;
lean_ctor_set_tag(x_10, 0);
lean_ctor_set(x_10, 1, x_71);
lean_ctor_set(x_10, 0, x_72);
x_73 = l_Lean_JsonNumber_fromNat(x_68);
x_74 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_74, 0, x_73);
x_75 = l___private_Prepare_0__positions___closed__13;
x_76 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_76, 0, x_75);
lean_ctor_set(x_76, 1, x_74);
x_77 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_77, 0, x_12);
x_78 = l___private_Prepare_0__positions___closed__14;
x_79 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_79, 0, x_78);
lean_ctor_set(x_79, 1, x_77);
x_80 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_80, 0, x_79);
lean_ctor_set(x_80, 1, x_14);
x_81 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_81, 0, x_76);
lean_ctor_set(x_81, 1, x_80);
x_82 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_82, 0, x_10);
lean_ctor_set(x_82, 1, x_81);
x_83 = l_Lean_Json_mkObj(x_82);
x_84 = l___private_Prepare_0__positions___closed__15;
x_85 = lean_array_push(x_84, x_83);
return x_85;
}
}
}
}
}
else
{
lean_object* x_86; lean_object* x_87; lean_object* x_88; uint8_t x_89; 
x_86 = lean_ctor_get(x_10, 1);
lean_inc(x_86);
lean_dec(x_10);
x_87 = lean_box(0);
x_88 = l___private_Prepare_0__positions___closed__11;
x_89 = l_List_elem___at___private_Mathlib_Tactic_Linter_HashCommandLinter_0__Mathlib_Linter_HashCommandLinter_allowed__commands___spec__3(x_86, x_88);
if (x_89 == 0)
{
lean_object* x_90; lean_object* x_91; lean_object* x_92; 
lean_dec(x_86);
lean_dec(x_1);
x_90 = l___private_Prepare_0__positions___closed__1;
x_91 = lean_box(0);
x_92 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_90, x_91);
lean_dec(x_2);
return x_92;
}
else
{
uint8_t x_93; lean_object* x_94; 
x_93 = 0;
x_94 = l_Lean_Syntax_getPos_x3f(x_1, x_93);
if (lean_obj_tag(x_94) == 0)
{
lean_object* x_95; lean_object* x_96; lean_object* x_97; 
lean_dec(x_86);
lean_dec(x_1);
x_95 = l___private_Prepare_0__positions___closed__1;
x_96 = lean_box(0);
x_97 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_95, x_96);
lean_dec(x_2);
return x_97;
}
else
{
lean_object* x_98; lean_object* x_99; lean_object* x_100; 
x_98 = lean_ctor_get(x_94, 0);
lean_inc(x_98);
if (lean_is_exclusive(x_94)) {
 lean_ctor_release(x_94, 0);
 x_99 = x_94;
} else {
 lean_dec_ref(x_94);
 x_99 = lean_box(0);
}
x_100 = l_Lean_Syntax_getTailPos_x3f(x_1, x_93);
if (lean_obj_tag(x_100) == 0)
{
lean_object* x_101; lean_object* x_102; lean_object* x_103; 
lean_dec(x_99);
lean_dec(x_98);
lean_dec(x_86);
x_101 = l___private_Prepare_0__positions___closed__1;
x_102 = lean_box(0);
x_103 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_101, x_102);
lean_dec(x_2);
return x_103;
}
else
{
lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; 
lean_dec(x_2);
x_104 = lean_ctor_get(x_100, 0);
lean_inc(x_104);
if (lean_is_exclusive(x_100)) {
 lean_ctor_release(x_100, 0);
 x_105 = x_100;
} else {
 lean_dec_ref(x_100);
 x_105 = lean_box(0);
}
x_106 = l_Lean_JsonNumber_fromNat(x_98);
if (lean_is_scalar(x_105)) {
 x_107 = lean_alloc_ctor(2, 1, 0);
} else {
 x_107 = x_105;
 lean_ctor_set_tag(x_107, 2);
}
lean_ctor_set(x_107, 0, x_106);
x_108 = l___private_Prepare_0__positions___closed__12;
x_109 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_109, 0, x_108);
lean_ctor_set(x_109, 1, x_107);
x_110 = l_Lean_JsonNumber_fromNat(x_104);
if (lean_is_scalar(x_99)) {
 x_111 = lean_alloc_ctor(2, 1, 0);
} else {
 x_111 = x_99;
 lean_ctor_set_tag(x_111, 2);
}
lean_ctor_set(x_111, 0, x_110);
x_112 = l___private_Prepare_0__positions___closed__13;
x_113 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_113, 0, x_112);
lean_ctor_set(x_113, 1, x_111);
x_114 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_114, 0, x_86);
x_115 = l___private_Prepare_0__positions___closed__14;
x_116 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_116, 0, x_115);
lean_ctor_set(x_116, 1, x_114);
x_117 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_117, 0, x_116);
lean_ctor_set(x_117, 1, x_87);
x_118 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_118, 0, x_113);
lean_ctor_set(x_118, 1, x_117);
x_119 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_119, 0, x_109);
lean_ctor_set(x_119, 1, x_118);
x_120 = l_Lean_Json_mkObj(x_119);
x_121 = l___private_Prepare_0__positions___closed__15;
x_122 = lean_array_push(x_121, x_120);
return x_122;
}
}
}
}
}
else
{
lean_object* x_123; lean_object* x_124; lean_object* x_125; 
lean_dec(x_10);
lean_dec(x_1);
x_123 = l___private_Prepare_0__positions___closed__1;
x_124 = lean_box(0);
x_125 = l___private_Prepare_0__positions___lambda__2(x_2, x_3, x_123, x_124);
lean_dec(x_2);
return x_125;
}
}
}
else
{
lean_object* x_126; 
lean_dec(x_1);
x_126 = l___private_Prepare_0__positions___closed__3;
return x_126;
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_Prepare_0__positions___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_7 = l_Array_forInUnsafe_loop___at___private_Prepare_0__positions___spec__1(x_1, x_5, x_6, x_4);
lean_dec(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l___private_Prepare_0__positions___lambda__1(x_1, x_2);
lean_dec(x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_Prepare_0__positions___lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l___private_Prepare_0__positions___lambda__2(x_1, x_2, x_3, x_4);
lean_dec(x_4);
lean_dec(x_1);
return x_5;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("error", 5);
return x_1;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("body", 4);
return x_1;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("id", 2);
return x_1;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("command", 7);
return x_1;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__4;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("<input>", 7);
return x_1;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_Prepare_0__positions___closed__1;
x_2 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("positions", 9);
return x_1;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8;
x_2 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__7;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__9;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_34; lean_object* x_55; 
x_55 = l_Lean_Json_parse(x_3);
if (lean_obj_tag(x_55) == 0)
{
lean_object* x_56; 
lean_dec(x_4);
x_56 = lean_ctor_get(x_55, 0);
lean_inc(x_56);
lean_dec(x_55);
x_7 = x_56;
goto block_33;
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_57 = lean_ctor_get(x_55, 0);
lean_inc(x_57);
lean_dec(x_55);
x_58 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__2;
lean_inc(x_57);
x_59 = l_Lean_Json_getObjValAs_x3f___at_Lean_JsonRpc_instFromJsonMessage___spec__3(x_57, x_58);
if (lean_obj_tag(x_59) == 0)
{
lean_object* x_60; 
lean_dec(x_57);
lean_dec(x_4);
x_60 = lean_ctor_get(x_59, 0);
lean_inc(x_60);
lean_dec(x_59);
x_7 = x_60;
goto block_33;
}
else
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; 
x_61 = lean_ctor_get(x_59, 0);
lean_inc(x_61);
lean_dec(x_59);
x_62 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__3;
x_63 = l_Lean_Json_getObjVal_x3f(x_57, x_62);
if (lean_obj_tag(x_63) == 0)
{
lean_object* x_64; 
lean_dec(x_61);
lean_dec(x_4);
x_64 = lean_ctor_get(x_63, 0);
lean_inc(x_64);
lean_dec(x_63);
x_7 = x_64;
goto block_33;
}
else
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; 
x_65 = lean_ctor_get(x_63, 0);
lean_inc(x_65);
lean_dec(x_63);
x_66 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__5;
x_67 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__6;
x_68 = l_Lean_Parser_runParserCategory(x_4, x_66, x_61, x_67);
if (lean_obj_tag(x_68) == 0)
{
uint8_t x_69; 
x_69 = !lean_is_exclusive(x_68);
if (x_69 == 0)
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
x_70 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_70, 0, x_62);
lean_ctor_set(x_70, 1, x_65);
lean_ctor_set_tag(x_68, 3);
x_71 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1;
x_72 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_72, 0, x_71);
lean_ctor_set(x_72, 1, x_68);
x_73 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__10;
x_74 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_74, 0, x_72);
lean_ctor_set(x_74, 1, x_73);
x_75 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_75, 0, x_70);
lean_ctor_set(x_75, 1, x_74);
x_76 = l_Lean_Json_mkObj(x_75);
x_34 = x_76;
goto block_54;
}
else
{
lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; 
x_77 = lean_ctor_get(x_68, 0);
lean_inc(x_77);
lean_dec(x_68);
x_78 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_78, 0, x_62);
lean_ctor_set(x_78, 1, x_65);
x_79 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_79, 0, x_77);
x_80 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1;
x_81 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_81, 0, x_80);
lean_ctor_set(x_81, 1, x_79);
x_82 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__10;
x_83 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_83, 0, x_81);
lean_ctor_set(x_83, 1, x_82);
x_84 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_84, 0, x_78);
lean_ctor_set(x_84, 1, x_83);
x_85 = l_Lean_Json_mkObj(x_84);
x_34 = x_85;
goto block_54;
}
}
else
{
uint8_t x_86; 
x_86 = !lean_is_exclusive(x_68);
if (x_86 == 0)
{
lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; 
x_87 = lean_ctor_get(x_68, 0);
x_88 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_88, 0, x_62);
lean_ctor_set(x_88, 1, x_65);
x_89 = l___private_Prepare_0__positions(x_87);
lean_ctor_set_tag(x_68, 4);
lean_ctor_set(x_68, 0, x_89);
x_90 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8;
x_91 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_91, 0, x_90);
lean_ctor_set(x_91, 1, x_68);
x_92 = lean_box(0);
x_93 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_93, 0, x_91);
lean_ctor_set(x_93, 1, x_92);
x_94 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_94, 0, x_88);
lean_ctor_set(x_94, 1, x_93);
x_95 = l_Lean_Json_mkObj(x_94);
x_34 = x_95;
goto block_54;
}
else
{
lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; 
x_96 = lean_ctor_get(x_68, 0);
lean_inc(x_96);
lean_dec(x_68);
x_97 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_97, 0, x_62);
lean_ctor_set(x_97, 1, x_65);
x_98 = l___private_Prepare_0__positions(x_96);
x_99 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_99, 0, x_98);
x_100 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8;
x_101 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_101, 0, x_100);
lean_ctor_set(x_101, 1, x_99);
x_102 = lean_box(0);
x_103 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_103, 0, x_101);
lean_ctor_set(x_103, 1, x_102);
x_104 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_104, 0, x_97);
lean_ctor_set(x_104, 1, x_103);
x_105 = l_Lean_Json_mkObj(x_104);
x_34 = x_105;
goto block_54;
}
}
}
}
}
block_33:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_8 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_8, 0, x_7);
x_9 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1;
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_8);
x_11 = lean_box(0);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_10);
lean_ctor_set(x_12, 1, x_11);
x_13 = l_Lean_Json_mkObj(x_12);
x_14 = l_Lean_Json_compress(x_13);
lean_inc(x_1);
x_15 = l_IO_FS_Stream_putStrLn(x_1, x_14, x_6);
if (lean_obj_tag(x_15) == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_15, 1);
lean_inc(x_16);
lean_dec(x_15);
x_17 = lean_ctor_get(x_1, 0);
lean_inc(x_17);
lean_dec(x_1);
x_18 = lean_apply_1(x_17, x_16);
if (lean_obj_tag(x_18) == 0)
{
uint8_t x_19; 
x_19 = !lean_is_exclusive(x_18);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; 
x_20 = lean_ctor_get(x_18, 0);
lean_dec(x_20);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_2);
lean_ctor_set(x_18, 0, x_21);
return x_18;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_22 = lean_ctor_get(x_18, 1);
lean_inc(x_22);
lean_dec(x_18);
x_23 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_23, 0, x_2);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_22);
return x_24;
}
}
else
{
uint8_t x_25; 
lean_dec(x_2);
x_25 = !lean_is_exclusive(x_18);
if (x_25 == 0)
{
return x_18;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_18, 0);
x_27 = lean_ctor_get(x_18, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_18);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
return x_28;
}
}
}
else
{
uint8_t x_29; 
lean_dec(x_2);
lean_dec(x_1);
x_29 = !lean_is_exclusive(x_15);
if (x_29 == 0)
{
return x_15;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_15, 0);
x_31 = lean_ctor_get(x_15, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_15);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
return x_32;
}
}
}
block_54:
{
lean_object* x_35; lean_object* x_36; 
x_35 = l_Lean_Json_compress(x_34);
lean_inc(x_1);
x_36 = l_IO_FS_Stream_putStrLn(x_1, x_35, x_6);
if (lean_obj_tag(x_36) == 0)
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_37 = lean_ctor_get(x_36, 1);
lean_inc(x_37);
lean_dec(x_36);
x_38 = lean_ctor_get(x_1, 0);
lean_inc(x_38);
lean_dec(x_1);
x_39 = lean_apply_1(x_38, x_37);
if (lean_obj_tag(x_39) == 0)
{
uint8_t x_40; 
x_40 = !lean_is_exclusive(x_39);
if (x_40 == 0)
{
lean_object* x_41; lean_object* x_42; 
x_41 = lean_ctor_get(x_39, 0);
lean_dec(x_41);
x_42 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_42, 0, x_2);
lean_ctor_set(x_39, 0, x_42);
return x_39;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_39, 1);
lean_inc(x_43);
lean_dec(x_39);
x_44 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_44, 0, x_2);
x_45 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_45, 0, x_44);
lean_ctor_set(x_45, 1, x_43);
return x_45;
}
}
else
{
uint8_t x_46; 
lean_dec(x_2);
x_46 = !lean_is_exclusive(x_39);
if (x_46 == 0)
{
return x_39;
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_47 = lean_ctor_get(x_39, 0);
x_48 = lean_ctor_get(x_39, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_39);
x_49 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_49, 0, x_47);
lean_ctor_set(x_49, 1, x_48);
return x_49;
}
}
}
else
{
uint8_t x_50; 
lean_dec(x_2);
lean_dec(x_1);
x_50 = !lean_is_exclusive(x_36);
if (x_50 == 0)
{
return x_36;
}
else
{
lean_object* x_51; lean_object* x_52; lean_object* x_53; 
x_51 = lean_ctor_get(x_36, 0);
x_52 = lean_ctor_get(x_36, 1);
lean_inc(x_52);
lean_inc(x_51);
lean_dec(x_36);
x_53 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_53, 0, x_51);
lean_ctor_set(x_53, 1, x_52);
return x_53;
}
}
}
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Lean_Loop_forIn_loop___at_main___spec__1___closed__1;
x_2 = lean_box(0);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; 
lean_dec(x_5);
x_7 = lean_ctor_get(x_2, 3);
lean_inc(x_7);
x_8 = lean_apply_1(x_7, x_6);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_10 = lean_ctor_get(x_8, 0);
x_11 = lean_ctor_get(x_8, 1);
x_12 = l_String_isEmpty(x_10);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; 
lean_free_object(x_8);
x_13 = lean_box(0);
lean_inc(x_1);
lean_inc(x_4);
lean_inc(x_3);
x_14 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1(x_3, x_4, x_10, x_1, x_13, x_11);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; 
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
if (lean_obj_tag(x_15) == 0)
{
uint8_t x_16; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_16 = !lean_is_exclusive(x_14);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_14, 0);
lean_dec(x_17);
x_18 = lean_ctor_get(x_15, 0);
lean_inc(x_18);
lean_dec(x_15);
lean_ctor_set(x_14, 0, x_18);
return x_14;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_14, 1);
lean_inc(x_19);
lean_dec(x_14);
x_20 = lean_ctor_get(x_15, 0);
lean_inc(x_20);
lean_dec(x_15);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_19);
return x_21;
}
}
else
{
lean_object* x_22; lean_object* x_23; 
x_22 = lean_ctor_get(x_14, 1);
lean_inc(x_22);
lean_dec(x_14);
x_23 = lean_ctor_get(x_15, 0);
lean_inc(x_23);
lean_dec(x_15);
x_5 = x_23;
x_6 = x_22;
goto _start;
}
}
else
{
uint8_t x_25; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_25 = !lean_is_exclusive(x_14);
if (x_25 == 0)
{
return x_14;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_14, 0);
x_27 = lean_ctor_get(x_14, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_14);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
return x_28;
}
}
}
else
{
lean_object* x_29; 
lean_dec(x_10);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_29 = l_Lean_Loop_forIn_loop___at_main___spec__1___closed__2;
lean_ctor_set(x_8, 0, x_29);
return x_8;
}
}
else
{
lean_object* x_30; lean_object* x_31; uint8_t x_32; 
x_30 = lean_ctor_get(x_8, 0);
x_31 = lean_ctor_get(x_8, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_8);
x_32 = l_String_isEmpty(x_30);
if (x_32 == 0)
{
lean_object* x_33; lean_object* x_34; 
x_33 = lean_box(0);
lean_inc(x_1);
lean_inc(x_4);
lean_inc(x_3);
x_34 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1(x_3, x_4, x_30, x_1, x_33, x_31);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; 
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
if (lean_obj_tag(x_35) == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_36 = lean_ctor_get(x_34, 1);
lean_inc(x_36);
if (lean_is_exclusive(x_34)) {
 lean_ctor_release(x_34, 0);
 lean_ctor_release(x_34, 1);
 x_37 = x_34;
} else {
 lean_dec_ref(x_34);
 x_37 = lean_box(0);
}
x_38 = lean_ctor_get(x_35, 0);
lean_inc(x_38);
lean_dec(x_35);
if (lean_is_scalar(x_37)) {
 x_39 = lean_alloc_ctor(0, 2, 0);
} else {
 x_39 = x_37;
}
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_36);
return x_39;
}
else
{
lean_object* x_40; lean_object* x_41; 
x_40 = lean_ctor_get(x_34, 1);
lean_inc(x_40);
lean_dec(x_34);
x_41 = lean_ctor_get(x_35, 0);
lean_inc(x_41);
lean_dec(x_35);
x_5 = x_41;
x_6 = x_40;
goto _start;
}
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_43 = lean_ctor_get(x_34, 0);
lean_inc(x_43);
x_44 = lean_ctor_get(x_34, 1);
lean_inc(x_44);
if (lean_is_exclusive(x_34)) {
 lean_ctor_release(x_34, 0);
 lean_ctor_release(x_34, 1);
 x_45 = x_34;
} else {
 lean_dec_ref(x_34);
 x_45 = lean_box(0);
}
if (lean_is_scalar(x_45)) {
 x_46 = lean_alloc_ctor(1, 2, 0);
} else {
 x_46 = x_45;
}
lean_ctor_set(x_46, 0, x_43);
lean_ctor_set(x_46, 1, x_44);
return x_46;
}
}
else
{
lean_object* x_47; lean_object* x_48; 
lean_dec(x_30);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_47 = l_Lean_Loop_forIn_loop___at_main___spec__1___closed__2;
x_48 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_48, 0, x_47);
lean_ctor_set(x_48, 1, x_31);
return x_48;
}
}
}
else
{
uint8_t x_49; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_49 = !lean_is_exclusive(x_8);
if (x_49 == 0)
{
return x_8;
}
else
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_50 = lean_ctor_get(x_8, 0);
x_51 = lean_ctor_get(x_8, 1);
lean_inc(x_51);
lean_inc(x_50);
lean_dec(x_8);
x_52 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_52, 0, x_50);
lean_ctor_set(x_52, 1, x_51);
return x_52;
}
}
}
}
static lean_object* _init_l_main___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("Mathlib", 7);
return x_1;
}
}
static lean_object* _init_l_main___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_main___closed__1;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_main___closed__3() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_main___closed__2;
x_2 = 0;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_main___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_Prepare_0__positions___closed__15;
x_2 = l_main___closed__3;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_main___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = lean_box(0);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* x_1) {
_start:
{
lean_object* x_2; uint32_t x_3; lean_object* x_4; uint8_t x_5; lean_object* x_6; 
x_2 = lean_box(0);
x_3 = 0;
x_4 = l_main___closed__4;
x_5 = 0;
x_6 = lean_import_modules(x_4, x_2, x_3, x_5, x_1);
if (lean_obj_tag(x_6) == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
x_8 = lean_ctor_get(x_6, 1);
lean_inc(x_8);
lean_dec(x_6);
x_9 = lean_get_stdin(x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_get_stdout(x_11);
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
x_14 = lean_ctor_get(x_12, 1);
lean_inc(x_14);
lean_dec(x_12);
x_15 = l_main___closed__5;
x_16 = l_Lean_Loop_forIn_loop___at_main___spec__1(x_7, x_10, x_13, x_15, x_15, x_14);
if (lean_obj_tag(x_16) == 0)
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
lean_dec(x_17);
if (lean_obj_tag(x_18) == 0)
{
uint8_t x_19; 
x_19 = !lean_is_exclusive(x_16);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; 
x_20 = lean_ctor_get(x_16, 0);
lean_dec(x_20);
x_21 = lean_box(0);
lean_ctor_set(x_16, 0, x_21);
return x_16;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_22 = lean_ctor_get(x_16, 1);
lean_inc(x_22);
lean_dec(x_16);
x_23 = lean_box(0);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_22);
return x_24;
}
}
else
{
uint8_t x_25; 
x_25 = !lean_is_exclusive(x_16);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_16, 0);
lean_dec(x_26);
x_27 = lean_ctor_get(x_18, 0);
lean_inc(x_27);
lean_dec(x_18);
lean_ctor_set(x_16, 0, x_27);
return x_16;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_28 = lean_ctor_get(x_16, 1);
lean_inc(x_28);
lean_dec(x_16);
x_29 = lean_ctor_get(x_18, 0);
lean_inc(x_29);
lean_dec(x_18);
x_30 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_30, 0, x_29);
lean_ctor_set(x_30, 1, x_28);
return x_30;
}
}
}
else
{
uint8_t x_31; 
x_31 = !lean_is_exclusive(x_16);
if (x_31 == 0)
{
return x_16;
}
else
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_32 = lean_ctor_get(x_16, 0);
x_33 = lean_ctor_get(x_16, 1);
lean_inc(x_33);
lean_inc(x_32);
lean_dec(x_16);
x_34 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_34, 0, x_32);
lean_ctor_set(x_34, 1, x_33);
return x_34;
}
}
}
else
{
uint8_t x_35; 
x_35 = !lean_is_exclusive(x_6);
if (x_35 == 0)
{
return x_6;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_36 = lean_ctor_get(x_6, 0);
x_37 = lean_ctor_get(x_6, 1);
lean_inc(x_37);
lean_inc(x_36);
lean_dec(x_6);
x_38 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_38, 0, x_36);
lean_ctor_set(x_38, 1, x_37);
return x_38;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
return x_7;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Mathlib(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Prepare(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Mathlib(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_Prepare_0__positions___closed__1 = _init_l___private_Prepare_0__positions___closed__1();
lean_mark_persistent(l___private_Prepare_0__positions___closed__1);
l___private_Prepare_0__positions___closed__2 = _init_l___private_Prepare_0__positions___closed__2();
lean_mark_persistent(l___private_Prepare_0__positions___closed__2);
l___private_Prepare_0__positions___closed__3 = _init_l___private_Prepare_0__positions___closed__3();
lean_mark_persistent(l___private_Prepare_0__positions___closed__3);
l___private_Prepare_0__positions___closed__4 = _init_l___private_Prepare_0__positions___closed__4();
lean_mark_persistent(l___private_Prepare_0__positions___closed__4);
l___private_Prepare_0__positions___closed__5 = _init_l___private_Prepare_0__positions___closed__5();
lean_mark_persistent(l___private_Prepare_0__positions___closed__5);
l___private_Prepare_0__positions___closed__6 = _init_l___private_Prepare_0__positions___closed__6();
lean_mark_persistent(l___private_Prepare_0__positions___closed__6);
l___private_Prepare_0__positions___closed__7 = _init_l___private_Prepare_0__positions___closed__7();
lean_mark_persistent(l___private_Prepare_0__positions___closed__7);
l___private_Prepare_0__positions___closed__8 = _init_l___private_Prepare_0__positions___closed__8();
lean_mark_persistent(l___private_Prepare_0__positions___closed__8);
l___private_Prepare_0__positions___closed__9 = _init_l___private_Prepare_0__positions___closed__9();
lean_mark_persistent(l___private_Prepare_0__positions___closed__9);
l___private_Prepare_0__positions___closed__10 = _init_l___private_Prepare_0__positions___closed__10();
lean_mark_persistent(l___private_Prepare_0__positions___closed__10);
l___private_Prepare_0__positions___closed__11 = _init_l___private_Prepare_0__positions___closed__11();
lean_mark_persistent(l___private_Prepare_0__positions___closed__11);
l___private_Prepare_0__positions___closed__12 = _init_l___private_Prepare_0__positions___closed__12();
lean_mark_persistent(l___private_Prepare_0__positions___closed__12);
l___private_Prepare_0__positions___closed__13 = _init_l___private_Prepare_0__positions___closed__13();
lean_mark_persistent(l___private_Prepare_0__positions___closed__13);
l___private_Prepare_0__positions___closed__14 = _init_l___private_Prepare_0__positions___closed__14();
lean_mark_persistent(l___private_Prepare_0__positions___closed__14);
l___private_Prepare_0__positions___closed__15 = _init_l___private_Prepare_0__positions___closed__15();
lean_mark_persistent(l___private_Prepare_0__positions___closed__15);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__1);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__2 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__2();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__2);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__3 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__3();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__3);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__4 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__4();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__4);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__5 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__5();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__5);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__6 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__6();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__6);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__7 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__7();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__7);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__8);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__9 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__9();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__9);
l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__10 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__10();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___lambda__1___closed__10);
l_Lean_Loop_forIn_loop___at_main___spec__1___closed__1 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___closed__1();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___closed__1);
l_Lean_Loop_forIn_loop___at_main___spec__1___closed__2 = _init_l_Lean_Loop_forIn_loop___at_main___spec__1___closed__2();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__1___closed__2);
l_main___closed__1 = _init_l_main___closed__1();
lean_mark_persistent(l_main___closed__1);
l_main___closed__2 = _init_l_main___closed__2();
lean_mark_persistent(l_main___closed__2);
l_main___closed__3 = _init_l_main___closed__3();
lean_mark_persistent(l_main___closed__3);
l_main___closed__4 = _init_l_main___closed__4();
lean_mark_persistent(l_main___closed__4);
l_main___closed__5 = _init_l_main___closed__5();
lean_mark_persistent(l_main___closed__5);
return lean_io_result_mk_ok(lean_box(0));
}
void lean_initialize();

  #if defined(WIN32) || defined(_WIN32)
  #include <windows.h>
  #endif

  int main(int argc, char ** argv) {
  #if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  #endif
  lean_object* in; lean_object* res;
lean_initialize();
lean_set_panic_messages(false);
res = initialize_Prepare(1 /* builtin */, lean_io_mk_world());
lean_set_panic_messages(true);
lean_io_mark_end_initialization();
if (lean_io_result_is_ok(res)) {
lean_dec_ref(res);
lean_init_task_manager();
res = _lean_main(lean_io_mk_world());
}
lean_finalize_task_manager();
if (lean_io_result_is_ok(res)) {
  int ret = 0;
  lean_dec_ref(res);
  return ret;
} else {
  lean_io_result_show_error(res);
  lean_dec_ref(res);
  return 1;
}
}
#ifdef __cplusplus
}
#endif
