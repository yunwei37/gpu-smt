import ClockControl
def main : IO Unit := GpuSmt.SimpAllProfile.SimpAll.clockControl
