from pathlib import Path
import gzip,json,datetime,subprocess
r=Path('/workspaces/repository')
assert subprocess.check_output(['git','symbolic-ref','--short','HEAD'],cwd=r,text=True).strip()=='main'
b=r/'artifacts/hotspot-mechanisms-2026-10-25'
out=b/'prepared71-20261026';out.mkdir(exist_ok=False)
step=r/'docs/tmp/build-and-evaluate'/('step-0057-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S+0000'));(step/'experiment-001').mkdir(parents=True)
Path('/tmp/gpu-smt-prepared71-step.txt').write_text(str(step))
def read(rel):return json.loads(gzip.decompress((b/rel).read_bytes()))
groups={
 'interval48':{'native':'interval-continuation/first-stage-map/original48-preparation/original.json.gz','import':'interval-continuation/first-stage-map/original48-preparation/import-control.json.gz','experimental':'interval-continuation/first-stage-map/original48-preparation/mapped.json.gz'},
 'simp23':{'native':'native-sites/prepared-simp23/original.json.gz','import':'native-sites/prepared-simp23/import-control.json.gz','experimental':'native-sites/prepared-simp23/profile.json.gz'}}
canonical=json.loads(gzip.decompress((r/'artifacts/engine-resource-profile-2026-10-25/population-inputs/all.json.gz').read_bytes()))
order={x['id']:i for i,x in enumerate(canonical['candidates'])};sources={x['id']:x['code']for x in canonical['candidates']}
inventory=[]
for condition in ['native','import','experimental']:
 rows=[]
 for group,paths in groups.items():
  d=read(paths[condition]);assert len(d['candidates'])==(48 if group=='interval48'else 23)
  for item in d['candidates']:
   c=dict(item,timeout_ms=item.get('timeout_ms',300000),reuse=False)
   assert c['timeout_ms']==300000
   if condition=='native':assert c['code']==sources[c['id']]
   rows.append(c)
   if condition=='native':inventory.append(dict(id=c['id'],group=group,source_file=paths[condition],purpose='on-demand interval mechanism'if group=='interval48'else'diagnostic phase attribution;not an acceleration arm'))
 assert len(rows)==71 and len({x['id']for x in rows})==71
 rows.sort(key=lambda x:order[x['id']])
 (out/(condition+'71.json.gz')).write_bytes(gzip.compress((json.dumps(dict(mode='all',candidates=rows),ensure_ascii=False,indent=2)+chr(10)).encode(),mtime=0))
# Existing exact14native/profile controls;do not alter the diagnostic algorithm.
qual=b/'simp-all-profile/qualification-007'
old=json.loads((qual/'terminal.json').read_text())
controls=[]
for row in old['results']:
 filename=qual/(row['id']+'.lean');assert filename.exists()
 controls.append(dict(id=row['id'],task_id=row['id'],code=filename.read_text(),timeout_ms=300000,reuse=False))
(out/'existing-simp-controls14.json.gz').write_bytes(gzip.compress((json.dumps(dict(mode='all',candidates=controls),ensure_ascii=False,indent=2)+chr(10)).encode(),mtime=0))
expectations=[dict(id=x['id'],expected_native_semantic_status=x['expected'],scope='Previously executed older observer;not a new qualification result or required strict-service stderr classification.')for x in old['results']]
# Native-context counterexample and ordinary backtracking/recovered-error controls.
tick=chr(96)
custom=('import Lean'+chr(10)+'open Lean Elab Tactic'+chr(10)+
 'elab "recovery_sensitive_control" : tactic => do'+chr(10)+
 '  unless (← read).recover do throwError "requires recovery context"'+chr(10)+
 '  evalTactic (← '+tick+'(tactic| exact True.intro))'+chr(10))
special=[
 ('recovery-context',custom,'  recovery_sensitive_control'+chr(10),'accepted','rejected',
  'Deliberately recovery-dependent metaprogram;generic wrapper is not universally transparent and must not be enabled for arbitrary Lean. Runtime confirmation pending.'),
 ('ordinary-backtracking','import Lean'+chr(10),'  first | fail "first branch" | exact True.intro'+chr(10),'accepted','accepted',
  'Ordinary first alternative already uses native withoutRecover;do not bypass its backtracking.'),
 ('already-failed-have','import Lean'+chr(10),'  have h : False := by fail "unproved have"'+chr(10)+'  exact True.intro'+chr(10),'rejected','rejected',
  'Tests native error propagation,not inevitable nontermination or a speed fixture.')
]
candidates=[]
for name,header,body,native_expected,wrapped_expected,reason in special:
 for variant in ['native','wrapped']:
  prefix=header+'theorem '+name.replace('-','_')+' : True := by'+chr(10)
  if variant=='wrapped':
   prefix='import NativeFailFast'+chr(10)+prefix
   body2='  failfast_native'+chr(10)+''.join('  '+l for l in body.splitlines(keepends=True))
  else:body2=body
  candidates.append(dict(id=name+'-'+variant,code=prefix+body2,timeout_ms=300000,reuse=False))
  expectations.append(dict(id=name+'-'+variant,expected_native_semantic_status=native_expected if variant=='native'else wrapped_expected,reason=reason,runtime_executed=False))
(out/'failfast-controls6.json.gz').write_bytes(gzip.compress((json.dumps(dict(mode='all',candidates=candidates),ensure_ascii=False,indent=2)+chr(10)).encode(),mtime=0))
(out/'control-expectations.json').write_text(json.dumps(expectations,indent=2)+chr(10))
(out/'inventory.json').write_text(json.dumps(dict(sources=71,groups={'interval48':48,'simp23':23},ordering='original canonical7808submission order in every condition',rows=sorted(inventory,key=lambda x:order[x['id']]),native_candidate_executions=0,warning='experimental71mixes interval mechanism and simp diagnostic;not one acceleration treatment or a valid combined speedup'),indent=2)+chr(10))
print('prepared',str(out),'step',str(step),'actual_native_executions',0)
