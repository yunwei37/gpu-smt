from pathlib import Path
import collections,datetime,gzip,json,shutil
r=Path('/workspaces/repository')
ctx=json.loads(Path(Path('/tmp/gpu-smt-active-original71-context.txt').read_text()).read_text())
out=Path(ctx['runtime_output']);a=Path(ctx['artifact'])
expected=json.loads(gzip.decompress((r/'artifacts/hotspot-mechanisms-2026-10-25/prepared71-20261026/native71.json.gz').read_bytes()))
expected_ids=[c['id']for c in expected['candidates']]
groups={c['id']:('interval48' if 'import IntervalMap' in d['code'] else 'simp23')for c,d in zip(expected['candidates'],
 json.loads(gzip.decompress((r/'artifacts/hotspot-mechanisms-2026-10-25/prepared71-20261026/import71.json.gz').read_bytes()))['candidates'])}
results={}
for name in ['native71','import71']:
 p=out/name;t=json.loads((p/'terminal.json').read_text());assert t['exit_code']==0
 rows=[x for line in gzip.decompress((p/'results.jsonl.gz').read_bytes()).decode().splitlines() for x in json.loads(line)['results']]
 assert [x['id']for x in rows]==expected_ids and len(rows)==71
 assert all(not x['cached']and not x['coalesced']for x in rows)
 active=set();maximum=0;peak=0;samples=0;excess=0;preemptions=[];registrations=[]
 with gzip.open(p/'resource-events.jsonl.gz','rt')as stream:
  for line in stream:
   e=json.loads(line);f=e['fields'];m=f.get('message')
   if m=='register active process':
    k=(f['pid'],f['start_ticks']);assert k not in active;active.add(k);registrations.append(k);maximum=max(maximum,len(active))
   elif m=='release active process ownership':
    k=(f['pid'],f['start_ticks']);assert k in active;active.remove(k)
   elif m=='owned RSS sample':
    samples+=1;peak=max(peak,f['rss_bytes']);excess+=f['rss_bytes']>48*1024**3
   elif m=='preempt owned attempt and requeue exclusively':preemptions.append(f);peak=max(peak,f['rss_bytes'])
 assert not active
 per=[];errors=[]
 for row in rows:
  response=row['outcome'].get('response')or{}
  messages=response.get('messages',[])
  missing=[x['data']for x in messages if x.get('severity')=='error' and "unknown package 'IntervalMap'" in str(x.get('data'))]
  if missing:errors.append(row['id'])
  per.append({'id':row['id'],'group':groups[row['id']],'service_status':row['outcome']['status'],
   'missing_IntervalMap_import':bool(missing),'attempts':row['attempts'],'consumer_seconds':row['elapsed_seconds']})
 results[name]={'cell_seconds':t['cell_seconds'],'statuses':dict(collections.Counter(x['outcome']['status']for x in rows)),
  'group_statuses':{g:dict(collections.Counter(x['outcome']['status']for x in rows if groups[x['id']]==g))for g in ['interval48','simp23']},
  'missing_IntervalMap_imports':len(errors),'import_failure_ids':errors,'attempt_statuses':dict(collections.Counter(v['status']for x in rows for v in x['attempts'])),
  'sampled_peak_rss_bytes':peak,'sampled_peak_GiB':peak/1024**3,'RSS_samples':samples,'samples_over_budget':excess,
  'watchdog_events':len(preemptions),'max_registered_native_leaders':maximum,'all_registration_releases_matched':True,
  'physical_native_processes':len(registrations),'sum_attempt_seconds':sum(v['elapsed_seconds']for x in rows for v in x['attempts'])}
 dest=a/name
 assert not dest.exists()
 shutil.copytree(p,dest)
 (dest/'per-source-analysis.json').write_text(json.dumps(per,indent=2)+'\n')
results['UTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
results['whole_pair_speedup']=None
results['scope']='Native71complete;interval48import path failed. Import elapsed is invalid as acceleration/early-rejection evidence. Simp23experimental stillactive.'
(a/'closed-reference-import-analysis.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({k:v for k,v in results.items()if k!='import71'}))
print('import71summary',json.dumps({k:v for k,v in results['import71'].items()if k!='import_failure_ids'}))
