from pathlib import Path
import collections,datetime,gzip,importlib.util,json,sys
sys.dont_write_bytecode=True
r=Path('/workspaces/repository')
ctx=json.loads(Path(Path('/tmp/gpu-smt-active-original71-context.txt').read_text()).read_text())
out=Path(ctx['runtime_output']);assert json.loads((out/'terminal.json').read_text())['exit_code']==0
dest=Path(ctx['artifact'])/'simp23-analysis';dest.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('existing_simp_analysis',r/'bench/lean-failure-profile/simp-all-profile/analyze.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
prep=json.loads((r/'artifacts/hotspot-mechanisms-2026-10-25/native-sites/prepared-simp23/preparation.json').read_text())
mapping={x['id']:x for x in prep['manifest']};assert len(mapping)==23
cell=out/'experimental71'
rows=[x for line in gzip.decompress((cell/'results.jsonl.gz').read_bytes()).decode().splitlines()for x in json.loads(line)['results']]
summaries=[]
for row in rows:
 if row['id']not in mapping:continue
 attempts=[]
 for n,attempt in enumerate(row['attempts']):
  logs=[json.loads(e['detail'])for e in attempt['backend_events']if e['stage']=='stderr_log']
  assert len(logs)==1
  log=Path(logs[0]['path']+'.gz');assert log.is_file()
  assert any(logs[0]['pid']==p['pid']and logs[0]['start_ticks']==p['start_ticks']for p in attempt['processes'])
  info=module.analyze_source(row['id'],log,mapping[row['id']])
  (dest/(row['id']+'-attempt'+str(n)+'.json.gz')).write_bytes(gzip.compress(json.dumps(info,ensure_ascii=False,indent=2).encode(),mtime=0))
  by_phase=collections.defaultdict(lambda:dict(began=0,ended=0,elapsed_ns=0,maximum_completed_ns=0))
  for phase in info['observed_phases']:
   v=by_phase[phase['phase']];v['began']+=phase['began'];v['ended']+=phase['ended'];v['elapsed_ns']+=phase['elapsed_ns']
   v['maximum_completed_ns']=max(v['maximum_completed_ns'],phase['max_elapsed_ns']or 0)
  tail_lines=collections.deque(maxlen=15);fatal=[]
  with gzip.open(log,'rt')as stream:
   for line in stream:
    if 'deep recursion was detected' in line or line.startswith('Stack overflow'):fatal.append(line.strip())
    tail_lines.append(line.rstrip())
  attempt_summary={'attempt':n,'status':attempt['status'],'attempt_seconds':attempt['elapsed_seconds'],
   'phase_events':info['parsed_events'],'outer_wrapper_entries':by_phase['elaborate-arguments']['began'],
   'max_observed_inner_round':max((p['round']or 0 for p in info['observed_phases']),default=0),
   'observed_phase_sums':dict(by_phase),'open_phases':info['open_phases'],'last_progress':info['last_progress'],
   'malformed_event_lines':info['malformed_event_lines'],'unmatched_event_count':len(info['unmatched_events']),
   'fatal_runtime_diagnostics':fatal,'raw_tail':list(tail_lines),'completion_flag_qualified':False,
   'scope':'sums include completed/unwound raw phase spans,not all source wall;open phases censored;origin use is cumulative,not causal or divergence certificate'}
  attempts.append(attempt_summary)
 summaries.append({'id':row['id'],'service_status':row['outcome']['status'],'consumer_seconds':row['elapsed_seconds'],
  'attempts':attempts,'certified_impossible':False})
result={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':len(summaries),
 'statuses':dict(collections.Counter(x['service_status']for x in summaries)),'certified_impossible_sources':0,
 'completion_flag_limit':'successful control sources emit false action_completed values;do not interpret those raw flags as actual error unwinding',
 'sources_detail':summaries,'scope':'new observer23actualsource diagnostics;three runtime failures and all censorship retained;not native equivalence or speedup'}
assert len(summaries)==23
(dest/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='sources_detail'}))
for row in summaries:
 last=row['attempts'][-1]
 print(json.dumps({'id':row['id'],'status':row['service_status'],'seconds':last['attempt_seconds'],
  'outer_entries':last['outer_wrapper_entries'],'max_inner_round':last['max_observed_inner_round'],
  'open_phases':[(p['phase'],p['round'],p['slot'])for p in last['open_phases']],
  'last_phase':(last['last_progress']or{}).get('phase'),
  'fatal':last['fatal_runtime_diagnostics']}))
