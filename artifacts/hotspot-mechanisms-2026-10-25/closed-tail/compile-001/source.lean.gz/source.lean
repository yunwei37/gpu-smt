/- Experimental runtime-guarded proof-program failure peephole.
No builtin tactic is overridden; unknown state executes the original sequence.
-/ 
import Mathlib

open Lean Elab Tactic

namespace GpuSmt.ClosedTail

private def andThenKind : Name := .str `Lean.Parser.Tactic "tactic_<;>_"

run_cmd do
  let env ← getEnv
  for kind in [``Lean.Parser.Tactic.omega, ``Lean.Parser.Tactic.exact,
      ``Mathlib.Tactic.intervalCases, andThenKind,
      ``Lean.Parser.Tactic.focus, ``Lean.Parser.Tactic.allGoals] do
    logInfo <| toMessageData (Json.mkObj [
      ("kind", toJson kind.toString),
      ("elaborators", toJson ((tacticElabAttribute.getEntries env kind).map (·.declName.toString))),
      ("macros", toJson ((macroAttribute.getEntries env kind).map (·.declName.toString)))]).compress

end GpuSmt.ClosedTail
