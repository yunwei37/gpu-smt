from pathlib import Path
import json,gzip,re,subprocess
r=Path('/workspaces/repository')
assert subprocess.check_output(['git','symbolic-ref','--short','HEAD'],cwd=r,text=True).strip()=='main'
b=r/'artifacts/hotspot-mechanisms-2026-10-25';a=b/'failfast-native-20261026'
source=json.loads(gzip.decompress((b/'native-sites/prepared-simp23/original.json.gz').read_bytes()))
rows=json.loads((b/'simp-all-profile/process-cadence-20261026/existing23/result.json').read_text())['rows']
rowmap={x['source_id']:x for x in rows}
sites={x['id']:x for x in json.loads((b/'native-sites/prepared-simp23/preparation.json').read_text())['manifest']}
review={
175:('finite sum; pow_two and Nat modulo rewrites','no explicit outer enumeration'),
1816:('pow_succ and Nat modulo rewrites','seven simp_all sites; nested semicolon chains; no active source-byte attribution yet'),
1841:('simp_all after interval_cases p/q/r','finite enumeration; many completed outer calls are not a cycle witness'),
1846:('simp_all[mul_assoc] after rcases p/q/r','finite constructor fanout'),
2429:('Nat.add_assoc/add_comm/add_left_comm plus Fibonacci recurrence','norm_num precedes simp_all; concrete-index expansion is not a cycle certificate'),
2498:('Nat.lcm/Nat.gcd/Nat.gcd_eq_right','symbolic recursive unfolding is a hypothesis,not observed phase or divergence proof'),
3101:('add_assoc/add_comm/mul_comm/Nat.mul_assoc after rcases a/m/c','finite branch fanout precedes one long inner call; nlinarith follows'),
3587:('sum_Icc_succ_top/mul_add/mul_comm/mul_left_comm','concrete finite sum/distributive expansion; not nontermination proof'),
3610:('Real.logb/log_rpow; then sum_Icc_succ_top/mul_add/mul_comm','two static sites; retained native frame has no byte attribution'),
4336:('sum_range_succ/add_comm plus recurrence hypothesis','concrete ranges98/49 do not establish rewrite cycle'),
4339:('sum_range_succ/add_comm/add_left_comm plus recurrence hypothesis','ordered permutations and finite sums; actual phase pending'),
4997:('decide-enabled simp_all after interval_cases i/m/o','many outer calls; nlinarith bounds precede fanout'),
5006:('simp_all in have-blocks and after interval_cases i/m/o','seven sites; cannot attribute all completed calls to final enumeration'),
5016:('simp_all after interval_cases i/m/o','many outer calls; failed have proofs are a candidate recovered-error source,not observed yet'),
5913:('pow/mod simp_all after induction','one completed outer call; do not call this high outer repetition'),
5919:('pow/mod simp_all in induction case','zero completed outer calls'),
6209:('Complex.ext_iff/pow_succ/distributivity','several have proofs precede long simp_all; earlier recovered errors unobserved'),
6373:('decide-enabled simp_all after interval_cases m/n','finite two-variable enumeration'),
6398:('Nat.Prime/Nat.succ_le_iff after all_goals/four rcases chains','nested finite constructor fanout'),
6807:('Int.add_emod/Int.mul_emod/pow_two','existential witness cases are not large finite enumeration;0completed outer calls'),
7129:('only sum_range_succ/casts/addition permutations','finite ranges8/5; no cycle certificate'),
7551:('simp_all[pow_succ] after interval_cases n','single finite enumeration'),
7771:('Nat modulo rewrites','no explicit outer enumeration;0completed outer calls')
}
assert set(review)=={int(x['id'].split('-')[1])for x in source['candidates']}
out={k:{'mode':'all','candidates':[]}for k in ['original','import-control','wrapped']};manifest=[]
for c in source['candidates']:
 code=c['code'];decl=list(re.finditer(r'^theorem ',code,re.M));assert len(decl)==1
 at=code.index(':= by'+chr(10),decl[0].start())+len(':= by'+chr(10))
 header,body=code[:at],code[at:];assert body and code[:29]=='import Mathlib'+chr(10)+'import Aesop'+chr(10)+chr(10)
 imported=header[:29]+chr(10)+'import NativeFailFast'+chr(10)+header[29:]
 indented=''.join('  '+line for line in body.splitlines(keepends=True))
 wrapper='  failfast_native'+chr(10)
 assert ''.join(line[2:]for line in indented.splitlines(keepends=True))==body
 assert imported.replace(chr(10)+'import NativeFailFast'+chr(10),'',1)==header
 for condition,text in [('original',code),('import-control',imported+body),('wrapped',imported+wrapper+indented)]:
  item=dict(c,code=text,reuse=False,timeout_ms=c.get('timeout_ms',300000))
  assert item['timeout_ms']==300000
  out[condition]['candidates'].append(item)
 row=rowmap[c['id']];lemmas,note=review[int(c['id'].split('-')[1])]
 manifest.append(dict(id=c['id'],observed_pattern='long'if row['last_open_simp_wall_ns']>=1000000000 else'short',
  source_lemma_group=lemmas,review_note=note,static_simp_sites=sites[c['id']]['original_sites'],
  completed_simp=row['cumulative_completed_simp_calls'],completed_outer_simpAll=row['cumulative_completed_simp_all_calls'],
  final_open_simp_wall_ns=row['last_open_simp_wall_ns'],root_body_character=at,inverse_restores_original_bytes=True,
  runtime_phase_or_lemma_cause=None,qualified_failure_witness=None))
for name,d in out.items():(a/(name+'23.json.gz')).write_bytes(gzip.compress((json.dumps(d,ensure_ascii=False,indent=2)+chr(10)).encode(),mtime=0))
(a/'source-review23.json').write_text(json.dumps(dict(scope='Exact reviewed sources and existing censored native counters; no new native execution/phase attribution.',sources=23,rows=manifest),indent=2,ensure_ascii=False)+chr(10))
(a/'preparation.json').write_text(json.dumps(dict(sources=23,conditions=list(out),native_executions=0,
 timeout_ms=300000,timeout_scope='Existing Rust Candidate default made explicit; original prepared files omit timeout_ms.',
 wrapper='Native Term.withoutErrToSorry + Tactic.withoutRecover',inverse_all=True,
 caution='Accepted-set/status parity unqualified; no engine integration or universal error certificate.'),indent=2)+chr(10))
print('prepared',len(manifest),'short_zero_outer',sum(x['observed_pattern']=='short'and x['completed_outer_simpAll']==0 for x in manifest),'short_one_outer',sum(x['observed_pattern']=='short'and x['completed_outer_simpAll']==1 for x in manifest))
