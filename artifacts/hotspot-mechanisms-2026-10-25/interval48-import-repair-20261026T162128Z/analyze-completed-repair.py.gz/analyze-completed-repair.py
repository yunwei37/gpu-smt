from pathlib import Path
import collections,datetime,gzip,json,shutil,subprocess,sys,importlib.util
sys.dont_write_bytecode=True
r=Path('/workspaces/repository')
ctx=json.loads(Path(Path('/tmp/gpu-smt-active-interval48-repair-context.txt').read_text()).read_text())
out=Path(ctx['runtime_output']);artifact=Path(ctx['artifact'])
assert json.loads((out/'terminal.json').read_text())['exit_code']==0
def birth(pid):
 try:return int((Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()[19])
 except (OSError,ValueError):return None
assert birth(ctx['controller_pid'])!=ctx['controller_start_ticks']
spec=importlib.util.spec_from_file_location('existing_repair',r/'artifacts/hotspot-mechanisms-2026-10-25/prepared71-20261026/repair-interval48.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
expected=module.batches()
summary={};allrows={}
for name in ['import48','mapped48']:
 p=out/name;t=json.loads((p/'terminal.json').read_text());assert t['exit_code']==0
 launch=json.loads((p/'launch.json').read_text());assert birth(launch['pid'])!=launch['start_ticks']
 inp=json.loads(gzip.decompress((p/'input.jsonl.gz').read_bytes()))
 assert inp==expected[name]
 rows=[x for line in gzip.decompress((p/'results.jsonl.gz').read_bytes()).decode().splitlines() for x in json.loads(line)['results']]
 assert [x['id']for x in rows]==[c['id']for c in inp['candidates']] and len(rows)==48
 assert all(not x['cached']and not x['coalesced']for x in rows)
 active=set();maximum=0;peak=0;samples=0;excess=0;preemptions=[];registrations=[];monitor_errors=[]
 with gzip.open(p/'resource-events.jsonl.gz','rt')as stream:
  for line in stream:
   e=json.loads(line);f=e.get('fields',{});m=f.get('message')
   if e.get('level')=='ERROR':monitor_errors.append(e)
   if m=='register active process':
    k=(f['pid'],f['start_ticks']);assert k not in active;active.add(k);registrations.append(k);maximum=max(maximum,len(active))
   elif m=='release active process ownership':
    k=(f['pid'],f['start_ticks']);assert k in active;active.remove(k)
   elif m=='owned RSS sample':
    samples+=1;peak=max(peak,f['rss_bytes']);excess+=f['rss_bytes']>48*1024**3
   elif m=='preempt owned attempt and requeue exclusively':preemptions.append(f);peak=max(peak,f['rss_bytes'])
 assert not active
 assert all(birth(pid)!=ticks for pid,ticks in registrations)
 assert all(not v.get('messages') for x in rows for v in [x['outcome'].get('response')or{}])
 per=[{'id':x['id'],'recorded_status':x['outcome']['status'],'attempts':x['attempts'],'consumer_seconds':x['elapsed_seconds']}for x in rows]
 dest=artifact/name;assert not dest.exists();shutil.copytree(p,dest)
 (dest/'per-source-analysis.json').write_text(json.dumps(per,indent=2)+'\n')
 summary[name]={'cell_seconds':t['cell_seconds'],'statuses':dict(collections.Counter(x['outcome']['status']for x in rows)),
  'accepted_ids':[x['id']for x in rows if x['outcome']['status']=='accepted'],
  'attempt_statuses':dict(collections.Counter(a['status']for x in rows for a in x['attempts'])),
  'sampled_peak_rss_bytes':peak,'sampled_peak_GiB':peak/1024**3,'samples':samples,'samples_over_budget':excess,
  'watchdog_preemptions':len(preemptions),'max_registered_leaders':maximum,'physical_native_processes':len(registrations),
  'sum_attempt_seconds':sum(v['elapsed_seconds']for x in rows for v in x['attempts']),
  'monitor_errors':monitor_errors,'all_registration_releases_matched':True,'all_owned_native_leaders_retired':True}
 allrows[name]={x['id']:x for x in rows}
assert set(allrows['import48'])==set(allrows['mapped48'])
summary['differences']=[{'id':i,'import':allrows['import48'][i]['outcome']['status'],'mapped':allrows['mapped48'][i]['outcome']['status']}for i in allrows['import48']if allrows['import48'][i]['outcome']['status']!=allrows['mapped48'][i]['outcome']['status']]
summary['accepted_set_equal']=summary['import48']['accepted_ids']==summary['mapped48']['accepted_ids']
summary['reliable_early_failure_coverage']=0
summary['UTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
summary['whole_native_population_speedup']=None
summary['scope']='Complete scoped import/prototype48 repair; native reference71 is separate; all48stilltimeout,no earlyfailurecertificate;one fixedorder sharedhost comparison'
summary['original_terminal']=json.loads((out/'terminal.json').read_text())
(artifact/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in ['manifest.json','terminal.json']:
 shutil.copyfile(out/name,artifact/('runtime-manifest.json'if name=='manifest.json'else name))
print(json.dumps(summary))
