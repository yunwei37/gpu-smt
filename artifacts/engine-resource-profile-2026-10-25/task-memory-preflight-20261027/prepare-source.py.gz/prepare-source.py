from pathlib import Path
import sys,json,gzip,collections,datetime
sys.dont_write_bytecode=True
r=Path('/workspaces/repository')
relative='artifacts/engine-resource-pair-2026-10-25/full7808-20261026T004621Z/native/capture.json.gz'
with gzip.open(r/relative,'rt')as f:old=json.load(f)
assert old['resources']=={'memory_bytes':48<<30,'cpus':[8,9,10,11],'cores_per_worker':1}
inputs=old['batch']['candidates'];results=old['results']
assert len(inputs)==len(results)==7808
by_id={x['id']:x for x in results};assert len(by_id)==7808
groups=collections.defaultdict(list)
for index,c in enumerate(inputs):groups[c['task_id']].append((index,c,by_id[c['id']]))
assert len(groups)==244 and all(len(rows)==32 for rows in groups.values())
failure_counts={task:sum(v['outcome']['status']=='resource_exhausted'for _,_,v in rows)for task,rows in groups.items()}
heavy=sorted([t for t,n in failure_counts.items()if n],key=lambda t:(-failure_counts[t],t))[:2]
assert len(heavy)==2
stable={'accepted','rejected','incomplete'}
ordinary=[]
for task in sorted(groups):
 if task in heavy:continue
 rows=groups[task];peaks=[max((a['peak_rss_bytes']for a in v['attempts']),default=0)for _,_,v in rows]
 if all(v['outcome']['status']in stable for _,_,v in rows)and any(v['outcome']['status']=='accepted'for _,_,v in rows)and all(0<x<=8<<30 for x in peaks):
  ordinary.append(task)
ordinary=ordinary[:2];assert len(ordinary)==2
selected=sorted([row for task in heavy+ordinary for row in groups[task][:8]],key=lambda x:x[0])
assert len(selected)==32
batch={'mode':'all','candidates':[c for _,c,_ in selected]}
assert all(c['reuse']is False and c['timeout_ms']==300000 for c in batch['candidates'])
rows=[]
for index,c,v in selected:
 attempts=v['attempts']
 rows.append({'original_index':index,'id':c['id'],'task_id':c['task_id'],'selected_class':'resource-tail'if c['task_id']in heavy else'ordinary-control',
  'prior_status':v['outcome']['status'],'prior_attempts':len(attempts),
  'prior_max_observed_peak_bytes':max((a['peak_rss_bytes']for a in attempts),default=0)or None,
  'prior_had_preemption':any(a['status']=='preempted'for a in attempts),
  'prior_accumulated_attempt_elapsed_seconds':sum(a['elapsed_seconds']for a in attempts),
  'prior_attempt_history':[{k:a[k]for k in ['status','elapsed_seconds','peak_rss_bytes','exclusive','preemption_rss_bytes']}for a in attempts]})
out=r/'artifacts/engine-resource-profile-2026-10-25/task-memory-preflight-20261027'
out.mkdir(exist_ok=False)
raw=json.dumps(batch,ensure_ascii=False,separators=(',',':')).encode()
packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
(out/'batch32.json.gz').write_bytes(packed)
assert json.loads(gzip.decompress((out/'batch32.json.gz').read_bytes()))==batch
assert all(c==inputs[index]for (index,_,_),c in zip(selected,batch['candidates']))
(out/'config.json').write_text(json.dumps(old['resources'],indent=2)+'\n')
(out/'prior-selected-observations.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_capture':relative,'source_version':'42659a8',
 'source_candidates':7808,'source_tasks':244,'selected_candidates':32,'selected_tasks':heavy+ordinary,
 'resource_tail_tasks':{t:failure_counts[t]for t in heavy},'ordinary_tasks':ordinary,
 'selected_prior_statuses':dict(collections.Counter(row['prior_status']for row in rows)),
 'selected_prior_preempted_candidates':sum(x['prior_had_preemption']for x in rows),
 'selected_prior_accumulated_attempt_seconds':sum(x['prior_accumulated_attempt_elapsed_seconds']for x in rows),
 'selected_prior_unknown_peak_count':sum(x['prior_max_observed_peak_bytes']is None for x in rows),
 'original_batch_order_preserved':True,'original_candidate_fields_preserved':True,
 'input_json_bytes':len(raw),'mode':'all','reuse':False,'timeout_ms':300000,
 'selection':'two highest-resource-failure tasks plus two lexical-first complete stable tasks with acceptance and positive maximum observed peak <=8GiB;first8original submissions per task;global original order',
 'scope':'outcome-informed development cohort,not blind/unbiased throughput evidence;prior statuses are observations,not injected results',
 'native_candidate_executions':0,'new_collections_started':0,
 'clock_scope':'accumulated concurrent attempt elapsed is not removable wall or an Amdahl bound',
 'future_reference':'fresh FIFO versus fresh TaskMemory on same pinned native environment/resources/bytes after current sole group retires'}
(out/'preparation.json').write_text(json.dumps(summary,indent=2)+'\n')
source=Path(__file__).read_bytes();gz=gzip.compress(source,mtime=0);assert gzip.decompress(gz)==source
(out/'prepare-source.py.gz').write_bytes(gz)
(out/'README.md').write_text("""# Task-memory real-input development cohort

Prepared from the complete prior uncapped native7808cell,not the current
growing capture. batch32.json.gz preserves exact original Candidate fields,
task IDs,source text,300s timeout,reusefalse and submission order,with modeall.
config.json retains48GiB actual RSS/CPU8–11/onecoreperworker/noAScap.

Fixed selection is intentionally outcome-informed:two tasks with most final
resource failures and two lexical-first stable32source tasks with acceptance,
positive observed peaks and maximum at most8GiB;take first8submitted candidates
per task and restore original global order. This gives actual queued siblings
beyond4workers plus ordinary controls. It is not a representative/blind sample.
preparation.json and prior-selected-observations.json retain every selected
prior status/attempt/preemption/peak,including censored resource observations.

Use existing measure twice with otherwise identical pinned native environment,
resources,input/mode/reuse and cold histories:--policy fifo versus task-memory.
Retain complete external lifecycle,stdout Capture and stderr RSS events,then
use existing compare. Do not start while the retained fullpair is active.
No new driver,logger,server,model or native experiment has run here.

An intrinsic solo48GiBfailure remains a resource failure;memory feedback cannot
make it a logical rejection or remove its necessary execution. Test whether
fewer repeated preemptions outweigh overreservation,not whether old results
can be replayed as verdicts. Accepted/status changes,retries,tails and cleanup
must remain visible. Prior concurrent attempt sums are not saved wall or a
speedup bound. Original full-population performance and novelty remain open.
""")
print(json.dumps(summary),flush=True)
