from pathlib import Path
import subprocess,os,time,json,signal,datetime
r=Path('/workspaces/repository');step=Path(Path('/tmp/gpu-smt-step0081-path.txt').read_text())
env=dict(os.environ,PATH='/usr/local/cargo/bin:'+os.environ['PATH'],CARGO_HOME='/usr/local/cargo',RUSTUP_HOME='/usr/local/rustup',CARGO_TARGET_DIR='/tmp/gpu-smt-rust-engine-build-20261025/target',CARGO_BUILD_JOBS='1')
cmd=['taskset','-c','11','/usr/local/cargo/bin/cargo','build','--locked','--release','-p','gpu-smt-server','--bin','gpu-smt']
log=Path('/tmp/gpu-smt-task-memory-release-20261027.log')
start=time.monotonic();peak=0;killed=False
with log.open('wb')as f:
 p=subprocess.Popen(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  total=0
  for q in Path('/proc').iterdir():
   if not q.name.isdecimal():continue
   try:
    st=(q/'stat').read_text().split(') ')[1].split()
    if int(st[3])==p.pid:total+=int(st[21])*os.sysconf('SC_PAGE_SIZE')
   except (OSError,ValueError):pass
  peak=max(peak,total)
  if total>48*2**30:os.killpg(p.pid,signal.SIGKILL);killed=True
  time.sleep(1)
 receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'sampled_build_tree_peak_rss_bytes':peak,'budget_kill':killed,'native_candidates':0}
 Path('/tmp/gpu-smt-task-memory-release-20261027.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
