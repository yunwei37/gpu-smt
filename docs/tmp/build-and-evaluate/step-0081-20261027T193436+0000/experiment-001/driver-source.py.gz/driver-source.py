from pathlib import Path
import datetime,gzip,importlib.util,json,os,resource,subprocess,sys,time,shutil
R=Path('/workspaces/repository');INPUT=R/'artifacts/engine-resource-profile-2026-10-25/task-memory-preflight-20261027'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('archive_closed',R/'artifacts/hotspot-mechanisms-2026-10-25/prepared71-20261026/execute.py')
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
 assert resource.getrlimit(resource.RLIMIT_AS)==(-1,-1)
 build=json.loads(Path('/tmp/gpu-smt-task-memory-release-20261027.json').read_text());assert build['exit_code']==0 and not build['budget_kill']
 prior=Path(Path('/tmp/gpu-smt-active-shared-cnf-original.txt').read_text());assert json.loads((prior/'terminal.json').read_text())['exit_code']==0
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:arg=(p/'cmdline').read_bytes().split(b'\0')[0].decode()
  except (OSError,UnicodeError):continue
  assert not (arg.endswith('/bin/repl') or arg.endswith('/prepared-host') or arg.endswith('/bin/lean')),('existing native owner',p.name)
 os.sched_setaffinity(0,{8,9,10,11})
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 out=Path('/tmp')/('gpu-smt-task-memory32-'+stamp);out.mkdir()
 Path('/tmp/gpu-smt-active-task-memory32.txt').write_text(str(out))
 cli=out/'gpu-smt';shutil.copyfile('/tmp/gpu-smt-rust-engine-build-20261025/target/release/gpu-smt',cli);cli.chmod(0o755)
 cfg=json.loads(Path('/tmp/gpu-smt-resource-pair-repair-20261027T032050/full7808/manifest.json').read_text())
 env=dict(os.environ,LEAN_SYSROOT=cfg['sysroot'],LEAN_PATH=cfg['LEAN_PATH'],PATH=cfg['sysroot']+'/bin:'+os.environ['PATH'])
 batch=json.loads(gzip.decompress((INPUT/'batch32.json.gz').read_bytes()))
 assert len(batch['candidates'])==32 and batch['mode']=='all' and all(x['timeout_ms']==300000 and not x['reuse'] for x in batch['candidates'])
 # Fixed real ordinary siblings for engagement,not an efficacy result.
 small={'mode':'all','candidates':[x for x in batch['candidates'] if x['task_id']=='aime_1983_p2'][:2]};assert len(small['candidates'])==2
 manifest={'utc':now(),'controller_pid':os.getpid(),'controller_start_ticks':A.birth(os.getpid()),'build':build,'CLI_bytes':cli.stat().st_size,'input':str(INPUT/'batch32.json.gz'),'backend_reference':cfg,'cells':['preflight-fifo','preflight-task-memory','fifo','task-memory'],'scope':'outcome-informed32-source development pair;not fullpopulation/strongest warm-service/novelty claim','fixed_process_AS_cap':False}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 begin=time.monotonic()
 for n,policy,data in [('preflight-fifo','fifo',small),('preflight-task-memory','task-memory',small),('fifo','fifo',batch),('task-memory','task-memory',batch)]:
  cell=out/n;cell.mkdir();inp=cell/'input.json';inp.write_text(json.dumps(data))
  cmd=[str(cli),'measure','--repl',cfg['repl'],'--project',cfg['project'],'--environment','lean49rc1-mathlib-task-memory32','--cpus','8,9,10,11','--worker-cores','1','--memory-gib','48','--policy',policy]
  start=time.monotonic()
  with inp.open('rb')as src,(cell/'capture.json').open('wb')as dest,(cell/'resource-events.jsonl').open('wb')as err:
   p=subprocess.Popen(cmd,cwd=cfg['project'],env=env,stdin=src,stdout=dest,stderr=err,start_new_session=True)
   (cell/'launch.json').write_text(json.dumps({'utc':now(),'pid':p.pid,'start_ticks':A.birth(p.pid),'command':cmd},indent=2)+'\n');rc=p.wait()
  capture=json.loads((cell/'capture.json').read_text())
  assert capture['batch']==data and capture['policy']==policy and len(capture['results'])==len(data['candidates'])
  (cell/'terminal.json').write_text(json.dumps({'utc':now(),'exit_code':rc,'external_cell_seconds':time.monotonic()-start,'lifecycle_seconds':capture['lifecycle_seconds'],'scope':'process launch through full measure output/exit;includes serialization/output,archival separately timed'},indent=2)+'\n')
  start=time.monotonic()
  for f in [inp,cell/'capture.json',cell/'resource-events.jsonl']:A.archive_closed(f)
  (cell/'archival.json').write_text(json.dumps({'utc':now(),'seconds':time.monotonic()-start,'closed_lossless':True})+'\n')
  print(n,(cell/'terminal.json').read_text(),flush=True)
  assert rc==0
  if n.startswith('preflight'):assert all(x['outcome']['status']=='accepted' for x in capture['results'])
 # Existing compare consumes ordinary JSON files;create disposable decompressed copies.
 for n in ['fifo','task-memory']:
  (out/(n+'.json')).write_bytes(gzip.decompress((out/n/'capture.json.gz').read_bytes()))
 q=subprocess.run([str(cli),'compare',str(out/'fifo.json'),str(out/'task-memory.json')],capture_output=True)
 (out/'comparison.json').write_bytes(q.stdout);(out/'compare.stderr').write_bytes(q.stderr);assert q.returncode==0
 (out/'terminal.json').write_text(json.dumps({'utc':now(),'exit_code':0,'controller_seconds':time.monotonic()-begin,'scope':'preflight/fullpair/capture/archival/compare;release build and environment preparation separately recorded'})+'\n')
if __name__=='__main__':main()
