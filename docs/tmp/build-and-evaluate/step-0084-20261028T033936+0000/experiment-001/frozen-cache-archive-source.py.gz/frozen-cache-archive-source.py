from pathlib import Path
import os,sys,tarfile,shutil,json,datetime,time
os.sched_setaffinity(0,{11})
step=Path(Path('/tmp/gpu-smt-step0084-path.txt').read_text())
root=Path('/workspaces/.agent-state/gpu-smt-native427-20261017-recovery/goedel427/mathlib4/.lake/build/lib')
assert root.resolve()==root
files=sorted(root.rglob('*.private'))
assert len(files)==7517 and all(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(root) for p in files)
source_bytes=sum(p.stat().st_size for p in files)
stage=Path('/tmp/gpu-smt-frozen-goedel-private-cache-20261028.tar.gz')
dest=root.parent/'frozen-private-cache-20261028.tar.gz'
assert not stage.exists() and not dest.exists()
begin=time.monotonic();free_before=shutil.disk_usage('/workspaces').free
with tarfile.open(stage,'w:gz',compresslevel=1,dereference=True)as t:
 for p in files:t.add(p,arcname=str(p.relative_to(root)),recursive=False)
print('ARCHIVE_CREATED',stage.stat().st_size,flush=True)
checked=0
with tarfile.open(stage,'r|gz')as t:
 for member in t:
  assert member.isfile()
  p=root/member.name;assert p.resolve().is_relative_to(root) and p in files
  f=t.extractfile(member);assert f is not None
  with p.open('rb')as src:
   while True:
    left=src.read(1024*1024);right=f.read(1024*1024);assert left==right
    if not left:break
  checked+=1
assert checked==len(files)
assert stage.stat().st_size<shutil.disk_usage('/workspaces').free,'keep both unmodified until final archive fits samePVC'
shutil.copyfile(stage,dest)
with stage.open('rb')as left,dest.open('rb')as right:
 while True:
  a=left.read(1024*1024);b=right.read(1024*1024);assert a==b
  if not a:break
for p in files:p.unlink()
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'inactive generated .private module-cache payloads of frozen old4.27Goedel environment only;not mathematical .lean source,data,rawresults,current4.9/nightly SDK or frozen executable','source_root':str(root),'files':checked,'source_bytes':source_bytes,'archive':str(dest),'staging_archive_retained':str(stage),'stored_bytes':dest.stat().st_size,'all_decompressed_file_bytes_compared':True,'samePVC_archive_bytes_compared':True,'free_before':free_before,'free_after':shutil.disk_usage('/workspaces').free,'seconds':time.monotonic()-begin,'restore':'tar -xzf '+str(dest)+' -C '+str(root),'runtime_limit':'restore these generated cache files before ever reusing the frozen oldGoedel environment;no oldoracle experiment executed'}
(step/'frozen-cache-reclamation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
