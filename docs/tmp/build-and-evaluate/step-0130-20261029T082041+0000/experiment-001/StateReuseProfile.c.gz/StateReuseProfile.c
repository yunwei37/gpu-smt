// Lean compiler output
// Module: StateReuseProfile
// Imports: Init Lean Init.System.Mutex Init.Util
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__1;
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6;
lean_object* lean_string_utf8_extract(lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28;
lean_object* lean_format_pretty(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__4;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__11;
uint8_t l_Lean_Exception_isMaxHeartbeat(lean_object*);
static lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3;
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT uint8_t l_GpuSmt_StateReuseProfile_sameEnvironmentImpl(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__2;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20;
lean_object* l_Lean_Json_mkObj(lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity(lean_object*);
LEAN_EXPORT lean_object* l_ReaderT_bind___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__3___rarg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__4(lean_object*, lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23;
uint8_t l_Lean_Exception_isMaxRecDepth(lean_object*);
lean_object* l_IO_Mutex_new___rarg(lean_object*, lean_object*);
static lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___closed__1;
LEAN_EXPORT uint8_t l_Array_isEqvAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__3;
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_initFn____x40_StateReuseProfile___hyg_242_(lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___closed__1;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__2;
uint8_t l_Lean_Exception_isInterrupt(lean_object*);
LEAN_EXPORT lean_object* l_IO_Mutex_atomically___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__4(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_StateRefT_x27_get___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__1___boxed(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__1;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27;
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__2___boxed(lean_object**);
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_sameEnvironmentImpl___boxed(lean_object*, lean_object*);
lean_object* l_Lean_Name_toString(lean_object*, uint8_t);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__5;
lean_object* l___private_Init_Meta_0__Lean_Meta_reprEtaStructMode____x40_Init_Meta___hyg_11624_(uint8_t, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_array_push(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___boxed(lean_object**);
lean_object* l___private_Init_GetElem_0__outOfBounds___rarg(lean_object*);
LEAN_EXPORT lean_object* l_IO_Mutex_atomically___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__2(lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__5;
lean_object* l_Lean_Syntax_getPos_x3f(lean_object*, uint8_t);
lean_object* lean_array_fget(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__10;
LEAN_EXPORT uint8_t l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63_(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_Registry_environments___default;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__3;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__10;
lean_object* lean_io_basemutex_lock(lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2___closed__1;
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__1;
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__4;
lean_object* lean_io_get_num_heartbeats(lean_object*);
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity(lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__1;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__4;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__1;
static lean_object* l_GpuSmt_StateReuseProfile_instInhabitedRegistry___closed__1;
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_registry;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__2;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__7;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__5;
LEAN_EXPORT lean_object* l_Array_isEqvAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Lean_Expr_hasMVar(lean_object*);
LEAN_EXPORT lean_object* l_ReaderT_bind___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__3(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__12;
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__12;
size_t lean_usize_of_nat(lean_object*);
lean_object* l_Lean_Elab_Tactic_getGoals___rarg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity(lean_object*);
lean_object* lean_expr_abstract(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__6(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__3;
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__3;
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__12;
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__7;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8;
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_Registry_nextCall___default;
lean_object* l_IO_eprintln___at___private_Init_System_IO_0__IO_eprintlnAux___spec__1(lean_object*, lean_object*);
lean_object* l___private_Lean_Expr_0__Lean_reprBinderInfo____x40_Lean_Expr___hyg_430_(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_observeState;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_MessageLog_toList(lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__5;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__4;
lean_object* l_Lean_Syntax_getKind(lean_object*);
uint8_t l_Lean_KVMap_eqv(lean_object*, lean_object*);
lean_object* l_Lean_MessageData_ofFormat(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__1(size_t, size_t, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31;
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3(lean_object*, lean_object*, lean_object*, lean_object*, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_instBEqKey___closed__1;
lean_object* l___private_Init_Meta_0__Lean_Meta_reprTransparencyMode____x40_Init_Meta___hyg_11476_(uint8_t, lean_object*);
static lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__2;
lean_object* lean_io_mono_nanos_now(lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__2;
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__1;
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__2;
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_instInhabitedKey;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19;
static lean_object* l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__3;
lean_object* l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_List_lengthTRAux___rarg(lean_object*, lean_object*);
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
static lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1;
uint8_t lean_expr_equal(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___boxed(lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__2;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__7;
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_Registry_keys___default;
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__1;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__2;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__6;
lean_object* l_Lean_LocalDecl_fvarId(lean_object*);
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__11;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__1;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__6;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29;
extern lean_object* l_Std_Format_defWidth;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__2;
static lean_object* l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
static lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__1;
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_instInhabitedRegistry;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__6;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__3;
lean_object* l_Array_append___rarg(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__11;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__1;
lean_object* l_Lean_Elab_throwUnsupportedSyntax___at_Lean_Elab_Tactic_Rfl_evalApplyRfl___spec__1___rarg(lean_object*);
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_sameEnvironmentNative___boxed(lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__1;
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___spec__1(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__13;
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l___private_Lean_MetavarContext_0__Lean_reprMetavarKind____x40_Lean_MetavarContext___hyg_123_(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__2(size_t, size_t, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14;
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__1;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__10;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t gpu_smt_environment_equal(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__4;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__3;
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Lean_MVarId_getDecl(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__6;
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__2;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___closed__1;
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__2;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24;
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__2(lean_object*, lean_object*);
lean_object* l_Lean_LocalDecl_type(lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__9;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__7;
lean_object* lean_nat_sub(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__6;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3;
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__5;
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__10;
lean_object* l_List_reverse___rarg(lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__9;
lean_object* l___private_Lean_LocalContext_0__Lean_reprLocalDeclKind____x40_Lean_LocalContext___hyg_17_(uint8_t, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11;
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__2(size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3;
size_t lean_usize_add(size_t, size_t);
uint8_t l_Lean_Expr_hasFVar(lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__5;
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__9;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__1;
lean_object* lean_array_uget(lean_object*, size_t);
lean_object* l_Lean_Expr_fvar___override(lean_object*);
lean_object* lean_io_error_to_string(lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__15;
lean_object* lean_st_ref_set(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit___closed__1;
lean_object* l_List_redLength___rarg(lean_object*);
LEAN_EXPORT lean_object* l_StateRefT_x27_get___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__1(lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25;
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_Tactic_evalTactic(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_io_basemutex_unlock(lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__12;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9;
lean_object* lean_array_get_size(lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__4;
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_instBEqKey;
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__8;
static lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__2;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__6;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8(size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity(lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7;
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__2;
uint8_t l___private_Lean_Message_0__Lean_beqMessageSeverity____x40_Lean_Message___hyg_106_(uint8_t, uint8_t);
static lean_object* l_GpuSmt_StateReuseProfile_observeState___closed__8;
static lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__16;
static lean_object* l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__2;
lean_object* l_Array_mapMUnsafe_map___at___private_Lean_Elab_ParseImportsFast_0__Lean_toJsonPrintImportResult____x40_Lean_Elab_ParseImportsFast___hyg_1460____spec__3(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(lean_object*, lean_object*);
lean_object* l_List_toArrayAux___rarg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(lean_object*);
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_sameEnvironmentNative___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; 
x_3 = gpu_smt_environment_equal(x_1, x_2);
lean_dec(x_2);
lean_dec(x_1);
x_4 = lean_box(x_3);
return x_4;
}
}
LEAN_EXPORT uint8_t l_GpuSmt_StateReuseProfile_sameEnvironmentImpl(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; 
x_3 = gpu_smt_environment_equal(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_sameEnvironmentImpl___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; 
x_3 = l_GpuSmt_StateReuseProfile_sameEnvironmentImpl(x_1, x_2);
lean_dec(x_2);
lean_dec(x_1);
x_4 = lean_box(x_3);
return x_4;
}
}
LEAN_EXPORT uint8_t l_Array_isEqvAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; uint8_t x_8; 
x_7 = lean_array_get_size(x_4);
x_8 = lean_nat_dec_lt(x_6, x_7);
lean_dec(x_7);
if (x_8 == 0)
{
uint8_t x_9; 
lean_dec(x_6);
x_9 = 1;
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_10 = lean_array_fget(x_4, x_6);
x_11 = lean_array_fget(x_5, x_6);
x_12 = lean_expr_equal(x_10, x_11);
lean_dec(x_11);
lean_dec(x_10);
if (x_12 == 0)
{
uint8_t x_13; 
lean_dec(x_6);
x_13 = 0;
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_unsigned_to_nat(1u);
x_15 = lean_nat_add(x_6, x_14);
lean_dec(x_6);
x_3 = lean_box(0);
x_6 = x_15;
goto _start;
}
}
}
}
LEAN_EXPORT uint8_t l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
x_5 = lean_ctor_get(x_1, 2);
lean_inc(x_5);
x_6 = lean_ctor_get(x_1, 3);
lean_inc(x_6);
lean_dec(x_1);
x_7 = lean_ctor_get(x_2, 0);
lean_inc(x_7);
x_8 = lean_ctor_get(x_2, 1);
lean_inc(x_8);
x_9 = lean_ctor_get(x_2, 2);
lean_inc(x_9);
x_10 = lean_ctor_get(x_2, 3);
lean_inc(x_10);
lean_dec(x_2);
x_11 = lean_nat_dec_eq(x_3, x_7);
lean_dec(x_7);
lean_dec(x_3);
if (x_11 == 0)
{
uint8_t x_12; 
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_12 = 0;
return x_12;
}
else
{
uint8_t x_13; 
x_13 = l_Lean_KVMap_eqv(x_4, x_8);
if (x_13 == 0)
{
uint8_t x_14; 
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_6);
lean_dec(x_5);
x_14 = 0;
return x_14;
}
else
{
uint8_t x_15; 
x_15 = lean_string_dec_eq(x_5, x_9);
lean_dec(x_9);
lean_dec(x_5);
if (x_15 == 0)
{
uint8_t x_16; 
lean_dec(x_10);
lean_dec(x_6);
x_16 = 0;
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_17 = lean_array_get_size(x_6);
x_18 = lean_array_get_size(x_10);
x_19 = lean_nat_dec_eq(x_17, x_18);
lean_dec(x_18);
lean_dec(x_17);
if (x_19 == 0)
{
uint8_t x_20; 
lean_dec(x_10);
lean_dec(x_6);
x_20 = 0;
return x_20;
}
else
{
lean_object* x_21; uint8_t x_22; 
x_21 = lean_unsigned_to_nat(0u);
x_22 = l_Array_isEqvAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____spec__1(x_6, x_10, lean_box(0), x_6, x_10, x_21);
lean_dec(x_10);
lean_dec(x_6);
return x_22;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_isEqvAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; lean_object* x_8; 
x_7 = l_Array_isEqvAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____spec__1(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
lean_dec(x_1);
x_8 = lean_box(x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; 
x_3 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63_(x_1, x_2);
x_4 = lean_box(x_3);
return x_4;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instBEqKey___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instBEqKey() {
_start:
{
lean_object* x_1; 
x_1 = l_GpuSmt_StateReuseProfile_instBEqKey___closed__1;
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("", 0);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = lean_box(0);
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__2;
x_4 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_5 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_5, 0, x_2);
lean_ctor_set(x_5, 1, x_1);
lean_ctor_set(x_5, 2, x_3);
lean_ctor_set(x_5, 3, x_4);
return x_5;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instInhabitedKey() {
_start:
{
lean_object* x_1; 
x_1 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__3;
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_Registry_environments___default() {
_start:
{
lean_object* x_1; 
x_1 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_Registry_keys___default() {
_start:
{
lean_object* x_1; 
x_1 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_Registry_nextCall___default() {
_start:
{
lean_object* x_1; 
x_1 = lean_unsigned_to_nat(0u);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instInhabitedRegistry___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_1);
lean_ctor_set(x_3, 2, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_instInhabitedRegistry() {
_start:
{
lean_object* x_1; 
x_1 = l_GpuSmt_StateReuseProfile_instInhabitedRegistry___closed__1;
return x_1;
}
}
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile_initFn____x40_StateReuseProfile___hyg_242_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
x_2 = l_GpuSmt_StateReuseProfile_instInhabitedRegistry___closed__1;
x_3 = l_IO_Mutex_new___rarg(x_2, x_1);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
lean_inc(x_5);
lean_dec(x_3);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_StateRefT_x27_get___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; uint8_t x_4; 
x_3 = lean_st_ref_get(x_1, x_2);
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_3, 0);
x_6 = lean_ctor_get(x_3, 1);
lean_inc(x_6);
lean_inc(x_5);
lean_dec(x_3);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_6 = lean_unsigned_to_nat(1u);
x_7 = lean_nat_add(x_2, x_6);
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_1);
lean_ctor_set(x_8, 1, x_7);
x_9 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_9, 0, x_8);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_5);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint8_t x_9; 
x_9 = lean_usize_dec_lt(x_5, x_4);
if (x_9 == 0)
{
lean_object* x_10; 
lean_dec(x_2);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_6);
lean_ctor_set(x_10, 1, x_8);
return x_10;
}
else
{
lean_object* x_11; uint8_t x_12; 
x_11 = lean_array_uget(x_3, x_5);
x_12 = !lean_is_exclusive(x_6);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_13 = lean_ctor_get(x_6, 1);
x_14 = lean_ctor_get(x_6, 0);
lean_dec(x_14);
x_15 = gpu_smt_environment_equal(x_11, x_1);
lean_dec(x_11);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; size_t x_21; size_t x_22; 
lean_free_object(x_6);
x_16 = lean_box(0);
lean_inc(x_2);
x_17 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___lambda__1(x_2, x_13, x_16, x_7, x_8);
lean_dec(x_13);
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_17, 1);
lean_inc(x_19);
lean_dec(x_17);
x_20 = lean_ctor_get(x_18, 0);
lean_inc(x_20);
lean_dec(x_18);
x_21 = 1;
x_22 = lean_usize_add(x_5, x_21);
x_5 = x_22;
x_6 = x_20;
x_8 = x_19;
goto _start;
}
else
{
lean_object* x_24; lean_object* x_25; 
lean_dec(x_2);
lean_inc(x_13);
x_24 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_24, 0, x_13);
lean_ctor_set(x_6, 0, x_24);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_6);
lean_ctor_set(x_25, 1, x_8);
return x_25;
}
}
else
{
lean_object* x_26; uint8_t x_27; 
x_26 = lean_ctor_get(x_6, 1);
lean_inc(x_26);
lean_dec(x_6);
x_27 = gpu_smt_environment_equal(x_11, x_1);
lean_dec(x_11);
if (x_27 == 0)
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; size_t x_33; size_t x_34; 
x_28 = lean_box(0);
lean_inc(x_2);
x_29 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___lambda__1(x_2, x_26, x_28, x_7, x_8);
lean_dec(x_26);
x_30 = lean_ctor_get(x_29, 0);
lean_inc(x_30);
x_31 = lean_ctor_get(x_29, 1);
lean_inc(x_31);
lean_dec(x_29);
x_32 = lean_ctor_get(x_30, 0);
lean_inc(x_32);
lean_dec(x_30);
x_33 = 1;
x_34 = lean_usize_add(x_5, x_33);
x_5 = x_34;
x_6 = x_32;
x_8 = x_31;
goto _start;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
lean_dec(x_2);
lean_inc(x_26);
x_36 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_36, 0, x_26);
x_37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_37, 0, x_36);
lean_ctor_set(x_37, 1, x_26);
x_38 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_38, 0, x_37);
lean_ctor_set(x_38, 1, x_8);
return x_38;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ReaderT_bind___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__3___rarg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
lean_inc(x_3);
x_5 = lean_apply_2(x_1, x_3, x_4);
if (lean_obj_tag(x_5) == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_6 = lean_ctor_get(x_5, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_5, 1);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_apply_3(x_2, x_6, x_3, x_7);
return x_8;
}
else
{
uint8_t x_9; 
lean_dec(x_3);
lean_dec(x_2);
x_9 = !lean_is_exclusive(x_5);
if (x_9 == 0)
{
return x_5;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_5, 0);
x_11 = lean_ctor_get(x_5, 1);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_5);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_10);
lean_ctor_set(x_12, 1, x_11);
return x_12;
}
}
}
}
LEAN_EXPORT lean_object* l_ReaderT_bind___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__3(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_alloc_closure((void*)(l_ReaderT_bind___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__3___rarg), 4, 0);
return x_3;
}
}
LEAN_EXPORT lean_object* l_IO_Mutex_atomically___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
x_5 = lean_io_basemutex_lock(x_4, x_3);
x_6 = lean_ctor_get(x_5, 1);
lean_inc(x_6);
lean_dec(x_5);
x_7 = lean_ctor_get(x_1, 0);
lean_inc(x_7);
lean_dec(x_1);
x_8 = lean_apply_2(x_2, x_7, x_6);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_io_basemutex_unlock(x_4, x_10);
lean_dec(x_4);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; 
x_13 = lean_ctor_get(x_11, 0);
lean_dec(x_13);
lean_ctor_set(x_11, 0, x_9);
return x_11;
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_11, 1);
lean_inc(x_14);
lean_dec(x_11);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_9);
lean_ctor_set(x_15, 1, x_14);
return x_15;
}
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_16 = lean_ctor_get(x_8, 0);
lean_inc(x_16);
x_17 = lean_ctor_get(x_8, 1);
lean_inc(x_17);
lean_dec(x_8);
x_18 = lean_io_basemutex_unlock(x_4, x_17);
lean_dec(x_4);
x_19 = !lean_is_exclusive(x_18);
if (x_19 == 0)
{
lean_object* x_20; 
x_20 = lean_ctor_get(x_18, 0);
lean_dec(x_20);
lean_ctor_set_tag(x_18, 1);
lean_ctor_set(x_18, 0, x_16);
return x_18;
}
else
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_18, 1);
lean_inc(x_21);
lean_dec(x_18);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_16);
lean_ctor_set(x_22, 1, x_21);
return x_22;
}
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_array_push(x_1, x_2);
x_10 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set(x_10, 1, x_3);
lean_ctor_set(x_10, 2, x_4);
x_11 = lean_st_ref_set(x_7, x_10, x_8);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; 
x_13 = lean_ctor_get(x_11, 0);
lean_dec(x_13);
lean_ctor_set(x_11, 0, x_5);
return x_11;
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_11, 1);
lean_inc(x_14);
lean_dec(x_11);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_5);
lean_ctor_set(x_15, 1, x_14);
return x_15;
}
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; size_t x_10; size_t x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_5 = lean_ctor_get(x_2, 0);
lean_inc(x_5);
x_6 = lean_ctor_get(x_2, 1);
lean_inc(x_6);
x_7 = lean_ctor_get(x_2, 2);
lean_inc(x_7);
lean_dec(x_2);
x_8 = lean_box(0);
x_9 = lean_array_get_size(x_5);
x_10 = lean_usize_of_nat(x_9);
lean_dec(x_9);
x_11 = 0;
x_12 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2___closed__1;
x_13 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2(x_1, x_8, x_5, x_10, x_11, x_12, x_3, x_4);
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
if (lean_obj_tag(x_15) == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_13, 1);
lean_inc(x_16);
lean_dec(x_13);
x_17 = lean_ctor_get(x_14, 1);
lean_inc(x_17);
lean_dec(x_14);
x_18 = lean_box(0);
x_19 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__1(x_5, x_1, x_6, x_7, x_17, x_18, x_3, x_16);
lean_dec(x_3);
return x_19;
}
else
{
uint8_t x_20; 
lean_dec(x_14);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_3);
lean_dec(x_1);
x_20 = !lean_is_exclusive(x_13);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_13, 0);
lean_dec(x_21);
x_22 = lean_ctor_get(x_15, 0);
lean_inc(x_22);
lean_dec(x_15);
lean_ctor_set(x_13, 0, x_22);
return x_13;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_23 = lean_ctor_get(x_13, 1);
lean_inc(x_23);
lean_dec(x_13);
x_24 = lean_ctor_get(x_15, 0);
lean_inc(x_24);
lean_dec(x_15);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_23);
return x_25;
}
}
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_StateRefT_x27_get___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__1___boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = l_GpuSmt_StateReuseProfile_registry;
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = lean_alloc_closure((void*)(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2), 4, 1);
lean_closure_set(x_3, 0, x_1);
x_4 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__1;
x_5 = lean_alloc_closure((void*)(l_ReaderT_bind___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__3___rarg), 4, 2);
lean_closure_set(x_5, 0, x_4);
lean_closure_set(x_5, 1, x_3);
x_6 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__2;
x_7 = l_IO_Mutex_atomically___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__4(x_6, x_5, x_2);
return x_7;
}
}
LEAN_EXPORT lean_object* l_StateRefT_x27_get___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_StateRefT_x27_get___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__1(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___lambda__1(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
size_t x_9; size_t x_10; lean_object* x_11; 
x_9 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_10 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_11 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__2(x_1, x_2, x_3, x_9, x_10, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_3);
lean_dec(x_1);
return x_11;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_6);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
uint8_t x_11; 
x_11 = lean_nat_dec_le(x_6, x_5);
if (x_11 == 0)
{
lean_object* x_12; uint8_t x_13; 
x_12 = lean_unsigned_to_nat(0u);
x_13 = lean_nat_dec_eq(x_4, x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_14 = lean_unsigned_to_nat(1u);
x_15 = lean_nat_sub(x_4, x_14);
lean_dec(x_4);
x_16 = lean_nat_dec_lt(x_5, x_3);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_17 = l_GpuSmt_StateReuseProfile_instInhabitedKey;
x_18 = l___private_Init_GetElem_0__outOfBounds___rarg(x_17);
lean_inc(x_2);
x_19 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63_(x_18, x_2);
if (x_19 == 0)
{
lean_object* x_20; 
x_20 = lean_nat_add(x_5, x_7);
lean_dec(x_5);
x_4 = x_15;
x_5 = x_20;
goto _start;
}
else
{
lean_object* x_22; lean_object* x_23; 
lean_dec(x_15);
lean_dec(x_8);
lean_dec(x_2);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_5);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_10);
return x_23;
}
}
else
{
lean_object* x_24; uint8_t x_25; 
x_24 = lean_array_fget(x_1, x_5);
lean_inc(x_2);
x_25 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_beqKey____x40_StateReuseProfile___hyg_63_(x_24, x_2);
if (x_25 == 0)
{
lean_object* x_26; 
x_26 = lean_nat_add(x_5, x_7);
lean_dec(x_5);
x_4 = x_15;
x_5 = x_26;
goto _start;
}
else
{
lean_object* x_28; lean_object* x_29; 
lean_dec(x_15);
lean_dec(x_8);
lean_dec(x_2);
x_28 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_28, 0, x_5);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_10);
return x_29;
}
}
}
else
{
lean_object* x_30; 
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
x_30 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_30, 0, x_8);
lean_ctor_set(x_30, 1, x_10);
return x_30;
}
}
else
{
lean_object* x_31; 
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
x_31 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_31, 0, x_8);
lean_ctor_set(x_31, 1, x_10);
return x_31;
}
}
}
LEAN_EXPORT lean_object* l_IO_Mutex_atomically___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
x_5 = lean_io_basemutex_lock(x_4, x_3);
x_6 = lean_ctor_get(x_5, 1);
lean_inc(x_6);
lean_dec(x_5);
x_7 = lean_ctor_get(x_1, 0);
lean_inc(x_7);
lean_dec(x_1);
x_8 = lean_apply_2(x_2, x_7, x_6);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_io_basemutex_unlock(x_4, x_10);
lean_dec(x_4);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; 
x_13 = lean_ctor_get(x_11, 0);
lean_dec(x_13);
lean_ctor_set(x_11, 0, x_9);
return x_11;
}
else
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_11, 1);
lean_inc(x_14);
lean_dec(x_11);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_9);
lean_ctor_set(x_15, 1, x_14);
return x_15;
}
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_16 = lean_ctor_get(x_8, 0);
lean_inc(x_16);
x_17 = lean_ctor_get(x_8, 1);
lean_inc(x_17);
lean_dec(x_8);
x_18 = lean_io_basemutex_unlock(x_4, x_17);
lean_dec(x_4);
x_19 = !lean_is_exclusive(x_18);
if (x_19 == 0)
{
lean_object* x_20; 
x_20 = lean_ctor_get(x_18, 0);
lean_dec(x_20);
lean_ctor_set_tag(x_18, 1);
lean_ctor_set(x_18, 0, x_16);
return x_18;
}
else
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_18, 1);
lean_inc(x_21);
lean_dec(x_18);
x_22 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_22, 0, x_16);
lean_ctor_set(x_22, 1, x_21);
return x_22;
}
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; uint8_t x_8; 
x_7 = lean_st_ref_set(x_5, x_3, x_6);
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; 
x_9 = lean_ctor_get(x_7, 0);
lean_dec(x_9);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_1);
lean_ctor_set(x_10, 1, x_2);
lean_ctor_set(x_7, 0, x_10);
return x_7;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_7, 1);
lean_inc(x_11);
lean_dec(x_7);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_1);
lean_ctor_set(x_12, 1, x_2);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_11);
return x_13;
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = !lean_is_exclusive(x_2);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_6 = lean_ctor_get(x_2, 0);
x_7 = lean_ctor_get(x_2, 1);
x_8 = lean_ctor_get(x_2, 2);
x_9 = lean_unsigned_to_nat(1u);
x_10 = lean_nat_add(x_8, x_9);
lean_inc(x_10);
lean_inc(x_7);
lean_inc(x_6);
lean_ctor_set(x_2, 2, x_10);
x_11 = lean_box(0);
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_12; lean_object* x_13; 
lean_dec(x_10);
lean_dec(x_7);
lean_dec(x_6);
x_12 = lean_box(0);
x_13 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_8, x_11, x_2, x_12, x_3, x_4);
lean_dec(x_3);
return x_13;
}
else
{
uint8_t x_14; 
x_14 = !lean_is_exclusive(x_1);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_15 = lean_ctor_get(x_1, 0);
x_16 = lean_array_get_size(x_7);
x_17 = lean_unsigned_to_nat(0u);
lean_inc(x_16);
lean_inc(x_15);
x_18 = l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1(x_7, x_15, x_16, x_16, x_17, x_16, x_9, x_11, x_3, x_4);
x_19 = lean_ctor_get(x_18, 0);
lean_inc(x_19);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
lean_dec(x_2);
x_20 = lean_ctor_get(x_18, 1);
lean_inc(x_20);
lean_dec(x_18);
lean_ctor_set(x_1, 0, x_16);
x_21 = lean_array_push(x_7, x_15);
x_22 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_22, 0, x_6);
lean_ctor_set(x_22, 1, x_21);
lean_ctor_set(x_22, 2, x_10);
x_23 = lean_box(0);
x_24 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_8, x_1, x_22, x_23, x_3, x_20);
lean_dec(x_3);
return x_24;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
lean_dec(x_16);
lean_free_object(x_1);
lean_dec(x_15);
lean_dec(x_10);
lean_dec(x_7);
lean_dec(x_6);
x_25 = lean_ctor_get(x_18, 1);
lean_inc(x_25);
lean_dec(x_18);
x_26 = lean_box(0);
x_27 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_8, x_19, x_2, x_26, x_3, x_25);
lean_dec(x_3);
return x_27;
}
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_28 = lean_ctor_get(x_1, 0);
lean_inc(x_28);
lean_dec(x_1);
x_29 = lean_array_get_size(x_7);
x_30 = lean_unsigned_to_nat(0u);
lean_inc(x_29);
lean_inc(x_28);
x_31 = l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1(x_7, x_28, x_29, x_29, x_30, x_29, x_9, x_11, x_3, x_4);
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
lean_dec(x_2);
x_33 = lean_ctor_get(x_31, 1);
lean_inc(x_33);
lean_dec(x_31);
x_34 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_34, 0, x_29);
x_35 = lean_array_push(x_7, x_28);
x_36 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_36, 0, x_6);
lean_ctor_set(x_36, 1, x_35);
lean_ctor_set(x_36, 2, x_10);
x_37 = lean_box(0);
x_38 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_8, x_34, x_36, x_37, x_3, x_33);
lean_dec(x_3);
return x_38;
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; 
lean_dec(x_29);
lean_dec(x_28);
lean_dec(x_10);
lean_dec(x_7);
lean_dec(x_6);
x_39 = lean_ctor_get(x_31, 1);
lean_inc(x_39);
lean_dec(x_31);
x_40 = lean_box(0);
x_41 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_8, x_32, x_2, x_40, x_3, x_39);
lean_dec(x_3);
return x_41;
}
}
}
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_42 = lean_ctor_get(x_2, 0);
x_43 = lean_ctor_get(x_2, 1);
x_44 = lean_ctor_get(x_2, 2);
lean_inc(x_44);
lean_inc(x_43);
lean_inc(x_42);
lean_dec(x_2);
x_45 = lean_unsigned_to_nat(1u);
x_46 = lean_nat_add(x_44, x_45);
lean_inc(x_46);
lean_inc(x_43);
lean_inc(x_42);
x_47 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_47, 0, x_42);
lean_ctor_set(x_47, 1, x_43);
lean_ctor_set(x_47, 2, x_46);
x_48 = lean_box(0);
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_49; lean_object* x_50; 
lean_dec(x_46);
lean_dec(x_43);
lean_dec(x_42);
x_49 = lean_box(0);
x_50 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_44, x_48, x_47, x_49, x_3, x_4);
lean_dec(x_3);
return x_50;
}
else
{
lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
x_51 = lean_ctor_get(x_1, 0);
lean_inc(x_51);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 x_52 = x_1;
} else {
 lean_dec_ref(x_1);
 x_52 = lean_box(0);
}
x_53 = lean_array_get_size(x_43);
x_54 = lean_unsigned_to_nat(0u);
lean_inc(x_53);
lean_inc(x_51);
x_55 = l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1(x_43, x_51, x_53, x_53, x_54, x_53, x_45, x_48, x_3, x_4);
x_56 = lean_ctor_get(x_55, 0);
lean_inc(x_56);
if (lean_obj_tag(x_56) == 0)
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
lean_dec(x_47);
x_57 = lean_ctor_get(x_55, 1);
lean_inc(x_57);
lean_dec(x_55);
if (lean_is_scalar(x_52)) {
 x_58 = lean_alloc_ctor(1, 1, 0);
} else {
 x_58 = x_52;
}
lean_ctor_set(x_58, 0, x_53);
x_59 = lean_array_push(x_43, x_51);
x_60 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_60, 0, x_42);
lean_ctor_set(x_60, 1, x_59);
lean_ctor_set(x_60, 2, x_46);
x_61 = lean_box(0);
x_62 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_44, x_58, x_60, x_61, x_3, x_57);
lean_dec(x_3);
return x_62;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; 
lean_dec(x_53);
lean_dec(x_52);
lean_dec(x_51);
lean_dec(x_46);
lean_dec(x_43);
lean_dec(x_42);
x_63 = lean_ctor_get(x_55, 1);
lean_inc(x_63);
lean_dec(x_55);
x_64 = lean_box(0);
x_65 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_44, x_56, x_47, x_64, x_3, x_63);
lean_dec(x_3);
return x_65;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = lean_alloc_closure((void*)(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__2), 4, 1);
lean_closure_set(x_3, 0, x_1);
x_4 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__1;
x_5 = lean_alloc_closure((void*)(l_ReaderT_bind___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___spec__3___rarg), 4, 2);
lean_closure_set(x_5, 0, x_4);
lean_closure_set(x_5, 1, x_3);
x_6 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__2;
x_7 = l_IO_Mutex_atomically___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__2(x_6, x_5, x_2);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Std_Range_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_3);
lean_dec(x_1);
return x_11;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_4);
return x_7;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("anonymous", 9);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__2;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__4;
x_2 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("str", 3);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__6;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__7;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("num", 3);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__10;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__11;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(lean_object* x_1) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
lean_object* x_2; 
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__5;
return x_2;
}
case 1:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc(x_4);
lean_dec(x_1);
x_5 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_3);
x_6 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_6, 0, x_4);
x_7 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__9;
x_8 = lean_array_push(x_7, x_5);
x_9 = lean_array_push(x_8, x_6);
x_10 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
default: 
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_11 = lean_ctor_get(x_1, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_1, 1);
lean_inc(x_12);
lean_dec(x_1);
x_13 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_11);
x_14 = l_Lean_JsonNumber_fromNat(x_12);
x_15 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_15, 0, x_14);
x_16 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__12;
x_17 = lean_array_push(x_16, x_13);
x_18 = lean_array_push(x_17, x_15);
x_19 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_19, 0, x_18);
return x_19;
}
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___spec__1(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; 
x_3 = l_List_reverse___rarg(x_2);
return x_3;
}
else
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_1);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_1, 0);
x_6 = lean_ctor_get(x_1, 1);
x_7 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_5);
lean_ctor_set(x_1, 1, x_2);
lean_ctor_set(x_1, 0, x_7);
{
lean_object* _tmp_0 = x_6;
lean_object* _tmp_1 = x_1;
x_1 = _tmp_0;
x_2 = _tmp_1;
}
goto _start;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = lean_ctor_get(x_1, 0);
x_10 = lean_ctor_get(x_1, 1);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_1);
x_11 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_9);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_2);
x_1 = x_10;
x_2 = x_12;
goto _start;
}
}
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("simple", 6);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__2;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("explicit", 8);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__4;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__5;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; size_t x_11; size_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_2 = lean_ctor_get(x_1, 0);
lean_inc(x_2);
x_3 = lean_ctor_get(x_1, 1);
lean_inc(x_3);
lean_dec(x_1);
x_4 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_2);
x_5 = lean_box(0);
x_6 = l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___spec__1(x_3, x_5);
x_7 = l_List_redLength___rarg(x_6);
x_8 = lean_mk_empty_array_with_capacity(x_7);
lean_dec(x_7);
x_9 = l_List_toArrayAux___rarg(x_6, x_8);
x_10 = lean_array_get_size(x_9);
x_11 = lean_usize_of_nat(x_10);
lean_dec(x_10);
x_12 = 0;
x_13 = l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__2(x_11, x_12, x_9);
x_14 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_14, 0, x_13);
x_15 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__3;
x_16 = lean_array_push(x_15, x_4);
x_17 = lean_array_push(x_16, x_14);
x_18 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_18, 0, x_17);
return x_18;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_19 = lean_ctor_get(x_1, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_1, 1);
lean_inc(x_20);
lean_dec(x_1);
x_21 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_19);
x_22 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_20);
x_23 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__6;
x_24 = lean_array_push(x_23, x_21);
x_25 = lean_array_push(x_24, x_22);
x_26 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_26, 0, x_25);
return x_26;
}
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("namespace", 9);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__3;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__2;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("decl", 4);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__5;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__6;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
uint8_t x_2; 
x_2 = !lean_is_exclusive(x_1);
if (x_2 == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = lean_ctor_get(x_1, 0);
x_4 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_3);
x_5 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__4;
x_6 = lean_array_push(x_5, x_4);
lean_ctor_set_tag(x_1, 4);
lean_ctor_set(x_1, 0, x_6);
return x_1;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_7 = lean_ctor_get(x_1, 0);
lean_inc(x_7);
lean_dec(x_1);
x_8 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_7);
x_9 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__4;
x_10 = lean_array_push(x_9, x_8);
x_11 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_11, 0, x_10);
return x_11;
}
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; size_t x_19; size_t x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_12 = lean_ctor_get(x_1, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_1, 1);
lean_inc(x_13);
lean_dec(x_1);
x_14 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_12);
x_15 = l_List_redLength___rarg(x_13);
x_16 = lean_mk_empty_array_with_capacity(x_15);
lean_dec(x_15);
x_17 = l_List_toArrayAux___rarg(x_13, x_16);
x_18 = lean_array_get_size(x_17);
x_19 = lean_usize_of_nat(x_18);
lean_dec(x_18);
x_20 = 0;
x_21 = l_Array_mapMUnsafe_map___at___private_Lean_Elab_ParseImportsFast_0__Lean_toJsonPrintImportResult____x40_Lean_Elab_ParseImportsFast___hyg_1460____spec__3(x_19, x_20, x_17);
x_22 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_22, 0, x_21);
x_23 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__7;
x_24 = lean_array_push(x_23, x_14);
x_25 = lean_array_push(x_24, x_22);
x_26 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_26, 0, x_25);
return x_26;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__1(size_t x_1, size_t x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_usize_dec_lt(x_2, x_1);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; size_t x_9; size_t x_10; lean_object* x_11; 
x_5 = lean_array_uget(x_3, x_2);
x_6 = lean_unsigned_to_nat(0u);
x_7 = lean_array_uset(x_3, x_2, x_6);
x_8 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity(x_5);
x_9 = 1;
x_10 = lean_usize_add(x_2, x_9);
x_11 = lean_array_uset(x_7, x_2, x_8);
x_2 = x_10;
x_3 = x_11;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__2(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; 
x_3 = l_List_reverse___rarg(x_2);
return x_3;
}
else
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_1);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_1, 0);
x_6 = lean_ctor_get(x_1, 1);
x_7 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity(x_5);
lean_ctor_set(x_1, 1, x_2);
lean_ctor_set(x_1, 0, x_7);
{
lean_object* _tmp_0 = x_6;
lean_object* _tmp_1 = x_1;
x_1 = _tmp_0;
x_2 = _tmp_1;
}
goto _start;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = lean_ctor_get(x_1, 0);
x_10 = lean_ctor_get(x_1, 1);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_1);
x_11 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity(x_9);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_2);
x_1 = x_10;
x_2 = x_12;
goto _start;
}
}
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("missing", 7);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("node", 4);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__3;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__4;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("atom", 4);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__6;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__3;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__7;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("ident", 5);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__9;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11;
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__10;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity(lean_object* x_1) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
lean_object* x_2; 
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__2;
return x_2;
}
case 1:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; size_t x_7; size_t x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_3 = lean_ctor_get(x_1, 1);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 2);
lean_inc(x_4);
lean_dec(x_1);
x_5 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_3);
x_6 = lean_array_get_size(x_4);
x_7 = lean_usize_of_nat(x_6);
lean_dec(x_6);
x_8 = 0;
x_9 = l_Array_mapMUnsafe_map___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__1(x_7, x_8, x_4);
x_10 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_10, 0, x_9);
x_11 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__5;
x_12 = lean_array_push(x_11, x_5);
x_13 = lean_array_push(x_12, x_10);
x_14 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
case 2:
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_15 = lean_ctor_get(x_1, 1);
lean_inc(x_15);
lean_dec(x_1);
x_16 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_16, 0, x_15);
x_17 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__8;
x_18 = lean_array_push(x_17, x_16);
x_19 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_19, 0, x_18);
return x_19;
}
default: 
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; size_t x_30; size_t x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
x_20 = lean_ctor_get(x_1, 1);
lean_inc(x_20);
x_21 = lean_ctor_get(x_1, 2);
lean_inc(x_21);
x_22 = lean_ctor_get(x_1, 3);
lean_inc(x_22);
lean_dec(x_1);
x_23 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_21);
x_24 = lean_box(0);
x_25 = l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__2(x_22, x_24);
x_26 = l_List_redLength___rarg(x_25);
x_27 = lean_mk_empty_array_with_capacity(x_26);
lean_dec(x_26);
x_28 = l_List_toArrayAux___rarg(x_25, x_27);
x_29 = lean_array_get_size(x_28);
x_30 = lean_usize_of_nat(x_29);
lean_dec(x_29);
x_31 = 0;
x_32 = l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__2(x_30, x_31, x_28);
x_33 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_33, 0, x_32);
x_34 = lean_ctor_get(x_20, 0);
lean_inc(x_34);
x_35 = lean_ctor_get(x_20, 1);
lean_inc(x_35);
x_36 = lean_ctor_get(x_20, 2);
lean_inc(x_36);
lean_dec(x_20);
x_37 = lean_string_utf8_extract(x_34, x_35, x_36);
lean_dec(x_36);
lean_dec(x_35);
lean_dec(x_34);
x_38 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_38, 0, x_37);
x_39 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__12;
x_40 = lean_array_push(x_39, x_38);
x_41 = lean_array_push(x_40, x_23);
x_42 = lean_array_push(x_41, x_33);
x_43 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_43, 0, x_42);
return x_43;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
size_t x_4; size_t x_5; lean_object* x_6; 
x_4 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = l_Array_mapMUnsafe_map___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___spec__1(x_4, x_5, x_3);
return x_6;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(13u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity(lean_object* x_1) {
_start:
{
uint8_t x_2; uint8_t x_3; uint8_t x_4; uint8_t x_5; uint8_t x_6; uint8_t x_7; uint8_t x_8; uint8_t x_9; uint8_t x_10; uint8_t x_11; uint8_t x_12; uint8_t x_13; uint8_t x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_2 = lean_ctor_get_uint8(x_1, 0);
x_3 = lean_ctor_get_uint8(x_1, 1);
x_4 = lean_ctor_get_uint8(x_1, 2);
x_5 = lean_ctor_get_uint8(x_1, 3);
x_6 = lean_ctor_get_uint8(x_1, 4);
x_7 = lean_ctor_get_uint8(x_1, 5);
x_8 = lean_ctor_get_uint8(x_1, 6);
x_9 = lean_ctor_get_uint8(x_1, 7);
x_10 = lean_ctor_get_uint8(x_1, 8);
x_11 = lean_ctor_get_uint8(x_1, 9);
x_12 = lean_ctor_get_uint8(x_1, 10);
x_13 = lean_ctor_get_uint8(x_1, 11);
x_14 = lean_ctor_get_uint8(x_1, 12);
x_15 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_15, 0, x_2);
x_16 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_16, 0, x_3);
x_17 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_17, 0, x_4);
x_18 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_18, 0, x_5);
x_19 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_19, 0, x_6);
x_20 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_20, 0, x_7);
x_21 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_21, 0, x_8);
x_22 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_22, 0, x_9);
x_23 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_23, 0, x_10);
x_24 = lean_unsigned_to_nat(0u);
x_25 = l___private_Init_Meta_0__Lean_Meta_reprTransparencyMode____x40_Init_Meta___hyg_11476_(x_11, x_24);
x_26 = l_Std_Format_defWidth;
x_27 = lean_format_pretty(x_25, x_26, x_24, x_24);
x_28 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_28, 0, x_27);
x_29 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_29, 0, x_12);
x_30 = l___private_Init_Meta_0__Lean_Meta_reprEtaStructMode____x40_Init_Meta___hyg_11624_(x_13, x_24);
x_31 = lean_format_pretty(x_30, x_26, x_24, x_24);
x_32 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_32, 0, x_31);
x_33 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_33, 0, x_14);
x_34 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___closed__1;
x_35 = lean_array_push(x_34, x_15);
x_36 = lean_array_push(x_35, x_16);
x_37 = lean_array_push(x_36, x_17);
x_38 = lean_array_push(x_37, x_18);
x_39 = lean_array_push(x_38, x_19);
x_40 = lean_array_push(x_39, x_20);
x_41 = lean_array_push(x_40, x_21);
x_42 = lean_array_push(x_41, x_22);
x_43 = lean_array_push(x_42, x_23);
x_44 = lean_array_push(x_43, x_28);
x_45 = lean_array_push(x_44, x_29);
x_46 = lean_array_push(x_45, x_32);
x_47 = lean_array_push(x_46, x_33);
x_48 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_48, 0, x_47);
return x_48;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__1(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; 
x_3 = l_List_reverse___rarg(x_2);
return x_3;
}
else
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_1);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_1, 0);
x_6 = lean_ctor_get(x_1, 1);
x_7 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity(x_5);
lean_ctor_set(x_1, 1, x_2);
lean_ctor_set(x_1, 0, x_7);
{
lean_object* _tmp_0 = x_6;
lean_object* _tmp_1 = x_1;
x_1 = _tmp_0;
x_2 = _tmp_1;
}
goto _start;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = lean_ctor_get(x_1, 0);
x_10 = lean_ctor_get(x_1, 1);
lean_inc(x_10);
lean_inc(x_9);
lean_dec(x_1);
x_11 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity(x_9);
x_12 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_2);
x_1 = x_10;
x_2 = x_12;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, size_t x_5, size_t x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
uint8_t x_17; 
x_17 = lean_usize_dec_lt(x_6, x_5);
if (x_17 == 0)
{
lean_object* x_18; 
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_7);
lean_ctor_set(x_18, 1, x_16);
return x_18;
}
else
{
lean_object* x_19; uint8_t x_20; 
x_19 = lean_array_uget(x_4, x_6);
x_20 = !lean_is_exclusive(x_7);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_21 = lean_ctor_get(x_7, 1);
x_22 = lean_ctor_get(x_7, 0);
lean_dec(x_22);
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_21);
lean_inc(x_2);
lean_inc(x_1);
x_23 = l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3(x_1, x_2, x_19, x_21, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
if (lean_obj_tag(x_23) == 0)
{
lean_object* x_24; 
x_24 = lean_ctor_get(x_23, 0);
lean_inc(x_24);
if (lean_obj_tag(x_24) == 0)
{
uint8_t x_25; 
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_25 = !lean_is_exclusive(x_23);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_23, 0);
lean_dec(x_26);
x_27 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_27, 0, x_24);
lean_ctor_set(x_7, 0, x_27);
lean_ctor_set(x_23, 0, x_7);
return x_23;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_28 = lean_ctor_get(x_23, 1);
lean_inc(x_28);
lean_dec(x_23);
x_29 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_29, 0, x_24);
lean_ctor_set(x_7, 0, x_29);
x_30 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_30, 0, x_7);
lean_ctor_set(x_30, 1, x_28);
return x_30;
}
}
else
{
lean_object* x_31; lean_object* x_32; size_t x_33; size_t x_34; 
lean_dec(x_21);
x_31 = lean_ctor_get(x_23, 1);
lean_inc(x_31);
lean_dec(x_23);
x_32 = lean_ctor_get(x_24, 0);
lean_inc(x_32);
lean_dec(x_24);
lean_inc(x_3);
lean_ctor_set(x_7, 1, x_32);
lean_ctor_set(x_7, 0, x_3);
x_33 = 1;
x_34 = lean_usize_add(x_6, x_33);
x_6 = x_34;
x_16 = x_31;
goto _start;
}
}
else
{
uint8_t x_36; 
lean_free_object(x_7);
lean_dec(x_21);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_36 = !lean_is_exclusive(x_23);
if (x_36 == 0)
{
return x_23;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_37 = lean_ctor_get(x_23, 0);
x_38 = lean_ctor_get(x_23, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_23);
x_39 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
return x_39;
}
}
}
else
{
lean_object* x_40; lean_object* x_41; 
x_40 = lean_ctor_get(x_7, 1);
lean_inc(x_40);
lean_dec(x_7);
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_40);
lean_inc(x_2);
lean_inc(x_1);
x_41 = l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3(x_1, x_2, x_19, x_40, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
if (lean_obj_tag(x_41) == 0)
{
lean_object* x_42; 
x_42 = lean_ctor_get(x_41, 0);
lean_inc(x_42);
if (lean_obj_tag(x_42) == 0)
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; 
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_43 = lean_ctor_get(x_41, 1);
lean_inc(x_43);
if (lean_is_exclusive(x_41)) {
 lean_ctor_release(x_41, 0);
 lean_ctor_release(x_41, 1);
 x_44 = x_41;
} else {
 lean_dec_ref(x_41);
 x_44 = lean_box(0);
}
x_45 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_45, 0, x_42);
x_46 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_46, 0, x_45);
lean_ctor_set(x_46, 1, x_40);
if (lean_is_scalar(x_44)) {
 x_47 = lean_alloc_ctor(0, 2, 0);
} else {
 x_47 = x_44;
}
lean_ctor_set(x_47, 0, x_46);
lean_ctor_set(x_47, 1, x_43);
return x_47;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; size_t x_51; size_t x_52; 
lean_dec(x_40);
x_48 = lean_ctor_get(x_41, 1);
lean_inc(x_48);
lean_dec(x_41);
x_49 = lean_ctor_get(x_42, 0);
lean_inc(x_49);
lean_dec(x_42);
lean_inc(x_3);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_3);
lean_ctor_set(x_50, 1, x_49);
x_51 = 1;
x_52 = lean_usize_add(x_6, x_51);
x_6 = x_52;
x_7 = x_50;
x_16 = x_48;
goto _start;
}
}
else
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; 
lean_dec(x_40);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_54 = lean_ctor_get(x_41, 0);
lean_inc(x_54);
x_55 = lean_ctor_get(x_41, 1);
lean_inc(x_55);
if (lean_is_exclusive(x_41)) {
 lean_ctor_release(x_41, 0);
 lean_ctor_release(x_41, 1);
 x_56 = x_41;
} else {
 lean_dec_ref(x_41);
 x_56 = lean_box(0);
}
if (lean_is_scalar(x_56)) {
 x_57 = lean_alloc_ctor(1, 2, 0);
} else {
 x_57 = x_56;
}
lean_ctor_set(x_57, 0, x_54);
lean_ctor_set(x_57, 1, x_55);
return x_57;
}
}
}
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("variable", 8);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11;
x_2 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__2;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("let", 3);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__4;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11;
x_2 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__5;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_16; uint8_t x_17; uint8_t x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_16 = lean_ctor_get(x_1, 2);
lean_inc(x_16);
x_17 = lean_ctor_get_uint8(x_1, sizeof(void*)*4);
x_18 = lean_ctor_get_uint8(x_1, sizeof(void*)*4 + 1);
lean_dec(x_1);
x_19 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_16);
x_20 = lean_unsigned_to_nat(0u);
x_21 = l___private_Lean_Expr_0__Lean_reprBinderInfo____x40_Lean_Expr___hyg_430_(x_17, x_20);
x_22 = l_Std_Format_defWidth;
x_23 = lean_format_pretty(x_21, x_22, x_20, x_20);
x_24 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_24, 0, x_23);
x_25 = l___private_Lean_LocalContext_0__Lean_reprLocalDeclKind____x40_Lean_LocalContext___hyg_17_(x_18, x_20);
x_26 = lean_format_pretty(x_25, x_22, x_20, x_20);
x_27 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_27, 0, x_26);
x_28 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__3;
x_29 = lean_array_push(x_28, x_19);
x_30 = lean_array_push(x_29, x_24);
x_31 = lean_array_push(x_30, x_27);
x_32 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_32, 0, x_31);
x_33 = lean_array_push(x_5, x_32);
x_34 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_34, 0, x_2);
lean_ctor_set(x_34, 1, x_33);
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_4);
lean_ctor_set(x_35, 1, x_34);
x_36 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_36, 0, x_3);
lean_ctor_set(x_36, 1, x_35);
x_37 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_37, 0, x_36);
x_38 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_38, 0, x_37);
lean_ctor_set(x_38, 1, x_15);
return x_38;
}
else
{
lean_object* x_39; uint8_t x_40; uint8_t x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_39 = lean_ctor_get(x_1, 2);
lean_inc(x_39);
x_40 = lean_ctor_get_uint8(x_1, sizeof(void*)*5);
x_41 = lean_ctor_get_uint8(x_1, sizeof(void*)*5 + 1);
lean_dec(x_1);
x_42 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_39);
x_43 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_43, 0, x_40);
x_44 = lean_unsigned_to_nat(0u);
x_45 = l___private_Lean_LocalContext_0__Lean_reprLocalDeclKind____x40_Lean_LocalContext___hyg_17_(x_41, x_44);
x_46 = l_Std_Format_defWidth;
x_47 = lean_format_pretty(x_45, x_46, x_44, x_44);
x_48 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_48, 0, x_47);
x_49 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__6;
x_50 = lean_array_push(x_49, x_42);
x_51 = lean_array_push(x_50, x_43);
x_52 = lean_array_push(x_51, x_48);
x_53 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_53, 0, x_52);
x_54 = lean_array_push(x_5, x_53);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_2);
lean_ctor_set(x_55, 1, x_54);
x_56 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_56, 0, x_4);
lean_ctor_set(x_56, 1, x_55);
x_57 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_57, 0, x_3);
lean_ctor_set(x_57, 1, x_56);
x_58 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_58, 0, x_57);
x_59 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_59, 0, x_58);
lean_ctor_set(x_59, 1, x_15);
return x_59;
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_array_push(x_4, x_1);
x_16 = lean_box(0);
x_17 = lean_apply_12(x_2, x_15, x_3, x_16, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
return x_17;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("unresolved_let_value", 20);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__2;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
lean_dec(x_7);
x_17 = lean_array_push(x_5, x_1);
if (lean_obj_tag(x_2) == 0)
{
lean_object* x_18; lean_object* x_19; 
x_18 = lean_box(0);
x_19 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1(x_2, x_3, x_4, x_17, x_6, x_18, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; uint8_t x_23; 
x_20 = lean_ctor_get(x_2, 4);
lean_inc(x_20);
lean_inc(x_3);
x_21 = lean_alloc_closure((void*)(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___boxed), 15, 3);
lean_closure_set(x_21, 0, x_2);
lean_closure_set(x_21, 1, x_3);
lean_closure_set(x_21, 2, x_4);
x_22 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_20, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; uint8_t x_27; 
x_24 = lean_ctor_get(x_22, 0);
x_25 = lean_ctor_get(x_22, 1);
x_26 = lean_expr_abstract(x_24, x_3);
lean_dec(x_24);
x_27 = l_Lean_Expr_hasMVar(x_26);
if (x_27 == 0)
{
uint8_t x_28; 
x_28 = l_Lean_Expr_hasFVar(x_26);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; 
lean_free_object(x_22);
lean_dec(x_3);
x_29 = lean_box(0);
x_30 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__2(x_26, x_21, x_6, x_17, x_29, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_25);
return x_30;
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
lean_dec(x_26);
lean_dec(x_21);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
x_31 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_31, 0, x_3);
lean_ctor_set(x_31, 1, x_6);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_17);
lean_ctor_set(x_32, 1, x_31);
x_33 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3;
x_34 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_34, 0, x_33);
lean_ctor_set(x_34, 1, x_32);
x_35 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_35, 0, x_34);
lean_ctor_set(x_22, 0, x_35);
return x_22;
}
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; 
lean_dec(x_26);
lean_dec(x_21);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
x_36 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_36, 0, x_3);
lean_ctor_set(x_36, 1, x_6);
x_37 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_37, 0, x_17);
lean_ctor_set(x_37, 1, x_36);
x_38 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3;
x_39 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_37);
x_40 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_40, 0, x_39);
lean_ctor_set(x_22, 0, x_40);
return x_22;
}
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; uint8_t x_44; 
x_41 = lean_ctor_get(x_22, 0);
x_42 = lean_ctor_get(x_22, 1);
lean_inc(x_42);
lean_inc(x_41);
lean_dec(x_22);
x_43 = lean_expr_abstract(x_41, x_3);
lean_dec(x_41);
x_44 = l_Lean_Expr_hasMVar(x_43);
if (x_44 == 0)
{
uint8_t x_45; 
x_45 = l_Lean_Expr_hasFVar(x_43);
if (x_45 == 0)
{
lean_object* x_46; lean_object* x_47; 
lean_dec(x_3);
x_46 = lean_box(0);
x_47 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__2(x_43, x_21, x_6, x_17, x_46, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_42);
return x_47;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; 
lean_dec(x_43);
lean_dec(x_21);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
x_48 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_48, 0, x_3);
lean_ctor_set(x_48, 1, x_6);
x_49 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_49, 0, x_17);
lean_ctor_set(x_49, 1, x_48);
x_50 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3;
x_51 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_51, 0, x_50);
lean_ctor_set(x_51, 1, x_49);
x_52 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_52, 0, x_51);
x_53 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_53, 0, x_52);
lean_ctor_set(x_53, 1, x_42);
return x_53;
}
}
else
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; 
lean_dec(x_43);
lean_dec(x_21);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
x_54 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_54, 0, x_3);
lean_ctor_set(x_54, 1, x_6);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_17);
lean_ctor_set(x_55, 1, x_54);
x_56 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3;
x_57 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_55);
x_58 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_58, 0, x_57);
x_59 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_59, 0, x_58);
lean_ctor_set(x_59, 1, x_42);
return x_59;
}
}
}
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("unresolved_local_type", 21);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__2;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
uint8_t x_16; 
x_16 = lean_usize_dec_lt(x_5, x_4);
if (x_16 == 0)
{
lean_object* x_17; 
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_6);
lean_ctor_set(x_17, 1, x_15);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_18 = lean_array_uget(x_3, x_5);
x_19 = lean_ctor_get(x_6, 1);
lean_inc(x_19);
if (lean_is_exclusive(x_6)) {
 lean_ctor_release(x_6, 0);
 lean_ctor_release(x_6, 1);
 x_20 = x_6;
} else {
 lean_dec_ref(x_6);
 x_20 = lean_box(0);
}
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_32; 
lean_inc(x_19);
x_32 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_32, 0, x_19);
x_21 = x_32;
x_22 = x_15;
goto block_31;
}
else
{
lean_object* x_33; lean_object* x_34; uint8_t x_35; 
x_33 = lean_ctor_get(x_19, 1);
lean_inc(x_33);
x_34 = lean_ctor_get(x_33, 1);
lean_inc(x_34);
x_35 = !lean_is_exclusive(x_18);
if (x_35 == 0)
{
uint8_t x_36; 
x_36 = !lean_is_exclusive(x_33);
if (x_36 == 0)
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; uint8_t x_40; 
x_37 = lean_ctor_get(x_18, 0);
x_38 = lean_ctor_get(x_33, 0);
x_39 = lean_ctor_get(x_33, 1);
lean_dec(x_39);
x_40 = !lean_is_exclusive(x_34);
if (x_40 == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; uint8_t x_48; 
x_41 = lean_ctor_get(x_34, 0);
x_42 = lean_ctor_get(x_34, 1);
x_43 = l_Lean_LocalDecl_fvarId(x_37);
x_44 = l_Lean_Expr_fvar___override(x_43);
x_45 = lean_array_push(x_41, x_44);
x_46 = l_Lean_LocalDecl_type(x_37);
x_47 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_46, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_48 = !lean_is_exclusive(x_47);
if (x_48 == 0)
{
lean_object* x_49; lean_object* x_50; lean_object* x_51; uint8_t x_52; 
x_49 = lean_ctor_get(x_47, 0);
x_50 = lean_ctor_get(x_47, 1);
x_51 = lean_expr_abstract(x_49, x_45);
lean_dec(x_49);
x_52 = l_Lean_Expr_hasMVar(x_51);
if (x_52 == 0)
{
uint8_t x_53; 
x_53 = l_Lean_Expr_hasFVar(x_51);
if (x_53 == 0)
{
lean_object* x_54; lean_object* x_55; 
lean_free_object(x_47);
lean_free_object(x_34);
lean_free_object(x_33);
lean_free_object(x_18);
x_54 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_55 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_51, x_37, x_45, x_1, x_38, x_42, x_54, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_50);
if (lean_obj_tag(x_55) == 0)
{
lean_object* x_56; lean_object* x_57; 
x_56 = lean_ctor_get(x_55, 0);
lean_inc(x_56);
x_57 = lean_ctor_get(x_55, 1);
lean_inc(x_57);
lean_dec(x_55);
x_21 = x_56;
x_22 = x_57;
goto block_31;
}
else
{
uint8_t x_58; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_58 = !lean_is_exclusive(x_55);
if (x_58 == 0)
{
return x_55;
}
else
{
lean_object* x_59; lean_object* x_60; lean_object* x_61; 
x_59 = lean_ctor_get(x_55, 0);
x_60 = lean_ctor_get(x_55, 1);
lean_inc(x_60);
lean_inc(x_59);
lean_dec(x_55);
x_61 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_61, 0, x_59);
lean_ctor_set(x_61, 1, x_60);
return x_61;
}
}
}
else
{
lean_object* x_62; 
lean_dec(x_51);
lean_dec(x_37);
lean_ctor_set(x_34, 0, x_45);
x_62 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
lean_ctor_set(x_47, 1, x_33);
lean_ctor_set(x_47, 0, x_62);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_47);
x_21 = x_18;
x_22 = x_50;
goto block_31;
}
}
else
{
lean_object* x_63; 
lean_dec(x_51);
lean_dec(x_37);
lean_ctor_set(x_34, 0, x_45);
x_63 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
lean_ctor_set(x_47, 1, x_33);
lean_ctor_set(x_47, 0, x_63);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_47);
x_21 = x_18;
x_22 = x_50;
goto block_31;
}
}
else
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; uint8_t x_67; 
x_64 = lean_ctor_get(x_47, 0);
x_65 = lean_ctor_get(x_47, 1);
lean_inc(x_65);
lean_inc(x_64);
lean_dec(x_47);
x_66 = lean_expr_abstract(x_64, x_45);
lean_dec(x_64);
x_67 = l_Lean_Expr_hasMVar(x_66);
if (x_67 == 0)
{
uint8_t x_68; 
x_68 = l_Lean_Expr_hasFVar(x_66);
if (x_68 == 0)
{
lean_object* x_69; lean_object* x_70; 
lean_free_object(x_34);
lean_free_object(x_33);
lean_free_object(x_18);
x_69 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_70 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_66, x_37, x_45, x_1, x_38, x_42, x_69, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_65);
if (lean_obj_tag(x_70) == 0)
{
lean_object* x_71; lean_object* x_72; 
x_71 = lean_ctor_get(x_70, 0);
lean_inc(x_71);
x_72 = lean_ctor_get(x_70, 1);
lean_inc(x_72);
lean_dec(x_70);
x_21 = x_71;
x_22 = x_72;
goto block_31;
}
else
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_73 = lean_ctor_get(x_70, 0);
lean_inc(x_73);
x_74 = lean_ctor_get(x_70, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_70)) {
 lean_ctor_release(x_70, 0);
 lean_ctor_release(x_70, 1);
 x_75 = x_70;
} else {
 lean_dec_ref(x_70);
 x_75 = lean_box(0);
}
if (lean_is_scalar(x_75)) {
 x_76 = lean_alloc_ctor(1, 2, 0);
} else {
 x_76 = x_75;
}
lean_ctor_set(x_76, 0, x_73);
lean_ctor_set(x_76, 1, x_74);
return x_76;
}
}
else
{
lean_object* x_77; lean_object* x_78; 
lean_dec(x_66);
lean_dec(x_37);
lean_ctor_set(x_34, 0, x_45);
x_77 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
x_78 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_78, 0, x_77);
lean_ctor_set(x_78, 1, x_33);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_78);
x_21 = x_18;
x_22 = x_65;
goto block_31;
}
}
else
{
lean_object* x_79; lean_object* x_80; 
lean_dec(x_66);
lean_dec(x_37);
lean_ctor_set(x_34, 0, x_45);
x_79 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
x_80 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_80, 0, x_79);
lean_ctor_set(x_80, 1, x_33);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_80);
x_21 = x_18;
x_22 = x_65;
goto block_31;
}
}
}
else
{
lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; uint8_t x_92; 
x_81 = lean_ctor_get(x_34, 0);
x_82 = lean_ctor_get(x_34, 1);
lean_inc(x_82);
lean_inc(x_81);
lean_dec(x_34);
x_83 = l_Lean_LocalDecl_fvarId(x_37);
x_84 = l_Lean_Expr_fvar___override(x_83);
x_85 = lean_array_push(x_81, x_84);
x_86 = l_Lean_LocalDecl_type(x_37);
x_87 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_86, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_88 = lean_ctor_get(x_87, 0);
lean_inc(x_88);
x_89 = lean_ctor_get(x_87, 1);
lean_inc(x_89);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 lean_ctor_release(x_87, 1);
 x_90 = x_87;
} else {
 lean_dec_ref(x_87);
 x_90 = lean_box(0);
}
x_91 = lean_expr_abstract(x_88, x_85);
lean_dec(x_88);
x_92 = l_Lean_Expr_hasMVar(x_91);
if (x_92 == 0)
{
uint8_t x_93; 
x_93 = l_Lean_Expr_hasFVar(x_91);
if (x_93 == 0)
{
lean_object* x_94; lean_object* x_95; 
lean_dec(x_90);
lean_free_object(x_33);
lean_free_object(x_18);
x_94 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_95 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_91, x_37, x_85, x_1, x_38, x_82, x_94, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_89);
if (lean_obj_tag(x_95) == 0)
{
lean_object* x_96; lean_object* x_97; 
x_96 = lean_ctor_get(x_95, 0);
lean_inc(x_96);
x_97 = lean_ctor_get(x_95, 1);
lean_inc(x_97);
lean_dec(x_95);
x_21 = x_96;
x_22 = x_97;
goto block_31;
}
else
{
lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_98 = lean_ctor_get(x_95, 0);
lean_inc(x_98);
x_99 = lean_ctor_get(x_95, 1);
lean_inc(x_99);
if (lean_is_exclusive(x_95)) {
 lean_ctor_release(x_95, 0);
 lean_ctor_release(x_95, 1);
 x_100 = x_95;
} else {
 lean_dec_ref(x_95);
 x_100 = lean_box(0);
}
if (lean_is_scalar(x_100)) {
 x_101 = lean_alloc_ctor(1, 2, 0);
} else {
 x_101 = x_100;
}
lean_ctor_set(x_101, 0, x_98);
lean_ctor_set(x_101, 1, x_99);
return x_101;
}
}
else
{
lean_object* x_102; lean_object* x_103; lean_object* x_104; 
lean_dec(x_91);
lean_dec(x_37);
x_102 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_102, 0, x_85);
lean_ctor_set(x_102, 1, x_82);
lean_ctor_set(x_33, 1, x_102);
x_103 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_90)) {
 x_104 = lean_alloc_ctor(0, 2, 0);
} else {
 x_104 = x_90;
}
lean_ctor_set(x_104, 0, x_103);
lean_ctor_set(x_104, 1, x_33);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_104);
x_21 = x_18;
x_22 = x_89;
goto block_31;
}
}
else
{
lean_object* x_105; lean_object* x_106; lean_object* x_107; 
lean_dec(x_91);
lean_dec(x_37);
x_105 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_105, 0, x_85);
lean_ctor_set(x_105, 1, x_82);
lean_ctor_set(x_33, 1, x_105);
x_106 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_90)) {
 x_107 = lean_alloc_ctor(0, 2, 0);
} else {
 x_107 = x_90;
}
lean_ctor_set(x_107, 0, x_106);
lean_ctor_set(x_107, 1, x_33);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_107);
x_21 = x_18;
x_22 = x_89;
goto block_31;
}
}
}
else
{
lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; uint8_t x_122; 
x_108 = lean_ctor_get(x_18, 0);
x_109 = lean_ctor_get(x_33, 0);
lean_inc(x_109);
lean_dec(x_33);
x_110 = lean_ctor_get(x_34, 0);
lean_inc(x_110);
x_111 = lean_ctor_get(x_34, 1);
lean_inc(x_111);
if (lean_is_exclusive(x_34)) {
 lean_ctor_release(x_34, 0);
 lean_ctor_release(x_34, 1);
 x_112 = x_34;
} else {
 lean_dec_ref(x_34);
 x_112 = lean_box(0);
}
x_113 = l_Lean_LocalDecl_fvarId(x_108);
x_114 = l_Lean_Expr_fvar___override(x_113);
x_115 = lean_array_push(x_110, x_114);
x_116 = l_Lean_LocalDecl_type(x_108);
x_117 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_116, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_118 = lean_ctor_get(x_117, 0);
lean_inc(x_118);
x_119 = lean_ctor_get(x_117, 1);
lean_inc(x_119);
if (lean_is_exclusive(x_117)) {
 lean_ctor_release(x_117, 0);
 lean_ctor_release(x_117, 1);
 x_120 = x_117;
} else {
 lean_dec_ref(x_117);
 x_120 = lean_box(0);
}
x_121 = lean_expr_abstract(x_118, x_115);
lean_dec(x_118);
x_122 = l_Lean_Expr_hasMVar(x_121);
if (x_122 == 0)
{
uint8_t x_123; 
x_123 = l_Lean_Expr_hasFVar(x_121);
if (x_123 == 0)
{
lean_object* x_124; lean_object* x_125; 
lean_dec(x_120);
lean_dec(x_112);
lean_free_object(x_18);
x_124 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_125 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_121, x_108, x_115, x_1, x_109, x_111, x_124, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_119);
if (lean_obj_tag(x_125) == 0)
{
lean_object* x_126; lean_object* x_127; 
x_126 = lean_ctor_get(x_125, 0);
lean_inc(x_126);
x_127 = lean_ctor_get(x_125, 1);
lean_inc(x_127);
lean_dec(x_125);
x_21 = x_126;
x_22 = x_127;
goto block_31;
}
else
{
lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_128 = lean_ctor_get(x_125, 0);
lean_inc(x_128);
x_129 = lean_ctor_get(x_125, 1);
lean_inc(x_129);
if (lean_is_exclusive(x_125)) {
 lean_ctor_release(x_125, 0);
 lean_ctor_release(x_125, 1);
 x_130 = x_125;
} else {
 lean_dec_ref(x_125);
 x_130 = lean_box(0);
}
if (lean_is_scalar(x_130)) {
 x_131 = lean_alloc_ctor(1, 2, 0);
} else {
 x_131 = x_130;
}
lean_ctor_set(x_131, 0, x_128);
lean_ctor_set(x_131, 1, x_129);
return x_131;
}
}
else
{
lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; 
lean_dec(x_121);
lean_dec(x_108);
if (lean_is_scalar(x_112)) {
 x_132 = lean_alloc_ctor(0, 2, 0);
} else {
 x_132 = x_112;
}
lean_ctor_set(x_132, 0, x_115);
lean_ctor_set(x_132, 1, x_111);
x_133 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_133, 0, x_109);
lean_ctor_set(x_133, 1, x_132);
x_134 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_120)) {
 x_135 = lean_alloc_ctor(0, 2, 0);
} else {
 x_135 = x_120;
}
lean_ctor_set(x_135, 0, x_134);
lean_ctor_set(x_135, 1, x_133);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_135);
x_21 = x_18;
x_22 = x_119;
goto block_31;
}
}
else
{
lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; 
lean_dec(x_121);
lean_dec(x_108);
if (lean_is_scalar(x_112)) {
 x_136 = lean_alloc_ctor(0, 2, 0);
} else {
 x_136 = x_112;
}
lean_ctor_set(x_136, 0, x_115);
lean_ctor_set(x_136, 1, x_111);
x_137 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_137, 0, x_109);
lean_ctor_set(x_137, 1, x_136);
x_138 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_120)) {
 x_139 = lean_alloc_ctor(0, 2, 0);
} else {
 x_139 = x_120;
}
lean_ctor_set(x_139, 0, x_138);
lean_ctor_set(x_139, 1, x_137);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_139);
x_21 = x_18;
x_22 = x_119;
goto block_31;
}
}
}
else
{
lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; lean_object* x_148; lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; uint8_t x_155; 
x_140 = lean_ctor_get(x_18, 0);
lean_inc(x_140);
lean_dec(x_18);
x_141 = lean_ctor_get(x_33, 0);
lean_inc(x_141);
if (lean_is_exclusive(x_33)) {
 lean_ctor_release(x_33, 0);
 lean_ctor_release(x_33, 1);
 x_142 = x_33;
} else {
 lean_dec_ref(x_33);
 x_142 = lean_box(0);
}
x_143 = lean_ctor_get(x_34, 0);
lean_inc(x_143);
x_144 = lean_ctor_get(x_34, 1);
lean_inc(x_144);
if (lean_is_exclusive(x_34)) {
 lean_ctor_release(x_34, 0);
 lean_ctor_release(x_34, 1);
 x_145 = x_34;
} else {
 lean_dec_ref(x_34);
 x_145 = lean_box(0);
}
x_146 = l_Lean_LocalDecl_fvarId(x_140);
x_147 = l_Lean_Expr_fvar___override(x_146);
x_148 = lean_array_push(x_143, x_147);
x_149 = l_Lean_LocalDecl_type(x_140);
x_150 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_149, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_151 = lean_ctor_get(x_150, 0);
lean_inc(x_151);
x_152 = lean_ctor_get(x_150, 1);
lean_inc(x_152);
if (lean_is_exclusive(x_150)) {
 lean_ctor_release(x_150, 0);
 lean_ctor_release(x_150, 1);
 x_153 = x_150;
} else {
 lean_dec_ref(x_150);
 x_153 = lean_box(0);
}
x_154 = lean_expr_abstract(x_151, x_148);
lean_dec(x_151);
x_155 = l_Lean_Expr_hasMVar(x_154);
if (x_155 == 0)
{
uint8_t x_156; 
x_156 = l_Lean_Expr_hasFVar(x_154);
if (x_156 == 0)
{
lean_object* x_157; lean_object* x_158; 
lean_dec(x_153);
lean_dec(x_145);
lean_dec(x_142);
x_157 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_158 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_154, x_140, x_148, x_1, x_141, x_144, x_157, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_152);
if (lean_obj_tag(x_158) == 0)
{
lean_object* x_159; lean_object* x_160; 
x_159 = lean_ctor_get(x_158, 0);
lean_inc(x_159);
x_160 = lean_ctor_get(x_158, 1);
lean_inc(x_160);
lean_dec(x_158);
x_21 = x_159;
x_22 = x_160;
goto block_31;
}
else
{
lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_161 = lean_ctor_get(x_158, 0);
lean_inc(x_161);
x_162 = lean_ctor_get(x_158, 1);
lean_inc(x_162);
if (lean_is_exclusive(x_158)) {
 lean_ctor_release(x_158, 0);
 lean_ctor_release(x_158, 1);
 x_163 = x_158;
} else {
 lean_dec_ref(x_158);
 x_163 = lean_box(0);
}
if (lean_is_scalar(x_163)) {
 x_164 = lean_alloc_ctor(1, 2, 0);
} else {
 x_164 = x_163;
}
lean_ctor_set(x_164, 0, x_161);
lean_ctor_set(x_164, 1, x_162);
return x_164;
}
}
else
{
lean_object* x_165; lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; 
lean_dec(x_154);
lean_dec(x_140);
if (lean_is_scalar(x_145)) {
 x_165 = lean_alloc_ctor(0, 2, 0);
} else {
 x_165 = x_145;
}
lean_ctor_set(x_165, 0, x_148);
lean_ctor_set(x_165, 1, x_144);
if (lean_is_scalar(x_142)) {
 x_166 = lean_alloc_ctor(0, 2, 0);
} else {
 x_166 = x_142;
}
lean_ctor_set(x_166, 0, x_141);
lean_ctor_set(x_166, 1, x_165);
x_167 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_153)) {
 x_168 = lean_alloc_ctor(0, 2, 0);
} else {
 x_168 = x_153;
}
lean_ctor_set(x_168, 0, x_167);
lean_ctor_set(x_168, 1, x_166);
x_169 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_169, 0, x_168);
x_21 = x_169;
x_22 = x_152;
goto block_31;
}
}
else
{
lean_object* x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; 
lean_dec(x_154);
lean_dec(x_140);
if (lean_is_scalar(x_145)) {
 x_170 = lean_alloc_ctor(0, 2, 0);
} else {
 x_170 = x_145;
}
lean_ctor_set(x_170, 0, x_148);
lean_ctor_set(x_170, 1, x_144);
if (lean_is_scalar(x_142)) {
 x_171 = lean_alloc_ctor(0, 2, 0);
} else {
 x_171 = x_142;
}
lean_ctor_set(x_171, 0, x_141);
lean_ctor_set(x_171, 1, x_170);
x_172 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_153)) {
 x_173 = lean_alloc_ctor(0, 2, 0);
} else {
 x_173 = x_153;
}
lean_ctor_set(x_173, 0, x_172);
lean_ctor_set(x_173, 1, x_171);
x_174 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_174, 0, x_173);
x_21 = x_174;
x_22 = x_152;
goto block_31;
}
}
}
block_31:
{
if (lean_obj_tag(x_21) == 0)
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; 
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_23 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_23, 0, x_21);
if (lean_is_scalar(x_20)) {
 x_24 = lean_alloc_ctor(0, 2, 0);
} else {
 x_24 = x_20;
}
lean_ctor_set(x_24, 0, x_23);
lean_ctor_set(x_24, 1, x_19);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_22);
return x_25;
}
else
{
lean_object* x_26; lean_object* x_27; size_t x_28; size_t x_29; 
lean_dec(x_19);
x_26 = lean_ctor_get(x_21, 0);
lean_inc(x_26);
lean_dec(x_21);
lean_inc(x_2);
if (lean_is_scalar(x_20)) {
 x_27 = lean_alloc_ctor(0, 2, 0);
} else {
 x_27 = x_20;
}
lean_ctor_set(x_27, 0, x_2);
lean_ctor_set(x_27, 1, x_26);
x_28 = 1;
x_29 = lean_usize_add(x_5, x_28);
x_5 = x_29;
x_6 = x_27;
x_15 = x_22;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_12, 0, x_1);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_11);
return x_13;
}
}
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; size_t x_18; size_t x_19; lean_object* x_20; 
x_14 = lean_ctor_get(x_3, 0);
lean_inc(x_14);
lean_dec(x_3);
x_15 = lean_box(0);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_4);
x_17 = lean_array_get_size(x_14);
x_18 = lean_usize_of_nat(x_17);
lean_dec(x_17);
x_19 = 0;
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
x_20 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__4(x_1, x_2, x_15, x_14, x_18, x_19, x_16, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
lean_dec(x_14);
if (lean_obj_tag(x_20) == 0)
{
lean_object* x_21; lean_object* x_22; 
x_21 = lean_ctor_get(x_20, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_21, 0);
lean_inc(x_22);
if (lean_obj_tag(x_22) == 0)
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_23 = lean_ctor_get(x_20, 1);
lean_inc(x_23);
lean_dec(x_20);
x_24 = lean_ctor_get(x_21, 1);
lean_inc(x_24);
lean_dec(x_21);
x_25 = lean_box(0);
x_26 = l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3___lambda__1(x_24, x_25, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_23);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
return x_26;
}
else
{
uint8_t x_27; 
lean_dec(x_21);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_27 = !lean_is_exclusive(x_20);
if (x_27 == 0)
{
lean_object* x_28; lean_object* x_29; 
x_28 = lean_ctor_get(x_20, 0);
lean_dec(x_28);
x_29 = lean_ctor_get(x_22, 0);
lean_inc(x_29);
lean_dec(x_22);
lean_ctor_set(x_20, 0, x_29);
return x_20;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_20, 1);
lean_inc(x_30);
lean_dec(x_20);
x_31 = lean_ctor_get(x_22, 0);
lean_inc(x_31);
lean_dec(x_22);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_30);
return x_32;
}
}
}
else
{
uint8_t x_33; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_33 = !lean_is_exclusive(x_20);
if (x_33 == 0)
{
return x_20;
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_34 = lean_ctor_get(x_20, 0);
x_35 = lean_ctor_get(x_20, 1);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_20);
x_36 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_36, 0, x_34);
lean_ctor_set(x_36, 1, x_35);
return x_36;
}
}
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; size_t x_41; size_t x_42; lean_object* x_43; 
lean_dec(x_2);
x_37 = lean_ctor_get(x_3, 0);
lean_inc(x_37);
lean_dec(x_3);
x_38 = lean_box(0);
x_39 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_4);
x_40 = lean_array_get_size(x_37);
x_41 = lean_usize_of_nat(x_40);
lean_dec(x_40);
x_42 = 0;
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
x_43 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5(x_1, x_38, x_37, x_41, x_42, x_39, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
lean_dec(x_37);
if (lean_obj_tag(x_43) == 0)
{
lean_object* x_44; lean_object* x_45; 
x_44 = lean_ctor_get(x_43, 0);
lean_inc(x_44);
x_45 = lean_ctor_get(x_44, 0);
lean_inc(x_45);
if (lean_obj_tag(x_45) == 0)
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_46 = lean_ctor_get(x_43, 1);
lean_inc(x_46);
lean_dec(x_43);
x_47 = lean_ctor_get(x_44, 1);
lean_inc(x_47);
lean_dec(x_44);
x_48 = lean_box(0);
x_49 = l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3___lambda__1(x_47, x_48, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_46);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
return x_49;
}
else
{
uint8_t x_50; 
lean_dec(x_44);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_50 = !lean_is_exclusive(x_43);
if (x_50 == 0)
{
lean_object* x_51; lean_object* x_52; 
x_51 = lean_ctor_get(x_43, 0);
lean_dec(x_51);
x_52 = lean_ctor_get(x_45, 0);
lean_inc(x_52);
lean_dec(x_45);
lean_ctor_set(x_43, 0, x_52);
return x_43;
}
else
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_53 = lean_ctor_get(x_43, 1);
lean_inc(x_53);
lean_dec(x_43);
x_54 = lean_ctor_get(x_45, 0);
lean_inc(x_54);
lean_dec(x_45);
x_55 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_55, 0, x_54);
lean_ctor_set(x_55, 1, x_53);
return x_55;
}
}
}
else
{
uint8_t x_56; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
x_56 = !lean_is_exclusive(x_43);
if (x_56 == 0)
{
return x_43;
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_57 = lean_ctor_get(x_43, 0);
x_58 = lean_ctor_get(x_43, 1);
lean_inc(x_58);
lean_inc(x_57);
lean_dec(x_43);
x_59 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_59, 0, x_57);
lean_ctor_set(x_59, 1, x_58);
return x_59;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__6(lean_object* x_1, lean_object* x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
uint8_t x_16; 
x_16 = lean_usize_dec_lt(x_5, x_4);
if (x_16 == 0)
{
lean_object* x_17; 
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_6);
lean_ctor_set(x_17, 1, x_15);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_18 = lean_array_uget(x_3, x_5);
x_19 = lean_ctor_get(x_6, 1);
lean_inc(x_19);
if (lean_is_exclusive(x_6)) {
 lean_ctor_release(x_6, 0);
 lean_ctor_release(x_6, 1);
 x_20 = x_6;
} else {
 lean_dec_ref(x_6);
 x_20 = lean_box(0);
}
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_36; 
lean_inc(x_19);
x_36 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_36, 0, x_19);
x_21 = x_36;
x_22 = x_15;
goto block_35;
}
else
{
lean_object* x_37; lean_object* x_38; uint8_t x_39; 
x_37 = lean_ctor_get(x_19, 1);
lean_inc(x_37);
x_38 = lean_ctor_get(x_37, 1);
lean_inc(x_38);
x_39 = !lean_is_exclusive(x_18);
if (x_39 == 0)
{
uint8_t x_40; 
x_40 = !lean_is_exclusive(x_37);
if (x_40 == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; uint8_t x_44; 
x_41 = lean_ctor_get(x_18, 0);
x_42 = lean_ctor_get(x_37, 0);
x_43 = lean_ctor_get(x_37, 1);
lean_dec(x_43);
x_44 = !lean_is_exclusive(x_38);
if (x_44 == 0)
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; uint8_t x_52; 
x_45 = lean_ctor_get(x_38, 0);
x_46 = lean_ctor_get(x_38, 1);
x_47 = l_Lean_LocalDecl_fvarId(x_41);
x_48 = l_Lean_Expr_fvar___override(x_47);
x_49 = lean_array_push(x_45, x_48);
x_50 = l_Lean_LocalDecl_type(x_41);
x_51 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_50, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_52 = !lean_is_exclusive(x_51);
if (x_52 == 0)
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; uint8_t x_56; 
x_53 = lean_ctor_get(x_51, 0);
x_54 = lean_ctor_get(x_51, 1);
x_55 = lean_expr_abstract(x_53, x_49);
lean_dec(x_53);
x_56 = l_Lean_Expr_hasMVar(x_55);
if (x_56 == 0)
{
uint8_t x_57; 
x_57 = l_Lean_Expr_hasFVar(x_55);
if (x_57 == 0)
{
lean_object* x_58; lean_object* x_59; 
lean_free_object(x_51);
lean_free_object(x_38);
lean_free_object(x_37);
lean_free_object(x_18);
x_58 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_59 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_55, x_41, x_49, x_1, x_42, x_46, x_58, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_54);
if (lean_obj_tag(x_59) == 0)
{
lean_object* x_60; lean_object* x_61; 
x_60 = lean_ctor_get(x_59, 0);
lean_inc(x_60);
x_61 = lean_ctor_get(x_59, 1);
lean_inc(x_61);
lean_dec(x_59);
x_21 = x_60;
x_22 = x_61;
goto block_35;
}
else
{
uint8_t x_62; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_62 = !lean_is_exclusive(x_59);
if (x_62 == 0)
{
return x_59;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; 
x_63 = lean_ctor_get(x_59, 0);
x_64 = lean_ctor_get(x_59, 1);
lean_inc(x_64);
lean_inc(x_63);
lean_dec(x_59);
x_65 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_65, 0, x_63);
lean_ctor_set(x_65, 1, x_64);
return x_65;
}
}
}
else
{
lean_object* x_66; 
lean_dec(x_55);
lean_dec(x_41);
lean_ctor_set(x_38, 0, x_49);
x_66 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
lean_ctor_set(x_51, 1, x_37);
lean_ctor_set(x_51, 0, x_66);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_51);
x_21 = x_18;
x_22 = x_54;
goto block_35;
}
}
else
{
lean_object* x_67; 
lean_dec(x_55);
lean_dec(x_41);
lean_ctor_set(x_38, 0, x_49);
x_67 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
lean_ctor_set(x_51, 1, x_37);
lean_ctor_set(x_51, 0, x_67);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_51);
x_21 = x_18;
x_22 = x_54;
goto block_35;
}
}
else
{
lean_object* x_68; lean_object* x_69; lean_object* x_70; uint8_t x_71; 
x_68 = lean_ctor_get(x_51, 0);
x_69 = lean_ctor_get(x_51, 1);
lean_inc(x_69);
lean_inc(x_68);
lean_dec(x_51);
x_70 = lean_expr_abstract(x_68, x_49);
lean_dec(x_68);
x_71 = l_Lean_Expr_hasMVar(x_70);
if (x_71 == 0)
{
uint8_t x_72; 
x_72 = l_Lean_Expr_hasFVar(x_70);
if (x_72 == 0)
{
lean_object* x_73; lean_object* x_74; 
lean_free_object(x_38);
lean_free_object(x_37);
lean_free_object(x_18);
x_73 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_74 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_70, x_41, x_49, x_1, x_42, x_46, x_73, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_69);
if (lean_obj_tag(x_74) == 0)
{
lean_object* x_75; lean_object* x_76; 
x_75 = lean_ctor_get(x_74, 0);
lean_inc(x_75);
x_76 = lean_ctor_get(x_74, 1);
lean_inc(x_76);
lean_dec(x_74);
x_21 = x_75;
x_22 = x_76;
goto block_35;
}
else
{
lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_77 = lean_ctor_get(x_74, 0);
lean_inc(x_77);
x_78 = lean_ctor_get(x_74, 1);
lean_inc(x_78);
if (lean_is_exclusive(x_74)) {
 lean_ctor_release(x_74, 0);
 lean_ctor_release(x_74, 1);
 x_79 = x_74;
} else {
 lean_dec_ref(x_74);
 x_79 = lean_box(0);
}
if (lean_is_scalar(x_79)) {
 x_80 = lean_alloc_ctor(1, 2, 0);
} else {
 x_80 = x_79;
}
lean_ctor_set(x_80, 0, x_77);
lean_ctor_set(x_80, 1, x_78);
return x_80;
}
}
else
{
lean_object* x_81; lean_object* x_82; 
lean_dec(x_70);
lean_dec(x_41);
lean_ctor_set(x_38, 0, x_49);
x_81 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
x_82 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_82, 0, x_81);
lean_ctor_set(x_82, 1, x_37);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_82);
x_21 = x_18;
x_22 = x_69;
goto block_35;
}
}
else
{
lean_object* x_83; lean_object* x_84; 
lean_dec(x_70);
lean_dec(x_41);
lean_ctor_set(x_38, 0, x_49);
x_83 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
x_84 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_84, 0, x_83);
lean_ctor_set(x_84, 1, x_37);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_84);
x_21 = x_18;
x_22 = x_69;
goto block_35;
}
}
}
else
{
lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; uint8_t x_96; 
x_85 = lean_ctor_get(x_38, 0);
x_86 = lean_ctor_get(x_38, 1);
lean_inc(x_86);
lean_inc(x_85);
lean_dec(x_38);
x_87 = l_Lean_LocalDecl_fvarId(x_41);
x_88 = l_Lean_Expr_fvar___override(x_87);
x_89 = lean_array_push(x_85, x_88);
x_90 = l_Lean_LocalDecl_type(x_41);
x_91 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_90, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_92 = lean_ctor_get(x_91, 0);
lean_inc(x_92);
x_93 = lean_ctor_get(x_91, 1);
lean_inc(x_93);
if (lean_is_exclusive(x_91)) {
 lean_ctor_release(x_91, 0);
 lean_ctor_release(x_91, 1);
 x_94 = x_91;
} else {
 lean_dec_ref(x_91);
 x_94 = lean_box(0);
}
x_95 = lean_expr_abstract(x_92, x_89);
lean_dec(x_92);
x_96 = l_Lean_Expr_hasMVar(x_95);
if (x_96 == 0)
{
uint8_t x_97; 
x_97 = l_Lean_Expr_hasFVar(x_95);
if (x_97 == 0)
{
lean_object* x_98; lean_object* x_99; 
lean_dec(x_94);
lean_free_object(x_37);
lean_free_object(x_18);
x_98 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_99 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_95, x_41, x_89, x_1, x_42, x_86, x_98, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_93);
if (lean_obj_tag(x_99) == 0)
{
lean_object* x_100; lean_object* x_101; 
x_100 = lean_ctor_get(x_99, 0);
lean_inc(x_100);
x_101 = lean_ctor_get(x_99, 1);
lean_inc(x_101);
lean_dec(x_99);
x_21 = x_100;
x_22 = x_101;
goto block_35;
}
else
{
lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_102 = lean_ctor_get(x_99, 0);
lean_inc(x_102);
x_103 = lean_ctor_get(x_99, 1);
lean_inc(x_103);
if (lean_is_exclusive(x_99)) {
 lean_ctor_release(x_99, 0);
 lean_ctor_release(x_99, 1);
 x_104 = x_99;
} else {
 lean_dec_ref(x_99);
 x_104 = lean_box(0);
}
if (lean_is_scalar(x_104)) {
 x_105 = lean_alloc_ctor(1, 2, 0);
} else {
 x_105 = x_104;
}
lean_ctor_set(x_105, 0, x_102);
lean_ctor_set(x_105, 1, x_103);
return x_105;
}
}
else
{
lean_object* x_106; lean_object* x_107; lean_object* x_108; 
lean_dec(x_95);
lean_dec(x_41);
x_106 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_106, 0, x_89);
lean_ctor_set(x_106, 1, x_86);
lean_ctor_set(x_37, 1, x_106);
x_107 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_94)) {
 x_108 = lean_alloc_ctor(0, 2, 0);
} else {
 x_108 = x_94;
}
lean_ctor_set(x_108, 0, x_107);
lean_ctor_set(x_108, 1, x_37);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_108);
x_21 = x_18;
x_22 = x_93;
goto block_35;
}
}
else
{
lean_object* x_109; lean_object* x_110; lean_object* x_111; 
lean_dec(x_95);
lean_dec(x_41);
x_109 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_109, 0, x_89);
lean_ctor_set(x_109, 1, x_86);
lean_ctor_set(x_37, 1, x_109);
x_110 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_94)) {
 x_111 = lean_alloc_ctor(0, 2, 0);
} else {
 x_111 = x_94;
}
lean_ctor_set(x_111, 0, x_110);
lean_ctor_set(x_111, 1, x_37);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_111);
x_21 = x_18;
x_22 = x_93;
goto block_35;
}
}
}
else
{
lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; uint8_t x_126; 
x_112 = lean_ctor_get(x_18, 0);
x_113 = lean_ctor_get(x_37, 0);
lean_inc(x_113);
lean_dec(x_37);
x_114 = lean_ctor_get(x_38, 0);
lean_inc(x_114);
x_115 = lean_ctor_get(x_38, 1);
lean_inc(x_115);
if (lean_is_exclusive(x_38)) {
 lean_ctor_release(x_38, 0);
 lean_ctor_release(x_38, 1);
 x_116 = x_38;
} else {
 lean_dec_ref(x_38);
 x_116 = lean_box(0);
}
x_117 = l_Lean_LocalDecl_fvarId(x_112);
x_118 = l_Lean_Expr_fvar___override(x_117);
x_119 = lean_array_push(x_114, x_118);
x_120 = l_Lean_LocalDecl_type(x_112);
x_121 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_120, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_122 = lean_ctor_get(x_121, 0);
lean_inc(x_122);
x_123 = lean_ctor_get(x_121, 1);
lean_inc(x_123);
if (lean_is_exclusive(x_121)) {
 lean_ctor_release(x_121, 0);
 lean_ctor_release(x_121, 1);
 x_124 = x_121;
} else {
 lean_dec_ref(x_121);
 x_124 = lean_box(0);
}
x_125 = lean_expr_abstract(x_122, x_119);
lean_dec(x_122);
x_126 = l_Lean_Expr_hasMVar(x_125);
if (x_126 == 0)
{
uint8_t x_127; 
x_127 = l_Lean_Expr_hasFVar(x_125);
if (x_127 == 0)
{
lean_object* x_128; lean_object* x_129; 
lean_dec(x_124);
lean_dec(x_116);
lean_free_object(x_18);
x_128 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_129 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_125, x_112, x_119, x_1, x_113, x_115, x_128, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_123);
if (lean_obj_tag(x_129) == 0)
{
lean_object* x_130; lean_object* x_131; 
x_130 = lean_ctor_get(x_129, 0);
lean_inc(x_130);
x_131 = lean_ctor_get(x_129, 1);
lean_inc(x_131);
lean_dec(x_129);
x_21 = x_130;
x_22 = x_131;
goto block_35;
}
else
{
lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_132 = lean_ctor_get(x_129, 0);
lean_inc(x_132);
x_133 = lean_ctor_get(x_129, 1);
lean_inc(x_133);
if (lean_is_exclusive(x_129)) {
 lean_ctor_release(x_129, 0);
 lean_ctor_release(x_129, 1);
 x_134 = x_129;
} else {
 lean_dec_ref(x_129);
 x_134 = lean_box(0);
}
if (lean_is_scalar(x_134)) {
 x_135 = lean_alloc_ctor(1, 2, 0);
} else {
 x_135 = x_134;
}
lean_ctor_set(x_135, 0, x_132);
lean_ctor_set(x_135, 1, x_133);
return x_135;
}
}
else
{
lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; 
lean_dec(x_125);
lean_dec(x_112);
if (lean_is_scalar(x_116)) {
 x_136 = lean_alloc_ctor(0, 2, 0);
} else {
 x_136 = x_116;
}
lean_ctor_set(x_136, 0, x_119);
lean_ctor_set(x_136, 1, x_115);
x_137 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_137, 0, x_113);
lean_ctor_set(x_137, 1, x_136);
x_138 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_124)) {
 x_139 = lean_alloc_ctor(0, 2, 0);
} else {
 x_139 = x_124;
}
lean_ctor_set(x_139, 0, x_138);
lean_ctor_set(x_139, 1, x_137);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_139);
x_21 = x_18;
x_22 = x_123;
goto block_35;
}
}
else
{
lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; 
lean_dec(x_125);
lean_dec(x_112);
if (lean_is_scalar(x_116)) {
 x_140 = lean_alloc_ctor(0, 2, 0);
} else {
 x_140 = x_116;
}
lean_ctor_set(x_140, 0, x_119);
lean_ctor_set(x_140, 1, x_115);
x_141 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_141, 0, x_113);
lean_ctor_set(x_141, 1, x_140);
x_142 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_124)) {
 x_143 = lean_alloc_ctor(0, 2, 0);
} else {
 x_143 = x_124;
}
lean_ctor_set(x_143, 0, x_142);
lean_ctor_set(x_143, 1, x_141);
lean_ctor_set_tag(x_18, 0);
lean_ctor_set(x_18, 0, x_143);
x_21 = x_18;
x_22 = x_123;
goto block_35;
}
}
}
else
{
lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; lean_object* x_148; lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; uint8_t x_159; 
x_144 = lean_ctor_get(x_18, 0);
lean_inc(x_144);
lean_dec(x_18);
x_145 = lean_ctor_get(x_37, 0);
lean_inc(x_145);
if (lean_is_exclusive(x_37)) {
 lean_ctor_release(x_37, 0);
 lean_ctor_release(x_37, 1);
 x_146 = x_37;
} else {
 lean_dec_ref(x_37);
 x_146 = lean_box(0);
}
x_147 = lean_ctor_get(x_38, 0);
lean_inc(x_147);
x_148 = lean_ctor_get(x_38, 1);
lean_inc(x_148);
if (lean_is_exclusive(x_38)) {
 lean_ctor_release(x_38, 0);
 lean_ctor_release(x_38, 1);
 x_149 = x_38;
} else {
 lean_dec_ref(x_38);
 x_149 = lean_box(0);
}
x_150 = l_Lean_LocalDecl_fvarId(x_144);
x_151 = l_Lean_Expr_fvar___override(x_150);
x_152 = lean_array_push(x_147, x_151);
x_153 = l_Lean_LocalDecl_type(x_144);
x_154 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_153, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_155 = lean_ctor_get(x_154, 0);
lean_inc(x_155);
x_156 = lean_ctor_get(x_154, 1);
lean_inc(x_156);
if (lean_is_exclusive(x_154)) {
 lean_ctor_release(x_154, 0);
 lean_ctor_release(x_154, 1);
 x_157 = x_154;
} else {
 lean_dec_ref(x_154);
 x_157 = lean_box(0);
}
x_158 = lean_expr_abstract(x_155, x_152);
lean_dec(x_155);
x_159 = l_Lean_Expr_hasMVar(x_158);
if (x_159 == 0)
{
uint8_t x_160; 
x_160 = l_Lean_Expr_hasFVar(x_158);
if (x_160 == 0)
{
lean_object* x_161; lean_object* x_162; 
lean_dec(x_157);
lean_dec(x_149);
lean_dec(x_146);
x_161 = lean_box(0);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_1);
x_162 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3(x_158, x_144, x_152, x_1, x_145, x_148, x_161, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_156);
if (lean_obj_tag(x_162) == 0)
{
lean_object* x_163; lean_object* x_164; 
x_163 = lean_ctor_get(x_162, 0);
lean_inc(x_163);
x_164 = lean_ctor_get(x_162, 1);
lean_inc(x_164);
lean_dec(x_162);
x_21 = x_163;
x_22 = x_164;
goto block_35;
}
else
{
lean_object* x_165; lean_object* x_166; lean_object* x_167; lean_object* x_168; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_165 = lean_ctor_get(x_162, 0);
lean_inc(x_165);
x_166 = lean_ctor_get(x_162, 1);
lean_inc(x_166);
if (lean_is_exclusive(x_162)) {
 lean_ctor_release(x_162, 0);
 lean_ctor_release(x_162, 1);
 x_167 = x_162;
} else {
 lean_dec_ref(x_162);
 x_167 = lean_box(0);
}
if (lean_is_scalar(x_167)) {
 x_168 = lean_alloc_ctor(1, 2, 0);
} else {
 x_168 = x_167;
}
lean_ctor_set(x_168, 0, x_165);
lean_ctor_set(x_168, 1, x_166);
return x_168;
}
}
else
{
lean_object* x_169; lean_object* x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; 
lean_dec(x_158);
lean_dec(x_144);
if (lean_is_scalar(x_149)) {
 x_169 = lean_alloc_ctor(0, 2, 0);
} else {
 x_169 = x_149;
}
lean_ctor_set(x_169, 0, x_152);
lean_ctor_set(x_169, 1, x_148);
if (lean_is_scalar(x_146)) {
 x_170 = lean_alloc_ctor(0, 2, 0);
} else {
 x_170 = x_146;
}
lean_ctor_set(x_170, 0, x_145);
lean_ctor_set(x_170, 1, x_169);
x_171 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_157)) {
 x_172 = lean_alloc_ctor(0, 2, 0);
} else {
 x_172 = x_157;
}
lean_ctor_set(x_172, 0, x_171);
lean_ctor_set(x_172, 1, x_170);
x_173 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_173, 0, x_172);
x_21 = x_173;
x_22 = x_156;
goto block_35;
}
}
else
{
lean_object* x_174; lean_object* x_175; lean_object* x_176; lean_object* x_177; lean_object* x_178; 
lean_dec(x_158);
lean_dec(x_144);
if (lean_is_scalar(x_149)) {
 x_174 = lean_alloc_ctor(0, 2, 0);
} else {
 x_174 = x_149;
}
lean_ctor_set(x_174, 0, x_152);
lean_ctor_set(x_174, 1, x_148);
if (lean_is_scalar(x_146)) {
 x_175 = lean_alloc_ctor(0, 2, 0);
} else {
 x_175 = x_146;
}
lean_ctor_set(x_175, 0, x_145);
lean_ctor_set(x_175, 1, x_174);
x_176 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3;
if (lean_is_scalar(x_157)) {
 x_177 = lean_alloc_ctor(0, 2, 0);
} else {
 x_177 = x_157;
}
lean_ctor_set(x_177, 0, x_176);
lean_ctor_set(x_177, 1, x_175);
x_178 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_178, 0, x_177);
x_21 = x_178;
x_22 = x_156;
goto block_35;
}
}
}
block_35:
{
if (lean_obj_tag(x_21) == 0)
{
uint8_t x_23; 
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_23 = !lean_is_exclusive(x_21);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; 
lean_ctor_set_tag(x_21, 1);
if (lean_is_scalar(x_20)) {
 x_24 = lean_alloc_ctor(0, 2, 0);
} else {
 x_24 = x_20;
}
lean_ctor_set(x_24, 0, x_21);
lean_ctor_set(x_24, 1, x_19);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_22);
return x_25;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_26 = lean_ctor_get(x_21, 0);
lean_inc(x_26);
lean_dec(x_21);
x_27 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_27, 0, x_26);
if (lean_is_scalar(x_20)) {
 x_28 = lean_alloc_ctor(0, 2, 0);
} else {
 x_28 = x_20;
}
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_19);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_22);
return x_29;
}
}
else
{
lean_object* x_30; lean_object* x_31; size_t x_32; size_t x_33; 
lean_dec(x_19);
x_30 = lean_ctor_get(x_21, 0);
lean_inc(x_30);
lean_dec(x_21);
lean_inc(x_2);
if (lean_is_scalar(x_20)) {
 x_31 = lean_alloc_ctor(0, 2, 0);
} else {
 x_31 = x_20;
}
lean_ctor_set(x_31, 0, x_2);
lean_ctor_set(x_31, 1, x_30);
x_32 = 1;
x_33 = lean_usize_add(x_5, x_32);
x_5 = x_33;
x_6 = x_31;
x_15 = x_22;
goto _start;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; 
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_1);
lean_ctor_set(x_12, 1, x_11);
return x_12;
}
}
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_ctor_get(x_2, 0);
lean_inc(x_13);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_1);
x_14 = l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3(x_1, x_3, x_13, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; 
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
if (lean_obj_tag(x_15) == 0)
{
uint8_t x_16; 
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
lean_dec(x_1);
x_16 = !lean_is_exclusive(x_14);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; 
x_17 = lean_ctor_get(x_14, 0);
lean_dec(x_17);
x_18 = lean_ctor_get(x_15, 0);
lean_inc(x_18);
lean_dec(x_15);
lean_ctor_set(x_14, 0, x_18);
return x_14;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_14, 1);
lean_inc(x_19);
lean_dec(x_14);
x_20 = lean_ctor_get(x_15, 0);
lean_inc(x_20);
lean_dec(x_15);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_19);
return x_21;
}
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; size_t x_28; size_t x_29; lean_object* x_30; 
x_22 = lean_ctor_get(x_14, 1);
lean_inc(x_22);
lean_dec(x_14);
x_23 = lean_ctor_get(x_15, 0);
lean_inc(x_23);
lean_dec(x_15);
x_24 = lean_ctor_get(x_2, 1);
lean_inc(x_24);
lean_dec(x_2);
x_25 = lean_box(0);
x_26 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_26, 0, x_25);
lean_ctor_set(x_26, 1, x_23);
x_27 = lean_array_get_size(x_24);
x_28 = lean_usize_of_nat(x_27);
lean_dec(x_27);
x_29 = 0;
x_30 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__6(x_1, x_25, x_24, x_28, x_29, x_26, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_22);
lean_dec(x_24);
if (lean_obj_tag(x_30) == 0)
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_ctor_get(x_30, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
if (lean_obj_tag(x_32) == 0)
{
uint8_t x_33; 
x_33 = !lean_is_exclusive(x_30);
if (x_33 == 0)
{
lean_object* x_34; lean_object* x_35; 
x_34 = lean_ctor_get(x_30, 0);
lean_dec(x_34);
x_35 = lean_ctor_get(x_31, 1);
lean_inc(x_35);
lean_dec(x_31);
lean_ctor_set(x_30, 0, x_35);
return x_30;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_36 = lean_ctor_get(x_30, 1);
lean_inc(x_36);
lean_dec(x_30);
x_37 = lean_ctor_get(x_31, 1);
lean_inc(x_37);
lean_dec(x_31);
x_38 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_38, 0, x_37);
lean_ctor_set(x_38, 1, x_36);
return x_38;
}
}
else
{
uint8_t x_39; 
lean_dec(x_31);
x_39 = !lean_is_exclusive(x_30);
if (x_39 == 0)
{
lean_object* x_40; lean_object* x_41; 
x_40 = lean_ctor_get(x_30, 0);
lean_dec(x_40);
x_41 = lean_ctor_get(x_32, 0);
lean_inc(x_41);
lean_dec(x_32);
lean_ctor_set(x_30, 0, x_41);
return x_30;
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; 
x_42 = lean_ctor_get(x_30, 1);
lean_inc(x_42);
lean_dec(x_30);
x_43 = lean_ctor_get(x_32, 0);
lean_inc(x_43);
lean_dec(x_32);
x_44 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_44, 0, x_43);
lean_ctor_set(x_44, 1, x_42);
return x_44;
}
}
}
else
{
uint8_t x_45; 
x_45 = !lean_is_exclusive(x_30);
if (x_45 == 0)
{
return x_30;
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_46 = lean_ctor_get(x_30, 0);
x_47 = lean_ctor_get(x_30, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_30);
x_48 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_48, 0, x_46);
lean_ctor_set(x_48, 1, x_47);
return x_48;
}
}
}
}
else
{
uint8_t x_49; 
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
lean_dec(x_1);
x_49 = !lean_is_exclusive(x_14);
if (x_49 == 0)
{
return x_14;
}
else
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_50 = lean_ctor_get(x_14, 0);
x_51 = lean_ctor_get(x_14, 1);
lean_inc(x_51);
lean_inc(x_50);
lean_dec(x_14);
x_52 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_52, 0, x_50);
lean_ctor_set(x_52, 1, x_51);
return x_52;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_16 = lean_array_push(x_4, x_1);
x_17 = lean_ctor_get(x_2, 0);
lean_inc(x_17);
lean_dec(x_2);
x_18 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_17);
x_19 = lean_array_push(x_5, x_18);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_16);
lean_ctor_set(x_20, 1, x_19);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_3);
lean_ctor_set(x_21, 1, x_20);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_15);
return x_23;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("unresolved_instance", 19);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__2;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7(lean_object* x_1, lean_object* x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
uint8_t x_16; 
x_16 = lean_usize_dec_lt(x_5, x_4);
if (x_16 == 0)
{
lean_object* x_17; 
lean_dec(x_1);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_6);
lean_ctor_set(x_17, 1, x_15);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_18 = lean_array_uget(x_3, x_5);
x_19 = lean_ctor_get(x_6, 1);
lean_inc(x_19);
lean_dec(x_6);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; uint8_t x_25; 
x_21 = lean_ctor_get(x_19, 0);
x_22 = lean_ctor_get(x_19, 1);
x_23 = lean_ctor_get(x_18, 1);
lean_inc(x_23);
x_24 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_23, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_25 = !lean_is_exclusive(x_24);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; uint8_t x_29; 
x_26 = lean_ctor_get(x_24, 0);
x_27 = lean_ctor_get(x_24, 1);
x_28 = lean_expr_abstract(x_26, x_2);
lean_dec(x_26);
x_29 = l_Lean_Expr_hasMVar(x_28);
if (x_29 == 0)
{
uint8_t x_30; 
x_30 = l_Lean_Expr_hasFVar(x_28);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; size_t x_36; size_t x_37; 
lean_free_object(x_24);
lean_free_object(x_19);
x_31 = lean_box(0);
lean_inc(x_1);
x_32 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1(x_28, x_18, x_1, x_21, x_22, x_31, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_27);
x_33 = lean_ctor_get(x_32, 0);
lean_inc(x_33);
x_34 = lean_ctor_get(x_32, 1);
lean_inc(x_34);
lean_dec(x_32);
x_35 = lean_ctor_get(x_33, 0);
lean_inc(x_35);
lean_dec(x_33);
x_36 = 1;
x_37 = lean_usize_add(x_5, x_36);
x_5 = x_37;
x_6 = x_35;
x_15 = x_34;
goto _start;
}
else
{
lean_object* x_39; lean_object* x_40; 
lean_dec(x_28);
lean_dec(x_18);
lean_dec(x_1);
x_39 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3;
x_40 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_40, 0, x_39);
lean_ctor_set(x_40, 1, x_19);
lean_ctor_set(x_24, 0, x_40);
return x_24;
}
}
else
{
lean_object* x_41; lean_object* x_42; 
lean_dec(x_28);
lean_dec(x_18);
lean_dec(x_1);
x_41 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3;
x_42 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_42, 0, x_41);
lean_ctor_set(x_42, 1, x_19);
lean_ctor_set(x_24, 0, x_42);
return x_24;
}
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; uint8_t x_46; 
x_43 = lean_ctor_get(x_24, 0);
x_44 = lean_ctor_get(x_24, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_24);
x_45 = lean_expr_abstract(x_43, x_2);
lean_dec(x_43);
x_46 = l_Lean_Expr_hasMVar(x_45);
if (x_46 == 0)
{
uint8_t x_47; 
x_47 = l_Lean_Expr_hasFVar(x_45);
if (x_47 == 0)
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; size_t x_53; size_t x_54; 
lean_free_object(x_19);
x_48 = lean_box(0);
lean_inc(x_1);
x_49 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1(x_45, x_18, x_1, x_21, x_22, x_48, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_44);
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
x_51 = lean_ctor_get(x_49, 1);
lean_inc(x_51);
lean_dec(x_49);
x_52 = lean_ctor_get(x_50, 0);
lean_inc(x_52);
lean_dec(x_50);
x_53 = 1;
x_54 = lean_usize_add(x_5, x_53);
x_5 = x_54;
x_6 = x_52;
x_15 = x_51;
goto _start;
}
else
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; 
lean_dec(x_45);
lean_dec(x_18);
lean_dec(x_1);
x_56 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3;
x_57 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_19);
x_58 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_58, 0, x_57);
lean_ctor_set(x_58, 1, x_44);
return x_58;
}
}
else
{
lean_object* x_59; lean_object* x_60; lean_object* x_61; 
lean_dec(x_45);
lean_dec(x_18);
lean_dec(x_1);
x_59 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3;
x_60 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_60, 1, x_19);
x_61 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_61, 0, x_60);
lean_ctor_set(x_61, 1, x_44);
return x_61;
}
}
}
else
{
lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; uint8_t x_70; 
x_62 = lean_ctor_get(x_19, 0);
x_63 = lean_ctor_get(x_19, 1);
lean_inc(x_63);
lean_inc(x_62);
lean_dec(x_19);
x_64 = lean_ctor_get(x_18, 1);
lean_inc(x_64);
x_65 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_64, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
x_66 = lean_ctor_get(x_65, 0);
lean_inc(x_66);
x_67 = lean_ctor_get(x_65, 1);
lean_inc(x_67);
if (lean_is_exclusive(x_65)) {
 lean_ctor_release(x_65, 0);
 lean_ctor_release(x_65, 1);
 x_68 = x_65;
} else {
 lean_dec_ref(x_65);
 x_68 = lean_box(0);
}
x_69 = lean_expr_abstract(x_66, x_2);
lean_dec(x_66);
x_70 = l_Lean_Expr_hasMVar(x_69);
if (x_70 == 0)
{
uint8_t x_71; 
x_71 = l_Lean_Expr_hasFVar(x_69);
if (x_71 == 0)
{
lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; size_t x_77; size_t x_78; 
lean_dec(x_68);
x_72 = lean_box(0);
lean_inc(x_1);
x_73 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1(x_69, x_18, x_1, x_62, x_63, x_72, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_67);
x_74 = lean_ctor_get(x_73, 0);
lean_inc(x_74);
x_75 = lean_ctor_get(x_73, 1);
lean_inc(x_75);
lean_dec(x_73);
x_76 = lean_ctor_get(x_74, 0);
lean_inc(x_76);
lean_dec(x_74);
x_77 = 1;
x_78 = lean_usize_add(x_5, x_77);
x_5 = x_78;
x_6 = x_76;
x_15 = x_75;
goto _start;
}
else
{
lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; 
lean_dec(x_69);
lean_dec(x_18);
lean_dec(x_1);
x_80 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_80, 0, x_62);
lean_ctor_set(x_80, 1, x_63);
x_81 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3;
x_82 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_82, 0, x_81);
lean_ctor_set(x_82, 1, x_80);
if (lean_is_scalar(x_68)) {
 x_83 = lean_alloc_ctor(0, 2, 0);
} else {
 x_83 = x_68;
}
lean_ctor_set(x_83, 0, x_82);
lean_ctor_set(x_83, 1, x_67);
return x_83;
}
}
else
{
lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; 
lean_dec(x_69);
lean_dec(x_18);
lean_dec(x_1);
x_84 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_84, 0, x_62);
lean_ctor_set(x_84, 1, x_63);
x_85 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3;
x_86 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_86, 0, x_85);
lean_ctor_set(x_86, 1, x_84);
if (lean_is_scalar(x_68)) {
 x_87 = lean_alloc_ctor(0, 2, 0);
} else {
 x_87 = x_68;
}
lean_ctor_set(x_87, 0, x_86);
lean_ctor_set(x_87, 1, x_67);
return x_87;
}
}
}
}
}
static lean_object* _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(6u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_17 = lean_ctor_get(x_1, 0);
lean_inc(x_17);
x_18 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_17);
x_19 = lean_ctor_get(x_1, 3);
lean_inc(x_19);
x_20 = l_Lean_JsonNumber_fromNat(x_19);
x_21 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_21, 0, x_20);
x_22 = lean_ctor_get_uint8(x_1, sizeof(void*)*7);
x_23 = lean_unsigned_to_nat(0u);
x_24 = l___private_Lean_MetavarContext_0__Lean_reprMetavarKind____x40_Lean_MetavarContext___hyg_123_(x_22, x_23);
x_25 = l_Std_Format_defWidth;
x_26 = lean_format_pretty(x_24, x_25, x_23, x_23);
x_27 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_27, 0, x_26);
x_28 = lean_ctor_get(x_1, 5);
lean_inc(x_28);
lean_dec(x_1);
x_29 = l_Lean_JsonNumber_fromNat(x_28);
x_30 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_30, 0, x_29);
x_31 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_31, 0, x_2);
x_32 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_32, 0, x_3);
x_33 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___closed__1;
x_34 = lean_array_push(x_33, x_18);
x_35 = lean_array_push(x_34, x_21);
x_36 = lean_array_push(x_35, x_27);
x_37 = lean_array_push(x_36, x_30);
x_38 = lean_array_push(x_37, x_31);
x_39 = lean_array_push(x_38, x_32);
x_40 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_40, 0, x_39);
x_41 = lean_array_push(x_6, x_40);
x_42 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_42, 0, x_4);
lean_ctor_set(x_42, 1, x_41);
x_43 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_43, 0, x_5);
lean_ctor_set(x_43, 1, x_42);
x_44 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_44, 0, x_43);
x_45 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_45, 0, x_44);
lean_ctor_set(x_45, 1, x_16);
return x_45;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, size_t x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16, lean_object* x_17, lean_object* x_18, lean_object* x_19) {
_start:
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; size_t x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
lean_dec(x_10);
x_20 = lean_array_push(x_8, x_1);
x_21 = lean_ctor_get(x_2, 4);
lean_inc(x_21);
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_20);
lean_ctor_set(x_22, 1, x_3);
lean_inc(x_4);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_4);
lean_ctor_set(x_23, 1, x_22);
x_24 = lean_array_get_size(x_21);
x_25 = lean_usize_of_nat(x_24);
lean_dec(x_24);
lean_inc(x_4);
x_26 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7(x_4, x_5, x_21, x_25, x_6, x_23, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_18, x_19);
lean_dec(x_21);
lean_dec(x_5);
x_27 = lean_ctor_get(x_26, 0);
lean_inc(x_27);
x_28 = lean_ctor_get(x_27, 1);
lean_inc(x_28);
x_29 = lean_ctor_get(x_27, 0);
lean_inc(x_29);
lean_dec(x_27);
if (lean_obj_tag(x_29) == 0)
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_30 = lean_ctor_get(x_26, 1);
lean_inc(x_30);
lean_dec(x_26);
x_31 = lean_ctor_get(x_28, 0);
lean_inc(x_31);
x_32 = lean_ctor_get(x_28, 1);
lean_inc(x_32);
lean_dec(x_28);
x_33 = lean_box(0);
x_34 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1(x_2, x_7, x_32, x_31, x_4, x_9, x_33, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_18, x_30);
lean_dec(x_16);
lean_dec(x_13);
return x_34;
}
else
{
uint8_t x_35; 
lean_dec(x_16);
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_2);
x_35 = !lean_is_exclusive(x_26);
if (x_35 == 0)
{
lean_object* x_36; uint8_t x_37; 
x_36 = lean_ctor_get(x_26, 0);
lean_dec(x_36);
x_37 = !lean_is_exclusive(x_28);
if (x_37 == 0)
{
lean_object* x_38; uint8_t x_39; 
x_38 = lean_ctor_get(x_28, 1);
lean_dec(x_38);
x_39 = !lean_is_exclusive(x_29);
if (x_39 == 0)
{
lean_object* x_40; lean_object* x_41; 
lean_ctor_set(x_28, 1, x_9);
x_40 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_40, 0, x_29);
lean_ctor_set(x_40, 1, x_28);
x_41 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_41, 0, x_40);
lean_ctor_set(x_26, 0, x_41);
return x_26;
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_42 = lean_ctor_get(x_29, 0);
lean_inc(x_42);
lean_dec(x_29);
x_43 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_43, 0, x_42);
lean_ctor_set(x_28, 1, x_9);
x_44 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_44, 0, x_43);
lean_ctor_set(x_44, 1, x_28);
x_45 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_45, 0, x_44);
lean_ctor_set(x_26, 0, x_45);
return x_26;
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_46 = lean_ctor_get(x_28, 0);
lean_inc(x_46);
lean_dec(x_28);
x_47 = lean_ctor_get(x_29, 0);
lean_inc(x_47);
if (lean_is_exclusive(x_29)) {
 lean_ctor_release(x_29, 0);
 x_48 = x_29;
} else {
 lean_dec_ref(x_29);
 x_48 = lean_box(0);
}
if (lean_is_scalar(x_48)) {
 x_49 = lean_alloc_ctor(1, 1, 0);
} else {
 x_49 = x_48;
}
lean_ctor_set(x_49, 0, x_47);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_46);
lean_ctor_set(x_50, 1, x_9);
x_51 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_51, 0, x_49);
lean_ctor_set(x_51, 1, x_50);
x_52 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_52, 0, x_51);
lean_ctor_set(x_26, 0, x_52);
return x_26;
}
}
else
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
x_53 = lean_ctor_get(x_26, 1);
lean_inc(x_53);
lean_dec(x_26);
x_54 = lean_ctor_get(x_28, 0);
lean_inc(x_54);
if (lean_is_exclusive(x_28)) {
 lean_ctor_release(x_28, 0);
 lean_ctor_release(x_28, 1);
 x_55 = x_28;
} else {
 lean_dec_ref(x_28);
 x_55 = lean_box(0);
}
x_56 = lean_ctor_get(x_29, 0);
lean_inc(x_56);
if (lean_is_exclusive(x_29)) {
 lean_ctor_release(x_29, 0);
 x_57 = x_29;
} else {
 lean_dec_ref(x_29);
 x_57 = lean_box(0);
}
if (lean_is_scalar(x_57)) {
 x_58 = lean_alloc_ctor(1, 1, 0);
} else {
 x_58 = x_57;
}
lean_ctor_set(x_58, 0, x_56);
if (lean_is_scalar(x_55)) {
 x_59 = lean_alloc_ctor(0, 2, 0);
} else {
 x_59 = x_55;
}
lean_ctor_set(x_59, 0, x_54);
lean_ctor_set(x_59, 1, x_9);
x_60 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_60, 0, x_58);
lean_ctor_set(x_60, 1, x_59);
x_61 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_61, 0, x_60);
x_62 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_62, 0, x_61);
lean_ctor_set(x_62, 1, x_53);
return x_62;
}
}
}
}
static lean_object* _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("unresolved_target", 17);
return x_1;
}
}
static lean_object* _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__2;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16, lean_object* x_17, lean_object* x_18) {
_start:
{
lean_object* x_19; lean_object* x_20; uint8_t x_21; 
lean_dec(x_9);
x_19 = lean_ctor_get(x_1, 2);
lean_inc(x_19);
x_20 = l_Lean_instantiateMVars___at_Lean_Elab_Tactic_getMainTarget___spec__1(x_19, x_10, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_18);
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; uint8_t x_25; 
x_22 = lean_ctor_get(x_20, 0);
x_23 = lean_ctor_get(x_20, 1);
x_24 = lean_expr_abstract(x_22, x_2);
lean_dec(x_22);
x_25 = l_Lean_Expr_hasMVar(x_24);
if (x_25 == 0)
{
uint8_t x_26; 
x_26 = l_Lean_Expr_hasFVar(x_24);
if (x_26 == 0)
{
lean_object* x_27; lean_object* x_28; 
lean_free_object(x_20);
x_27 = lean_box(0);
x_28 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__2(x_24, x_1, x_3, x_4, x_2, x_5, x_6, x_7, x_8, x_27, x_10, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_23);
lean_dec(x_17);
lean_dec(x_16);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_11);
lean_dec(x_10);
return x_28;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
lean_dec(x_24);
lean_dec(x_17);
lean_dec(x_16);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_7);
lean_ctor_set(x_29, 1, x_8);
x_30 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3;
x_31 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_31, 0, x_30);
lean_ctor_set(x_31, 1, x_29);
x_32 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_20, 0, x_32);
return x_20;
}
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
lean_dec(x_24);
lean_dec(x_17);
lean_dec(x_16);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_33 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_33, 0, x_7);
lean_ctor_set(x_33, 1, x_8);
x_34 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3;
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_34);
lean_ctor_set(x_35, 1, x_33);
x_36 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_36, 0, x_35);
lean_ctor_set(x_20, 0, x_36);
return x_20;
}
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; uint8_t x_40; 
x_37 = lean_ctor_get(x_20, 0);
x_38 = lean_ctor_get(x_20, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_20);
x_39 = lean_expr_abstract(x_37, x_2);
lean_dec(x_37);
x_40 = l_Lean_Expr_hasMVar(x_39);
if (x_40 == 0)
{
uint8_t x_41; 
x_41 = l_Lean_Expr_hasFVar(x_39);
if (x_41 == 0)
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_box(0);
x_43 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__2(x_39, x_1, x_3, x_4, x_2, x_5, x_6, x_7, x_8, x_42, x_10, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_38);
lean_dec(x_17);
lean_dec(x_16);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_11);
lean_dec(x_10);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
lean_dec(x_39);
lean_dec(x_17);
lean_dec(x_16);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_44 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_44, 0, x_7);
lean_ctor_set(x_44, 1, x_8);
x_45 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3;
x_46 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_46, 0, x_45);
lean_ctor_set(x_46, 1, x_44);
x_47 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_47, 0, x_46);
x_48 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_48, 0, x_47);
lean_ctor_set(x_48, 1, x_38);
return x_48;
}
}
else
{
lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; 
lean_dec(x_39);
lean_dec(x_17);
lean_dec(x_16);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_49 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_49, 0, x_7);
lean_ctor_set(x_49, 1, x_8);
x_50 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3;
x_51 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_51, 0, x_50);
lean_ctor_set(x_51, 1, x_49);
x_52 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_52, 0, x_51);
x_53 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_53, 0, x_52);
lean_ctor_set(x_53, 1, x_38);
return x_53;
}
}
}
}
static lean_object* _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_2 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8(size_t x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
if (lean_obj_tag(x_3) == 0)
{
lean_object* x_14; 
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_4);
lean_ctor_set(x_14, 1, x_13);
return x_14;
}
else
{
lean_object* x_15; uint8_t x_16; 
x_15 = lean_ctor_get(x_4, 1);
lean_inc(x_15);
lean_dec(x_4);
x_16 = !lean_is_exclusive(x_3);
if (x_16 == 0)
{
uint8_t x_17; 
x_17 = !lean_is_exclusive(x_15);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_18 = lean_ctor_get(x_3, 0);
x_19 = lean_ctor_get(x_3, 1);
x_20 = lean_ctor_get(x_15, 0);
x_21 = lean_ctor_get(x_15, 1);
x_22 = l_Lean_MVarId_getDecl(x_18, x_9, x_10, x_11, x_12, x_13);
if (lean_obj_tag(x_22) == 0)
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_23 = lean_ctor_get(x_22, 0);
lean_inc(x_23);
x_24 = lean_ctor_get(x_22, 1);
lean_inc(x_24);
lean_dec(x_22);
x_25 = lean_ctor_get(x_23, 1);
lean_inc(x_25);
x_26 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1;
lean_ctor_set(x_15, 1, x_26);
lean_inc(x_2);
lean_ctor_set_tag(x_3, 0);
lean_ctor_set(x_3, 1, x_15);
lean_ctor_set(x_3, 0, x_2);
x_27 = lean_ctor_get(x_25, 1);
lean_inc(x_27);
lean_dec(x_25);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_2);
x_28 = l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2(x_2, x_27, x_3, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_24);
if (lean_obj_tag(x_28) == 0)
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_29, 1);
lean_inc(x_30);
x_31 = lean_ctor_get(x_30, 1);
lean_inc(x_31);
x_32 = lean_ctor_get(x_29, 0);
lean_inc(x_32);
lean_dec(x_29);
if (lean_obj_tag(x_32) == 0)
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; 
x_33 = lean_ctor_get(x_28, 1);
lean_inc(x_33);
lean_dec(x_28);
x_34 = lean_ctor_get(x_30, 0);
lean_inc(x_34);
lean_dec(x_30);
x_35 = lean_ctor_get(x_31, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_31, 1);
lean_inc(x_36);
lean_dec(x_31);
x_37 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_38 = lean_box(0);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_2);
x_39 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3(x_23, x_35, x_37, x_2, x_1, x_36, x_34, x_21, x_38, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_33);
x_40 = lean_ctor_get(x_39, 0);
lean_inc(x_40);
if (lean_obj_tag(x_40) == 0)
{
uint8_t x_41; 
lean_dec(x_19);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_41 = !lean_is_exclusive(x_39);
if (x_41 == 0)
{
lean_object* x_42; lean_object* x_43; 
x_42 = lean_ctor_get(x_39, 0);
lean_dec(x_42);
x_43 = lean_ctor_get(x_40, 0);
lean_inc(x_43);
lean_dec(x_40);
lean_ctor_set(x_39, 0, x_43);
return x_39;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_ctor_get(x_39, 1);
lean_inc(x_44);
lean_dec(x_39);
x_45 = lean_ctor_get(x_40, 0);
lean_inc(x_45);
lean_dec(x_40);
x_46 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_46, 0, x_45);
lean_ctor_set(x_46, 1, x_44);
return x_46;
}
}
else
{
lean_object* x_47; lean_object* x_48; 
x_47 = lean_ctor_get(x_39, 1);
lean_inc(x_47);
lean_dec(x_39);
x_48 = lean_ctor_get(x_40, 0);
lean_inc(x_48);
lean_dec(x_40);
x_3 = x_19;
x_4 = x_48;
x_13 = x_47;
goto _start;
}
}
else
{
uint8_t x_50; 
lean_dec(x_23);
lean_dec(x_19);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_50 = !lean_is_exclusive(x_31);
if (x_50 == 0)
{
lean_object* x_51; lean_object* x_52; uint8_t x_53; 
x_51 = lean_ctor_get(x_31, 1);
lean_dec(x_51);
x_52 = lean_ctor_get(x_31, 0);
lean_dec(x_52);
x_53 = !lean_is_exclusive(x_28);
if (x_53 == 0)
{
lean_object* x_54; uint8_t x_55; 
x_54 = lean_ctor_get(x_28, 0);
lean_dec(x_54);
x_55 = !lean_is_exclusive(x_30);
if (x_55 == 0)
{
lean_object* x_56; lean_object* x_57; uint8_t x_58; 
x_56 = lean_ctor_get(x_30, 0);
x_57 = lean_ctor_get(x_30, 1);
lean_dec(x_57);
x_58 = !lean_is_exclusive(x_32);
if (x_58 == 0)
{
lean_ctor_set(x_31, 1, x_21);
lean_ctor_set(x_31, 0, x_56);
lean_ctor_set(x_30, 0, x_32);
lean_ctor_set(x_28, 0, x_30);
return x_28;
}
else
{
lean_object* x_59; lean_object* x_60; 
x_59 = lean_ctor_get(x_32, 0);
lean_inc(x_59);
lean_dec(x_32);
x_60 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_31, 1, x_21);
lean_ctor_set(x_31, 0, x_56);
lean_ctor_set(x_30, 0, x_60);
lean_ctor_set(x_28, 0, x_30);
return x_28;
}
}
else
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; 
x_61 = lean_ctor_get(x_30, 0);
lean_inc(x_61);
lean_dec(x_30);
x_62 = lean_ctor_get(x_32, 0);
lean_inc(x_62);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 x_63 = x_32;
} else {
 lean_dec_ref(x_32);
 x_63 = lean_box(0);
}
if (lean_is_scalar(x_63)) {
 x_64 = lean_alloc_ctor(1, 1, 0);
} else {
 x_64 = x_63;
}
lean_ctor_set(x_64, 0, x_62);
lean_ctor_set(x_31, 1, x_21);
lean_ctor_set(x_31, 0, x_61);
x_65 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_65, 0, x_64);
lean_ctor_set(x_65, 1, x_31);
lean_ctor_set(x_28, 0, x_65);
return x_28;
}
}
else
{
lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; 
x_66 = lean_ctor_get(x_28, 1);
lean_inc(x_66);
lean_dec(x_28);
x_67 = lean_ctor_get(x_30, 0);
lean_inc(x_67);
if (lean_is_exclusive(x_30)) {
 lean_ctor_release(x_30, 0);
 lean_ctor_release(x_30, 1);
 x_68 = x_30;
} else {
 lean_dec_ref(x_30);
 x_68 = lean_box(0);
}
x_69 = lean_ctor_get(x_32, 0);
lean_inc(x_69);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 x_70 = x_32;
} else {
 lean_dec_ref(x_32);
 x_70 = lean_box(0);
}
if (lean_is_scalar(x_70)) {
 x_71 = lean_alloc_ctor(1, 1, 0);
} else {
 x_71 = x_70;
}
lean_ctor_set(x_71, 0, x_69);
lean_ctor_set(x_31, 1, x_21);
lean_ctor_set(x_31, 0, x_67);
if (lean_is_scalar(x_68)) {
 x_72 = lean_alloc_ctor(0, 2, 0);
} else {
 x_72 = x_68;
}
lean_ctor_set(x_72, 0, x_71);
lean_ctor_set(x_72, 1, x_31);
x_73 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_73, 0, x_72);
lean_ctor_set(x_73, 1, x_66);
return x_73;
}
}
else
{
lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; 
lean_dec(x_31);
x_74 = lean_ctor_get(x_28, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_28)) {
 lean_ctor_release(x_28, 0);
 lean_ctor_release(x_28, 1);
 x_75 = x_28;
} else {
 lean_dec_ref(x_28);
 x_75 = lean_box(0);
}
x_76 = lean_ctor_get(x_30, 0);
lean_inc(x_76);
if (lean_is_exclusive(x_30)) {
 lean_ctor_release(x_30, 0);
 lean_ctor_release(x_30, 1);
 x_77 = x_30;
} else {
 lean_dec_ref(x_30);
 x_77 = lean_box(0);
}
x_78 = lean_ctor_get(x_32, 0);
lean_inc(x_78);
if (lean_is_exclusive(x_32)) {
 lean_ctor_release(x_32, 0);
 x_79 = x_32;
} else {
 lean_dec_ref(x_32);
 x_79 = lean_box(0);
}
if (lean_is_scalar(x_79)) {
 x_80 = lean_alloc_ctor(1, 1, 0);
} else {
 x_80 = x_79;
}
lean_ctor_set(x_80, 0, x_78);
x_81 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_81, 0, x_76);
lean_ctor_set(x_81, 1, x_21);
if (lean_is_scalar(x_77)) {
 x_82 = lean_alloc_ctor(0, 2, 0);
} else {
 x_82 = x_77;
}
lean_ctor_set(x_82, 0, x_80);
lean_ctor_set(x_82, 1, x_81);
if (lean_is_scalar(x_75)) {
 x_83 = lean_alloc_ctor(0, 2, 0);
} else {
 x_83 = x_75;
}
lean_ctor_set(x_83, 0, x_82);
lean_ctor_set(x_83, 1, x_74);
return x_83;
}
}
}
else
{
uint8_t x_84; 
lean_dec(x_23);
lean_dec(x_21);
lean_dec(x_19);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_84 = !lean_is_exclusive(x_28);
if (x_84 == 0)
{
return x_28;
}
else
{
lean_object* x_85; lean_object* x_86; lean_object* x_87; 
x_85 = lean_ctor_get(x_28, 0);
x_86 = lean_ctor_get(x_28, 1);
lean_inc(x_86);
lean_inc(x_85);
lean_dec(x_28);
x_87 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_87, 0, x_85);
lean_ctor_set(x_87, 1, x_86);
return x_87;
}
}
}
else
{
uint8_t x_88; 
lean_free_object(x_15);
lean_dec(x_21);
lean_dec(x_20);
lean_free_object(x_3);
lean_dec(x_19);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_88 = !lean_is_exclusive(x_22);
if (x_88 == 0)
{
return x_22;
}
else
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; 
x_89 = lean_ctor_get(x_22, 0);
x_90 = lean_ctor_get(x_22, 1);
lean_inc(x_90);
lean_inc(x_89);
lean_dec(x_22);
x_91 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_91, 0, x_89);
lean_ctor_set(x_91, 1, x_90);
return x_91;
}
}
}
else
{
lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; 
x_92 = lean_ctor_get(x_3, 0);
x_93 = lean_ctor_get(x_3, 1);
x_94 = lean_ctor_get(x_15, 0);
x_95 = lean_ctor_get(x_15, 1);
lean_inc(x_95);
lean_inc(x_94);
lean_dec(x_15);
x_96 = l_Lean_MVarId_getDecl(x_92, x_9, x_10, x_11, x_12, x_13);
if (lean_obj_tag(x_96) == 0)
{
lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; 
x_97 = lean_ctor_get(x_96, 0);
lean_inc(x_97);
x_98 = lean_ctor_get(x_96, 1);
lean_inc(x_98);
lean_dec(x_96);
x_99 = lean_ctor_get(x_97, 1);
lean_inc(x_99);
x_100 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1;
x_101 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_101, 0, x_94);
lean_ctor_set(x_101, 1, x_100);
lean_inc(x_2);
lean_ctor_set_tag(x_3, 0);
lean_ctor_set(x_3, 1, x_101);
lean_ctor_set(x_3, 0, x_2);
x_102 = lean_ctor_get(x_99, 1);
lean_inc(x_102);
lean_dec(x_99);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_2);
x_103 = l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2(x_2, x_102, x_3, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_98);
if (lean_obj_tag(x_103) == 0)
{
lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; 
x_104 = lean_ctor_get(x_103, 0);
lean_inc(x_104);
x_105 = lean_ctor_get(x_104, 1);
lean_inc(x_105);
x_106 = lean_ctor_get(x_105, 1);
lean_inc(x_106);
x_107 = lean_ctor_get(x_104, 0);
lean_inc(x_107);
lean_dec(x_104);
if (lean_obj_tag(x_107) == 0)
{
lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; 
x_108 = lean_ctor_get(x_103, 1);
lean_inc(x_108);
lean_dec(x_103);
x_109 = lean_ctor_get(x_105, 0);
lean_inc(x_109);
lean_dec(x_105);
x_110 = lean_ctor_get(x_106, 0);
lean_inc(x_110);
x_111 = lean_ctor_get(x_106, 1);
lean_inc(x_111);
lean_dec(x_106);
x_112 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_113 = lean_box(0);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_2);
x_114 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3(x_97, x_110, x_112, x_2, x_1, x_111, x_109, x_95, x_113, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_108);
x_115 = lean_ctor_get(x_114, 0);
lean_inc(x_115);
if (lean_obj_tag(x_115) == 0)
{
lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; 
lean_dec(x_93);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_116 = lean_ctor_get(x_114, 1);
lean_inc(x_116);
if (lean_is_exclusive(x_114)) {
 lean_ctor_release(x_114, 0);
 lean_ctor_release(x_114, 1);
 x_117 = x_114;
} else {
 lean_dec_ref(x_114);
 x_117 = lean_box(0);
}
x_118 = lean_ctor_get(x_115, 0);
lean_inc(x_118);
lean_dec(x_115);
if (lean_is_scalar(x_117)) {
 x_119 = lean_alloc_ctor(0, 2, 0);
} else {
 x_119 = x_117;
}
lean_ctor_set(x_119, 0, x_118);
lean_ctor_set(x_119, 1, x_116);
return x_119;
}
else
{
lean_object* x_120; lean_object* x_121; 
x_120 = lean_ctor_get(x_114, 1);
lean_inc(x_120);
lean_dec(x_114);
x_121 = lean_ctor_get(x_115, 0);
lean_inc(x_121);
lean_dec(x_115);
x_3 = x_93;
x_4 = x_121;
x_13 = x_120;
goto _start;
}
}
else
{
lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; 
lean_dec(x_97);
lean_dec(x_93);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
if (lean_is_exclusive(x_106)) {
 lean_ctor_release(x_106, 0);
 lean_ctor_release(x_106, 1);
 x_123 = x_106;
} else {
 lean_dec_ref(x_106);
 x_123 = lean_box(0);
}
x_124 = lean_ctor_get(x_103, 1);
lean_inc(x_124);
if (lean_is_exclusive(x_103)) {
 lean_ctor_release(x_103, 0);
 lean_ctor_release(x_103, 1);
 x_125 = x_103;
} else {
 lean_dec_ref(x_103);
 x_125 = lean_box(0);
}
x_126 = lean_ctor_get(x_105, 0);
lean_inc(x_126);
if (lean_is_exclusive(x_105)) {
 lean_ctor_release(x_105, 0);
 lean_ctor_release(x_105, 1);
 x_127 = x_105;
} else {
 lean_dec_ref(x_105);
 x_127 = lean_box(0);
}
x_128 = lean_ctor_get(x_107, 0);
lean_inc(x_128);
if (lean_is_exclusive(x_107)) {
 lean_ctor_release(x_107, 0);
 x_129 = x_107;
} else {
 lean_dec_ref(x_107);
 x_129 = lean_box(0);
}
if (lean_is_scalar(x_129)) {
 x_130 = lean_alloc_ctor(1, 1, 0);
} else {
 x_130 = x_129;
}
lean_ctor_set(x_130, 0, x_128);
if (lean_is_scalar(x_123)) {
 x_131 = lean_alloc_ctor(0, 2, 0);
} else {
 x_131 = x_123;
}
lean_ctor_set(x_131, 0, x_126);
lean_ctor_set(x_131, 1, x_95);
if (lean_is_scalar(x_127)) {
 x_132 = lean_alloc_ctor(0, 2, 0);
} else {
 x_132 = x_127;
}
lean_ctor_set(x_132, 0, x_130);
lean_ctor_set(x_132, 1, x_131);
if (lean_is_scalar(x_125)) {
 x_133 = lean_alloc_ctor(0, 2, 0);
} else {
 x_133 = x_125;
}
lean_ctor_set(x_133, 0, x_132);
lean_ctor_set(x_133, 1, x_124);
return x_133;
}
}
else
{
lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; 
lean_dec(x_97);
lean_dec(x_95);
lean_dec(x_93);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_134 = lean_ctor_get(x_103, 0);
lean_inc(x_134);
x_135 = lean_ctor_get(x_103, 1);
lean_inc(x_135);
if (lean_is_exclusive(x_103)) {
 lean_ctor_release(x_103, 0);
 lean_ctor_release(x_103, 1);
 x_136 = x_103;
} else {
 lean_dec_ref(x_103);
 x_136 = lean_box(0);
}
if (lean_is_scalar(x_136)) {
 x_137 = lean_alloc_ctor(1, 2, 0);
} else {
 x_137 = x_136;
}
lean_ctor_set(x_137, 0, x_134);
lean_ctor_set(x_137, 1, x_135);
return x_137;
}
}
else
{
lean_object* x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; 
lean_dec(x_95);
lean_dec(x_94);
lean_free_object(x_3);
lean_dec(x_93);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_138 = lean_ctor_get(x_96, 0);
lean_inc(x_138);
x_139 = lean_ctor_get(x_96, 1);
lean_inc(x_139);
if (lean_is_exclusive(x_96)) {
 lean_ctor_release(x_96, 0);
 lean_ctor_release(x_96, 1);
 x_140 = x_96;
} else {
 lean_dec_ref(x_96);
 x_140 = lean_box(0);
}
if (lean_is_scalar(x_140)) {
 x_141 = lean_alloc_ctor(1, 2, 0);
} else {
 x_141 = x_140;
}
lean_ctor_set(x_141, 0, x_138);
lean_ctor_set(x_141, 1, x_139);
return x_141;
}
}
}
else
{
lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; 
x_142 = lean_ctor_get(x_3, 0);
x_143 = lean_ctor_get(x_3, 1);
lean_inc(x_143);
lean_inc(x_142);
lean_dec(x_3);
x_144 = lean_ctor_get(x_15, 0);
lean_inc(x_144);
x_145 = lean_ctor_get(x_15, 1);
lean_inc(x_145);
if (lean_is_exclusive(x_15)) {
 lean_ctor_release(x_15, 0);
 lean_ctor_release(x_15, 1);
 x_146 = x_15;
} else {
 lean_dec_ref(x_15);
 x_146 = lean_box(0);
}
x_147 = l_Lean_MVarId_getDecl(x_142, x_9, x_10, x_11, x_12, x_13);
if (lean_obj_tag(x_147) == 0)
{
lean_object* x_148; lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; 
x_148 = lean_ctor_get(x_147, 0);
lean_inc(x_148);
x_149 = lean_ctor_get(x_147, 1);
lean_inc(x_149);
lean_dec(x_147);
x_150 = lean_ctor_get(x_148, 1);
lean_inc(x_150);
x_151 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1;
if (lean_is_scalar(x_146)) {
 x_152 = lean_alloc_ctor(0, 2, 0);
} else {
 x_152 = x_146;
}
lean_ctor_set(x_152, 0, x_144);
lean_ctor_set(x_152, 1, x_151);
lean_inc(x_2);
x_153 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_153, 0, x_2);
lean_ctor_set(x_153, 1, x_152);
x_154 = lean_ctor_get(x_150, 1);
lean_inc(x_154);
lean_dec(x_150);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_2);
x_155 = l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2(x_2, x_154, x_153, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_149);
if (lean_obj_tag(x_155) == 0)
{
lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; 
x_156 = lean_ctor_get(x_155, 0);
lean_inc(x_156);
x_157 = lean_ctor_get(x_156, 1);
lean_inc(x_157);
x_158 = lean_ctor_get(x_157, 1);
lean_inc(x_158);
x_159 = lean_ctor_get(x_156, 0);
lean_inc(x_159);
lean_dec(x_156);
if (lean_obj_tag(x_159) == 0)
{
lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; lean_object* x_165; lean_object* x_166; lean_object* x_167; 
x_160 = lean_ctor_get(x_155, 1);
lean_inc(x_160);
lean_dec(x_155);
x_161 = lean_ctor_get(x_157, 0);
lean_inc(x_161);
lean_dec(x_157);
x_162 = lean_ctor_get(x_158, 0);
lean_inc(x_162);
x_163 = lean_ctor_get(x_158, 1);
lean_inc(x_163);
lean_dec(x_158);
x_164 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_165 = lean_box(0);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_2);
x_166 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3(x_148, x_162, x_164, x_2, x_1, x_163, x_161, x_145, x_165, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_160);
x_167 = lean_ctor_get(x_166, 0);
lean_inc(x_167);
if (lean_obj_tag(x_167) == 0)
{
lean_object* x_168; lean_object* x_169; lean_object* x_170; lean_object* x_171; 
lean_dec(x_143);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_168 = lean_ctor_get(x_166, 1);
lean_inc(x_168);
if (lean_is_exclusive(x_166)) {
 lean_ctor_release(x_166, 0);
 lean_ctor_release(x_166, 1);
 x_169 = x_166;
} else {
 lean_dec_ref(x_166);
 x_169 = lean_box(0);
}
x_170 = lean_ctor_get(x_167, 0);
lean_inc(x_170);
lean_dec(x_167);
if (lean_is_scalar(x_169)) {
 x_171 = lean_alloc_ctor(0, 2, 0);
} else {
 x_171 = x_169;
}
lean_ctor_set(x_171, 0, x_170);
lean_ctor_set(x_171, 1, x_168);
return x_171;
}
else
{
lean_object* x_172; lean_object* x_173; 
x_172 = lean_ctor_get(x_166, 1);
lean_inc(x_172);
lean_dec(x_166);
x_173 = lean_ctor_get(x_167, 0);
lean_inc(x_173);
lean_dec(x_167);
x_3 = x_143;
x_4 = x_173;
x_13 = x_172;
goto _start;
}
}
else
{
lean_object* x_175; lean_object* x_176; lean_object* x_177; lean_object* x_178; lean_object* x_179; lean_object* x_180; lean_object* x_181; lean_object* x_182; lean_object* x_183; lean_object* x_184; lean_object* x_185; 
lean_dec(x_148);
lean_dec(x_143);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
if (lean_is_exclusive(x_158)) {
 lean_ctor_release(x_158, 0);
 lean_ctor_release(x_158, 1);
 x_175 = x_158;
} else {
 lean_dec_ref(x_158);
 x_175 = lean_box(0);
}
x_176 = lean_ctor_get(x_155, 1);
lean_inc(x_176);
if (lean_is_exclusive(x_155)) {
 lean_ctor_release(x_155, 0);
 lean_ctor_release(x_155, 1);
 x_177 = x_155;
} else {
 lean_dec_ref(x_155);
 x_177 = lean_box(0);
}
x_178 = lean_ctor_get(x_157, 0);
lean_inc(x_178);
if (lean_is_exclusive(x_157)) {
 lean_ctor_release(x_157, 0);
 lean_ctor_release(x_157, 1);
 x_179 = x_157;
} else {
 lean_dec_ref(x_157);
 x_179 = lean_box(0);
}
x_180 = lean_ctor_get(x_159, 0);
lean_inc(x_180);
if (lean_is_exclusive(x_159)) {
 lean_ctor_release(x_159, 0);
 x_181 = x_159;
} else {
 lean_dec_ref(x_159);
 x_181 = lean_box(0);
}
if (lean_is_scalar(x_181)) {
 x_182 = lean_alloc_ctor(1, 1, 0);
} else {
 x_182 = x_181;
}
lean_ctor_set(x_182, 0, x_180);
if (lean_is_scalar(x_175)) {
 x_183 = lean_alloc_ctor(0, 2, 0);
} else {
 x_183 = x_175;
}
lean_ctor_set(x_183, 0, x_178);
lean_ctor_set(x_183, 1, x_145);
if (lean_is_scalar(x_179)) {
 x_184 = lean_alloc_ctor(0, 2, 0);
} else {
 x_184 = x_179;
}
lean_ctor_set(x_184, 0, x_182);
lean_ctor_set(x_184, 1, x_183);
if (lean_is_scalar(x_177)) {
 x_185 = lean_alloc_ctor(0, 2, 0);
} else {
 x_185 = x_177;
}
lean_ctor_set(x_185, 0, x_184);
lean_ctor_set(x_185, 1, x_176);
return x_185;
}
}
else
{
lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; 
lean_dec(x_148);
lean_dec(x_145);
lean_dec(x_143);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_186 = lean_ctor_get(x_155, 0);
lean_inc(x_186);
x_187 = lean_ctor_get(x_155, 1);
lean_inc(x_187);
if (lean_is_exclusive(x_155)) {
 lean_ctor_release(x_155, 0);
 lean_ctor_release(x_155, 1);
 x_188 = x_155;
} else {
 lean_dec_ref(x_155);
 x_188 = lean_box(0);
}
if (lean_is_scalar(x_188)) {
 x_189 = lean_alloc_ctor(1, 2, 0);
} else {
 x_189 = x_188;
}
lean_ctor_set(x_189, 0, x_186);
lean_ctor_set(x_189, 1, x_187);
return x_189;
}
}
else
{
lean_object* x_190; lean_object* x_191; lean_object* x_192; lean_object* x_193; 
lean_dec(x_146);
lean_dec(x_145);
lean_dec(x_144);
lean_dec(x_143);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_2);
x_190 = lean_ctor_get(x_147, 0);
lean_inc(x_190);
x_191 = lean_ctor_get(x_147, 1);
lean_inc(x_191);
if (lean_is_exclusive(x_147)) {
 lean_ctor_release(x_147, 0);
 lean_ctor_release(x_147, 1);
 x_192 = x_147;
} else {
 lean_dec_ref(x_147);
 x_192 = lean_box(0);
}
if (lean_is_scalar(x_192)) {
 x_193 = lean_alloc_ctor(1, 2, 0);
} else {
 x_193 = x_192;
}
lean_ctor_set(x_193, 0, x_190);
lean_ctor_set(x_193, 1, x_191);
return x_193;
}
}
}
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("observed_input_only", 19);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_14 = lean_ctor_get(x_11, 2);
x_15 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_15, 0, x_1);
x_16 = l_Lean_Json_compress(x_15);
lean_inc(x_14);
x_17 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_17, 0, x_2);
lean_ctor_set(x_17, 1, x_14);
lean_ctor_set(x_17, 2, x_16);
lean_ctor_set(x_17, 3, x_3);
x_18 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_18, 0, x_17);
x_19 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___closed__1;
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_18);
lean_ctor_set(x_20, 1, x_19);
x_21 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_13);
return x_21;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__2(size_t x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; uint8_t x_16; 
lean_dec(x_5);
x_15 = l_Lean_Elab_Tactic_getGoals___rarg(x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
x_16 = !lean_is_exclusive(x_15);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_17 = lean_ctor_get(x_15, 0);
x_18 = lean_ctor_get(x_15, 1);
x_19 = lean_box(0);
lean_ctor_set(x_15, 1, x_4);
lean_ctor_set(x_15, 0, x_3);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_20, 1, x_15);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
x_21 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8(x_1, x_19, x_17, x_20, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_18);
if (lean_obj_tag(x_21) == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_22 = lean_ctor_get(x_21, 0);
lean_inc(x_22);
x_23 = lean_ctor_get(x_22, 1);
lean_inc(x_23);
x_24 = lean_ctor_get(x_22, 0);
lean_inc(x_24);
lean_dec(x_22);
if (lean_obj_tag(x_24) == 0)
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_25 = lean_ctor_get(x_21, 1);
lean_inc(x_25);
lean_dec(x_21);
x_26 = lean_ctor_get(x_23, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_23, 1);
lean_inc(x_27);
lean_dec(x_23);
x_28 = lean_box(0);
x_29 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1(x_27, x_2, x_26, x_28, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_25);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
return x_29;
}
else
{
uint8_t x_30; 
lean_dec(x_23);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_30 = !lean_is_exclusive(x_21);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; 
x_31 = lean_ctor_get(x_21, 0);
lean_dec(x_31);
x_32 = lean_ctor_get(x_24, 0);
lean_inc(x_32);
lean_dec(x_24);
lean_ctor_set(x_21, 0, x_32);
return x_21;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_21, 1);
lean_inc(x_33);
lean_dec(x_21);
x_34 = lean_ctor_get(x_24, 0);
lean_inc(x_34);
lean_dec(x_24);
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_34);
lean_ctor_set(x_35, 1, x_33);
return x_35;
}
}
}
else
{
uint8_t x_36; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_36 = !lean_is_exclusive(x_21);
if (x_36 == 0)
{
return x_21;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_37 = lean_ctor_get(x_21, 0);
x_38 = lean_ctor_get(x_21, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_21);
x_39 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
return x_39;
}
}
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_40 = lean_ctor_get(x_15, 0);
x_41 = lean_ctor_get(x_15, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_15);
x_42 = lean_box(0);
x_43 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_43, 0, x_3);
lean_ctor_set(x_43, 1, x_4);
x_44 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_44, 0, x_42);
lean_ctor_set(x_44, 1, x_43);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
x_45 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8(x_1, x_42, x_40, x_44, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_41);
if (lean_obj_tag(x_45) == 0)
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_46 = lean_ctor_get(x_45, 0);
lean_inc(x_46);
x_47 = lean_ctor_get(x_46, 1);
lean_inc(x_47);
x_48 = lean_ctor_get(x_46, 0);
lean_inc(x_48);
lean_dec(x_46);
if (lean_obj_tag(x_48) == 0)
{
lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; 
x_49 = lean_ctor_get(x_45, 1);
lean_inc(x_49);
lean_dec(x_45);
x_50 = lean_ctor_get(x_47, 0);
lean_inc(x_50);
x_51 = lean_ctor_get(x_47, 1);
lean_inc(x_51);
lean_dec(x_47);
x_52 = lean_box(0);
x_53 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1(x_51, x_2, x_50, x_52, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_49);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
return x_53;
}
else
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; 
lean_dec(x_47);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_54 = lean_ctor_get(x_45, 1);
lean_inc(x_54);
if (lean_is_exclusive(x_45)) {
 lean_ctor_release(x_45, 0);
 lean_ctor_release(x_45, 1);
 x_55 = x_45;
} else {
 lean_dec_ref(x_45);
 x_55 = lean_box(0);
}
x_56 = lean_ctor_get(x_48, 0);
lean_inc(x_56);
lean_dec(x_48);
if (lean_is_scalar(x_55)) {
 x_57 = lean_alloc_ctor(0, 2, 0);
} else {
 x_57 = x_55;
}
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_54);
return x_57;
}
}
else
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_58 = lean_ctor_get(x_45, 0);
lean_inc(x_58);
x_59 = lean_ctor_get(x_45, 1);
lean_inc(x_59);
if (lean_is_exclusive(x_45)) {
 lean_ctor_release(x_45, 0);
 lean_ctor_release(x_45, 1);
 x_60 = x_45;
} else {
 lean_dec_ref(x_45);
 x_60 = lean_box(0);
}
if (lean_is_scalar(x_60)) {
 x_61 = lean_alloc_ctor(1, 2, 0);
} else {
 x_61 = x_60;
}
lean_ctor_set(x_61, 0, x_58);
lean_ctor_set(x_61, 1, x_59);
return x_61;
}
}
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(7u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("custom_unfold_or_defeq_context", 30);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; uint8_t x_12; 
x_11 = lean_st_ref_get(x_9, x_10);
x_12 = !lean_is_exclusive(x_11);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_13 = lean_ctor_get(x_11, 0);
x_14 = lean_ctor_get(x_11, 1);
x_15 = lean_ctor_get(x_13, 0);
lean_inc(x_15);
lean_dec(x_13);
x_16 = lean_ctor_get(x_8, 5);
lean_inc(x_16);
x_17 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId(x_15, x_14);
if (lean_obj_tag(x_17) == 0)
{
lean_object* x_18; 
lean_dec(x_16);
lean_free_object(x_11);
x_18 = lean_ctor_get(x_6, 5);
lean_inc(x_18);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; 
x_19 = lean_ctor_get(x_6, 3);
lean_inc(x_19);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; size_t x_34; size_t x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; uint8_t x_43; lean_object* x_44; uint8_t x_45; lean_object* x_46; uint8_t x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; 
x_20 = lean_ctor_get(x_17, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_17, 1);
lean_inc(x_21);
lean_dec(x_17);
x_22 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity(x_1);
x_23 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3;
x_24 = lean_array_push(x_23, x_22);
x_25 = lean_ctor_get(x_8, 6);
lean_inc(x_25);
x_26 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_25);
x_27 = lean_ctor_get(x_8, 7);
lean_inc(x_27);
x_28 = lean_box(0);
x_29 = l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__1(x_27, x_28);
x_30 = l_List_redLength___rarg(x_29);
x_31 = lean_mk_empty_array_with_capacity(x_30);
lean_dec(x_30);
x_32 = l_List_toArrayAux___rarg(x_29, x_31);
x_33 = lean_array_get_size(x_32);
x_34 = lean_usize_of_nat(x_33);
lean_dec(x_33);
x_35 = 0;
x_36 = l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__2(x_34, x_35, x_32);
x_37 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_37, 0, x_36);
x_38 = lean_ctor_get(x_6, 0);
lean_inc(x_38);
x_39 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity(x_38);
lean_dec(x_38);
x_40 = lean_ctor_get(x_6, 4);
lean_inc(x_40);
x_41 = l_Lean_JsonNumber_fromNat(x_40);
x_42 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_42, 0, x_41);
x_43 = lean_ctor_get_uint8(x_6, sizeof(void*)*6);
x_44 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_44, 0, x_43);
x_45 = lean_ctor_get_uint8(x_6, sizeof(void*)*6 + 1);
x_46 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_46, 0, x_45);
x_47 = lean_ctor_get_uint8(x_2, sizeof(void*)*1);
x_48 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_48, 0, x_47);
x_49 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__1;
x_50 = lean_array_push(x_49, x_26);
x_51 = lean_array_push(x_50, x_37);
x_52 = lean_array_push(x_51, x_39);
x_53 = lean_array_push(x_52, x_42);
x_54 = lean_array_push(x_53, x_44);
x_55 = lean_array_push(x_54, x_46);
x_56 = lean_array_push(x_55, x_48);
x_57 = l_Array_append___rarg(x_24, x_56);
x_58 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_59 = lean_box(0);
x_60 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__2(x_35, x_20, x_58, x_57, x_59, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_21);
return x_60;
}
else
{
uint8_t x_61; 
lean_dec(x_19);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_61 = !lean_is_exclusive(x_17);
if (x_61 == 0)
{
lean_object* x_62; lean_object* x_63; 
x_62 = lean_ctor_get(x_17, 0);
lean_dec(x_62);
x_63 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3;
lean_ctor_set(x_17, 0, x_63);
return x_17;
}
else
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_64 = lean_ctor_get(x_17, 1);
lean_inc(x_64);
lean_dec(x_17);
x_65 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3;
x_66 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_66, 0, x_65);
lean_ctor_set(x_66, 1, x_64);
return x_66;
}
}
}
else
{
uint8_t x_67; 
lean_dec(x_18);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_67 = !lean_is_exclusive(x_17);
if (x_67 == 0)
{
lean_object* x_68; lean_object* x_69; 
x_68 = lean_ctor_get(x_17, 0);
lean_dec(x_68);
x_69 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3;
lean_ctor_set(x_17, 0, x_69);
return x_17;
}
else
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; 
x_70 = lean_ctor_get(x_17, 1);
lean_inc(x_70);
lean_dec(x_17);
x_71 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3;
x_72 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_72, 0, x_71);
lean_ctor_set(x_72, 1, x_70);
return x_72;
}
}
}
else
{
uint8_t x_73; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_73 = !lean_is_exclusive(x_17);
if (x_73 == 0)
{
lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; 
x_74 = lean_ctor_get(x_17, 0);
x_75 = lean_io_error_to_string(x_74);
x_76 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_76, 0, x_75);
x_77 = l_Lean_MessageData_ofFormat(x_76);
lean_ctor_set(x_11, 1, x_77);
lean_ctor_set(x_11, 0, x_16);
lean_ctor_set(x_17, 0, x_11);
return x_17;
}
else
{
lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; 
x_78 = lean_ctor_get(x_17, 0);
x_79 = lean_ctor_get(x_17, 1);
lean_inc(x_79);
lean_inc(x_78);
lean_dec(x_17);
x_80 = lean_io_error_to_string(x_78);
x_81 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_81, 0, x_80);
x_82 = l_Lean_MessageData_ofFormat(x_81);
lean_ctor_set(x_11, 1, x_82);
lean_ctor_set(x_11, 0, x_16);
x_83 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_83, 0, x_11);
lean_ctor_set(x_83, 1, x_79);
return x_83;
}
}
}
else
{
lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; 
x_84 = lean_ctor_get(x_11, 0);
x_85 = lean_ctor_get(x_11, 1);
lean_inc(x_85);
lean_inc(x_84);
lean_dec(x_11);
x_86 = lean_ctor_get(x_84, 0);
lean_inc(x_86);
lean_dec(x_84);
x_87 = lean_ctor_get(x_8, 5);
lean_inc(x_87);
x_88 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId(x_86, x_85);
if (lean_obj_tag(x_88) == 0)
{
lean_object* x_89; 
lean_dec(x_87);
x_89 = lean_ctor_get(x_6, 5);
lean_inc(x_89);
if (lean_obj_tag(x_89) == 0)
{
lean_object* x_90; 
x_90 = lean_ctor_get(x_6, 3);
lean_inc(x_90);
if (lean_obj_tag(x_90) == 0)
{
lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; size_t x_105; size_t x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; uint8_t x_114; lean_object* x_115; uint8_t x_116; lean_object* x_117; uint8_t x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; 
x_91 = lean_ctor_get(x_88, 0);
lean_inc(x_91);
x_92 = lean_ctor_get(x_88, 1);
lean_inc(x_92);
lean_dec(x_88);
x_93 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity(x_1);
x_94 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3;
x_95 = lean_array_push(x_94, x_93);
x_96 = lean_ctor_get(x_8, 6);
lean_inc(x_96);
x_97 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity(x_96);
x_98 = lean_ctor_get(x_8, 7);
lean_inc(x_98);
x_99 = lean_box(0);
x_100 = l_List_mapTR_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__1(x_98, x_99);
x_101 = l_List_redLength___rarg(x_100);
x_102 = lean_mk_empty_array_with_capacity(x_101);
lean_dec(x_101);
x_103 = l_List_toArrayAux___rarg(x_100, x_102);
x_104 = lean_array_get_size(x_103);
x_105 = lean_usize_of_nat(x_104);
lean_dec(x_104);
x_106 = 0;
x_107 = l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__2(x_105, x_106, x_103);
x_108 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_108, 0, x_107);
x_109 = lean_ctor_get(x_6, 0);
lean_inc(x_109);
x_110 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity(x_109);
lean_dec(x_109);
x_111 = lean_ctor_get(x_6, 4);
lean_inc(x_111);
x_112 = l_Lean_JsonNumber_fromNat(x_111);
x_113 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_113, 0, x_112);
x_114 = lean_ctor_get_uint8(x_6, sizeof(void*)*6);
x_115 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_115, 0, x_114);
x_116 = lean_ctor_get_uint8(x_6, sizeof(void*)*6 + 1);
x_117 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_117, 0, x_116);
x_118 = lean_ctor_get_uint8(x_2, sizeof(void*)*1);
x_119 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_119, 0, x_118);
x_120 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__1;
x_121 = lean_array_push(x_120, x_97);
x_122 = lean_array_push(x_121, x_108);
x_123 = lean_array_push(x_122, x_110);
x_124 = lean_array_push(x_123, x_113);
x_125 = lean_array_push(x_124, x_115);
x_126 = lean_array_push(x_125, x_117);
x_127 = lean_array_push(x_126, x_119);
x_128 = l_Array_append___rarg(x_95, x_127);
x_129 = l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1;
x_130 = lean_box(0);
x_131 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__2(x_106, x_91, x_129, x_128, x_130, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_92);
return x_131;
}
else
{
lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; 
lean_dec(x_90);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_132 = lean_ctor_get(x_88, 1);
lean_inc(x_132);
if (lean_is_exclusive(x_88)) {
 lean_ctor_release(x_88, 0);
 lean_ctor_release(x_88, 1);
 x_133 = x_88;
} else {
 lean_dec_ref(x_88);
 x_133 = lean_box(0);
}
x_134 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3;
if (lean_is_scalar(x_133)) {
 x_135 = lean_alloc_ctor(0, 2, 0);
} else {
 x_135 = x_133;
}
lean_ctor_set(x_135, 0, x_134);
lean_ctor_set(x_135, 1, x_132);
return x_135;
}
}
else
{
lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; 
lean_dec(x_89);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_136 = lean_ctor_get(x_88, 1);
lean_inc(x_136);
if (lean_is_exclusive(x_88)) {
 lean_ctor_release(x_88, 0);
 lean_ctor_release(x_88, 1);
 x_137 = x_88;
} else {
 lean_dec_ref(x_88);
 x_137 = lean_box(0);
}
x_138 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3;
if (lean_is_scalar(x_137)) {
 x_139 = lean_alloc_ctor(0, 2, 0);
} else {
 x_139 = x_137;
}
lean_ctor_set(x_139, 0, x_138);
lean_ctor_set(x_139, 1, x_136);
return x_139;
}
}
else
{
lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; lean_object* x_146; lean_object* x_147; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_140 = lean_ctor_get(x_88, 0);
lean_inc(x_140);
x_141 = lean_ctor_get(x_88, 1);
lean_inc(x_141);
if (lean_is_exclusive(x_88)) {
 lean_ctor_release(x_88, 0);
 lean_ctor_release(x_88, 1);
 x_142 = x_88;
} else {
 lean_dec_ref(x_88);
 x_142 = lean_box(0);
}
x_143 = lean_io_error_to_string(x_140);
x_144 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_144, 0, x_143);
x_145 = l_Lean_MessageData_ofFormat(x_144);
x_146 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_146, 0, x_87);
lean_ctor_set(x_146, 1, x_145);
if (lean_is_scalar(x_142)) {
 x_147 = lean_alloc_ctor(1, 2, 0);
} else {
 x_147 = x_142;
}
lean_ctor_set(x_147, 0, x_146);
lean_ctor_set(x_147, 1, x_141);
return x_147;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
size_t x_17; size_t x_18; lean_object* x_19; 
x_17 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_18 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_19 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__4(x_1, x_2, x_3, x_4, x_17, x_18, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
lean_dec(x_4);
return x_19;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
lean_object* x_16; 
x_16 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
return x_16;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
lean_object* x_15; 
x_15 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
lean_dec(x_5);
return x_15;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
size_t x_16; size_t x_17; lean_object* x_18; 
x_16 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_17 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_18 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5(x_1, x_2, x_3, x_16, x_17, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_3);
return x_18;
}
}
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; 
x_12 = l_Lean_PersistentArray_forInAux___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__3___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_12;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
size_t x_16; size_t x_17; lean_object* x_18; 
x_16 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_17 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_18 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__6(x_1, x_2, x_3, x_16, x_17, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_3);
return x_18;
}
}
LEAN_EXPORT lean_object* l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
lean_object* x_12; 
x_12 = l_Lean_PersistentArray_forIn___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__2___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_12;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
lean_object* x_16; 
x_16 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
return x_16;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15) {
_start:
{
size_t x_16; size_t x_17; lean_object* x_18; 
x_16 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_17 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_18 = l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7(x_1, x_2, x_3, x_16, x_17, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_3);
lean_dec(x_2);
return x_18;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14, lean_object* x_15, lean_object* x_16) {
_start:
{
lean_object* x_17; 
x_17 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
return x_17;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__2___boxed(lean_object** _args) {
lean_object* x_1 = _args[0];
lean_object* x_2 = _args[1];
lean_object* x_3 = _args[2];
lean_object* x_4 = _args[3];
lean_object* x_5 = _args[4];
lean_object* x_6 = _args[5];
lean_object* x_7 = _args[6];
lean_object* x_8 = _args[7];
lean_object* x_9 = _args[8];
lean_object* x_10 = _args[9];
lean_object* x_11 = _args[10];
lean_object* x_12 = _args[11];
lean_object* x_13 = _args[12];
lean_object* x_14 = _args[13];
lean_object* x_15 = _args[14];
lean_object* x_16 = _args[15];
lean_object* x_17 = _args[16];
lean_object* x_18 = _args[17];
lean_object* x_19 = _args[18];
_start:
{
size_t x_20; lean_object* x_21; 
x_20 = lean_unbox_usize(x_6);
lean_dec(x_6);
x_21 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__2(x_1, x_2, x_3, x_4, x_5, x_20, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_18, x_19);
lean_dec(x_18);
lean_dec(x_17);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_12);
lean_dec(x_11);
return x_21;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___boxed(lean_object** _args) {
lean_object* x_1 = _args[0];
lean_object* x_2 = _args[1];
lean_object* x_3 = _args[2];
lean_object* x_4 = _args[3];
lean_object* x_5 = _args[4];
lean_object* x_6 = _args[5];
lean_object* x_7 = _args[6];
lean_object* x_8 = _args[7];
lean_object* x_9 = _args[8];
lean_object* x_10 = _args[9];
lean_object* x_11 = _args[10];
lean_object* x_12 = _args[11];
lean_object* x_13 = _args[12];
lean_object* x_14 = _args[13];
lean_object* x_15 = _args[14];
lean_object* x_16 = _args[15];
lean_object* x_17 = _args[16];
lean_object* x_18 = _args[17];
_start:
{
size_t x_19; lean_object* x_20; 
x_19 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_20 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3(x_1, x_2, x_3, x_4, x_19, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14, x_15, x_16, x_17, x_18);
return x_20;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
size_t x_14; lean_object* x_15; 
x_14 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_15 = l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8(x_14, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
return x_15;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13) {
_start:
{
lean_object* x_14; 
x_14 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13);
lean_dec(x_12);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
return x_14;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12, lean_object* x_13, lean_object* x_14) {
_start:
{
size_t x_15; lean_object* x_16; 
x_15 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_16 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__2(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12, x_13, x_14);
return x_16;
}
}
static lean_object* _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("[gpu-smt-state-reuse] ", 22);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = l_Lean_Json_mkObj(x_1);
x_4 = l_Lean_Json_compress(x_3);
x_5 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit___closed__1;
x_6 = lean_string_append(x_5, x_4);
lean_dec(x_4);
x_7 = l_IO_eprintln___at___private_Init_System_IO_0__IO_eprintlnAux___spec__1(x_6, x_2);
return x_7;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("GpuSmt", 6);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("StateReuseProfile", 17);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("observeState", 12);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_GpuSmt_StateReuseProfile_observeState___closed__1;
x_2 = l_GpuSmt_StateReuseProfile_observeState___closed__2;
x_3 = l_GpuSmt_StateReuseProfile_observeState___closed__3;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("andthen", 7);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_GpuSmt_StateReuseProfile_observeState___closed__5;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("observe_state ", 14);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__8() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_GpuSmt_StateReuseProfile_observeState___closed__7;
x_2 = 0;
x_3 = lean_alloc_ctor(6, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("tactic", 6);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_GpuSmt_StateReuseProfile_observeState___closed__9;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_GpuSmt_StateReuseProfile_observeState___closed__10;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_GpuSmt_StateReuseProfile_observeState___closed__6;
x_2 = l_GpuSmt_StateReuseProfile_observeState___closed__8;
x_3 = l_GpuSmt_StateReuseProfile_observeState___closed__11;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_GpuSmt_StateReuseProfile_observeState___closed__4;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_GpuSmt_StateReuseProfile_observeState___closed__12;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile_observeState() {
_start:
{
lean_object* x_1; 
x_1 = l_GpuSmt_StateReuseProfile_observeState___closed__13;
return x_1;
}
}
LEAN_EXPORT lean_object* l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; 
x_3 = l_List_reverse___rarg(x_2);
return x_3;
}
else
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_1);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; uint8_t x_7; uint8_t x_8; uint8_t x_9; 
x_5 = lean_ctor_get(x_1, 0);
x_6 = lean_ctor_get(x_1, 1);
x_7 = lean_ctor_get_uint8(x_5, sizeof(void*)*5 + 1);
x_8 = 2;
x_9 = l___private_Lean_Message_0__Lean_beqMessageSeverity____x40_Lean_Message___hyg_106_(x_7, x_8);
if (x_9 == 0)
{
lean_free_object(x_1);
lean_dec(x_5);
x_1 = x_6;
goto _start;
}
else
{
lean_ctor_set(x_1, 1, x_2);
{
lean_object* _tmp_0 = x_6;
lean_object* _tmp_1 = x_1;
x_1 = _tmp_0;
x_2 = _tmp_1;
}
goto _start;
}
}
else
{
lean_object* x_12; lean_object* x_13; uint8_t x_14; uint8_t x_15; uint8_t x_16; 
x_12 = lean_ctor_get(x_1, 0);
x_13 = lean_ctor_get(x_1, 1);
lean_inc(x_13);
lean_inc(x_12);
lean_dec(x_1);
x_14 = lean_ctor_get_uint8(x_12, sizeof(void*)*5 + 1);
x_15 = 2;
x_16 = l___private_Lean_Message_0__Lean_beqMessageSeverity____x40_Lean_Message___hyg_106_(x_14, x_15);
if (x_16 == 0)
{
lean_dec(x_12);
x_1 = x_13;
goto _start;
}
else
{
lean_object* x_18; 
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_12);
lean_ctor_set(x_18, 1, x_2);
x_1 = x_13;
x_2 = x_18;
goto _start;
}
}
}
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("begin", 5);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("event", 5);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__3;
x_2 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("call", 4);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("eligibility", 11);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("source", 6);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("kind", 4);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("capture_ns", 10);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__10() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 0;
x_2 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("replay_qualified", 16);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__11;
x_2 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__10;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__12;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("key", 3);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__15() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("end", 3);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__15;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__3;
x_2 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__16;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("outcome", 7);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("elapsed_ns", 10);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("heartbeats", 10);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("remaining_goals", 15);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("new_error_messages", 18);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("returned", 8);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("native_error", 12);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("internal_exception", 18);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("interrupted", 11);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("recursion_limit", 15);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("heartbeat_limit", 15);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("environment", 11);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("byte", 4);
return x_1;
}
}
static lean_object* _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
x_2 = lean_box(0);
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; uint8_t x_12; 
x_11 = l_GpuSmt_StateReuseProfile_observeState___closed__4;
lean_inc(x_1);
x_12 = l_Lean_Syntax_isOfKind(x_1, x_11);
if (x_12 == 0)
{
lean_object* x_13; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_13 = l_Lean_Elab_throwUnsupportedSyntax___at_Lean_Elab_Tactic_Rfl_evalApplyRfl___spec__1___rarg(x_10);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_14 = lean_unsigned_to_nat(1u);
x_15 = l_Lean_Syntax_getArg(x_1, x_14);
lean_dec(x_1);
x_16 = lean_io_mono_nanos_now(x_10);
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_18 = lean_ctor_get(x_16, 0);
x_19 = lean_ctor_get(x_16, 1);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_15);
x_20 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_19);
if (lean_obj_tag(x_20) == 0)
{
lean_object* x_21; lean_object* x_22; uint8_t x_23; 
x_21 = lean_ctor_get(x_20, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_20, 1);
lean_inc(x_22);
lean_dec(x_20);
x_23 = !lean_is_exclusive(x_21);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_24 = lean_ctor_get(x_21, 0);
x_25 = lean_ctor_get(x_21, 1);
x_26 = lean_ctor_get(x_8, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_8, 5);
lean_inc(x_27);
lean_inc(x_24);
x_28 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register(x_24, x_22);
if (lean_obj_tag(x_28) == 0)
{
lean_object* x_29; lean_object* x_30; uint8_t x_31; 
x_29 = lean_ctor_get(x_28, 0);
lean_inc(x_29);
x_30 = lean_ctor_get(x_28, 1);
lean_inc(x_30);
lean_dec(x_28);
x_31 = !lean_is_exclusive(x_29);
if (x_31 == 0)
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; 
x_32 = lean_ctor_get(x_29, 0);
x_33 = lean_ctor_get(x_29, 1);
x_34 = lean_io_mono_nanos_now(x_30);
x_35 = !lean_is_exclusive(x_34);
if (x_35 == 0)
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; uint8_t x_46; lean_object* x_47; lean_object* x_48; uint8_t x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
x_36 = lean_ctor_get(x_34, 0);
x_37 = lean_ctor_get(x_34, 1);
x_38 = lean_nat_sub(x_36, x_18);
lean_dec(x_18);
lean_dec(x_36);
x_39 = l_Lean_JsonNumber_fromNat(x_32);
x_40 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_40, 0, x_39);
x_41 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5;
lean_ctor_set(x_29, 1, x_40);
lean_ctor_set(x_29, 0, x_41);
x_42 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_42, 0, x_25);
x_43 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6;
lean_ctor_set(x_21, 1, x_42);
lean_ctor_set(x_21, 0, x_43);
x_44 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_44, 0, x_26);
x_45 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7;
lean_ctor_set(x_34, 1, x_44);
lean_ctor_set(x_34, 0, x_45);
x_46 = 0;
x_47 = l_Lean_Syntax_getPos_x3f(x_15, x_46);
lean_inc(x_15);
x_48 = l_Lean_Syntax_getKind(x_15);
x_49 = 1;
x_50 = l_Lean_Name_toString(x_48, x_49);
x_51 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_51, 0, x_50);
x_52 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8;
lean_ctor_set(x_16, 1, x_51);
lean_ctor_set(x_16, 0, x_52);
x_53 = l_Lean_JsonNumber_fromNat(x_38);
x_54 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_54, 0, x_53);
x_55 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9;
x_56 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_56, 0, x_55);
lean_ctor_set(x_56, 1, x_54);
x_57 = lean_box(0);
x_58 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13;
x_59 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_59, 0, x_56);
lean_ctor_set(x_59, 1, x_58);
x_60 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_60, 0, x_16);
lean_ctor_set(x_60, 1, x_59);
if (lean_obj_tag(x_33) == 0)
{
lean_object* x_282; 
x_282 = lean_box(0);
x_61 = x_282;
goto block_281;
}
else
{
uint8_t x_283; 
x_283 = !lean_is_exclusive(x_33);
if (x_283 == 0)
{
lean_object* x_284; lean_object* x_285; 
x_284 = lean_ctor_get(x_33, 0);
x_285 = l_Lean_JsonNumber_fromNat(x_284);
lean_ctor_set_tag(x_33, 2);
lean_ctor_set(x_33, 0, x_285);
x_61 = x_33;
goto block_281;
}
else
{
lean_object* x_286; lean_object* x_287; lean_object* x_288; 
x_286 = lean_ctor_get(x_33, 0);
lean_inc(x_286);
lean_dec(x_33);
x_287 = l_Lean_JsonNumber_fromNat(x_286);
x_288 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_288, 0, x_287);
x_61 = x_288;
goto block_281;
}
}
block_281:
{
lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_193; 
x_62 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14;
x_63 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_63, 0, x_62);
lean_ctor_set(x_63, 1, x_61);
if (lean_obj_tag(x_24) == 0)
{
lean_object* x_272; 
x_272 = lean_box(0);
x_193 = x_272;
goto block_271;
}
else
{
uint8_t x_273; 
x_273 = !lean_is_exclusive(x_24);
if (x_273 == 0)
{
lean_object* x_274; lean_object* x_275; lean_object* x_276; 
x_274 = lean_ctor_get(x_24, 0);
x_275 = lean_ctor_get(x_274, 0);
lean_inc(x_275);
lean_dec(x_274);
x_276 = l_Lean_JsonNumber_fromNat(x_275);
lean_ctor_set_tag(x_24, 2);
lean_ctor_set(x_24, 0, x_276);
x_193 = x_24;
goto block_271;
}
else
{
lean_object* x_277; lean_object* x_278; lean_object* x_279; lean_object* x_280; 
x_277 = lean_ctor_get(x_24, 0);
lean_inc(x_277);
lean_dec(x_24);
x_278 = lean_ctor_get(x_277, 0);
lean_inc(x_278);
lean_dec(x_277);
x_279 = l_Lean_JsonNumber_fromNat(x_278);
x_280 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_280, 0, x_279);
x_193 = x_280;
goto block_271;
}
}
block_192:
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_186; 
x_65 = lean_st_ref_get(x_9, x_64);
x_66 = lean_ctor_get(x_65, 0);
lean_inc(x_66);
x_67 = lean_ctor_get(x_65, 1);
lean_inc(x_67);
if (lean_is_exclusive(x_65)) {
 lean_ctor_release(x_65, 0);
 lean_ctor_release(x_65, 1);
 x_68 = x_65;
} else {
 lean_dec_ref(x_65);
 x_68 = lean_box(0);
}
x_69 = lean_ctor_get(x_66, 5);
lean_inc(x_69);
lean_dec(x_66);
x_70 = l_Lean_MessageLog_toList(x_69);
x_71 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_70, x_57);
x_72 = lean_unsigned_to_nat(0u);
x_73 = l_List_lengthTRAux___rarg(x_71, x_72);
lean_dec(x_71);
x_74 = lean_io_mono_nanos_now(x_67);
x_75 = lean_ctor_get(x_74, 0);
lean_inc(x_75);
x_76 = lean_ctor_get(x_74, 1);
lean_inc(x_76);
if (lean_is_exclusive(x_74)) {
 lean_ctor_release(x_74, 0);
 lean_ctor_release(x_74, 1);
 x_77 = x_74;
} else {
 lean_dec_ref(x_74);
 x_77 = lean_box(0);
}
x_78 = lean_io_get_num_heartbeats(x_76);
x_79 = lean_ctor_get(x_78, 0);
lean_inc(x_79);
x_80 = lean_ctor_get(x_78, 1);
lean_inc(x_80);
if (lean_is_exclusive(x_78)) {
 lean_ctor_release(x_78, 0);
 lean_ctor_release(x_78, 1);
 x_81 = x_78;
} else {
 lean_dec_ref(x_78);
 x_81 = lean_box(0);
}
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
x_186 = l_Lean_Elab_Tactic_evalTactic(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_80);
if (lean_obj_tag(x_186) == 0)
{
lean_object* x_187; lean_object* x_188; 
x_187 = lean_ctor_get(x_186, 1);
lean_inc(x_187);
lean_dec(x_186);
x_188 = lean_box(0);
x_82 = x_188;
x_83 = x_187;
goto block_185;
}
else
{
lean_object* x_189; lean_object* x_190; lean_object* x_191; 
x_189 = lean_ctor_get(x_186, 0);
lean_inc(x_189);
x_190 = lean_ctor_get(x_186, 1);
lean_inc(x_190);
lean_dec(x_186);
x_191 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_191, 0, x_189);
x_82 = x_191;
x_83 = x_190;
goto block_185;
}
block_185:
{
lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_162; 
x_84 = lean_io_get_num_heartbeats(x_83);
x_85 = lean_ctor_get(x_84, 0);
lean_inc(x_85);
x_86 = lean_ctor_get(x_84, 1);
lean_inc(x_86);
if (lean_is_exclusive(x_84)) {
 lean_ctor_release(x_84, 0);
 lean_ctor_release(x_84, 1);
 x_87 = x_84;
} else {
 lean_dec_ref(x_84);
 x_87 = lean_box(0);
}
x_88 = lean_nat_sub(x_85, x_79);
lean_dec(x_79);
lean_dec(x_85);
x_89 = lean_io_mono_nanos_now(x_86);
x_90 = lean_ctor_get(x_89, 0);
lean_inc(x_90);
x_91 = lean_ctor_get(x_89, 1);
lean_inc(x_91);
if (lean_is_exclusive(x_89)) {
 lean_ctor_release(x_89, 0);
 lean_ctor_release(x_89, 1);
 x_92 = x_89;
} else {
 lean_dec_ref(x_89);
 x_92 = lean_box(0);
}
x_93 = lean_nat_sub(x_90, x_75);
lean_dec(x_75);
lean_dec(x_90);
x_94 = lean_st_ref_get(x_9, x_91);
x_95 = lean_ctor_get(x_94, 0);
lean_inc(x_95);
x_96 = lean_ctor_get(x_94, 1);
lean_inc(x_96);
if (lean_is_exclusive(x_94)) {
 lean_ctor_release(x_94, 0);
 lean_ctor_release(x_94, 1);
 x_97 = x_94;
} else {
 lean_dec_ref(x_94);
 x_97 = lean_box(0);
}
x_98 = lean_ctor_get(x_95, 5);
lean_inc(x_98);
lean_dec(x_95);
x_99 = l_Lean_MessageLog_toList(x_98);
x_100 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_99, x_57);
x_101 = l_List_lengthTRAux___rarg(x_100, x_72);
lean_dec(x_100);
x_162 = l_Lean_Elab_Tactic_getGoals___rarg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_96);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
if (lean_obj_tag(x_82) == 0)
{
lean_object* x_163; lean_object* x_164; lean_object* x_165; 
x_163 = lean_ctor_get(x_162, 0);
lean_inc(x_163);
x_164 = lean_ctor_get(x_162, 1);
lean_inc(x_164);
lean_dec(x_162);
x_165 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23;
x_102 = x_165;
x_103 = x_163;
x_104 = x_164;
goto block_161;
}
else
{
lean_object* x_166; uint8_t x_167; 
x_166 = lean_ctor_get(x_82, 0);
lean_inc(x_166);
x_167 = l_Lean_Exception_isMaxHeartbeat(x_166);
if (x_167 == 0)
{
uint8_t x_168; 
x_168 = l_Lean_Exception_isMaxRecDepth(x_166);
if (x_168 == 0)
{
uint8_t x_169; 
x_169 = l_Lean_Exception_isInterrupt(x_166);
if (x_169 == 0)
{
if (lean_obj_tag(x_166) == 0)
{
lean_object* x_170; lean_object* x_171; lean_object* x_172; 
lean_dec(x_166);
x_170 = lean_ctor_get(x_162, 0);
lean_inc(x_170);
x_171 = lean_ctor_get(x_162, 1);
lean_inc(x_171);
lean_dec(x_162);
x_172 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24;
x_102 = x_172;
x_103 = x_170;
x_104 = x_171;
goto block_161;
}
else
{
lean_object* x_173; lean_object* x_174; lean_object* x_175; 
lean_dec(x_166);
x_173 = lean_ctor_get(x_162, 0);
lean_inc(x_173);
x_174 = lean_ctor_get(x_162, 1);
lean_inc(x_174);
lean_dec(x_162);
x_175 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25;
x_102 = x_175;
x_103 = x_173;
x_104 = x_174;
goto block_161;
}
}
else
{
lean_object* x_176; lean_object* x_177; lean_object* x_178; 
lean_dec(x_166);
x_176 = lean_ctor_get(x_162, 0);
lean_inc(x_176);
x_177 = lean_ctor_get(x_162, 1);
lean_inc(x_177);
lean_dec(x_162);
x_178 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26;
x_102 = x_178;
x_103 = x_176;
x_104 = x_177;
goto block_161;
}
}
else
{
lean_object* x_179; lean_object* x_180; lean_object* x_181; 
lean_dec(x_166);
x_179 = lean_ctor_get(x_162, 0);
lean_inc(x_179);
x_180 = lean_ctor_get(x_162, 1);
lean_inc(x_180);
lean_dec(x_162);
x_181 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27;
x_102 = x_181;
x_103 = x_179;
x_104 = x_180;
goto block_161;
}
}
else
{
lean_object* x_182; lean_object* x_183; lean_object* x_184; 
lean_dec(x_166);
x_182 = lean_ctor_get(x_162, 0);
lean_inc(x_182);
x_183 = lean_ctor_get(x_162, 1);
lean_inc(x_183);
lean_dec(x_162);
x_184 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28;
x_102 = x_184;
x_103 = x_182;
x_104 = x_183;
goto block_161;
}
}
block_161:
{
lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; 
x_105 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_105, 0, x_102);
x_106 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18;
if (lean_is_scalar(x_97)) {
 x_107 = lean_alloc_ctor(0, 2, 0);
} else {
 x_107 = x_97;
}
lean_ctor_set(x_107, 0, x_106);
lean_ctor_set(x_107, 1, x_105);
x_108 = l_Lean_JsonNumber_fromNat(x_93);
x_109 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_109, 0, x_108);
x_110 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19;
if (lean_is_scalar(x_92)) {
 x_111 = lean_alloc_ctor(0, 2, 0);
} else {
 x_111 = x_92;
}
lean_ctor_set(x_111, 0, x_110);
lean_ctor_set(x_111, 1, x_109);
x_112 = l_Lean_JsonNumber_fromNat(x_88);
x_113 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_113, 0, x_112);
x_114 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20;
if (lean_is_scalar(x_87)) {
 x_115 = lean_alloc_ctor(0, 2, 0);
} else {
 x_115 = x_87;
}
lean_ctor_set(x_115, 0, x_114);
lean_ctor_set(x_115, 1, x_113);
x_116 = l_List_lengthTRAux___rarg(x_103, x_72);
lean_dec(x_103);
x_117 = l_Lean_JsonNumber_fromNat(x_116);
x_118 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_118, 0, x_117);
x_119 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21;
if (lean_is_scalar(x_81)) {
 x_120 = lean_alloc_ctor(0, 2, 0);
} else {
 x_120 = x_81;
}
lean_ctor_set(x_120, 0, x_119);
lean_ctor_set(x_120, 1, x_118);
x_121 = lean_nat_sub(x_101, x_73);
lean_dec(x_73);
lean_dec(x_101);
x_122 = l_Lean_JsonNumber_fromNat(x_121);
x_123 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_123, 0, x_122);
x_124 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22;
if (lean_is_scalar(x_77)) {
 x_125 = lean_alloc_ctor(0, 2, 0);
} else {
 x_125 = x_77;
}
lean_ctor_set(x_125, 0, x_124);
lean_ctor_set(x_125, 1, x_123);
if (lean_is_scalar(x_68)) {
 x_126 = lean_alloc_ctor(1, 2, 0);
} else {
 x_126 = x_68;
 lean_ctor_set_tag(x_126, 1);
}
lean_ctor_set(x_126, 0, x_125);
lean_ctor_set(x_126, 1, x_58);
x_127 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_127, 0, x_120);
lean_ctor_set(x_127, 1, x_126);
x_128 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_128, 0, x_115);
lean_ctor_set(x_128, 1, x_127);
x_129 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_129, 0, x_111);
lean_ctor_set(x_129, 1, x_128);
x_130 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_130, 0, x_107);
lean_ctor_set(x_130, 1, x_129);
x_131 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_131, 0, x_63);
lean_ctor_set(x_131, 1, x_130);
x_132 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_132, 0, x_29);
lean_ctor_set(x_132, 1, x_131);
x_133 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17;
x_134 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_134, 0, x_133);
lean_ctor_set(x_134, 1, x_132);
x_135 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_134, x_104);
if (lean_obj_tag(x_135) == 0)
{
lean_dec(x_27);
if (lean_obj_tag(x_82) == 0)
{
uint8_t x_136; 
x_136 = !lean_is_exclusive(x_135);
if (x_136 == 0)
{
lean_object* x_137; lean_object* x_138; 
x_137 = lean_ctor_get(x_135, 0);
lean_dec(x_137);
x_138 = lean_box(0);
lean_ctor_set(x_135, 0, x_138);
return x_135;
}
else
{
lean_object* x_139; lean_object* x_140; lean_object* x_141; 
x_139 = lean_ctor_get(x_135, 1);
lean_inc(x_139);
lean_dec(x_135);
x_140 = lean_box(0);
x_141 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_141, 0, x_140);
lean_ctor_set(x_141, 1, x_139);
return x_141;
}
}
else
{
uint8_t x_142; 
x_142 = !lean_is_exclusive(x_135);
if (x_142 == 0)
{
lean_object* x_143; lean_object* x_144; 
x_143 = lean_ctor_get(x_135, 0);
lean_dec(x_143);
x_144 = lean_ctor_get(x_82, 0);
lean_inc(x_144);
lean_dec(x_82);
lean_ctor_set_tag(x_135, 1);
lean_ctor_set(x_135, 0, x_144);
return x_135;
}
else
{
lean_object* x_145; lean_object* x_146; lean_object* x_147; 
x_145 = lean_ctor_get(x_135, 1);
lean_inc(x_145);
lean_dec(x_135);
x_146 = lean_ctor_get(x_82, 0);
lean_inc(x_146);
lean_dec(x_82);
x_147 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_147, 0, x_146);
lean_ctor_set(x_147, 1, x_145);
return x_147;
}
}
}
else
{
uint8_t x_148; 
lean_dec(x_82);
x_148 = !lean_is_exclusive(x_135);
if (x_148 == 0)
{
lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; 
x_149 = lean_ctor_get(x_135, 0);
x_150 = lean_io_error_to_string(x_149);
x_151 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_151, 0, x_150);
x_152 = l_Lean_MessageData_ofFormat(x_151);
x_153 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_153, 0, x_27);
lean_ctor_set(x_153, 1, x_152);
lean_ctor_set(x_135, 0, x_153);
return x_135;
}
else
{
lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; 
x_154 = lean_ctor_get(x_135, 0);
x_155 = lean_ctor_get(x_135, 1);
lean_inc(x_155);
lean_inc(x_154);
lean_dec(x_135);
x_156 = lean_io_error_to_string(x_154);
x_157 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_157, 0, x_156);
x_158 = l_Lean_MessageData_ofFormat(x_157);
x_159 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_159, 0, x_27);
lean_ctor_set(x_159, 1, x_158);
x_160 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_160, 0, x_159);
lean_ctor_set(x_160, 1, x_155);
return x_160;
}
}
}
}
}
block_271:
{
lean_object* x_194; lean_object* x_195; 
x_194 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29;
x_195 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_195, 0, x_194);
lean_ctor_set(x_195, 1, x_193);
if (lean_obj_tag(x_47) == 0)
{
lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; lean_object* x_200; lean_object* x_201; lean_object* x_202; lean_object* x_203; lean_object* x_204; lean_object* x_205; 
x_196 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31;
x_197 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_197, 0, x_196);
lean_ctor_set(x_197, 1, x_60);
x_198 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_198, 0, x_34);
lean_ctor_set(x_198, 1, x_197);
x_199 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_199, 0, x_21);
lean_ctor_set(x_199, 1, x_198);
x_200 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_200, 0, x_195);
lean_ctor_set(x_200, 1, x_199);
lean_inc(x_63);
x_201 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_201, 0, x_63);
lean_ctor_set(x_201, 1, x_200);
lean_inc(x_29);
x_202 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_202, 0, x_29);
lean_ctor_set(x_202, 1, x_201);
x_203 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_204 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_204, 0, x_203);
lean_ctor_set(x_204, 1, x_202);
x_205 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_204, x_37);
if (lean_obj_tag(x_205) == 0)
{
lean_object* x_206; 
x_206 = lean_ctor_get(x_205, 1);
lean_inc(x_206);
lean_dec(x_205);
x_64 = x_206;
goto block_192;
}
else
{
uint8_t x_207; 
lean_dec(x_63);
lean_dec(x_29);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_207 = !lean_is_exclusive(x_205);
if (x_207 == 0)
{
lean_object* x_208; lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; 
x_208 = lean_ctor_get(x_205, 0);
x_209 = lean_io_error_to_string(x_208);
x_210 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_210, 0, x_209);
x_211 = l_Lean_MessageData_ofFormat(x_210);
x_212 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_212, 0, x_27);
lean_ctor_set(x_212, 1, x_211);
lean_ctor_set(x_205, 0, x_212);
return x_205;
}
else
{
lean_object* x_213; lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; 
x_213 = lean_ctor_get(x_205, 0);
x_214 = lean_ctor_get(x_205, 1);
lean_inc(x_214);
lean_inc(x_213);
lean_dec(x_205);
x_215 = lean_io_error_to_string(x_213);
x_216 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_216, 0, x_215);
x_217 = l_Lean_MessageData_ofFormat(x_216);
x_218 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_218, 0, x_27);
lean_ctor_set(x_218, 1, x_217);
x_219 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_219, 0, x_218);
lean_ctor_set(x_219, 1, x_214);
return x_219;
}
}
}
else
{
uint8_t x_220; 
x_220 = !lean_is_exclusive(x_47);
if (x_220 == 0)
{
lean_object* x_221; lean_object* x_222; lean_object* x_223; lean_object* x_224; lean_object* x_225; lean_object* x_226; lean_object* x_227; lean_object* x_228; lean_object* x_229; lean_object* x_230; lean_object* x_231; lean_object* x_232; lean_object* x_233; 
x_221 = lean_ctor_get(x_47, 0);
x_222 = l_Lean_JsonNumber_fromNat(x_221);
lean_ctor_set_tag(x_47, 2);
lean_ctor_set(x_47, 0, x_222);
x_223 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
x_224 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_224, 0, x_223);
lean_ctor_set(x_224, 1, x_47);
x_225 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_225, 0, x_224);
lean_ctor_set(x_225, 1, x_60);
x_226 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_226, 0, x_34);
lean_ctor_set(x_226, 1, x_225);
x_227 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_227, 0, x_21);
lean_ctor_set(x_227, 1, x_226);
x_228 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_228, 0, x_195);
lean_ctor_set(x_228, 1, x_227);
lean_inc(x_63);
x_229 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_229, 0, x_63);
lean_ctor_set(x_229, 1, x_228);
lean_inc(x_29);
x_230 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_230, 0, x_29);
lean_ctor_set(x_230, 1, x_229);
x_231 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_232 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_232, 0, x_231);
lean_ctor_set(x_232, 1, x_230);
x_233 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_232, x_37);
if (lean_obj_tag(x_233) == 0)
{
lean_object* x_234; 
x_234 = lean_ctor_get(x_233, 1);
lean_inc(x_234);
lean_dec(x_233);
x_64 = x_234;
goto block_192;
}
else
{
uint8_t x_235; 
lean_dec(x_63);
lean_dec(x_29);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_235 = !lean_is_exclusive(x_233);
if (x_235 == 0)
{
lean_object* x_236; lean_object* x_237; lean_object* x_238; lean_object* x_239; lean_object* x_240; 
x_236 = lean_ctor_get(x_233, 0);
x_237 = lean_io_error_to_string(x_236);
x_238 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_238, 0, x_237);
x_239 = l_Lean_MessageData_ofFormat(x_238);
x_240 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_240, 0, x_27);
lean_ctor_set(x_240, 1, x_239);
lean_ctor_set(x_233, 0, x_240);
return x_233;
}
else
{
lean_object* x_241; lean_object* x_242; lean_object* x_243; lean_object* x_244; lean_object* x_245; lean_object* x_246; lean_object* x_247; 
x_241 = lean_ctor_get(x_233, 0);
x_242 = lean_ctor_get(x_233, 1);
lean_inc(x_242);
lean_inc(x_241);
lean_dec(x_233);
x_243 = lean_io_error_to_string(x_241);
x_244 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_244, 0, x_243);
x_245 = l_Lean_MessageData_ofFormat(x_244);
x_246 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_246, 0, x_27);
lean_ctor_set(x_246, 1, x_245);
x_247 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_247, 0, x_246);
lean_ctor_set(x_247, 1, x_242);
return x_247;
}
}
}
else
{
lean_object* x_248; lean_object* x_249; lean_object* x_250; lean_object* x_251; lean_object* x_252; lean_object* x_253; lean_object* x_254; lean_object* x_255; lean_object* x_256; lean_object* x_257; lean_object* x_258; lean_object* x_259; lean_object* x_260; lean_object* x_261; 
x_248 = lean_ctor_get(x_47, 0);
lean_inc(x_248);
lean_dec(x_47);
x_249 = l_Lean_JsonNumber_fromNat(x_248);
x_250 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_250, 0, x_249);
x_251 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
x_252 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_252, 0, x_251);
lean_ctor_set(x_252, 1, x_250);
x_253 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_253, 0, x_252);
lean_ctor_set(x_253, 1, x_60);
x_254 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_254, 0, x_34);
lean_ctor_set(x_254, 1, x_253);
x_255 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_255, 0, x_21);
lean_ctor_set(x_255, 1, x_254);
x_256 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_256, 0, x_195);
lean_ctor_set(x_256, 1, x_255);
lean_inc(x_63);
x_257 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_257, 0, x_63);
lean_ctor_set(x_257, 1, x_256);
lean_inc(x_29);
x_258 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_258, 0, x_29);
lean_ctor_set(x_258, 1, x_257);
x_259 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_260 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_260, 0, x_259);
lean_ctor_set(x_260, 1, x_258);
x_261 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_260, x_37);
if (lean_obj_tag(x_261) == 0)
{
lean_object* x_262; 
x_262 = lean_ctor_get(x_261, 1);
lean_inc(x_262);
lean_dec(x_261);
x_64 = x_262;
goto block_192;
}
else
{
lean_object* x_263; lean_object* x_264; lean_object* x_265; lean_object* x_266; lean_object* x_267; lean_object* x_268; lean_object* x_269; lean_object* x_270; 
lean_dec(x_63);
lean_dec(x_29);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_263 = lean_ctor_get(x_261, 0);
lean_inc(x_263);
x_264 = lean_ctor_get(x_261, 1);
lean_inc(x_264);
if (lean_is_exclusive(x_261)) {
 lean_ctor_release(x_261, 0);
 lean_ctor_release(x_261, 1);
 x_265 = x_261;
} else {
 lean_dec_ref(x_261);
 x_265 = lean_box(0);
}
x_266 = lean_io_error_to_string(x_263);
x_267 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_267, 0, x_266);
x_268 = l_Lean_MessageData_ofFormat(x_267);
x_269 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_269, 0, x_27);
lean_ctor_set(x_269, 1, x_268);
if (lean_is_scalar(x_265)) {
 x_270 = lean_alloc_ctor(1, 2, 0);
} else {
 x_270 = x_265;
}
lean_ctor_set(x_270, 0, x_269);
lean_ctor_set(x_270, 1, x_264);
return x_270;
}
}
}
}
}
}
else
{
lean_object* x_289; lean_object* x_290; lean_object* x_291; lean_object* x_292; lean_object* x_293; lean_object* x_294; lean_object* x_295; lean_object* x_296; lean_object* x_297; lean_object* x_298; lean_object* x_299; uint8_t x_300; lean_object* x_301; lean_object* x_302; uint8_t x_303; lean_object* x_304; lean_object* x_305; lean_object* x_306; lean_object* x_307; lean_object* x_308; lean_object* x_309; lean_object* x_310; lean_object* x_311; lean_object* x_312; lean_object* x_313; lean_object* x_314; lean_object* x_315; 
x_289 = lean_ctor_get(x_34, 0);
x_290 = lean_ctor_get(x_34, 1);
lean_inc(x_290);
lean_inc(x_289);
lean_dec(x_34);
x_291 = lean_nat_sub(x_289, x_18);
lean_dec(x_18);
lean_dec(x_289);
x_292 = l_Lean_JsonNumber_fromNat(x_32);
x_293 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_293, 0, x_292);
x_294 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5;
lean_ctor_set(x_29, 1, x_293);
lean_ctor_set(x_29, 0, x_294);
x_295 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_295, 0, x_25);
x_296 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6;
lean_ctor_set(x_21, 1, x_295);
lean_ctor_set(x_21, 0, x_296);
x_297 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_297, 0, x_26);
x_298 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7;
x_299 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_299, 0, x_298);
lean_ctor_set(x_299, 1, x_297);
x_300 = 0;
x_301 = l_Lean_Syntax_getPos_x3f(x_15, x_300);
lean_inc(x_15);
x_302 = l_Lean_Syntax_getKind(x_15);
x_303 = 1;
x_304 = l_Lean_Name_toString(x_302, x_303);
x_305 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_305, 0, x_304);
x_306 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8;
lean_ctor_set(x_16, 1, x_305);
lean_ctor_set(x_16, 0, x_306);
x_307 = l_Lean_JsonNumber_fromNat(x_291);
x_308 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_308, 0, x_307);
x_309 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9;
x_310 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_310, 0, x_309);
lean_ctor_set(x_310, 1, x_308);
x_311 = lean_box(0);
x_312 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13;
x_313 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_313, 0, x_310);
lean_ctor_set(x_313, 1, x_312);
x_314 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_314, 0, x_16);
lean_ctor_set(x_314, 1, x_313);
if (lean_obj_tag(x_33) == 0)
{
lean_object* x_492; 
x_492 = lean_box(0);
x_315 = x_492;
goto block_491;
}
else
{
lean_object* x_493; lean_object* x_494; lean_object* x_495; lean_object* x_496; 
x_493 = lean_ctor_get(x_33, 0);
lean_inc(x_493);
if (lean_is_exclusive(x_33)) {
 lean_ctor_release(x_33, 0);
 x_494 = x_33;
} else {
 lean_dec_ref(x_33);
 x_494 = lean_box(0);
}
x_495 = l_Lean_JsonNumber_fromNat(x_493);
if (lean_is_scalar(x_494)) {
 x_496 = lean_alloc_ctor(2, 1, 0);
} else {
 x_496 = x_494;
 lean_ctor_set_tag(x_496, 2);
}
lean_ctor_set(x_496, 0, x_495);
x_315 = x_496;
goto block_491;
}
block_491:
{
lean_object* x_316; lean_object* x_317; lean_object* x_318; lean_object* x_438; 
x_316 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14;
x_317 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_317, 0, x_316);
lean_ctor_set(x_317, 1, x_315);
if (lean_obj_tag(x_24) == 0)
{
lean_object* x_485; 
x_485 = lean_box(0);
x_438 = x_485;
goto block_484;
}
else
{
lean_object* x_486; lean_object* x_487; lean_object* x_488; lean_object* x_489; lean_object* x_490; 
x_486 = lean_ctor_get(x_24, 0);
lean_inc(x_486);
if (lean_is_exclusive(x_24)) {
 lean_ctor_release(x_24, 0);
 x_487 = x_24;
} else {
 lean_dec_ref(x_24);
 x_487 = lean_box(0);
}
x_488 = lean_ctor_get(x_486, 0);
lean_inc(x_488);
lean_dec(x_486);
x_489 = l_Lean_JsonNumber_fromNat(x_488);
if (lean_is_scalar(x_487)) {
 x_490 = lean_alloc_ctor(2, 1, 0);
} else {
 x_490 = x_487;
 lean_ctor_set_tag(x_490, 2);
}
lean_ctor_set(x_490, 0, x_489);
x_438 = x_490;
goto block_484;
}
block_437:
{
lean_object* x_319; lean_object* x_320; lean_object* x_321; lean_object* x_322; lean_object* x_323; lean_object* x_324; lean_object* x_325; lean_object* x_326; lean_object* x_327; lean_object* x_328; lean_object* x_329; lean_object* x_330; lean_object* x_331; lean_object* x_332; lean_object* x_333; lean_object* x_334; lean_object* x_335; lean_object* x_336; lean_object* x_337; lean_object* x_431; 
x_319 = lean_st_ref_get(x_9, x_318);
x_320 = lean_ctor_get(x_319, 0);
lean_inc(x_320);
x_321 = lean_ctor_get(x_319, 1);
lean_inc(x_321);
if (lean_is_exclusive(x_319)) {
 lean_ctor_release(x_319, 0);
 lean_ctor_release(x_319, 1);
 x_322 = x_319;
} else {
 lean_dec_ref(x_319);
 x_322 = lean_box(0);
}
x_323 = lean_ctor_get(x_320, 5);
lean_inc(x_323);
lean_dec(x_320);
x_324 = l_Lean_MessageLog_toList(x_323);
x_325 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_324, x_311);
x_326 = lean_unsigned_to_nat(0u);
x_327 = l_List_lengthTRAux___rarg(x_325, x_326);
lean_dec(x_325);
x_328 = lean_io_mono_nanos_now(x_321);
x_329 = lean_ctor_get(x_328, 0);
lean_inc(x_329);
x_330 = lean_ctor_get(x_328, 1);
lean_inc(x_330);
if (lean_is_exclusive(x_328)) {
 lean_ctor_release(x_328, 0);
 lean_ctor_release(x_328, 1);
 x_331 = x_328;
} else {
 lean_dec_ref(x_328);
 x_331 = lean_box(0);
}
x_332 = lean_io_get_num_heartbeats(x_330);
x_333 = lean_ctor_get(x_332, 0);
lean_inc(x_333);
x_334 = lean_ctor_get(x_332, 1);
lean_inc(x_334);
if (lean_is_exclusive(x_332)) {
 lean_ctor_release(x_332, 0);
 lean_ctor_release(x_332, 1);
 x_335 = x_332;
} else {
 lean_dec_ref(x_332);
 x_335 = lean_box(0);
}
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
x_431 = l_Lean_Elab_Tactic_evalTactic(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_334);
if (lean_obj_tag(x_431) == 0)
{
lean_object* x_432; lean_object* x_433; 
x_432 = lean_ctor_get(x_431, 1);
lean_inc(x_432);
lean_dec(x_431);
x_433 = lean_box(0);
x_336 = x_433;
x_337 = x_432;
goto block_430;
}
else
{
lean_object* x_434; lean_object* x_435; lean_object* x_436; 
x_434 = lean_ctor_get(x_431, 0);
lean_inc(x_434);
x_435 = lean_ctor_get(x_431, 1);
lean_inc(x_435);
lean_dec(x_431);
x_436 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_436, 0, x_434);
x_336 = x_436;
x_337 = x_435;
goto block_430;
}
block_430:
{
lean_object* x_338; lean_object* x_339; lean_object* x_340; lean_object* x_341; lean_object* x_342; lean_object* x_343; lean_object* x_344; lean_object* x_345; lean_object* x_346; lean_object* x_347; lean_object* x_348; lean_object* x_349; lean_object* x_350; lean_object* x_351; lean_object* x_352; lean_object* x_353; lean_object* x_354; lean_object* x_355; lean_object* x_356; lean_object* x_357; lean_object* x_358; lean_object* x_407; 
x_338 = lean_io_get_num_heartbeats(x_337);
x_339 = lean_ctor_get(x_338, 0);
lean_inc(x_339);
x_340 = lean_ctor_get(x_338, 1);
lean_inc(x_340);
if (lean_is_exclusive(x_338)) {
 lean_ctor_release(x_338, 0);
 lean_ctor_release(x_338, 1);
 x_341 = x_338;
} else {
 lean_dec_ref(x_338);
 x_341 = lean_box(0);
}
x_342 = lean_nat_sub(x_339, x_333);
lean_dec(x_333);
lean_dec(x_339);
x_343 = lean_io_mono_nanos_now(x_340);
x_344 = lean_ctor_get(x_343, 0);
lean_inc(x_344);
x_345 = lean_ctor_get(x_343, 1);
lean_inc(x_345);
if (lean_is_exclusive(x_343)) {
 lean_ctor_release(x_343, 0);
 lean_ctor_release(x_343, 1);
 x_346 = x_343;
} else {
 lean_dec_ref(x_343);
 x_346 = lean_box(0);
}
x_347 = lean_nat_sub(x_344, x_329);
lean_dec(x_329);
lean_dec(x_344);
x_348 = lean_st_ref_get(x_9, x_345);
x_349 = lean_ctor_get(x_348, 0);
lean_inc(x_349);
x_350 = lean_ctor_get(x_348, 1);
lean_inc(x_350);
if (lean_is_exclusive(x_348)) {
 lean_ctor_release(x_348, 0);
 lean_ctor_release(x_348, 1);
 x_351 = x_348;
} else {
 lean_dec_ref(x_348);
 x_351 = lean_box(0);
}
x_352 = lean_ctor_get(x_349, 5);
lean_inc(x_352);
lean_dec(x_349);
x_353 = l_Lean_MessageLog_toList(x_352);
x_354 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_353, x_311);
x_355 = l_List_lengthTRAux___rarg(x_354, x_326);
lean_dec(x_354);
x_407 = l_Lean_Elab_Tactic_getGoals___rarg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_350);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
if (lean_obj_tag(x_336) == 0)
{
lean_object* x_408; lean_object* x_409; lean_object* x_410; 
x_408 = lean_ctor_get(x_407, 0);
lean_inc(x_408);
x_409 = lean_ctor_get(x_407, 1);
lean_inc(x_409);
lean_dec(x_407);
x_410 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23;
x_356 = x_410;
x_357 = x_408;
x_358 = x_409;
goto block_406;
}
else
{
lean_object* x_411; uint8_t x_412; 
x_411 = lean_ctor_get(x_336, 0);
lean_inc(x_411);
x_412 = l_Lean_Exception_isMaxHeartbeat(x_411);
if (x_412 == 0)
{
uint8_t x_413; 
x_413 = l_Lean_Exception_isMaxRecDepth(x_411);
if (x_413 == 0)
{
uint8_t x_414; 
x_414 = l_Lean_Exception_isInterrupt(x_411);
if (x_414 == 0)
{
if (lean_obj_tag(x_411) == 0)
{
lean_object* x_415; lean_object* x_416; lean_object* x_417; 
lean_dec(x_411);
x_415 = lean_ctor_get(x_407, 0);
lean_inc(x_415);
x_416 = lean_ctor_get(x_407, 1);
lean_inc(x_416);
lean_dec(x_407);
x_417 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24;
x_356 = x_417;
x_357 = x_415;
x_358 = x_416;
goto block_406;
}
else
{
lean_object* x_418; lean_object* x_419; lean_object* x_420; 
lean_dec(x_411);
x_418 = lean_ctor_get(x_407, 0);
lean_inc(x_418);
x_419 = lean_ctor_get(x_407, 1);
lean_inc(x_419);
lean_dec(x_407);
x_420 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25;
x_356 = x_420;
x_357 = x_418;
x_358 = x_419;
goto block_406;
}
}
else
{
lean_object* x_421; lean_object* x_422; lean_object* x_423; 
lean_dec(x_411);
x_421 = lean_ctor_get(x_407, 0);
lean_inc(x_421);
x_422 = lean_ctor_get(x_407, 1);
lean_inc(x_422);
lean_dec(x_407);
x_423 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26;
x_356 = x_423;
x_357 = x_421;
x_358 = x_422;
goto block_406;
}
}
else
{
lean_object* x_424; lean_object* x_425; lean_object* x_426; 
lean_dec(x_411);
x_424 = lean_ctor_get(x_407, 0);
lean_inc(x_424);
x_425 = lean_ctor_get(x_407, 1);
lean_inc(x_425);
lean_dec(x_407);
x_426 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27;
x_356 = x_426;
x_357 = x_424;
x_358 = x_425;
goto block_406;
}
}
else
{
lean_object* x_427; lean_object* x_428; lean_object* x_429; 
lean_dec(x_411);
x_427 = lean_ctor_get(x_407, 0);
lean_inc(x_427);
x_428 = lean_ctor_get(x_407, 1);
lean_inc(x_428);
lean_dec(x_407);
x_429 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28;
x_356 = x_429;
x_357 = x_427;
x_358 = x_428;
goto block_406;
}
}
block_406:
{
lean_object* x_359; lean_object* x_360; lean_object* x_361; lean_object* x_362; lean_object* x_363; lean_object* x_364; lean_object* x_365; lean_object* x_366; lean_object* x_367; lean_object* x_368; lean_object* x_369; lean_object* x_370; lean_object* x_371; lean_object* x_372; lean_object* x_373; lean_object* x_374; lean_object* x_375; lean_object* x_376; lean_object* x_377; lean_object* x_378; lean_object* x_379; lean_object* x_380; lean_object* x_381; lean_object* x_382; lean_object* x_383; lean_object* x_384; lean_object* x_385; lean_object* x_386; lean_object* x_387; lean_object* x_388; lean_object* x_389; 
x_359 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_359, 0, x_356);
x_360 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18;
if (lean_is_scalar(x_351)) {
 x_361 = lean_alloc_ctor(0, 2, 0);
} else {
 x_361 = x_351;
}
lean_ctor_set(x_361, 0, x_360);
lean_ctor_set(x_361, 1, x_359);
x_362 = l_Lean_JsonNumber_fromNat(x_347);
x_363 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_363, 0, x_362);
x_364 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19;
if (lean_is_scalar(x_346)) {
 x_365 = lean_alloc_ctor(0, 2, 0);
} else {
 x_365 = x_346;
}
lean_ctor_set(x_365, 0, x_364);
lean_ctor_set(x_365, 1, x_363);
x_366 = l_Lean_JsonNumber_fromNat(x_342);
x_367 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_367, 0, x_366);
x_368 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20;
if (lean_is_scalar(x_341)) {
 x_369 = lean_alloc_ctor(0, 2, 0);
} else {
 x_369 = x_341;
}
lean_ctor_set(x_369, 0, x_368);
lean_ctor_set(x_369, 1, x_367);
x_370 = l_List_lengthTRAux___rarg(x_357, x_326);
lean_dec(x_357);
x_371 = l_Lean_JsonNumber_fromNat(x_370);
x_372 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_372, 0, x_371);
x_373 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21;
if (lean_is_scalar(x_335)) {
 x_374 = lean_alloc_ctor(0, 2, 0);
} else {
 x_374 = x_335;
}
lean_ctor_set(x_374, 0, x_373);
lean_ctor_set(x_374, 1, x_372);
x_375 = lean_nat_sub(x_355, x_327);
lean_dec(x_327);
lean_dec(x_355);
x_376 = l_Lean_JsonNumber_fromNat(x_375);
x_377 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_377, 0, x_376);
x_378 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22;
if (lean_is_scalar(x_331)) {
 x_379 = lean_alloc_ctor(0, 2, 0);
} else {
 x_379 = x_331;
}
lean_ctor_set(x_379, 0, x_378);
lean_ctor_set(x_379, 1, x_377);
if (lean_is_scalar(x_322)) {
 x_380 = lean_alloc_ctor(1, 2, 0);
} else {
 x_380 = x_322;
 lean_ctor_set_tag(x_380, 1);
}
lean_ctor_set(x_380, 0, x_379);
lean_ctor_set(x_380, 1, x_312);
x_381 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_381, 0, x_374);
lean_ctor_set(x_381, 1, x_380);
x_382 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_382, 0, x_369);
lean_ctor_set(x_382, 1, x_381);
x_383 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_383, 0, x_365);
lean_ctor_set(x_383, 1, x_382);
x_384 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_384, 0, x_361);
lean_ctor_set(x_384, 1, x_383);
x_385 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_385, 0, x_317);
lean_ctor_set(x_385, 1, x_384);
x_386 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_386, 0, x_29);
lean_ctor_set(x_386, 1, x_385);
x_387 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17;
x_388 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_388, 0, x_387);
lean_ctor_set(x_388, 1, x_386);
x_389 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_388, x_358);
if (lean_obj_tag(x_389) == 0)
{
lean_dec(x_27);
if (lean_obj_tag(x_336) == 0)
{
lean_object* x_390; lean_object* x_391; lean_object* x_392; lean_object* x_393; 
x_390 = lean_ctor_get(x_389, 1);
lean_inc(x_390);
if (lean_is_exclusive(x_389)) {
 lean_ctor_release(x_389, 0);
 lean_ctor_release(x_389, 1);
 x_391 = x_389;
} else {
 lean_dec_ref(x_389);
 x_391 = lean_box(0);
}
x_392 = lean_box(0);
if (lean_is_scalar(x_391)) {
 x_393 = lean_alloc_ctor(0, 2, 0);
} else {
 x_393 = x_391;
}
lean_ctor_set(x_393, 0, x_392);
lean_ctor_set(x_393, 1, x_390);
return x_393;
}
else
{
lean_object* x_394; lean_object* x_395; lean_object* x_396; lean_object* x_397; 
x_394 = lean_ctor_get(x_389, 1);
lean_inc(x_394);
if (lean_is_exclusive(x_389)) {
 lean_ctor_release(x_389, 0);
 lean_ctor_release(x_389, 1);
 x_395 = x_389;
} else {
 lean_dec_ref(x_389);
 x_395 = lean_box(0);
}
x_396 = lean_ctor_get(x_336, 0);
lean_inc(x_396);
lean_dec(x_336);
if (lean_is_scalar(x_395)) {
 x_397 = lean_alloc_ctor(1, 2, 0);
} else {
 x_397 = x_395;
 lean_ctor_set_tag(x_397, 1);
}
lean_ctor_set(x_397, 0, x_396);
lean_ctor_set(x_397, 1, x_394);
return x_397;
}
}
else
{
lean_object* x_398; lean_object* x_399; lean_object* x_400; lean_object* x_401; lean_object* x_402; lean_object* x_403; lean_object* x_404; lean_object* x_405; 
lean_dec(x_336);
x_398 = lean_ctor_get(x_389, 0);
lean_inc(x_398);
x_399 = lean_ctor_get(x_389, 1);
lean_inc(x_399);
if (lean_is_exclusive(x_389)) {
 lean_ctor_release(x_389, 0);
 lean_ctor_release(x_389, 1);
 x_400 = x_389;
} else {
 lean_dec_ref(x_389);
 x_400 = lean_box(0);
}
x_401 = lean_io_error_to_string(x_398);
x_402 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_402, 0, x_401);
x_403 = l_Lean_MessageData_ofFormat(x_402);
x_404 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_404, 0, x_27);
lean_ctor_set(x_404, 1, x_403);
if (lean_is_scalar(x_400)) {
 x_405 = lean_alloc_ctor(1, 2, 0);
} else {
 x_405 = x_400;
}
lean_ctor_set(x_405, 0, x_404);
lean_ctor_set(x_405, 1, x_399);
return x_405;
}
}
}
}
block_484:
{
lean_object* x_439; lean_object* x_440; 
x_439 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29;
x_440 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_440, 0, x_439);
lean_ctor_set(x_440, 1, x_438);
if (lean_obj_tag(x_301) == 0)
{
lean_object* x_441; lean_object* x_442; lean_object* x_443; lean_object* x_444; lean_object* x_445; lean_object* x_446; lean_object* x_447; lean_object* x_448; lean_object* x_449; lean_object* x_450; 
x_441 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31;
x_442 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_442, 0, x_441);
lean_ctor_set(x_442, 1, x_314);
x_443 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_443, 0, x_299);
lean_ctor_set(x_443, 1, x_442);
x_444 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_444, 0, x_21);
lean_ctor_set(x_444, 1, x_443);
x_445 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_445, 0, x_440);
lean_ctor_set(x_445, 1, x_444);
lean_inc(x_317);
x_446 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_446, 0, x_317);
lean_ctor_set(x_446, 1, x_445);
lean_inc(x_29);
x_447 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_447, 0, x_29);
lean_ctor_set(x_447, 1, x_446);
x_448 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_449 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_449, 0, x_448);
lean_ctor_set(x_449, 1, x_447);
x_450 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_449, x_290);
if (lean_obj_tag(x_450) == 0)
{
lean_object* x_451; 
x_451 = lean_ctor_get(x_450, 1);
lean_inc(x_451);
lean_dec(x_450);
x_318 = x_451;
goto block_437;
}
else
{
lean_object* x_452; lean_object* x_453; lean_object* x_454; lean_object* x_455; lean_object* x_456; lean_object* x_457; lean_object* x_458; lean_object* x_459; 
lean_dec(x_317);
lean_dec(x_29);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_452 = lean_ctor_get(x_450, 0);
lean_inc(x_452);
x_453 = lean_ctor_get(x_450, 1);
lean_inc(x_453);
if (lean_is_exclusive(x_450)) {
 lean_ctor_release(x_450, 0);
 lean_ctor_release(x_450, 1);
 x_454 = x_450;
} else {
 lean_dec_ref(x_450);
 x_454 = lean_box(0);
}
x_455 = lean_io_error_to_string(x_452);
x_456 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_456, 0, x_455);
x_457 = l_Lean_MessageData_ofFormat(x_456);
x_458 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_458, 0, x_27);
lean_ctor_set(x_458, 1, x_457);
if (lean_is_scalar(x_454)) {
 x_459 = lean_alloc_ctor(1, 2, 0);
} else {
 x_459 = x_454;
}
lean_ctor_set(x_459, 0, x_458);
lean_ctor_set(x_459, 1, x_453);
return x_459;
}
}
else
{
lean_object* x_460; lean_object* x_461; lean_object* x_462; lean_object* x_463; lean_object* x_464; lean_object* x_465; lean_object* x_466; lean_object* x_467; lean_object* x_468; lean_object* x_469; lean_object* x_470; lean_object* x_471; lean_object* x_472; lean_object* x_473; lean_object* x_474; 
x_460 = lean_ctor_get(x_301, 0);
lean_inc(x_460);
if (lean_is_exclusive(x_301)) {
 lean_ctor_release(x_301, 0);
 x_461 = x_301;
} else {
 lean_dec_ref(x_301);
 x_461 = lean_box(0);
}
x_462 = l_Lean_JsonNumber_fromNat(x_460);
if (lean_is_scalar(x_461)) {
 x_463 = lean_alloc_ctor(2, 1, 0);
} else {
 x_463 = x_461;
 lean_ctor_set_tag(x_463, 2);
}
lean_ctor_set(x_463, 0, x_462);
x_464 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
x_465 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_465, 0, x_464);
lean_ctor_set(x_465, 1, x_463);
x_466 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_466, 0, x_465);
lean_ctor_set(x_466, 1, x_314);
x_467 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_467, 0, x_299);
lean_ctor_set(x_467, 1, x_466);
x_468 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_468, 0, x_21);
lean_ctor_set(x_468, 1, x_467);
x_469 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_469, 0, x_440);
lean_ctor_set(x_469, 1, x_468);
lean_inc(x_317);
x_470 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_470, 0, x_317);
lean_ctor_set(x_470, 1, x_469);
lean_inc(x_29);
x_471 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_471, 0, x_29);
lean_ctor_set(x_471, 1, x_470);
x_472 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_473 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_473, 0, x_472);
lean_ctor_set(x_473, 1, x_471);
x_474 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_473, x_290);
if (lean_obj_tag(x_474) == 0)
{
lean_object* x_475; 
x_475 = lean_ctor_get(x_474, 1);
lean_inc(x_475);
lean_dec(x_474);
x_318 = x_475;
goto block_437;
}
else
{
lean_object* x_476; lean_object* x_477; lean_object* x_478; lean_object* x_479; lean_object* x_480; lean_object* x_481; lean_object* x_482; lean_object* x_483; 
lean_dec(x_317);
lean_dec(x_29);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_476 = lean_ctor_get(x_474, 0);
lean_inc(x_476);
x_477 = lean_ctor_get(x_474, 1);
lean_inc(x_477);
if (lean_is_exclusive(x_474)) {
 lean_ctor_release(x_474, 0);
 lean_ctor_release(x_474, 1);
 x_478 = x_474;
} else {
 lean_dec_ref(x_474);
 x_478 = lean_box(0);
}
x_479 = lean_io_error_to_string(x_476);
x_480 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_480, 0, x_479);
x_481 = l_Lean_MessageData_ofFormat(x_480);
x_482 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_482, 0, x_27);
lean_ctor_set(x_482, 1, x_481);
if (lean_is_scalar(x_478)) {
 x_483 = lean_alloc_ctor(1, 2, 0);
} else {
 x_483 = x_478;
}
lean_ctor_set(x_483, 0, x_482);
lean_ctor_set(x_483, 1, x_477);
return x_483;
}
}
}
}
}
}
else
{
lean_object* x_497; lean_object* x_498; lean_object* x_499; lean_object* x_500; lean_object* x_501; lean_object* x_502; lean_object* x_503; lean_object* x_504; lean_object* x_505; lean_object* x_506; lean_object* x_507; lean_object* x_508; lean_object* x_509; lean_object* x_510; lean_object* x_511; lean_object* x_512; uint8_t x_513; lean_object* x_514; lean_object* x_515; uint8_t x_516; lean_object* x_517; lean_object* x_518; lean_object* x_519; lean_object* x_520; lean_object* x_521; lean_object* x_522; lean_object* x_523; lean_object* x_524; lean_object* x_525; lean_object* x_526; lean_object* x_527; lean_object* x_528; 
x_497 = lean_ctor_get(x_29, 0);
x_498 = lean_ctor_get(x_29, 1);
lean_inc(x_498);
lean_inc(x_497);
lean_dec(x_29);
x_499 = lean_io_mono_nanos_now(x_30);
x_500 = lean_ctor_get(x_499, 0);
lean_inc(x_500);
x_501 = lean_ctor_get(x_499, 1);
lean_inc(x_501);
if (lean_is_exclusive(x_499)) {
 lean_ctor_release(x_499, 0);
 lean_ctor_release(x_499, 1);
 x_502 = x_499;
} else {
 lean_dec_ref(x_499);
 x_502 = lean_box(0);
}
x_503 = lean_nat_sub(x_500, x_18);
lean_dec(x_18);
lean_dec(x_500);
x_504 = l_Lean_JsonNumber_fromNat(x_497);
x_505 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_505, 0, x_504);
x_506 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5;
x_507 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_507, 0, x_506);
lean_ctor_set(x_507, 1, x_505);
x_508 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_508, 0, x_25);
x_509 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6;
lean_ctor_set(x_21, 1, x_508);
lean_ctor_set(x_21, 0, x_509);
x_510 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_510, 0, x_26);
x_511 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7;
if (lean_is_scalar(x_502)) {
 x_512 = lean_alloc_ctor(0, 2, 0);
} else {
 x_512 = x_502;
}
lean_ctor_set(x_512, 0, x_511);
lean_ctor_set(x_512, 1, x_510);
x_513 = 0;
x_514 = l_Lean_Syntax_getPos_x3f(x_15, x_513);
lean_inc(x_15);
x_515 = l_Lean_Syntax_getKind(x_15);
x_516 = 1;
x_517 = l_Lean_Name_toString(x_515, x_516);
x_518 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_518, 0, x_517);
x_519 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8;
lean_ctor_set(x_16, 1, x_518);
lean_ctor_set(x_16, 0, x_519);
x_520 = l_Lean_JsonNumber_fromNat(x_503);
x_521 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_521, 0, x_520);
x_522 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9;
x_523 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_523, 0, x_522);
lean_ctor_set(x_523, 1, x_521);
x_524 = lean_box(0);
x_525 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13;
x_526 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_526, 0, x_523);
lean_ctor_set(x_526, 1, x_525);
x_527 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_527, 0, x_16);
lean_ctor_set(x_527, 1, x_526);
if (lean_obj_tag(x_498) == 0)
{
lean_object* x_705; 
x_705 = lean_box(0);
x_528 = x_705;
goto block_704;
}
else
{
lean_object* x_706; lean_object* x_707; lean_object* x_708; lean_object* x_709; 
x_706 = lean_ctor_get(x_498, 0);
lean_inc(x_706);
if (lean_is_exclusive(x_498)) {
 lean_ctor_release(x_498, 0);
 x_707 = x_498;
} else {
 lean_dec_ref(x_498);
 x_707 = lean_box(0);
}
x_708 = l_Lean_JsonNumber_fromNat(x_706);
if (lean_is_scalar(x_707)) {
 x_709 = lean_alloc_ctor(2, 1, 0);
} else {
 x_709 = x_707;
 lean_ctor_set_tag(x_709, 2);
}
lean_ctor_set(x_709, 0, x_708);
x_528 = x_709;
goto block_704;
}
block_704:
{
lean_object* x_529; lean_object* x_530; lean_object* x_531; lean_object* x_651; 
x_529 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14;
x_530 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_530, 0, x_529);
lean_ctor_set(x_530, 1, x_528);
if (lean_obj_tag(x_24) == 0)
{
lean_object* x_698; 
x_698 = lean_box(0);
x_651 = x_698;
goto block_697;
}
else
{
lean_object* x_699; lean_object* x_700; lean_object* x_701; lean_object* x_702; lean_object* x_703; 
x_699 = lean_ctor_get(x_24, 0);
lean_inc(x_699);
if (lean_is_exclusive(x_24)) {
 lean_ctor_release(x_24, 0);
 x_700 = x_24;
} else {
 lean_dec_ref(x_24);
 x_700 = lean_box(0);
}
x_701 = lean_ctor_get(x_699, 0);
lean_inc(x_701);
lean_dec(x_699);
x_702 = l_Lean_JsonNumber_fromNat(x_701);
if (lean_is_scalar(x_700)) {
 x_703 = lean_alloc_ctor(2, 1, 0);
} else {
 x_703 = x_700;
 lean_ctor_set_tag(x_703, 2);
}
lean_ctor_set(x_703, 0, x_702);
x_651 = x_703;
goto block_697;
}
block_650:
{
lean_object* x_532; lean_object* x_533; lean_object* x_534; lean_object* x_535; lean_object* x_536; lean_object* x_537; lean_object* x_538; lean_object* x_539; lean_object* x_540; lean_object* x_541; lean_object* x_542; lean_object* x_543; lean_object* x_544; lean_object* x_545; lean_object* x_546; lean_object* x_547; lean_object* x_548; lean_object* x_549; lean_object* x_550; lean_object* x_644; 
x_532 = lean_st_ref_get(x_9, x_531);
x_533 = lean_ctor_get(x_532, 0);
lean_inc(x_533);
x_534 = lean_ctor_get(x_532, 1);
lean_inc(x_534);
if (lean_is_exclusive(x_532)) {
 lean_ctor_release(x_532, 0);
 lean_ctor_release(x_532, 1);
 x_535 = x_532;
} else {
 lean_dec_ref(x_532);
 x_535 = lean_box(0);
}
x_536 = lean_ctor_get(x_533, 5);
lean_inc(x_536);
lean_dec(x_533);
x_537 = l_Lean_MessageLog_toList(x_536);
x_538 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_537, x_524);
x_539 = lean_unsigned_to_nat(0u);
x_540 = l_List_lengthTRAux___rarg(x_538, x_539);
lean_dec(x_538);
x_541 = lean_io_mono_nanos_now(x_534);
x_542 = lean_ctor_get(x_541, 0);
lean_inc(x_542);
x_543 = lean_ctor_get(x_541, 1);
lean_inc(x_543);
if (lean_is_exclusive(x_541)) {
 lean_ctor_release(x_541, 0);
 lean_ctor_release(x_541, 1);
 x_544 = x_541;
} else {
 lean_dec_ref(x_541);
 x_544 = lean_box(0);
}
x_545 = lean_io_get_num_heartbeats(x_543);
x_546 = lean_ctor_get(x_545, 0);
lean_inc(x_546);
x_547 = lean_ctor_get(x_545, 1);
lean_inc(x_547);
if (lean_is_exclusive(x_545)) {
 lean_ctor_release(x_545, 0);
 lean_ctor_release(x_545, 1);
 x_548 = x_545;
} else {
 lean_dec_ref(x_545);
 x_548 = lean_box(0);
}
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
x_644 = l_Lean_Elab_Tactic_evalTactic(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_547);
if (lean_obj_tag(x_644) == 0)
{
lean_object* x_645; lean_object* x_646; 
x_645 = lean_ctor_get(x_644, 1);
lean_inc(x_645);
lean_dec(x_644);
x_646 = lean_box(0);
x_549 = x_646;
x_550 = x_645;
goto block_643;
}
else
{
lean_object* x_647; lean_object* x_648; lean_object* x_649; 
x_647 = lean_ctor_get(x_644, 0);
lean_inc(x_647);
x_648 = lean_ctor_get(x_644, 1);
lean_inc(x_648);
lean_dec(x_644);
x_649 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_649, 0, x_647);
x_549 = x_649;
x_550 = x_648;
goto block_643;
}
block_643:
{
lean_object* x_551; lean_object* x_552; lean_object* x_553; lean_object* x_554; lean_object* x_555; lean_object* x_556; lean_object* x_557; lean_object* x_558; lean_object* x_559; lean_object* x_560; lean_object* x_561; lean_object* x_562; lean_object* x_563; lean_object* x_564; lean_object* x_565; lean_object* x_566; lean_object* x_567; lean_object* x_568; lean_object* x_569; lean_object* x_570; lean_object* x_571; lean_object* x_620; 
x_551 = lean_io_get_num_heartbeats(x_550);
x_552 = lean_ctor_get(x_551, 0);
lean_inc(x_552);
x_553 = lean_ctor_get(x_551, 1);
lean_inc(x_553);
if (lean_is_exclusive(x_551)) {
 lean_ctor_release(x_551, 0);
 lean_ctor_release(x_551, 1);
 x_554 = x_551;
} else {
 lean_dec_ref(x_551);
 x_554 = lean_box(0);
}
x_555 = lean_nat_sub(x_552, x_546);
lean_dec(x_546);
lean_dec(x_552);
x_556 = lean_io_mono_nanos_now(x_553);
x_557 = lean_ctor_get(x_556, 0);
lean_inc(x_557);
x_558 = lean_ctor_get(x_556, 1);
lean_inc(x_558);
if (lean_is_exclusive(x_556)) {
 lean_ctor_release(x_556, 0);
 lean_ctor_release(x_556, 1);
 x_559 = x_556;
} else {
 lean_dec_ref(x_556);
 x_559 = lean_box(0);
}
x_560 = lean_nat_sub(x_557, x_542);
lean_dec(x_542);
lean_dec(x_557);
x_561 = lean_st_ref_get(x_9, x_558);
x_562 = lean_ctor_get(x_561, 0);
lean_inc(x_562);
x_563 = lean_ctor_get(x_561, 1);
lean_inc(x_563);
if (lean_is_exclusive(x_561)) {
 lean_ctor_release(x_561, 0);
 lean_ctor_release(x_561, 1);
 x_564 = x_561;
} else {
 lean_dec_ref(x_561);
 x_564 = lean_box(0);
}
x_565 = lean_ctor_get(x_562, 5);
lean_inc(x_565);
lean_dec(x_562);
x_566 = l_Lean_MessageLog_toList(x_565);
x_567 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_566, x_524);
x_568 = l_List_lengthTRAux___rarg(x_567, x_539);
lean_dec(x_567);
x_620 = l_Lean_Elab_Tactic_getGoals___rarg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_563);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
if (lean_obj_tag(x_549) == 0)
{
lean_object* x_621; lean_object* x_622; lean_object* x_623; 
x_621 = lean_ctor_get(x_620, 0);
lean_inc(x_621);
x_622 = lean_ctor_get(x_620, 1);
lean_inc(x_622);
lean_dec(x_620);
x_623 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23;
x_569 = x_623;
x_570 = x_621;
x_571 = x_622;
goto block_619;
}
else
{
lean_object* x_624; uint8_t x_625; 
x_624 = lean_ctor_get(x_549, 0);
lean_inc(x_624);
x_625 = l_Lean_Exception_isMaxHeartbeat(x_624);
if (x_625 == 0)
{
uint8_t x_626; 
x_626 = l_Lean_Exception_isMaxRecDepth(x_624);
if (x_626 == 0)
{
uint8_t x_627; 
x_627 = l_Lean_Exception_isInterrupt(x_624);
if (x_627 == 0)
{
if (lean_obj_tag(x_624) == 0)
{
lean_object* x_628; lean_object* x_629; lean_object* x_630; 
lean_dec(x_624);
x_628 = lean_ctor_get(x_620, 0);
lean_inc(x_628);
x_629 = lean_ctor_get(x_620, 1);
lean_inc(x_629);
lean_dec(x_620);
x_630 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24;
x_569 = x_630;
x_570 = x_628;
x_571 = x_629;
goto block_619;
}
else
{
lean_object* x_631; lean_object* x_632; lean_object* x_633; 
lean_dec(x_624);
x_631 = lean_ctor_get(x_620, 0);
lean_inc(x_631);
x_632 = lean_ctor_get(x_620, 1);
lean_inc(x_632);
lean_dec(x_620);
x_633 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25;
x_569 = x_633;
x_570 = x_631;
x_571 = x_632;
goto block_619;
}
}
else
{
lean_object* x_634; lean_object* x_635; lean_object* x_636; 
lean_dec(x_624);
x_634 = lean_ctor_get(x_620, 0);
lean_inc(x_634);
x_635 = lean_ctor_get(x_620, 1);
lean_inc(x_635);
lean_dec(x_620);
x_636 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26;
x_569 = x_636;
x_570 = x_634;
x_571 = x_635;
goto block_619;
}
}
else
{
lean_object* x_637; lean_object* x_638; lean_object* x_639; 
lean_dec(x_624);
x_637 = lean_ctor_get(x_620, 0);
lean_inc(x_637);
x_638 = lean_ctor_get(x_620, 1);
lean_inc(x_638);
lean_dec(x_620);
x_639 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27;
x_569 = x_639;
x_570 = x_637;
x_571 = x_638;
goto block_619;
}
}
else
{
lean_object* x_640; lean_object* x_641; lean_object* x_642; 
lean_dec(x_624);
x_640 = lean_ctor_get(x_620, 0);
lean_inc(x_640);
x_641 = lean_ctor_get(x_620, 1);
lean_inc(x_641);
lean_dec(x_620);
x_642 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28;
x_569 = x_642;
x_570 = x_640;
x_571 = x_641;
goto block_619;
}
}
block_619:
{
lean_object* x_572; lean_object* x_573; lean_object* x_574; lean_object* x_575; lean_object* x_576; lean_object* x_577; lean_object* x_578; lean_object* x_579; lean_object* x_580; lean_object* x_581; lean_object* x_582; lean_object* x_583; lean_object* x_584; lean_object* x_585; lean_object* x_586; lean_object* x_587; lean_object* x_588; lean_object* x_589; lean_object* x_590; lean_object* x_591; lean_object* x_592; lean_object* x_593; lean_object* x_594; lean_object* x_595; lean_object* x_596; lean_object* x_597; lean_object* x_598; lean_object* x_599; lean_object* x_600; lean_object* x_601; lean_object* x_602; 
x_572 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_572, 0, x_569);
x_573 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18;
if (lean_is_scalar(x_564)) {
 x_574 = lean_alloc_ctor(0, 2, 0);
} else {
 x_574 = x_564;
}
lean_ctor_set(x_574, 0, x_573);
lean_ctor_set(x_574, 1, x_572);
x_575 = l_Lean_JsonNumber_fromNat(x_560);
x_576 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_576, 0, x_575);
x_577 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19;
if (lean_is_scalar(x_559)) {
 x_578 = lean_alloc_ctor(0, 2, 0);
} else {
 x_578 = x_559;
}
lean_ctor_set(x_578, 0, x_577);
lean_ctor_set(x_578, 1, x_576);
x_579 = l_Lean_JsonNumber_fromNat(x_555);
x_580 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_580, 0, x_579);
x_581 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20;
if (lean_is_scalar(x_554)) {
 x_582 = lean_alloc_ctor(0, 2, 0);
} else {
 x_582 = x_554;
}
lean_ctor_set(x_582, 0, x_581);
lean_ctor_set(x_582, 1, x_580);
x_583 = l_List_lengthTRAux___rarg(x_570, x_539);
lean_dec(x_570);
x_584 = l_Lean_JsonNumber_fromNat(x_583);
x_585 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_585, 0, x_584);
x_586 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21;
if (lean_is_scalar(x_548)) {
 x_587 = lean_alloc_ctor(0, 2, 0);
} else {
 x_587 = x_548;
}
lean_ctor_set(x_587, 0, x_586);
lean_ctor_set(x_587, 1, x_585);
x_588 = lean_nat_sub(x_568, x_540);
lean_dec(x_540);
lean_dec(x_568);
x_589 = l_Lean_JsonNumber_fromNat(x_588);
x_590 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_590, 0, x_589);
x_591 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22;
if (lean_is_scalar(x_544)) {
 x_592 = lean_alloc_ctor(0, 2, 0);
} else {
 x_592 = x_544;
}
lean_ctor_set(x_592, 0, x_591);
lean_ctor_set(x_592, 1, x_590);
if (lean_is_scalar(x_535)) {
 x_593 = lean_alloc_ctor(1, 2, 0);
} else {
 x_593 = x_535;
 lean_ctor_set_tag(x_593, 1);
}
lean_ctor_set(x_593, 0, x_592);
lean_ctor_set(x_593, 1, x_525);
x_594 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_594, 0, x_587);
lean_ctor_set(x_594, 1, x_593);
x_595 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_595, 0, x_582);
lean_ctor_set(x_595, 1, x_594);
x_596 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_596, 0, x_578);
lean_ctor_set(x_596, 1, x_595);
x_597 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_597, 0, x_574);
lean_ctor_set(x_597, 1, x_596);
x_598 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_598, 0, x_530);
lean_ctor_set(x_598, 1, x_597);
x_599 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_599, 0, x_507);
lean_ctor_set(x_599, 1, x_598);
x_600 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17;
x_601 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_601, 0, x_600);
lean_ctor_set(x_601, 1, x_599);
x_602 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_601, x_571);
if (lean_obj_tag(x_602) == 0)
{
lean_dec(x_27);
if (lean_obj_tag(x_549) == 0)
{
lean_object* x_603; lean_object* x_604; lean_object* x_605; lean_object* x_606; 
x_603 = lean_ctor_get(x_602, 1);
lean_inc(x_603);
if (lean_is_exclusive(x_602)) {
 lean_ctor_release(x_602, 0);
 lean_ctor_release(x_602, 1);
 x_604 = x_602;
} else {
 lean_dec_ref(x_602);
 x_604 = lean_box(0);
}
x_605 = lean_box(0);
if (lean_is_scalar(x_604)) {
 x_606 = lean_alloc_ctor(0, 2, 0);
} else {
 x_606 = x_604;
}
lean_ctor_set(x_606, 0, x_605);
lean_ctor_set(x_606, 1, x_603);
return x_606;
}
else
{
lean_object* x_607; lean_object* x_608; lean_object* x_609; lean_object* x_610; 
x_607 = lean_ctor_get(x_602, 1);
lean_inc(x_607);
if (lean_is_exclusive(x_602)) {
 lean_ctor_release(x_602, 0);
 lean_ctor_release(x_602, 1);
 x_608 = x_602;
} else {
 lean_dec_ref(x_602);
 x_608 = lean_box(0);
}
x_609 = lean_ctor_get(x_549, 0);
lean_inc(x_609);
lean_dec(x_549);
if (lean_is_scalar(x_608)) {
 x_610 = lean_alloc_ctor(1, 2, 0);
} else {
 x_610 = x_608;
 lean_ctor_set_tag(x_610, 1);
}
lean_ctor_set(x_610, 0, x_609);
lean_ctor_set(x_610, 1, x_607);
return x_610;
}
}
else
{
lean_object* x_611; lean_object* x_612; lean_object* x_613; lean_object* x_614; lean_object* x_615; lean_object* x_616; lean_object* x_617; lean_object* x_618; 
lean_dec(x_549);
x_611 = lean_ctor_get(x_602, 0);
lean_inc(x_611);
x_612 = lean_ctor_get(x_602, 1);
lean_inc(x_612);
if (lean_is_exclusive(x_602)) {
 lean_ctor_release(x_602, 0);
 lean_ctor_release(x_602, 1);
 x_613 = x_602;
} else {
 lean_dec_ref(x_602);
 x_613 = lean_box(0);
}
x_614 = lean_io_error_to_string(x_611);
x_615 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_615, 0, x_614);
x_616 = l_Lean_MessageData_ofFormat(x_615);
x_617 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_617, 0, x_27);
lean_ctor_set(x_617, 1, x_616);
if (lean_is_scalar(x_613)) {
 x_618 = lean_alloc_ctor(1, 2, 0);
} else {
 x_618 = x_613;
}
lean_ctor_set(x_618, 0, x_617);
lean_ctor_set(x_618, 1, x_612);
return x_618;
}
}
}
}
block_697:
{
lean_object* x_652; lean_object* x_653; 
x_652 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29;
x_653 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_653, 0, x_652);
lean_ctor_set(x_653, 1, x_651);
if (lean_obj_tag(x_514) == 0)
{
lean_object* x_654; lean_object* x_655; lean_object* x_656; lean_object* x_657; lean_object* x_658; lean_object* x_659; lean_object* x_660; lean_object* x_661; lean_object* x_662; lean_object* x_663; 
x_654 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31;
x_655 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_655, 0, x_654);
lean_ctor_set(x_655, 1, x_527);
x_656 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_656, 0, x_512);
lean_ctor_set(x_656, 1, x_655);
x_657 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_657, 0, x_21);
lean_ctor_set(x_657, 1, x_656);
x_658 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_658, 0, x_653);
lean_ctor_set(x_658, 1, x_657);
lean_inc(x_530);
x_659 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_659, 0, x_530);
lean_ctor_set(x_659, 1, x_658);
lean_inc(x_507);
x_660 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_660, 0, x_507);
lean_ctor_set(x_660, 1, x_659);
x_661 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_662 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_662, 0, x_661);
lean_ctor_set(x_662, 1, x_660);
x_663 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_662, x_501);
if (lean_obj_tag(x_663) == 0)
{
lean_object* x_664; 
x_664 = lean_ctor_get(x_663, 1);
lean_inc(x_664);
lean_dec(x_663);
x_531 = x_664;
goto block_650;
}
else
{
lean_object* x_665; lean_object* x_666; lean_object* x_667; lean_object* x_668; lean_object* x_669; lean_object* x_670; lean_object* x_671; lean_object* x_672; 
lean_dec(x_530);
lean_dec(x_507);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_665 = lean_ctor_get(x_663, 0);
lean_inc(x_665);
x_666 = lean_ctor_get(x_663, 1);
lean_inc(x_666);
if (lean_is_exclusive(x_663)) {
 lean_ctor_release(x_663, 0);
 lean_ctor_release(x_663, 1);
 x_667 = x_663;
} else {
 lean_dec_ref(x_663);
 x_667 = lean_box(0);
}
x_668 = lean_io_error_to_string(x_665);
x_669 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_669, 0, x_668);
x_670 = l_Lean_MessageData_ofFormat(x_669);
x_671 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_671, 0, x_27);
lean_ctor_set(x_671, 1, x_670);
if (lean_is_scalar(x_667)) {
 x_672 = lean_alloc_ctor(1, 2, 0);
} else {
 x_672 = x_667;
}
lean_ctor_set(x_672, 0, x_671);
lean_ctor_set(x_672, 1, x_666);
return x_672;
}
}
else
{
lean_object* x_673; lean_object* x_674; lean_object* x_675; lean_object* x_676; lean_object* x_677; lean_object* x_678; lean_object* x_679; lean_object* x_680; lean_object* x_681; lean_object* x_682; lean_object* x_683; lean_object* x_684; lean_object* x_685; lean_object* x_686; lean_object* x_687; 
x_673 = lean_ctor_get(x_514, 0);
lean_inc(x_673);
if (lean_is_exclusive(x_514)) {
 lean_ctor_release(x_514, 0);
 x_674 = x_514;
} else {
 lean_dec_ref(x_514);
 x_674 = lean_box(0);
}
x_675 = l_Lean_JsonNumber_fromNat(x_673);
if (lean_is_scalar(x_674)) {
 x_676 = lean_alloc_ctor(2, 1, 0);
} else {
 x_676 = x_674;
 lean_ctor_set_tag(x_676, 2);
}
lean_ctor_set(x_676, 0, x_675);
x_677 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
x_678 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_678, 0, x_677);
lean_ctor_set(x_678, 1, x_676);
x_679 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_679, 0, x_678);
lean_ctor_set(x_679, 1, x_527);
x_680 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_680, 0, x_512);
lean_ctor_set(x_680, 1, x_679);
x_681 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_681, 0, x_21);
lean_ctor_set(x_681, 1, x_680);
x_682 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_682, 0, x_653);
lean_ctor_set(x_682, 1, x_681);
lean_inc(x_530);
x_683 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_683, 0, x_530);
lean_ctor_set(x_683, 1, x_682);
lean_inc(x_507);
x_684 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_684, 0, x_507);
lean_ctor_set(x_684, 1, x_683);
x_685 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_686 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_686, 0, x_685);
lean_ctor_set(x_686, 1, x_684);
x_687 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_686, x_501);
if (lean_obj_tag(x_687) == 0)
{
lean_object* x_688; 
x_688 = lean_ctor_get(x_687, 1);
lean_inc(x_688);
lean_dec(x_687);
x_531 = x_688;
goto block_650;
}
else
{
lean_object* x_689; lean_object* x_690; lean_object* x_691; lean_object* x_692; lean_object* x_693; lean_object* x_694; lean_object* x_695; lean_object* x_696; 
lean_dec(x_530);
lean_dec(x_507);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_689 = lean_ctor_get(x_687, 0);
lean_inc(x_689);
x_690 = lean_ctor_get(x_687, 1);
lean_inc(x_690);
if (lean_is_exclusive(x_687)) {
 lean_ctor_release(x_687, 0);
 lean_ctor_release(x_687, 1);
 x_691 = x_687;
} else {
 lean_dec_ref(x_687);
 x_691 = lean_box(0);
}
x_692 = lean_io_error_to_string(x_689);
x_693 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_693, 0, x_692);
x_694 = l_Lean_MessageData_ofFormat(x_693);
x_695 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_695, 0, x_27);
lean_ctor_set(x_695, 1, x_694);
if (lean_is_scalar(x_691)) {
 x_696 = lean_alloc_ctor(1, 2, 0);
} else {
 x_696 = x_691;
}
lean_ctor_set(x_696, 0, x_695);
lean_ctor_set(x_696, 1, x_690);
return x_696;
}
}
}
}
}
}
else
{
uint8_t x_710; 
lean_dec(x_26);
lean_free_object(x_21);
lean_dec(x_25);
lean_dec(x_24);
lean_dec(x_18);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_710 = !lean_is_exclusive(x_28);
if (x_710 == 0)
{
lean_object* x_711; lean_object* x_712; lean_object* x_713; lean_object* x_714; 
x_711 = lean_ctor_get(x_28, 0);
x_712 = lean_io_error_to_string(x_711);
x_713 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_713, 0, x_712);
x_714 = l_Lean_MessageData_ofFormat(x_713);
lean_ctor_set(x_16, 1, x_714);
lean_ctor_set(x_16, 0, x_27);
lean_ctor_set(x_28, 0, x_16);
return x_28;
}
else
{
lean_object* x_715; lean_object* x_716; lean_object* x_717; lean_object* x_718; lean_object* x_719; lean_object* x_720; 
x_715 = lean_ctor_get(x_28, 0);
x_716 = lean_ctor_get(x_28, 1);
lean_inc(x_716);
lean_inc(x_715);
lean_dec(x_28);
x_717 = lean_io_error_to_string(x_715);
x_718 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_718, 0, x_717);
x_719 = l_Lean_MessageData_ofFormat(x_718);
lean_ctor_set(x_16, 1, x_719);
lean_ctor_set(x_16, 0, x_27);
x_720 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_720, 0, x_16);
lean_ctor_set(x_720, 1, x_716);
return x_720;
}
}
}
else
{
lean_object* x_721; lean_object* x_722; lean_object* x_723; lean_object* x_724; lean_object* x_725; 
x_721 = lean_ctor_get(x_21, 0);
x_722 = lean_ctor_get(x_21, 1);
lean_inc(x_722);
lean_inc(x_721);
lean_dec(x_21);
x_723 = lean_ctor_get(x_8, 0);
lean_inc(x_723);
x_724 = lean_ctor_get(x_8, 5);
lean_inc(x_724);
lean_inc(x_721);
x_725 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register(x_721, x_22);
if (lean_obj_tag(x_725) == 0)
{
lean_object* x_726; lean_object* x_727; lean_object* x_728; lean_object* x_729; lean_object* x_730; lean_object* x_731; lean_object* x_732; lean_object* x_733; lean_object* x_734; lean_object* x_735; lean_object* x_736; lean_object* x_737; lean_object* x_738; lean_object* x_739; lean_object* x_740; lean_object* x_741; lean_object* x_742; lean_object* x_743; lean_object* x_744; lean_object* x_745; uint8_t x_746; lean_object* x_747; lean_object* x_748; uint8_t x_749; lean_object* x_750; lean_object* x_751; lean_object* x_752; lean_object* x_753; lean_object* x_754; lean_object* x_755; lean_object* x_756; lean_object* x_757; lean_object* x_758; lean_object* x_759; lean_object* x_760; lean_object* x_761; 
x_726 = lean_ctor_get(x_725, 0);
lean_inc(x_726);
x_727 = lean_ctor_get(x_725, 1);
lean_inc(x_727);
lean_dec(x_725);
x_728 = lean_ctor_get(x_726, 0);
lean_inc(x_728);
x_729 = lean_ctor_get(x_726, 1);
lean_inc(x_729);
if (lean_is_exclusive(x_726)) {
 lean_ctor_release(x_726, 0);
 lean_ctor_release(x_726, 1);
 x_730 = x_726;
} else {
 lean_dec_ref(x_726);
 x_730 = lean_box(0);
}
x_731 = lean_io_mono_nanos_now(x_727);
x_732 = lean_ctor_get(x_731, 0);
lean_inc(x_732);
x_733 = lean_ctor_get(x_731, 1);
lean_inc(x_733);
if (lean_is_exclusive(x_731)) {
 lean_ctor_release(x_731, 0);
 lean_ctor_release(x_731, 1);
 x_734 = x_731;
} else {
 lean_dec_ref(x_731);
 x_734 = lean_box(0);
}
x_735 = lean_nat_sub(x_732, x_18);
lean_dec(x_18);
lean_dec(x_732);
x_736 = l_Lean_JsonNumber_fromNat(x_728);
x_737 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_737, 0, x_736);
x_738 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5;
if (lean_is_scalar(x_730)) {
 x_739 = lean_alloc_ctor(0, 2, 0);
} else {
 x_739 = x_730;
}
lean_ctor_set(x_739, 0, x_738);
lean_ctor_set(x_739, 1, x_737);
x_740 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_740, 0, x_722);
x_741 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6;
x_742 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_742, 0, x_741);
lean_ctor_set(x_742, 1, x_740);
x_743 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_743, 0, x_723);
x_744 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7;
if (lean_is_scalar(x_734)) {
 x_745 = lean_alloc_ctor(0, 2, 0);
} else {
 x_745 = x_734;
}
lean_ctor_set(x_745, 0, x_744);
lean_ctor_set(x_745, 1, x_743);
x_746 = 0;
x_747 = l_Lean_Syntax_getPos_x3f(x_15, x_746);
lean_inc(x_15);
x_748 = l_Lean_Syntax_getKind(x_15);
x_749 = 1;
x_750 = l_Lean_Name_toString(x_748, x_749);
x_751 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_751, 0, x_750);
x_752 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8;
lean_ctor_set(x_16, 1, x_751);
lean_ctor_set(x_16, 0, x_752);
x_753 = l_Lean_JsonNumber_fromNat(x_735);
x_754 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_754, 0, x_753);
x_755 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9;
x_756 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_756, 0, x_755);
lean_ctor_set(x_756, 1, x_754);
x_757 = lean_box(0);
x_758 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13;
x_759 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_759, 0, x_756);
lean_ctor_set(x_759, 1, x_758);
x_760 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_760, 0, x_16);
lean_ctor_set(x_760, 1, x_759);
if (lean_obj_tag(x_729) == 0)
{
lean_object* x_938; 
x_938 = lean_box(0);
x_761 = x_938;
goto block_937;
}
else
{
lean_object* x_939; lean_object* x_940; lean_object* x_941; lean_object* x_942; 
x_939 = lean_ctor_get(x_729, 0);
lean_inc(x_939);
if (lean_is_exclusive(x_729)) {
 lean_ctor_release(x_729, 0);
 x_940 = x_729;
} else {
 lean_dec_ref(x_729);
 x_940 = lean_box(0);
}
x_941 = l_Lean_JsonNumber_fromNat(x_939);
if (lean_is_scalar(x_940)) {
 x_942 = lean_alloc_ctor(2, 1, 0);
} else {
 x_942 = x_940;
 lean_ctor_set_tag(x_942, 2);
}
lean_ctor_set(x_942, 0, x_941);
x_761 = x_942;
goto block_937;
}
block_937:
{
lean_object* x_762; lean_object* x_763; lean_object* x_764; lean_object* x_884; 
x_762 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14;
x_763 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_763, 0, x_762);
lean_ctor_set(x_763, 1, x_761);
if (lean_obj_tag(x_721) == 0)
{
lean_object* x_931; 
x_931 = lean_box(0);
x_884 = x_931;
goto block_930;
}
else
{
lean_object* x_932; lean_object* x_933; lean_object* x_934; lean_object* x_935; lean_object* x_936; 
x_932 = lean_ctor_get(x_721, 0);
lean_inc(x_932);
if (lean_is_exclusive(x_721)) {
 lean_ctor_release(x_721, 0);
 x_933 = x_721;
} else {
 lean_dec_ref(x_721);
 x_933 = lean_box(0);
}
x_934 = lean_ctor_get(x_932, 0);
lean_inc(x_934);
lean_dec(x_932);
x_935 = l_Lean_JsonNumber_fromNat(x_934);
if (lean_is_scalar(x_933)) {
 x_936 = lean_alloc_ctor(2, 1, 0);
} else {
 x_936 = x_933;
 lean_ctor_set_tag(x_936, 2);
}
lean_ctor_set(x_936, 0, x_935);
x_884 = x_936;
goto block_930;
}
block_883:
{
lean_object* x_765; lean_object* x_766; lean_object* x_767; lean_object* x_768; lean_object* x_769; lean_object* x_770; lean_object* x_771; lean_object* x_772; lean_object* x_773; lean_object* x_774; lean_object* x_775; lean_object* x_776; lean_object* x_777; lean_object* x_778; lean_object* x_779; lean_object* x_780; lean_object* x_781; lean_object* x_782; lean_object* x_783; lean_object* x_877; 
x_765 = lean_st_ref_get(x_9, x_764);
x_766 = lean_ctor_get(x_765, 0);
lean_inc(x_766);
x_767 = lean_ctor_get(x_765, 1);
lean_inc(x_767);
if (lean_is_exclusive(x_765)) {
 lean_ctor_release(x_765, 0);
 lean_ctor_release(x_765, 1);
 x_768 = x_765;
} else {
 lean_dec_ref(x_765);
 x_768 = lean_box(0);
}
x_769 = lean_ctor_get(x_766, 5);
lean_inc(x_769);
lean_dec(x_766);
x_770 = l_Lean_MessageLog_toList(x_769);
x_771 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_770, x_757);
x_772 = lean_unsigned_to_nat(0u);
x_773 = l_List_lengthTRAux___rarg(x_771, x_772);
lean_dec(x_771);
x_774 = lean_io_mono_nanos_now(x_767);
x_775 = lean_ctor_get(x_774, 0);
lean_inc(x_775);
x_776 = lean_ctor_get(x_774, 1);
lean_inc(x_776);
if (lean_is_exclusive(x_774)) {
 lean_ctor_release(x_774, 0);
 lean_ctor_release(x_774, 1);
 x_777 = x_774;
} else {
 lean_dec_ref(x_774);
 x_777 = lean_box(0);
}
x_778 = lean_io_get_num_heartbeats(x_776);
x_779 = lean_ctor_get(x_778, 0);
lean_inc(x_779);
x_780 = lean_ctor_get(x_778, 1);
lean_inc(x_780);
if (lean_is_exclusive(x_778)) {
 lean_ctor_release(x_778, 0);
 lean_ctor_release(x_778, 1);
 x_781 = x_778;
} else {
 lean_dec_ref(x_778);
 x_781 = lean_box(0);
}
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
x_877 = l_Lean_Elab_Tactic_evalTactic(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_780);
if (lean_obj_tag(x_877) == 0)
{
lean_object* x_878; lean_object* x_879; 
x_878 = lean_ctor_get(x_877, 1);
lean_inc(x_878);
lean_dec(x_877);
x_879 = lean_box(0);
x_782 = x_879;
x_783 = x_878;
goto block_876;
}
else
{
lean_object* x_880; lean_object* x_881; lean_object* x_882; 
x_880 = lean_ctor_get(x_877, 0);
lean_inc(x_880);
x_881 = lean_ctor_get(x_877, 1);
lean_inc(x_881);
lean_dec(x_877);
x_882 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_882, 0, x_880);
x_782 = x_882;
x_783 = x_881;
goto block_876;
}
block_876:
{
lean_object* x_784; lean_object* x_785; lean_object* x_786; lean_object* x_787; lean_object* x_788; lean_object* x_789; lean_object* x_790; lean_object* x_791; lean_object* x_792; lean_object* x_793; lean_object* x_794; lean_object* x_795; lean_object* x_796; lean_object* x_797; lean_object* x_798; lean_object* x_799; lean_object* x_800; lean_object* x_801; lean_object* x_802; lean_object* x_803; lean_object* x_804; lean_object* x_853; 
x_784 = lean_io_get_num_heartbeats(x_783);
x_785 = lean_ctor_get(x_784, 0);
lean_inc(x_785);
x_786 = lean_ctor_get(x_784, 1);
lean_inc(x_786);
if (lean_is_exclusive(x_784)) {
 lean_ctor_release(x_784, 0);
 lean_ctor_release(x_784, 1);
 x_787 = x_784;
} else {
 lean_dec_ref(x_784);
 x_787 = lean_box(0);
}
x_788 = lean_nat_sub(x_785, x_779);
lean_dec(x_779);
lean_dec(x_785);
x_789 = lean_io_mono_nanos_now(x_786);
x_790 = lean_ctor_get(x_789, 0);
lean_inc(x_790);
x_791 = lean_ctor_get(x_789, 1);
lean_inc(x_791);
if (lean_is_exclusive(x_789)) {
 lean_ctor_release(x_789, 0);
 lean_ctor_release(x_789, 1);
 x_792 = x_789;
} else {
 lean_dec_ref(x_789);
 x_792 = lean_box(0);
}
x_793 = lean_nat_sub(x_790, x_775);
lean_dec(x_775);
lean_dec(x_790);
x_794 = lean_st_ref_get(x_9, x_791);
x_795 = lean_ctor_get(x_794, 0);
lean_inc(x_795);
x_796 = lean_ctor_get(x_794, 1);
lean_inc(x_796);
if (lean_is_exclusive(x_794)) {
 lean_ctor_release(x_794, 0);
 lean_ctor_release(x_794, 1);
 x_797 = x_794;
} else {
 lean_dec_ref(x_794);
 x_797 = lean_box(0);
}
x_798 = lean_ctor_get(x_795, 5);
lean_inc(x_798);
lean_dec(x_795);
x_799 = l_Lean_MessageLog_toList(x_798);
x_800 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_799, x_757);
x_801 = l_List_lengthTRAux___rarg(x_800, x_772);
lean_dec(x_800);
x_853 = l_Lean_Elab_Tactic_getGoals___rarg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_796);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
if (lean_obj_tag(x_782) == 0)
{
lean_object* x_854; lean_object* x_855; lean_object* x_856; 
x_854 = lean_ctor_get(x_853, 0);
lean_inc(x_854);
x_855 = lean_ctor_get(x_853, 1);
lean_inc(x_855);
lean_dec(x_853);
x_856 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23;
x_802 = x_856;
x_803 = x_854;
x_804 = x_855;
goto block_852;
}
else
{
lean_object* x_857; uint8_t x_858; 
x_857 = lean_ctor_get(x_782, 0);
lean_inc(x_857);
x_858 = l_Lean_Exception_isMaxHeartbeat(x_857);
if (x_858 == 0)
{
uint8_t x_859; 
x_859 = l_Lean_Exception_isMaxRecDepth(x_857);
if (x_859 == 0)
{
uint8_t x_860; 
x_860 = l_Lean_Exception_isInterrupt(x_857);
if (x_860 == 0)
{
if (lean_obj_tag(x_857) == 0)
{
lean_object* x_861; lean_object* x_862; lean_object* x_863; 
lean_dec(x_857);
x_861 = lean_ctor_get(x_853, 0);
lean_inc(x_861);
x_862 = lean_ctor_get(x_853, 1);
lean_inc(x_862);
lean_dec(x_853);
x_863 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24;
x_802 = x_863;
x_803 = x_861;
x_804 = x_862;
goto block_852;
}
else
{
lean_object* x_864; lean_object* x_865; lean_object* x_866; 
lean_dec(x_857);
x_864 = lean_ctor_get(x_853, 0);
lean_inc(x_864);
x_865 = lean_ctor_get(x_853, 1);
lean_inc(x_865);
lean_dec(x_853);
x_866 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25;
x_802 = x_866;
x_803 = x_864;
x_804 = x_865;
goto block_852;
}
}
else
{
lean_object* x_867; lean_object* x_868; lean_object* x_869; 
lean_dec(x_857);
x_867 = lean_ctor_get(x_853, 0);
lean_inc(x_867);
x_868 = lean_ctor_get(x_853, 1);
lean_inc(x_868);
lean_dec(x_853);
x_869 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26;
x_802 = x_869;
x_803 = x_867;
x_804 = x_868;
goto block_852;
}
}
else
{
lean_object* x_870; lean_object* x_871; lean_object* x_872; 
lean_dec(x_857);
x_870 = lean_ctor_get(x_853, 0);
lean_inc(x_870);
x_871 = lean_ctor_get(x_853, 1);
lean_inc(x_871);
lean_dec(x_853);
x_872 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27;
x_802 = x_872;
x_803 = x_870;
x_804 = x_871;
goto block_852;
}
}
else
{
lean_object* x_873; lean_object* x_874; lean_object* x_875; 
lean_dec(x_857);
x_873 = lean_ctor_get(x_853, 0);
lean_inc(x_873);
x_874 = lean_ctor_get(x_853, 1);
lean_inc(x_874);
lean_dec(x_853);
x_875 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28;
x_802 = x_875;
x_803 = x_873;
x_804 = x_874;
goto block_852;
}
}
block_852:
{
lean_object* x_805; lean_object* x_806; lean_object* x_807; lean_object* x_808; lean_object* x_809; lean_object* x_810; lean_object* x_811; lean_object* x_812; lean_object* x_813; lean_object* x_814; lean_object* x_815; lean_object* x_816; lean_object* x_817; lean_object* x_818; lean_object* x_819; lean_object* x_820; lean_object* x_821; lean_object* x_822; lean_object* x_823; lean_object* x_824; lean_object* x_825; lean_object* x_826; lean_object* x_827; lean_object* x_828; lean_object* x_829; lean_object* x_830; lean_object* x_831; lean_object* x_832; lean_object* x_833; lean_object* x_834; lean_object* x_835; 
x_805 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_805, 0, x_802);
x_806 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18;
if (lean_is_scalar(x_797)) {
 x_807 = lean_alloc_ctor(0, 2, 0);
} else {
 x_807 = x_797;
}
lean_ctor_set(x_807, 0, x_806);
lean_ctor_set(x_807, 1, x_805);
x_808 = l_Lean_JsonNumber_fromNat(x_793);
x_809 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_809, 0, x_808);
x_810 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19;
if (lean_is_scalar(x_792)) {
 x_811 = lean_alloc_ctor(0, 2, 0);
} else {
 x_811 = x_792;
}
lean_ctor_set(x_811, 0, x_810);
lean_ctor_set(x_811, 1, x_809);
x_812 = l_Lean_JsonNumber_fromNat(x_788);
x_813 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_813, 0, x_812);
x_814 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20;
if (lean_is_scalar(x_787)) {
 x_815 = lean_alloc_ctor(0, 2, 0);
} else {
 x_815 = x_787;
}
lean_ctor_set(x_815, 0, x_814);
lean_ctor_set(x_815, 1, x_813);
x_816 = l_List_lengthTRAux___rarg(x_803, x_772);
lean_dec(x_803);
x_817 = l_Lean_JsonNumber_fromNat(x_816);
x_818 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_818, 0, x_817);
x_819 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21;
if (lean_is_scalar(x_781)) {
 x_820 = lean_alloc_ctor(0, 2, 0);
} else {
 x_820 = x_781;
}
lean_ctor_set(x_820, 0, x_819);
lean_ctor_set(x_820, 1, x_818);
x_821 = lean_nat_sub(x_801, x_773);
lean_dec(x_773);
lean_dec(x_801);
x_822 = l_Lean_JsonNumber_fromNat(x_821);
x_823 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_823, 0, x_822);
x_824 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22;
if (lean_is_scalar(x_777)) {
 x_825 = lean_alloc_ctor(0, 2, 0);
} else {
 x_825 = x_777;
}
lean_ctor_set(x_825, 0, x_824);
lean_ctor_set(x_825, 1, x_823);
if (lean_is_scalar(x_768)) {
 x_826 = lean_alloc_ctor(1, 2, 0);
} else {
 x_826 = x_768;
 lean_ctor_set_tag(x_826, 1);
}
lean_ctor_set(x_826, 0, x_825);
lean_ctor_set(x_826, 1, x_758);
x_827 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_827, 0, x_820);
lean_ctor_set(x_827, 1, x_826);
x_828 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_828, 0, x_815);
lean_ctor_set(x_828, 1, x_827);
x_829 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_829, 0, x_811);
lean_ctor_set(x_829, 1, x_828);
x_830 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_830, 0, x_807);
lean_ctor_set(x_830, 1, x_829);
x_831 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_831, 0, x_763);
lean_ctor_set(x_831, 1, x_830);
x_832 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_832, 0, x_739);
lean_ctor_set(x_832, 1, x_831);
x_833 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17;
x_834 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_834, 0, x_833);
lean_ctor_set(x_834, 1, x_832);
x_835 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_834, x_804);
if (lean_obj_tag(x_835) == 0)
{
lean_dec(x_724);
if (lean_obj_tag(x_782) == 0)
{
lean_object* x_836; lean_object* x_837; lean_object* x_838; lean_object* x_839; 
x_836 = lean_ctor_get(x_835, 1);
lean_inc(x_836);
if (lean_is_exclusive(x_835)) {
 lean_ctor_release(x_835, 0);
 lean_ctor_release(x_835, 1);
 x_837 = x_835;
} else {
 lean_dec_ref(x_835);
 x_837 = lean_box(0);
}
x_838 = lean_box(0);
if (lean_is_scalar(x_837)) {
 x_839 = lean_alloc_ctor(0, 2, 0);
} else {
 x_839 = x_837;
}
lean_ctor_set(x_839, 0, x_838);
lean_ctor_set(x_839, 1, x_836);
return x_839;
}
else
{
lean_object* x_840; lean_object* x_841; lean_object* x_842; lean_object* x_843; 
x_840 = lean_ctor_get(x_835, 1);
lean_inc(x_840);
if (lean_is_exclusive(x_835)) {
 lean_ctor_release(x_835, 0);
 lean_ctor_release(x_835, 1);
 x_841 = x_835;
} else {
 lean_dec_ref(x_835);
 x_841 = lean_box(0);
}
x_842 = lean_ctor_get(x_782, 0);
lean_inc(x_842);
lean_dec(x_782);
if (lean_is_scalar(x_841)) {
 x_843 = lean_alloc_ctor(1, 2, 0);
} else {
 x_843 = x_841;
 lean_ctor_set_tag(x_843, 1);
}
lean_ctor_set(x_843, 0, x_842);
lean_ctor_set(x_843, 1, x_840);
return x_843;
}
}
else
{
lean_object* x_844; lean_object* x_845; lean_object* x_846; lean_object* x_847; lean_object* x_848; lean_object* x_849; lean_object* x_850; lean_object* x_851; 
lean_dec(x_782);
x_844 = lean_ctor_get(x_835, 0);
lean_inc(x_844);
x_845 = lean_ctor_get(x_835, 1);
lean_inc(x_845);
if (lean_is_exclusive(x_835)) {
 lean_ctor_release(x_835, 0);
 lean_ctor_release(x_835, 1);
 x_846 = x_835;
} else {
 lean_dec_ref(x_835);
 x_846 = lean_box(0);
}
x_847 = lean_io_error_to_string(x_844);
x_848 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_848, 0, x_847);
x_849 = l_Lean_MessageData_ofFormat(x_848);
x_850 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_850, 0, x_724);
lean_ctor_set(x_850, 1, x_849);
if (lean_is_scalar(x_846)) {
 x_851 = lean_alloc_ctor(1, 2, 0);
} else {
 x_851 = x_846;
}
lean_ctor_set(x_851, 0, x_850);
lean_ctor_set(x_851, 1, x_845);
return x_851;
}
}
}
}
block_930:
{
lean_object* x_885; lean_object* x_886; 
x_885 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29;
x_886 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_886, 0, x_885);
lean_ctor_set(x_886, 1, x_884);
if (lean_obj_tag(x_747) == 0)
{
lean_object* x_887; lean_object* x_888; lean_object* x_889; lean_object* x_890; lean_object* x_891; lean_object* x_892; lean_object* x_893; lean_object* x_894; lean_object* x_895; lean_object* x_896; 
x_887 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31;
x_888 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_888, 0, x_887);
lean_ctor_set(x_888, 1, x_760);
x_889 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_889, 0, x_745);
lean_ctor_set(x_889, 1, x_888);
x_890 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_890, 0, x_742);
lean_ctor_set(x_890, 1, x_889);
x_891 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_891, 0, x_886);
lean_ctor_set(x_891, 1, x_890);
lean_inc(x_763);
x_892 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_892, 0, x_763);
lean_ctor_set(x_892, 1, x_891);
lean_inc(x_739);
x_893 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_893, 0, x_739);
lean_ctor_set(x_893, 1, x_892);
x_894 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_895 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_895, 0, x_894);
lean_ctor_set(x_895, 1, x_893);
x_896 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_895, x_733);
if (lean_obj_tag(x_896) == 0)
{
lean_object* x_897; 
x_897 = lean_ctor_get(x_896, 1);
lean_inc(x_897);
lean_dec(x_896);
x_764 = x_897;
goto block_883;
}
else
{
lean_object* x_898; lean_object* x_899; lean_object* x_900; lean_object* x_901; lean_object* x_902; lean_object* x_903; lean_object* x_904; lean_object* x_905; 
lean_dec(x_763);
lean_dec(x_739);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_898 = lean_ctor_get(x_896, 0);
lean_inc(x_898);
x_899 = lean_ctor_get(x_896, 1);
lean_inc(x_899);
if (lean_is_exclusive(x_896)) {
 lean_ctor_release(x_896, 0);
 lean_ctor_release(x_896, 1);
 x_900 = x_896;
} else {
 lean_dec_ref(x_896);
 x_900 = lean_box(0);
}
x_901 = lean_io_error_to_string(x_898);
x_902 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_902, 0, x_901);
x_903 = l_Lean_MessageData_ofFormat(x_902);
x_904 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_904, 0, x_724);
lean_ctor_set(x_904, 1, x_903);
if (lean_is_scalar(x_900)) {
 x_905 = lean_alloc_ctor(1, 2, 0);
} else {
 x_905 = x_900;
}
lean_ctor_set(x_905, 0, x_904);
lean_ctor_set(x_905, 1, x_899);
return x_905;
}
}
else
{
lean_object* x_906; lean_object* x_907; lean_object* x_908; lean_object* x_909; lean_object* x_910; lean_object* x_911; lean_object* x_912; lean_object* x_913; lean_object* x_914; lean_object* x_915; lean_object* x_916; lean_object* x_917; lean_object* x_918; lean_object* x_919; lean_object* x_920; 
x_906 = lean_ctor_get(x_747, 0);
lean_inc(x_906);
if (lean_is_exclusive(x_747)) {
 lean_ctor_release(x_747, 0);
 x_907 = x_747;
} else {
 lean_dec_ref(x_747);
 x_907 = lean_box(0);
}
x_908 = l_Lean_JsonNumber_fromNat(x_906);
if (lean_is_scalar(x_907)) {
 x_909 = lean_alloc_ctor(2, 1, 0);
} else {
 x_909 = x_907;
 lean_ctor_set_tag(x_909, 2);
}
lean_ctor_set(x_909, 0, x_908);
x_910 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
x_911 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_911, 0, x_910);
lean_ctor_set(x_911, 1, x_909);
x_912 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_912, 0, x_911);
lean_ctor_set(x_912, 1, x_760);
x_913 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_913, 0, x_745);
lean_ctor_set(x_913, 1, x_912);
x_914 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_914, 0, x_742);
lean_ctor_set(x_914, 1, x_913);
x_915 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_915, 0, x_886);
lean_ctor_set(x_915, 1, x_914);
lean_inc(x_763);
x_916 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_916, 0, x_763);
lean_ctor_set(x_916, 1, x_915);
lean_inc(x_739);
x_917 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_917, 0, x_739);
lean_ctor_set(x_917, 1, x_916);
x_918 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_919 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_919, 0, x_918);
lean_ctor_set(x_919, 1, x_917);
x_920 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_919, x_733);
if (lean_obj_tag(x_920) == 0)
{
lean_object* x_921; 
x_921 = lean_ctor_get(x_920, 1);
lean_inc(x_921);
lean_dec(x_920);
x_764 = x_921;
goto block_883;
}
else
{
lean_object* x_922; lean_object* x_923; lean_object* x_924; lean_object* x_925; lean_object* x_926; lean_object* x_927; lean_object* x_928; lean_object* x_929; 
lean_dec(x_763);
lean_dec(x_739);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_922 = lean_ctor_get(x_920, 0);
lean_inc(x_922);
x_923 = lean_ctor_get(x_920, 1);
lean_inc(x_923);
if (lean_is_exclusive(x_920)) {
 lean_ctor_release(x_920, 0);
 lean_ctor_release(x_920, 1);
 x_924 = x_920;
} else {
 lean_dec_ref(x_920);
 x_924 = lean_box(0);
}
x_925 = lean_io_error_to_string(x_922);
x_926 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_926, 0, x_925);
x_927 = l_Lean_MessageData_ofFormat(x_926);
x_928 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_928, 0, x_724);
lean_ctor_set(x_928, 1, x_927);
if (lean_is_scalar(x_924)) {
 x_929 = lean_alloc_ctor(1, 2, 0);
} else {
 x_929 = x_924;
}
lean_ctor_set(x_929, 0, x_928);
lean_ctor_set(x_929, 1, x_923);
return x_929;
}
}
}
}
}
else
{
lean_object* x_943; lean_object* x_944; lean_object* x_945; lean_object* x_946; lean_object* x_947; lean_object* x_948; lean_object* x_949; 
lean_dec(x_723);
lean_dec(x_722);
lean_dec(x_721);
lean_dec(x_18);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_943 = lean_ctor_get(x_725, 0);
lean_inc(x_943);
x_944 = lean_ctor_get(x_725, 1);
lean_inc(x_944);
if (lean_is_exclusive(x_725)) {
 lean_ctor_release(x_725, 0);
 lean_ctor_release(x_725, 1);
 x_945 = x_725;
} else {
 lean_dec_ref(x_725);
 x_945 = lean_box(0);
}
x_946 = lean_io_error_to_string(x_943);
x_947 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_947, 0, x_946);
x_948 = l_Lean_MessageData_ofFormat(x_947);
lean_ctor_set(x_16, 1, x_948);
lean_ctor_set(x_16, 0, x_724);
if (lean_is_scalar(x_945)) {
 x_949 = lean_alloc_ctor(1, 2, 0);
} else {
 x_949 = x_945;
}
lean_ctor_set(x_949, 0, x_16);
lean_ctor_set(x_949, 1, x_944);
return x_949;
}
}
}
else
{
uint8_t x_950; 
lean_free_object(x_16);
lean_dec(x_18);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_950 = !lean_is_exclusive(x_20);
if (x_950 == 0)
{
return x_20;
}
else
{
lean_object* x_951; lean_object* x_952; lean_object* x_953; 
x_951 = lean_ctor_get(x_20, 0);
x_952 = lean_ctor_get(x_20, 1);
lean_inc(x_952);
lean_inc(x_951);
lean_dec(x_20);
x_953 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_953, 0, x_951);
lean_ctor_set(x_953, 1, x_952);
return x_953;
}
}
}
else
{
lean_object* x_954; lean_object* x_955; lean_object* x_956; 
x_954 = lean_ctor_get(x_16, 0);
x_955 = lean_ctor_get(x_16, 1);
lean_inc(x_955);
lean_inc(x_954);
lean_dec(x_16);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_15);
x_956 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_955);
if (lean_obj_tag(x_956) == 0)
{
lean_object* x_957; lean_object* x_958; lean_object* x_959; lean_object* x_960; lean_object* x_961; lean_object* x_962; lean_object* x_963; lean_object* x_964; 
x_957 = lean_ctor_get(x_956, 0);
lean_inc(x_957);
x_958 = lean_ctor_get(x_956, 1);
lean_inc(x_958);
lean_dec(x_956);
x_959 = lean_ctor_get(x_957, 0);
lean_inc(x_959);
x_960 = lean_ctor_get(x_957, 1);
lean_inc(x_960);
if (lean_is_exclusive(x_957)) {
 lean_ctor_release(x_957, 0);
 lean_ctor_release(x_957, 1);
 x_961 = x_957;
} else {
 lean_dec_ref(x_957);
 x_961 = lean_box(0);
}
x_962 = lean_ctor_get(x_8, 0);
lean_inc(x_962);
x_963 = lean_ctor_get(x_8, 5);
lean_inc(x_963);
lean_inc(x_959);
x_964 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_register(x_959, x_958);
if (lean_obj_tag(x_964) == 0)
{
lean_object* x_965; lean_object* x_966; lean_object* x_967; lean_object* x_968; lean_object* x_969; lean_object* x_970; lean_object* x_971; lean_object* x_972; lean_object* x_973; lean_object* x_974; lean_object* x_975; lean_object* x_976; lean_object* x_977; lean_object* x_978; lean_object* x_979; lean_object* x_980; lean_object* x_981; lean_object* x_982; lean_object* x_983; lean_object* x_984; uint8_t x_985; lean_object* x_986; lean_object* x_987; uint8_t x_988; lean_object* x_989; lean_object* x_990; lean_object* x_991; lean_object* x_992; lean_object* x_993; lean_object* x_994; lean_object* x_995; lean_object* x_996; lean_object* x_997; lean_object* x_998; lean_object* x_999; lean_object* x_1000; lean_object* x_1001; 
x_965 = lean_ctor_get(x_964, 0);
lean_inc(x_965);
x_966 = lean_ctor_get(x_964, 1);
lean_inc(x_966);
lean_dec(x_964);
x_967 = lean_ctor_get(x_965, 0);
lean_inc(x_967);
x_968 = lean_ctor_get(x_965, 1);
lean_inc(x_968);
if (lean_is_exclusive(x_965)) {
 lean_ctor_release(x_965, 0);
 lean_ctor_release(x_965, 1);
 x_969 = x_965;
} else {
 lean_dec_ref(x_965);
 x_969 = lean_box(0);
}
x_970 = lean_io_mono_nanos_now(x_966);
x_971 = lean_ctor_get(x_970, 0);
lean_inc(x_971);
x_972 = lean_ctor_get(x_970, 1);
lean_inc(x_972);
if (lean_is_exclusive(x_970)) {
 lean_ctor_release(x_970, 0);
 lean_ctor_release(x_970, 1);
 x_973 = x_970;
} else {
 lean_dec_ref(x_970);
 x_973 = lean_box(0);
}
x_974 = lean_nat_sub(x_971, x_954);
lean_dec(x_954);
lean_dec(x_971);
x_975 = l_Lean_JsonNumber_fromNat(x_967);
x_976 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_976, 0, x_975);
x_977 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5;
if (lean_is_scalar(x_969)) {
 x_978 = lean_alloc_ctor(0, 2, 0);
} else {
 x_978 = x_969;
}
lean_ctor_set(x_978, 0, x_977);
lean_ctor_set(x_978, 1, x_976);
x_979 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_979, 0, x_960);
x_980 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6;
if (lean_is_scalar(x_961)) {
 x_981 = lean_alloc_ctor(0, 2, 0);
} else {
 x_981 = x_961;
}
lean_ctor_set(x_981, 0, x_980);
lean_ctor_set(x_981, 1, x_979);
x_982 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_982, 0, x_962);
x_983 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7;
if (lean_is_scalar(x_973)) {
 x_984 = lean_alloc_ctor(0, 2, 0);
} else {
 x_984 = x_973;
}
lean_ctor_set(x_984, 0, x_983);
lean_ctor_set(x_984, 1, x_982);
x_985 = 0;
x_986 = l_Lean_Syntax_getPos_x3f(x_15, x_985);
lean_inc(x_15);
x_987 = l_Lean_Syntax_getKind(x_15);
x_988 = 1;
x_989 = l_Lean_Name_toString(x_987, x_988);
x_990 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_990, 0, x_989);
x_991 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8;
x_992 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_992, 0, x_991);
lean_ctor_set(x_992, 1, x_990);
x_993 = l_Lean_JsonNumber_fromNat(x_974);
x_994 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_994, 0, x_993);
x_995 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9;
x_996 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_996, 0, x_995);
lean_ctor_set(x_996, 1, x_994);
x_997 = lean_box(0);
x_998 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13;
x_999 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_999, 0, x_996);
lean_ctor_set(x_999, 1, x_998);
x_1000 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1000, 0, x_992);
lean_ctor_set(x_1000, 1, x_999);
if (lean_obj_tag(x_968) == 0)
{
lean_object* x_1178; 
x_1178 = lean_box(0);
x_1001 = x_1178;
goto block_1177;
}
else
{
lean_object* x_1179; lean_object* x_1180; lean_object* x_1181; lean_object* x_1182; 
x_1179 = lean_ctor_get(x_968, 0);
lean_inc(x_1179);
if (lean_is_exclusive(x_968)) {
 lean_ctor_release(x_968, 0);
 x_1180 = x_968;
} else {
 lean_dec_ref(x_968);
 x_1180 = lean_box(0);
}
x_1181 = l_Lean_JsonNumber_fromNat(x_1179);
if (lean_is_scalar(x_1180)) {
 x_1182 = lean_alloc_ctor(2, 1, 0);
} else {
 x_1182 = x_1180;
 lean_ctor_set_tag(x_1182, 2);
}
lean_ctor_set(x_1182, 0, x_1181);
x_1001 = x_1182;
goto block_1177;
}
block_1177:
{
lean_object* x_1002; lean_object* x_1003; lean_object* x_1004; lean_object* x_1124; 
x_1002 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14;
x_1003 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_1003, 0, x_1002);
lean_ctor_set(x_1003, 1, x_1001);
if (lean_obj_tag(x_959) == 0)
{
lean_object* x_1171; 
x_1171 = lean_box(0);
x_1124 = x_1171;
goto block_1170;
}
else
{
lean_object* x_1172; lean_object* x_1173; lean_object* x_1174; lean_object* x_1175; lean_object* x_1176; 
x_1172 = lean_ctor_get(x_959, 0);
lean_inc(x_1172);
if (lean_is_exclusive(x_959)) {
 lean_ctor_release(x_959, 0);
 x_1173 = x_959;
} else {
 lean_dec_ref(x_959);
 x_1173 = lean_box(0);
}
x_1174 = lean_ctor_get(x_1172, 0);
lean_inc(x_1174);
lean_dec(x_1172);
x_1175 = l_Lean_JsonNumber_fromNat(x_1174);
if (lean_is_scalar(x_1173)) {
 x_1176 = lean_alloc_ctor(2, 1, 0);
} else {
 x_1176 = x_1173;
 lean_ctor_set_tag(x_1176, 2);
}
lean_ctor_set(x_1176, 0, x_1175);
x_1124 = x_1176;
goto block_1170;
}
block_1123:
{
lean_object* x_1005; lean_object* x_1006; lean_object* x_1007; lean_object* x_1008; lean_object* x_1009; lean_object* x_1010; lean_object* x_1011; lean_object* x_1012; lean_object* x_1013; lean_object* x_1014; lean_object* x_1015; lean_object* x_1016; lean_object* x_1017; lean_object* x_1018; lean_object* x_1019; lean_object* x_1020; lean_object* x_1021; lean_object* x_1022; lean_object* x_1023; lean_object* x_1117; 
x_1005 = lean_st_ref_get(x_9, x_1004);
x_1006 = lean_ctor_get(x_1005, 0);
lean_inc(x_1006);
x_1007 = lean_ctor_get(x_1005, 1);
lean_inc(x_1007);
if (lean_is_exclusive(x_1005)) {
 lean_ctor_release(x_1005, 0);
 lean_ctor_release(x_1005, 1);
 x_1008 = x_1005;
} else {
 lean_dec_ref(x_1005);
 x_1008 = lean_box(0);
}
x_1009 = lean_ctor_get(x_1006, 5);
lean_inc(x_1009);
lean_dec(x_1006);
x_1010 = l_Lean_MessageLog_toList(x_1009);
x_1011 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_1010, x_997);
x_1012 = lean_unsigned_to_nat(0u);
x_1013 = l_List_lengthTRAux___rarg(x_1011, x_1012);
lean_dec(x_1011);
x_1014 = lean_io_mono_nanos_now(x_1007);
x_1015 = lean_ctor_get(x_1014, 0);
lean_inc(x_1015);
x_1016 = lean_ctor_get(x_1014, 1);
lean_inc(x_1016);
if (lean_is_exclusive(x_1014)) {
 lean_ctor_release(x_1014, 0);
 lean_ctor_release(x_1014, 1);
 x_1017 = x_1014;
} else {
 lean_dec_ref(x_1014);
 x_1017 = lean_box(0);
}
x_1018 = lean_io_get_num_heartbeats(x_1016);
x_1019 = lean_ctor_get(x_1018, 0);
lean_inc(x_1019);
x_1020 = lean_ctor_get(x_1018, 1);
lean_inc(x_1020);
if (lean_is_exclusive(x_1018)) {
 lean_ctor_release(x_1018, 0);
 lean_ctor_release(x_1018, 1);
 x_1021 = x_1018;
} else {
 lean_dec_ref(x_1018);
 x_1021 = lean_box(0);
}
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
x_1117 = l_Lean_Elab_Tactic_evalTactic(x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_1020);
if (lean_obj_tag(x_1117) == 0)
{
lean_object* x_1118; lean_object* x_1119; 
x_1118 = lean_ctor_get(x_1117, 1);
lean_inc(x_1118);
lean_dec(x_1117);
x_1119 = lean_box(0);
x_1022 = x_1119;
x_1023 = x_1118;
goto block_1116;
}
else
{
lean_object* x_1120; lean_object* x_1121; lean_object* x_1122; 
x_1120 = lean_ctor_get(x_1117, 0);
lean_inc(x_1120);
x_1121 = lean_ctor_get(x_1117, 1);
lean_inc(x_1121);
lean_dec(x_1117);
x_1122 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_1122, 0, x_1120);
x_1022 = x_1122;
x_1023 = x_1121;
goto block_1116;
}
block_1116:
{
lean_object* x_1024; lean_object* x_1025; lean_object* x_1026; lean_object* x_1027; lean_object* x_1028; lean_object* x_1029; lean_object* x_1030; lean_object* x_1031; lean_object* x_1032; lean_object* x_1033; lean_object* x_1034; lean_object* x_1035; lean_object* x_1036; lean_object* x_1037; lean_object* x_1038; lean_object* x_1039; lean_object* x_1040; lean_object* x_1041; lean_object* x_1042; lean_object* x_1043; lean_object* x_1044; lean_object* x_1093; 
x_1024 = lean_io_get_num_heartbeats(x_1023);
x_1025 = lean_ctor_get(x_1024, 0);
lean_inc(x_1025);
x_1026 = lean_ctor_get(x_1024, 1);
lean_inc(x_1026);
if (lean_is_exclusive(x_1024)) {
 lean_ctor_release(x_1024, 0);
 lean_ctor_release(x_1024, 1);
 x_1027 = x_1024;
} else {
 lean_dec_ref(x_1024);
 x_1027 = lean_box(0);
}
x_1028 = lean_nat_sub(x_1025, x_1019);
lean_dec(x_1019);
lean_dec(x_1025);
x_1029 = lean_io_mono_nanos_now(x_1026);
x_1030 = lean_ctor_get(x_1029, 0);
lean_inc(x_1030);
x_1031 = lean_ctor_get(x_1029, 1);
lean_inc(x_1031);
if (lean_is_exclusive(x_1029)) {
 lean_ctor_release(x_1029, 0);
 lean_ctor_release(x_1029, 1);
 x_1032 = x_1029;
} else {
 lean_dec_ref(x_1029);
 x_1032 = lean_box(0);
}
x_1033 = lean_nat_sub(x_1030, x_1015);
lean_dec(x_1015);
lean_dec(x_1030);
x_1034 = lean_st_ref_get(x_9, x_1031);
x_1035 = lean_ctor_get(x_1034, 0);
lean_inc(x_1035);
x_1036 = lean_ctor_get(x_1034, 1);
lean_inc(x_1036);
if (lean_is_exclusive(x_1034)) {
 lean_ctor_release(x_1034, 0);
 lean_ctor_release(x_1034, 1);
 x_1037 = x_1034;
} else {
 lean_dec_ref(x_1034);
 x_1037 = lean_box(0);
}
x_1038 = lean_ctor_get(x_1035, 5);
lean_inc(x_1038);
lean_dec(x_1035);
x_1039 = l_Lean_MessageLog_toList(x_1038);
x_1040 = l_List_filterTR_loop___at_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___spec__1(x_1039, x_997);
x_1041 = l_List_lengthTRAux___rarg(x_1040, x_1012);
lean_dec(x_1040);
x_1093 = l_Lean_Elab_Tactic_getGoals___rarg(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_1036);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
if (lean_obj_tag(x_1022) == 0)
{
lean_object* x_1094; lean_object* x_1095; lean_object* x_1096; 
x_1094 = lean_ctor_get(x_1093, 0);
lean_inc(x_1094);
x_1095 = lean_ctor_get(x_1093, 1);
lean_inc(x_1095);
lean_dec(x_1093);
x_1096 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23;
x_1042 = x_1096;
x_1043 = x_1094;
x_1044 = x_1095;
goto block_1092;
}
else
{
lean_object* x_1097; uint8_t x_1098; 
x_1097 = lean_ctor_get(x_1022, 0);
lean_inc(x_1097);
x_1098 = l_Lean_Exception_isMaxHeartbeat(x_1097);
if (x_1098 == 0)
{
uint8_t x_1099; 
x_1099 = l_Lean_Exception_isMaxRecDepth(x_1097);
if (x_1099 == 0)
{
uint8_t x_1100; 
x_1100 = l_Lean_Exception_isInterrupt(x_1097);
if (x_1100 == 0)
{
if (lean_obj_tag(x_1097) == 0)
{
lean_object* x_1101; lean_object* x_1102; lean_object* x_1103; 
lean_dec(x_1097);
x_1101 = lean_ctor_get(x_1093, 0);
lean_inc(x_1101);
x_1102 = lean_ctor_get(x_1093, 1);
lean_inc(x_1102);
lean_dec(x_1093);
x_1103 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24;
x_1042 = x_1103;
x_1043 = x_1101;
x_1044 = x_1102;
goto block_1092;
}
else
{
lean_object* x_1104; lean_object* x_1105; lean_object* x_1106; 
lean_dec(x_1097);
x_1104 = lean_ctor_get(x_1093, 0);
lean_inc(x_1104);
x_1105 = lean_ctor_get(x_1093, 1);
lean_inc(x_1105);
lean_dec(x_1093);
x_1106 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25;
x_1042 = x_1106;
x_1043 = x_1104;
x_1044 = x_1105;
goto block_1092;
}
}
else
{
lean_object* x_1107; lean_object* x_1108; lean_object* x_1109; 
lean_dec(x_1097);
x_1107 = lean_ctor_get(x_1093, 0);
lean_inc(x_1107);
x_1108 = lean_ctor_get(x_1093, 1);
lean_inc(x_1108);
lean_dec(x_1093);
x_1109 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26;
x_1042 = x_1109;
x_1043 = x_1107;
x_1044 = x_1108;
goto block_1092;
}
}
else
{
lean_object* x_1110; lean_object* x_1111; lean_object* x_1112; 
lean_dec(x_1097);
x_1110 = lean_ctor_get(x_1093, 0);
lean_inc(x_1110);
x_1111 = lean_ctor_get(x_1093, 1);
lean_inc(x_1111);
lean_dec(x_1093);
x_1112 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27;
x_1042 = x_1112;
x_1043 = x_1110;
x_1044 = x_1111;
goto block_1092;
}
}
else
{
lean_object* x_1113; lean_object* x_1114; lean_object* x_1115; 
lean_dec(x_1097);
x_1113 = lean_ctor_get(x_1093, 0);
lean_inc(x_1113);
x_1114 = lean_ctor_get(x_1093, 1);
lean_inc(x_1114);
lean_dec(x_1093);
x_1115 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28;
x_1042 = x_1115;
x_1043 = x_1113;
x_1044 = x_1114;
goto block_1092;
}
}
block_1092:
{
lean_object* x_1045; lean_object* x_1046; lean_object* x_1047; lean_object* x_1048; lean_object* x_1049; lean_object* x_1050; lean_object* x_1051; lean_object* x_1052; lean_object* x_1053; lean_object* x_1054; lean_object* x_1055; lean_object* x_1056; lean_object* x_1057; lean_object* x_1058; lean_object* x_1059; lean_object* x_1060; lean_object* x_1061; lean_object* x_1062; lean_object* x_1063; lean_object* x_1064; lean_object* x_1065; lean_object* x_1066; lean_object* x_1067; lean_object* x_1068; lean_object* x_1069; lean_object* x_1070; lean_object* x_1071; lean_object* x_1072; lean_object* x_1073; lean_object* x_1074; lean_object* x_1075; 
x_1045 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_1045, 0, x_1042);
x_1046 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18;
if (lean_is_scalar(x_1037)) {
 x_1047 = lean_alloc_ctor(0, 2, 0);
} else {
 x_1047 = x_1037;
}
lean_ctor_set(x_1047, 0, x_1046);
lean_ctor_set(x_1047, 1, x_1045);
x_1048 = l_Lean_JsonNumber_fromNat(x_1033);
x_1049 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_1049, 0, x_1048);
x_1050 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19;
if (lean_is_scalar(x_1032)) {
 x_1051 = lean_alloc_ctor(0, 2, 0);
} else {
 x_1051 = x_1032;
}
lean_ctor_set(x_1051, 0, x_1050);
lean_ctor_set(x_1051, 1, x_1049);
x_1052 = l_Lean_JsonNumber_fromNat(x_1028);
x_1053 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_1053, 0, x_1052);
x_1054 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20;
if (lean_is_scalar(x_1027)) {
 x_1055 = lean_alloc_ctor(0, 2, 0);
} else {
 x_1055 = x_1027;
}
lean_ctor_set(x_1055, 0, x_1054);
lean_ctor_set(x_1055, 1, x_1053);
x_1056 = l_List_lengthTRAux___rarg(x_1043, x_1012);
lean_dec(x_1043);
x_1057 = l_Lean_JsonNumber_fromNat(x_1056);
x_1058 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_1058, 0, x_1057);
x_1059 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21;
if (lean_is_scalar(x_1021)) {
 x_1060 = lean_alloc_ctor(0, 2, 0);
} else {
 x_1060 = x_1021;
}
lean_ctor_set(x_1060, 0, x_1059);
lean_ctor_set(x_1060, 1, x_1058);
x_1061 = lean_nat_sub(x_1041, x_1013);
lean_dec(x_1013);
lean_dec(x_1041);
x_1062 = l_Lean_JsonNumber_fromNat(x_1061);
x_1063 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_1063, 0, x_1062);
x_1064 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22;
if (lean_is_scalar(x_1017)) {
 x_1065 = lean_alloc_ctor(0, 2, 0);
} else {
 x_1065 = x_1017;
}
lean_ctor_set(x_1065, 0, x_1064);
lean_ctor_set(x_1065, 1, x_1063);
if (lean_is_scalar(x_1008)) {
 x_1066 = lean_alloc_ctor(1, 2, 0);
} else {
 x_1066 = x_1008;
 lean_ctor_set_tag(x_1066, 1);
}
lean_ctor_set(x_1066, 0, x_1065);
lean_ctor_set(x_1066, 1, x_998);
x_1067 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1067, 0, x_1060);
lean_ctor_set(x_1067, 1, x_1066);
x_1068 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1068, 0, x_1055);
lean_ctor_set(x_1068, 1, x_1067);
x_1069 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1069, 0, x_1051);
lean_ctor_set(x_1069, 1, x_1068);
x_1070 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1070, 0, x_1047);
lean_ctor_set(x_1070, 1, x_1069);
x_1071 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1071, 0, x_1003);
lean_ctor_set(x_1071, 1, x_1070);
x_1072 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1072, 0, x_978);
lean_ctor_set(x_1072, 1, x_1071);
x_1073 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17;
x_1074 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1074, 0, x_1073);
lean_ctor_set(x_1074, 1, x_1072);
x_1075 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_1074, x_1044);
if (lean_obj_tag(x_1075) == 0)
{
lean_dec(x_963);
if (lean_obj_tag(x_1022) == 0)
{
lean_object* x_1076; lean_object* x_1077; lean_object* x_1078; lean_object* x_1079; 
x_1076 = lean_ctor_get(x_1075, 1);
lean_inc(x_1076);
if (lean_is_exclusive(x_1075)) {
 lean_ctor_release(x_1075, 0);
 lean_ctor_release(x_1075, 1);
 x_1077 = x_1075;
} else {
 lean_dec_ref(x_1075);
 x_1077 = lean_box(0);
}
x_1078 = lean_box(0);
if (lean_is_scalar(x_1077)) {
 x_1079 = lean_alloc_ctor(0, 2, 0);
} else {
 x_1079 = x_1077;
}
lean_ctor_set(x_1079, 0, x_1078);
lean_ctor_set(x_1079, 1, x_1076);
return x_1079;
}
else
{
lean_object* x_1080; lean_object* x_1081; lean_object* x_1082; lean_object* x_1083; 
x_1080 = lean_ctor_get(x_1075, 1);
lean_inc(x_1080);
if (lean_is_exclusive(x_1075)) {
 lean_ctor_release(x_1075, 0);
 lean_ctor_release(x_1075, 1);
 x_1081 = x_1075;
} else {
 lean_dec_ref(x_1075);
 x_1081 = lean_box(0);
}
x_1082 = lean_ctor_get(x_1022, 0);
lean_inc(x_1082);
lean_dec(x_1022);
if (lean_is_scalar(x_1081)) {
 x_1083 = lean_alloc_ctor(1, 2, 0);
} else {
 x_1083 = x_1081;
 lean_ctor_set_tag(x_1083, 1);
}
lean_ctor_set(x_1083, 0, x_1082);
lean_ctor_set(x_1083, 1, x_1080);
return x_1083;
}
}
else
{
lean_object* x_1084; lean_object* x_1085; lean_object* x_1086; lean_object* x_1087; lean_object* x_1088; lean_object* x_1089; lean_object* x_1090; lean_object* x_1091; 
lean_dec(x_1022);
x_1084 = lean_ctor_get(x_1075, 0);
lean_inc(x_1084);
x_1085 = lean_ctor_get(x_1075, 1);
lean_inc(x_1085);
if (lean_is_exclusive(x_1075)) {
 lean_ctor_release(x_1075, 0);
 lean_ctor_release(x_1075, 1);
 x_1086 = x_1075;
} else {
 lean_dec_ref(x_1075);
 x_1086 = lean_box(0);
}
x_1087 = lean_io_error_to_string(x_1084);
x_1088 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_1088, 0, x_1087);
x_1089 = l_Lean_MessageData_ofFormat(x_1088);
x_1090 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_1090, 0, x_963);
lean_ctor_set(x_1090, 1, x_1089);
if (lean_is_scalar(x_1086)) {
 x_1091 = lean_alloc_ctor(1, 2, 0);
} else {
 x_1091 = x_1086;
}
lean_ctor_set(x_1091, 0, x_1090);
lean_ctor_set(x_1091, 1, x_1085);
return x_1091;
}
}
}
}
block_1170:
{
lean_object* x_1125; lean_object* x_1126; 
x_1125 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29;
x_1126 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_1126, 0, x_1125);
lean_ctor_set(x_1126, 1, x_1124);
if (lean_obj_tag(x_986) == 0)
{
lean_object* x_1127; lean_object* x_1128; lean_object* x_1129; lean_object* x_1130; lean_object* x_1131; lean_object* x_1132; lean_object* x_1133; lean_object* x_1134; lean_object* x_1135; lean_object* x_1136; 
x_1127 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31;
x_1128 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1128, 0, x_1127);
lean_ctor_set(x_1128, 1, x_1000);
x_1129 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1129, 0, x_984);
lean_ctor_set(x_1129, 1, x_1128);
x_1130 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1130, 0, x_981);
lean_ctor_set(x_1130, 1, x_1129);
x_1131 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1131, 0, x_1126);
lean_ctor_set(x_1131, 1, x_1130);
lean_inc(x_1003);
x_1132 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1132, 0, x_1003);
lean_ctor_set(x_1132, 1, x_1131);
lean_inc(x_978);
x_1133 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1133, 0, x_978);
lean_ctor_set(x_1133, 1, x_1132);
x_1134 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_1135 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1135, 0, x_1134);
lean_ctor_set(x_1135, 1, x_1133);
x_1136 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_1135, x_972);
if (lean_obj_tag(x_1136) == 0)
{
lean_object* x_1137; 
x_1137 = lean_ctor_get(x_1136, 1);
lean_inc(x_1137);
lean_dec(x_1136);
x_1004 = x_1137;
goto block_1123;
}
else
{
lean_object* x_1138; lean_object* x_1139; lean_object* x_1140; lean_object* x_1141; lean_object* x_1142; lean_object* x_1143; lean_object* x_1144; lean_object* x_1145; 
lean_dec(x_1003);
lean_dec(x_978);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_1138 = lean_ctor_get(x_1136, 0);
lean_inc(x_1138);
x_1139 = lean_ctor_get(x_1136, 1);
lean_inc(x_1139);
if (lean_is_exclusive(x_1136)) {
 lean_ctor_release(x_1136, 0);
 lean_ctor_release(x_1136, 1);
 x_1140 = x_1136;
} else {
 lean_dec_ref(x_1136);
 x_1140 = lean_box(0);
}
x_1141 = lean_io_error_to_string(x_1138);
x_1142 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_1142, 0, x_1141);
x_1143 = l_Lean_MessageData_ofFormat(x_1142);
x_1144 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_1144, 0, x_963);
lean_ctor_set(x_1144, 1, x_1143);
if (lean_is_scalar(x_1140)) {
 x_1145 = lean_alloc_ctor(1, 2, 0);
} else {
 x_1145 = x_1140;
}
lean_ctor_set(x_1145, 0, x_1144);
lean_ctor_set(x_1145, 1, x_1139);
return x_1145;
}
}
else
{
lean_object* x_1146; lean_object* x_1147; lean_object* x_1148; lean_object* x_1149; lean_object* x_1150; lean_object* x_1151; lean_object* x_1152; lean_object* x_1153; lean_object* x_1154; lean_object* x_1155; lean_object* x_1156; lean_object* x_1157; lean_object* x_1158; lean_object* x_1159; lean_object* x_1160; 
x_1146 = lean_ctor_get(x_986, 0);
lean_inc(x_1146);
if (lean_is_exclusive(x_986)) {
 lean_ctor_release(x_986, 0);
 x_1147 = x_986;
} else {
 lean_dec_ref(x_986);
 x_1147 = lean_box(0);
}
x_1148 = l_Lean_JsonNumber_fromNat(x_1146);
if (lean_is_scalar(x_1147)) {
 x_1149 = lean_alloc_ctor(2, 1, 0);
} else {
 x_1149 = x_1147;
 lean_ctor_set_tag(x_1149, 2);
}
lean_ctor_set(x_1149, 0, x_1148);
x_1150 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30;
x_1151 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_1151, 0, x_1150);
lean_ctor_set(x_1151, 1, x_1149);
x_1152 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1152, 0, x_1151);
lean_ctor_set(x_1152, 1, x_1000);
x_1153 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1153, 0, x_984);
lean_ctor_set(x_1153, 1, x_1152);
x_1154 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1154, 0, x_981);
lean_ctor_set(x_1154, 1, x_1153);
x_1155 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1155, 0, x_1126);
lean_ctor_set(x_1155, 1, x_1154);
lean_inc(x_1003);
x_1156 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1156, 0, x_1003);
lean_ctor_set(x_1156, 1, x_1155);
lean_inc(x_978);
x_1157 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1157, 0, x_978);
lean_ctor_set(x_1157, 1, x_1156);
x_1158 = l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4;
x_1159 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_1159, 0, x_1158);
lean_ctor_set(x_1159, 1, x_1157);
x_1160 = l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit(x_1159, x_972);
if (lean_obj_tag(x_1160) == 0)
{
lean_object* x_1161; 
x_1161 = lean_ctor_get(x_1160, 1);
lean_inc(x_1161);
lean_dec(x_1160);
x_1004 = x_1161;
goto block_1123;
}
else
{
lean_object* x_1162; lean_object* x_1163; lean_object* x_1164; lean_object* x_1165; lean_object* x_1166; lean_object* x_1167; lean_object* x_1168; lean_object* x_1169; 
lean_dec(x_1003);
lean_dec(x_978);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_1162 = lean_ctor_get(x_1160, 0);
lean_inc(x_1162);
x_1163 = lean_ctor_get(x_1160, 1);
lean_inc(x_1163);
if (lean_is_exclusive(x_1160)) {
 lean_ctor_release(x_1160, 0);
 lean_ctor_release(x_1160, 1);
 x_1164 = x_1160;
} else {
 lean_dec_ref(x_1160);
 x_1164 = lean_box(0);
}
x_1165 = lean_io_error_to_string(x_1162);
x_1166 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_1166, 0, x_1165);
x_1167 = l_Lean_MessageData_ofFormat(x_1166);
x_1168 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_1168, 0, x_963);
lean_ctor_set(x_1168, 1, x_1167);
if (lean_is_scalar(x_1164)) {
 x_1169 = lean_alloc_ctor(1, 2, 0);
} else {
 x_1169 = x_1164;
}
lean_ctor_set(x_1169, 0, x_1168);
lean_ctor_set(x_1169, 1, x_1163);
return x_1169;
}
}
}
}
}
else
{
lean_object* x_1183; lean_object* x_1184; lean_object* x_1185; lean_object* x_1186; lean_object* x_1187; lean_object* x_1188; lean_object* x_1189; lean_object* x_1190; 
lean_dec(x_962);
lean_dec(x_961);
lean_dec(x_960);
lean_dec(x_959);
lean_dec(x_954);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_1183 = lean_ctor_get(x_964, 0);
lean_inc(x_1183);
x_1184 = lean_ctor_get(x_964, 1);
lean_inc(x_1184);
if (lean_is_exclusive(x_964)) {
 lean_ctor_release(x_964, 0);
 lean_ctor_release(x_964, 1);
 x_1185 = x_964;
} else {
 lean_dec_ref(x_964);
 x_1185 = lean_box(0);
}
x_1186 = lean_io_error_to_string(x_1183);
x_1187 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_1187, 0, x_1186);
x_1188 = l_Lean_MessageData_ofFormat(x_1187);
x_1189 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_1189, 0, x_963);
lean_ctor_set(x_1189, 1, x_1188);
if (lean_is_scalar(x_1185)) {
 x_1190 = lean_alloc_ctor(1, 2, 0);
} else {
 x_1190 = x_1185;
}
lean_ctor_set(x_1190, 0, x_1189);
lean_ctor_set(x_1190, 1, x_1184);
return x_1190;
}
}
else
{
lean_object* x_1191; lean_object* x_1192; lean_object* x_1193; lean_object* x_1194; 
lean_dec(x_954);
lean_dec(x_15);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_1191 = lean_ctor_get(x_956, 0);
lean_inc(x_1191);
x_1192 = lean_ctor_get(x_956, 1);
lean_inc(x_1192);
if (lean_is_exclusive(x_956)) {
 lean_ctor_release(x_956, 0);
 lean_ctor_release(x_956, 1);
 x_1193 = x_956;
} else {
 lean_dec_ref(x_956);
 x_1193 = lean_box(0);
}
if (lean_is_scalar(x_1193)) {
 x_1194 = lean_alloc_ctor(1, 2, 0);
} else {
 x_1194 = x_1193;
}
lean_ctor_set(x_1194, 0, x_1191);
lean_ctor_set(x_1194, 1, x_1192);
return x_1194;
}
}
}
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean(uint8_t builtin, lean_object*);
lean_object* initialize_Init_System_Mutex(uint8_t builtin, lean_object*);
lean_object* initialize_Init_Util(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_StateReuseProfile(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init_System_Mutex(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init_Util(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_GpuSmt_StateReuseProfile_instBEqKey___closed__1 = _init_l_GpuSmt_StateReuseProfile_instBEqKey___closed__1();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instBEqKey___closed__1);
l_GpuSmt_StateReuseProfile_instBEqKey = _init_l_GpuSmt_StateReuseProfile_instBEqKey();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instBEqKey);
l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1 = _init_l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__1);
l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__2 = _init_l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__2();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__2);
l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__3 = _init_l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__3();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instInhabitedKey___closed__3);
l_GpuSmt_StateReuseProfile_instInhabitedKey = _init_l_GpuSmt_StateReuseProfile_instInhabitedKey();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instInhabitedKey);
l_GpuSmt_StateReuseProfile_Registry_environments___default = _init_l_GpuSmt_StateReuseProfile_Registry_environments___default();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_Registry_environments___default);
l_GpuSmt_StateReuseProfile_Registry_keys___default = _init_l_GpuSmt_StateReuseProfile_Registry_keys___default();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_Registry_keys___default);
l_GpuSmt_StateReuseProfile_Registry_nextCall___default = _init_l_GpuSmt_StateReuseProfile_Registry_nextCall___default();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_Registry_nextCall___default);
l_GpuSmt_StateReuseProfile_instInhabitedRegistry___closed__1 = _init_l_GpuSmt_StateReuseProfile_instInhabitedRegistry___closed__1();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instInhabitedRegistry___closed__1);
l_GpuSmt_StateReuseProfile_instInhabitedRegistry = _init_l_GpuSmt_StateReuseProfile_instInhabitedRegistry();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_instInhabitedRegistry);
res = l_GpuSmt_StateReuseProfile_initFn____x40_StateReuseProfile___hyg_242_(lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
l_GpuSmt_StateReuseProfile_registry = lean_io_result_get_value(res);
lean_mark_persistent(l_GpuSmt_StateReuseProfile_registry);
lean_dec_ref(res);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___lambda__2___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__2 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__2();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_environmentId___closed__2);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__2 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__2();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__2);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__3);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__4 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__4();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__4);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__5 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__5();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__5);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__6 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__6();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__6);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__7 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__7();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__7);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__8);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__9 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__9();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__9);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__10 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__10();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__10);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__11 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__11();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__11);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__12 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__12();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_nameIdentity___closed__12);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__2 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__2();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__2);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__3 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__3();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__3);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__4 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__4();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__4);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__5 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__5();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__5);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__6 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__6();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_openIdentity___closed__6);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__2 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__2();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__2);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__3 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__3();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__3);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__4 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__4();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__4);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__5 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__5();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__5);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__6 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__6();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__6);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__7 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__7();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_resolvedIdentity___closed__7);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__2 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__2();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__2);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__3 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__3();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__3);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__4 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__4();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__4);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__5 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__5();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__5);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__6 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__6();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__6);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__7 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__7();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__7);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__8 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__8();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__8);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__9 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__9();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__9);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__10 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__10();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__10);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__11);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__12 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__12();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_syntaxIdentity___closed__12);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_configIdentity___closed__1);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__1 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__1();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__1);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__2 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__2();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__2);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__3 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__3();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__3);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__4 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__4();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__4);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__5 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__5();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__5);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__6 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__6();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__1___closed__6);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__1 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__1();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__1);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__2 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__2();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__2);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___lambda__3___closed__3);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__1 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__1();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__1);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__2 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__2();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__2);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__5___closed__3);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__1 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__1();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__1);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__2 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__2();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__2);
l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3 = _init_l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3();
lean_mark_persistent(l_Array_forInUnsafe_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__7___closed__3);
l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___closed__1 = _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___closed__1();
lean_mark_persistent(l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__1___closed__1);
l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__1 = _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__1();
lean_mark_persistent(l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__1);
l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__2 = _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__2();
lean_mark_persistent(l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__2);
l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3 = _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3();
lean_mark_persistent(l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___lambda__3___closed__3);
l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1 = _init_l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1();
lean_mark_persistent(l_List_forIn_loop___at___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___spec__8___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___lambda__1___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__1);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__2 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__2();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__2);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_inputKey___closed__3);
l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit___closed__1 = _init_l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit___closed__1();
lean_mark_persistent(l___private_StateReuseProfile_0__GpuSmt_StateReuseProfile_emit___closed__1);
l_GpuSmt_StateReuseProfile_observeState___closed__1 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__1();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__1);
l_GpuSmt_StateReuseProfile_observeState___closed__2 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__2();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__2);
l_GpuSmt_StateReuseProfile_observeState___closed__3 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__3();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__3);
l_GpuSmt_StateReuseProfile_observeState___closed__4 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__4();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__4);
l_GpuSmt_StateReuseProfile_observeState___closed__5 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__5();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__5);
l_GpuSmt_StateReuseProfile_observeState___closed__6 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__6();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__6);
l_GpuSmt_StateReuseProfile_observeState___closed__7 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__7();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__7);
l_GpuSmt_StateReuseProfile_observeState___closed__8 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__8();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__8);
l_GpuSmt_StateReuseProfile_observeState___closed__9 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__9();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__9);
l_GpuSmt_StateReuseProfile_observeState___closed__10 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__10();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__10);
l_GpuSmt_StateReuseProfile_observeState___closed__11 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__11();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__11);
l_GpuSmt_StateReuseProfile_observeState___closed__12 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__12();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__12);
l_GpuSmt_StateReuseProfile_observeState___closed__13 = _init_l_GpuSmt_StateReuseProfile_observeState___closed__13();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState___closed__13);
l_GpuSmt_StateReuseProfile_observeState = _init_l_GpuSmt_StateReuseProfile_observeState();
lean_mark_persistent(l_GpuSmt_StateReuseProfile_observeState);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__1 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__1();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__1);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__2 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__2();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__2);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__3 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__3();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__3);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__4);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__5);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__6);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__7);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__8);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__9);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__10 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__10();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__10);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__11 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__11();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__11);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__12 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__12();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__12);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__13);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__14);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__15 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__15();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__15);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__16 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__16();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__16);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__17);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__18);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__19);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__20);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__21);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__22);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__23);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__24);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__25);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__26);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__27);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__28);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__29);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__30);
l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31 = _init_l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31();
lean_mark_persistent(l_GpuSmt_StateReuseProfile___aux__StateReuseProfile______elabRules__GpuSmt__StateReuseProfile__observeState__1___closed__31);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
