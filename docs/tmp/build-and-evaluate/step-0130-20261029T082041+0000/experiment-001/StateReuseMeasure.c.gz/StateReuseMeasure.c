// Lean compiler output
// Module: StateReuseMeasure
// Imports: Init StateReuseProfile Lean.Elab.Import Lean.Parser.Module Lean.Elab.Frontend
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_JsonNumber_fromNat(lean_object*);
lean_object* lean_string_utf8_extract(lean_object*, lean_object*, lean_object*);
static lean_object* l_main___lambda__1___closed__2;
lean_object* l_Lean_Json_compress(lean_object*);
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* _lean_main(lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__8;
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__1;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10;
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__3;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__8;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getHeadInfo(lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__3(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__7;
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___closed__3;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__3;
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__10;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__1;
LEAN_EXPORT lean_object* l_IO_ofExcept___at_main___spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__7;
static lean_object* l_main___lambda__1___closed__1;
lean_object* l_Lean_Elab_Command_mkState(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getArgs(lean_object*);
lean_object* l___private_Init_GetElem_0__outOfBounds___rarg(lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7;
lean_object* lean_array_fget(lean_object*, lean_object*);
lean_object* l_Lean_Json_getObjValAs_x3f___at___private_Lean_Message_0__Lean_fromJsonBaseMessage____x40_Lean_Message___hyg_2442____spec__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_List_forIn_loop___at_main___spec__5(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_io_getenv(lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__3;
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__1;
static lean_object* l_main___closed__3;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__9;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__12;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__5;
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__3;
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__2(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Elab_processHeader(lean_object*, lean_object*, lean_object*, lean_object*, uint32_t, uint8_t, lean_object*);
lean_object* l_EStateM_instMonad(lean_object*, lean_object*);
lean_object* l_List_head_x21___rarg(lean_object*, lean_object*);
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__10;
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__observe___lambda__1___boxed(lean_object*, lean_object*);
lean_object* lean_get_stdout(lean_object*);
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__8;
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_initSearchPath(lean_object*, lean_object*, lean_object*);
size_t lean_usize_of_nat(lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__11;
uint8_t l_Lean_Parser_isTerminalCommand(lean_object*);
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__9;
lean_object* l_Lean_findSysroot(lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4;
lean_object* l_Lean_Elab_Frontend_elabCommandAtFrontend(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__9;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__1;
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__11;
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__11;
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__1___boxed(lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__6;
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__4;
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_MessageLog_toList(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__2;
static lean_object* l_main___closed__1;
lean_object* l_Lean_Syntax_getKind(lean_object*);
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__1;
lean_object* lean_enable_initializer_execution(lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__9;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__2;
lean_object* lean_st_ref_get(lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___closed__2;
lean_object* l_Lean_Parser_mkInputContext(lean_object*, lean_object*, uint8_t);
static lean_object* l_main___closed__5;
lean_object* lean_st_mk_ref(lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__4;
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___closed__1;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6;
static lean_object* l_main___closed__4;
lean_object* lean_io_mono_nanos_now(lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l___private_StateReuseMeasure_0__expensive(lean_object*);
LEAN_EXPORT lean_object* l_main___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_name_eq(lean_object*, lean_object*);
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__observe___lambda__1(lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8;
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__observe(lean_object*);
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence(lean_object*);
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__7;
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__5;
lean_object* l_IO_FS_readFile(lean_object*, lean_object*);
lean_object* l_Lean_Syntax_setArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__1;
lean_object* l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__3(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__expensive___boxed(lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__3;
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__2;
LEAN_EXPORT lean_object* l_IO_ofExcept___at_main___spec__2(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__8;
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__4;
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__observe___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__4;
lean_object* lean_array_set(lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__12;
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__2;
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__6;
lean_object* lean_nat_sub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__2;
LEAN_EXPORT lean_object* l_main___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__3(lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__7;
extern lean_object* l_Lean_Elab_Command_instInhabitedScope;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__13;
lean_object* l_Lean_MessageLog_append(lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__4(lean_object*, size_t, lean_object*, size_t, lean_object*, lean_object*);
extern lean_object* l_Lean_instInhabitedSyntax;
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__1;
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__2;
lean_object* l_Lean_Name_mkStr4(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__5;
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__2;
lean_object* l_IO_FS_Stream_putStrLn(lean_object*, lean_object*, lean_object*);
static lean_object* l_main___closed__2;
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__12;
static lean_object* l___private_StateReuseMeasure_0__expensive___closed__6;
lean_object* lean_array_get_size(lean_object*);
lean_object* lean_load_dynlib(lean_object*, lean_object*);
lean_object* l_Lean_Parser_parseHeader(lean_object*, lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__1(lean_object*, lean_object*);
uint8_t lean_usize_dec_lt(size_t, size_t);
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__2___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_parse(lean_object*);
static lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__5;
lean_object* lean_nat_add(lean_object*, lean_object*);
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__6;
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__emit(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5;
lean_object* l_Lean_Parser_parseCommand(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_pretty(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__3;
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__observe___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__2;
static lean_object* l_List_forIn_loop___at_main___spec__5___closed__10;
lean_object* l_Lean_Message_toString(lean_object*, uint8_t, lean_object*);
uint8_t l_Lean_MessageLog_hasErrors(lean_object*);
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("nlinarith", 9);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l___private_StateReuseMeasure_0__expensive___closed__1;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("Mathlib", 7);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("Tactic", 6);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("intervalCases", 13);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___private_StateReuseMeasure_0__expensive___closed__3;
x_2 = l___private_StateReuseMeasure_0__expensive___closed__4;
x_3 = l___private_StateReuseMeasure_0__expensive___closed__5;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("Lean", 4);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("Parser", 6);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("simpAll", 7);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l___private_StateReuseMeasure_0__expensive___closed__7;
x_2 = l___private_StateReuseMeasure_0__expensive___closed__8;
x_3 = l___private_StateReuseMeasure_0__expensive___closed__4;
x_4 = l___private_StateReuseMeasure_0__expensive___closed__9;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("normNum", 7);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__expensive___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___private_StateReuseMeasure_0__expensive___closed__3;
x_2 = l___private_StateReuseMeasure_0__expensive___closed__4;
x_3 = l___private_StateReuseMeasure_0__expensive___closed__11;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
LEAN_EXPORT uint8_t l___private_StateReuseMeasure_0__expensive(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l___private_StateReuseMeasure_0__expensive___closed__2;
x_3 = lean_name_eq(x_1, x_2);
if (x_3 == 0)
{
lean_object* x_4; uint8_t x_5; 
x_4 = l___private_StateReuseMeasure_0__expensive___closed__6;
x_5 = lean_name_eq(x_1, x_4);
if (x_5 == 0)
{
lean_object* x_6; uint8_t x_7; 
x_6 = l___private_StateReuseMeasure_0__expensive___closed__10;
x_7 = lean_name_eq(x_1, x_6);
if (x_7 == 0)
{
lean_object* x_8; uint8_t x_9; 
x_8 = l___private_StateReuseMeasure_0__expensive___closed__12;
x_9 = lean_name_eq(x_1, x_8);
return x_9;
}
else
{
uint8_t x_10; 
x_10 = 1;
return x_10;
}
}
else
{
uint8_t x_11; 
x_11 = 1;
return x_11;
}
}
else
{
uint8_t x_12; 
x_12 = 1;
return x_12;
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__expensive___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l___private_StateReuseMeasure_0__expensive(x_1);
lean_dec(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("GpuSmt", 6);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("StateReuseProfile", 17);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("observeState", 12);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__1;
x_2 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__2;
x_3 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__3;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("observe_state", 13);
return x_1;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(2);
x_2 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__5;
x_3 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__7;
x_2 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__6;
x_3 = lean_array_push(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_nat_dec_le(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; uint8_t x_8; 
x_7 = lean_unsigned_to_nat(0u);
x_8 = lean_nat_dec_eq(x_1, x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_9 = lean_unsigned_to_nat(1u);
x_10 = lean_nat_sub(x_1, x_9);
lean_dec(x_1);
x_11 = !lean_is_exclusive(x_5);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; uint8_t x_15; 
x_12 = lean_ctor_get(x_5, 0);
x_13 = lean_ctor_get(x_5, 1);
x_14 = lean_array_get_size(x_12);
x_15 = lean_nat_dec_lt(x_2, x_14);
lean_dec(x_14);
if (x_15 == 0)
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_16 = l_Lean_instInhabitedSyntax;
x_17 = l___private_Init_GetElem_0__outOfBounds___rarg(x_16);
lean_inc(x_17);
x_18 = l_Lean_Syntax_getKind(x_17);
x_19 = l___private_StateReuseMeasure_0__expensive(x_18);
lean_dec(x_18);
if (x_19 == 0)
{
lean_object* x_20; 
lean_dec(x_17);
x_20 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_20;
goto _start;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_22 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8;
x_23 = lean_array_push(x_22, x_17);
x_24 = lean_box(2);
x_25 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4;
x_26 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
lean_ctor_set(x_26, 2, x_23);
x_27 = lean_array_set(x_12, x_2, x_26);
x_28 = lean_nat_add(x_13, x_9);
lean_dec(x_13);
lean_ctor_set(x_5, 1, x_28);
lean_ctor_set(x_5, 0, x_27);
x_29 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_29;
goto _start;
}
}
else
{
lean_object* x_31; lean_object* x_32; uint8_t x_33; 
x_31 = lean_array_fget(x_12, x_2);
lean_inc(x_31);
x_32 = l_Lean_Syntax_getKind(x_31);
x_33 = l___private_StateReuseMeasure_0__expensive(x_32);
lean_dec(x_32);
if (x_33 == 0)
{
lean_object* x_34; 
lean_dec(x_31);
x_34 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_34;
goto _start;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
x_36 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8;
x_37 = lean_array_push(x_36, x_31);
x_38 = lean_box(2);
x_39 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4;
x_40 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_40, 0, x_38);
lean_ctor_set(x_40, 1, x_39);
lean_ctor_set(x_40, 2, x_37);
x_41 = lean_array_set(x_12, x_2, x_40);
x_42 = lean_nat_add(x_13, x_9);
lean_dec(x_13);
lean_ctor_set(x_5, 1, x_42);
lean_ctor_set(x_5, 0, x_41);
x_43 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_43;
goto _start;
}
}
}
else
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; uint8_t x_48; 
x_45 = lean_ctor_get(x_5, 0);
x_46 = lean_ctor_get(x_5, 1);
lean_inc(x_46);
lean_inc(x_45);
lean_dec(x_5);
x_47 = lean_array_get_size(x_45);
x_48 = lean_nat_dec_lt(x_2, x_47);
lean_dec(x_47);
if (x_48 == 0)
{
lean_object* x_49; lean_object* x_50; lean_object* x_51; uint8_t x_52; 
x_49 = l_Lean_instInhabitedSyntax;
x_50 = l___private_Init_GetElem_0__outOfBounds___rarg(x_49);
lean_inc(x_50);
x_51 = l_Lean_Syntax_getKind(x_50);
x_52 = l___private_StateReuseMeasure_0__expensive(x_51);
lean_dec(x_51);
if (x_52 == 0)
{
lean_object* x_53; lean_object* x_54; 
lean_dec(x_50);
x_53 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_53, 0, x_45);
lean_ctor_set(x_53, 1, x_46);
x_54 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_54;
x_5 = x_53;
goto _start;
}
else
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_56 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8;
x_57 = lean_array_push(x_56, x_50);
x_58 = lean_box(2);
x_59 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4;
x_60 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_60, 0, x_58);
lean_ctor_set(x_60, 1, x_59);
lean_ctor_set(x_60, 2, x_57);
x_61 = lean_array_set(x_45, x_2, x_60);
x_62 = lean_nat_add(x_46, x_9);
lean_dec(x_46);
x_63 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_63, 0, x_61);
lean_ctor_set(x_63, 1, x_62);
x_64 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_64;
x_5 = x_63;
goto _start;
}
}
else
{
lean_object* x_66; lean_object* x_67; uint8_t x_68; 
x_66 = lean_array_fget(x_45, x_2);
lean_inc(x_66);
x_67 = l_Lean_Syntax_getKind(x_66);
x_68 = l___private_StateReuseMeasure_0__expensive(x_67);
lean_dec(x_67);
if (x_68 == 0)
{
lean_object* x_69; lean_object* x_70; 
lean_dec(x_66);
x_69 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_69, 0, x_45);
lean_ctor_set(x_69, 1, x_46);
x_70 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_70;
x_5 = x_69;
goto _start;
}
else
{
lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; 
x_72 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8;
x_73 = lean_array_push(x_72, x_66);
x_74 = lean_box(2);
x_75 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4;
x_76 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_76, 0, x_74);
lean_ctor_set(x_76, 1, x_75);
lean_ctor_set(x_76, 2, x_73);
x_77 = lean_array_set(x_45, x_2, x_76);
x_78 = lean_nat_add(x_46, x_9);
lean_dec(x_46);
x_79 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_79, 0, x_77);
lean_ctor_set(x_79, 1, x_78);
x_80 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_80;
x_5 = x_79;
goto _start;
}
}
}
}
else
{
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
else
{
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; 
x_3 = lean_unsigned_to_nat(0u);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_3);
return x_4;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("null", 4);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__1;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
x_4 = l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__2;
x_5 = lean_name_eq(x_2, x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_unsigned_to_nat(0u);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_1);
lean_ctor_set(x_7, 1, x_6);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_8 = l_Lean_Syntax_getArgs(x_1);
x_9 = lean_array_get_size(x_8);
x_10 = lean_unsigned_to_nat(0u);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_8);
lean_ctor_set(x_11, 1, x_10);
x_12 = lean_unsigned_to_nat(1u);
lean_inc(x_9);
x_13 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1(x_9, x_10, x_9, x_12, x_11);
lean_dec(x_9);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_15 = lean_ctor_get(x_13, 0);
x_16 = l_Lean_Syntax_getHeadInfo(x_1);
lean_dec(x_1);
x_17 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_2);
lean_ctor_set(x_17, 2, x_15);
lean_ctor_set(x_13, 0, x_17);
return x_13;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_18 = lean_ctor_get(x_13, 0);
x_19 = lean_ctor_get(x_13, 1);
lean_inc(x_19);
lean_inc(x_18);
lean_dec(x_13);
x_20 = l_Lean_Syntax_getHeadInfo(x_1);
lean_dec(x_1);
x_21 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_2);
lean_ctor_set(x_21, 2, x_18);
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_22, 1, x_19);
return x_22;
}
}
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("tacticSeq", 9);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l___private_StateReuseMeasure_0__expensive___closed__7;
x_2 = l___private_StateReuseMeasure_0__expensive___closed__8;
x_3 = l___private_StateReuseMeasure_0__expensive___closed__4;
x_4 = l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__1;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("tacticSeq1Indented", 18);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l___private_StateReuseMeasure_0__expensive___closed__7;
x_2 = l___private_StateReuseMeasure_0__expensive___closed__8;
x_3 = l___private_StateReuseMeasure_0__expensive___closed__4;
x_4 = l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__3;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
lean_dec(x_3);
x_4 = l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__2;
x_5 = lean_name_eq(x_2, x_4);
if (x_5 == 0)
{
lean_object* x_6; uint8_t x_7; 
x_6 = l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__4;
x_7 = lean_name_eq(x_2, x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_box(0);
x_9 = l___private_StateReuseMeasure_0__wrapSequence___lambda__2(x_1, x_2, x_8);
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
lean_dec(x_2);
x_10 = lean_unsigned_to_nat(0u);
x_11 = l_Lean_Syntax_getArg(x_1, x_10);
x_12 = l___private_StateReuseMeasure_0__wrapSequence(x_11);
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; 
x_14 = lean_ctor_get(x_12, 0);
x_15 = l_Lean_Syntax_setArg(x_1, x_10, x_14);
lean_ctor_set(x_12, 0, x_15);
return x_12;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_16 = lean_ctor_get(x_12, 0);
x_17 = lean_ctor_get(x_12, 1);
lean_inc(x_17);
lean_inc(x_16);
lean_dec(x_12);
x_18 = l_Lean_Syntax_setArg(x_1, x_10, x_16);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_19, 1, x_17);
return x_19;
}
}
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; uint8_t x_23; 
lean_dec(x_2);
x_20 = lean_unsigned_to_nat(0u);
x_21 = l_Lean_Syntax_getArg(x_1, x_20);
x_22 = l___private_StateReuseMeasure_0__wrapSequence(x_21);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_ctor_get(x_22, 0);
x_25 = l_Lean_Syntax_setArg(x_1, x_20, x_24);
lean_ctor_set(x_22, 0, x_25);
return x_22;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_26 = lean_ctor_get(x_22, 0);
x_27 = lean_ctor_get(x_22, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_22);
x_28 = l_Lean_Syntax_setArg(x_1, x_20, x_26);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_28);
lean_ctor_set(x_29, 1, x_27);
return x_29;
}
}
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("Term", 4);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("byTactic", 8);
return x_1;
}
}
static lean_object* _init_l___private_StateReuseMeasure_0__wrapSequence___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l___private_StateReuseMeasure_0__expensive___closed__7;
x_2 = l___private_StateReuseMeasure_0__expensive___closed__8;
x_3 = l___private_StateReuseMeasure_0__wrapSequence___closed__1;
x_4 = l___private_StateReuseMeasure_0__wrapSequence___closed__2;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
lean_inc(x_1);
x_2 = l_Lean_Syntax_getKind(x_1);
x_3 = l___private_StateReuseMeasure_0__wrapSequence___closed__3;
x_4 = lean_name_eq(x_2, x_3);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_box(0);
x_6 = l___private_StateReuseMeasure_0__wrapSequence___lambda__3(x_1, x_2, x_5);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; uint8_t x_10; 
lean_dec(x_2);
x_7 = lean_unsigned_to_nat(1u);
x_8 = l_Lean_Syntax_getArg(x_1, x_7);
x_9 = l___private_StateReuseMeasure_0__wrapSequence(x_8);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = l_Lean_Syntax_setArg(x_1, x_7, x_11);
lean_ctor_set(x_9, 0, x_12);
return x_9;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_13 = lean_ctor_get(x_9, 0);
x_14 = lean_ctor_get(x_9, 1);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_9);
x_15 = l_Lean_Syntax_setArg(x_1, x_7, x_13);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_14);
return x_16;
}
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l___private_StateReuseMeasure_0__wrapSequence___lambda__1(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__wrapSequence___lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l___private_StateReuseMeasure_0__wrapSequence___lambda__2(x_1, x_2, x_3);
lean_dec(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__observe___spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_nat_dec_le(x_3, x_2);
if (x_6 == 0)
{
lean_object* x_7; uint8_t x_8; 
x_7 = lean_unsigned_to_nat(0u);
x_8 = lean_nat_dec_eq(x_1, x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_9 = lean_unsigned_to_nat(1u);
x_10 = lean_nat_sub(x_1, x_9);
lean_dec(x_1);
x_11 = lean_ctor_get(x_5, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_5, 1);
lean_inc(x_12);
lean_dec(x_5);
x_13 = lean_array_get_size(x_11);
x_14 = lean_nat_dec_lt(x_2, x_13);
lean_dec(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; uint8_t x_18; 
x_15 = l_Lean_instInhabitedSyntax;
x_16 = l___private_Init_GetElem_0__outOfBounds___rarg(x_15);
x_17 = l___private_StateReuseMeasure_0__observe(x_16);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_19 = lean_ctor_get(x_17, 0);
x_20 = lean_ctor_get(x_17, 1);
x_21 = lean_array_set(x_11, x_2, x_19);
x_22 = lean_nat_add(x_12, x_20);
lean_dec(x_20);
lean_dec(x_12);
lean_ctor_set(x_17, 1, x_22);
lean_ctor_set(x_17, 0, x_21);
x_23 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_23;
x_5 = x_17;
goto _start;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_25 = lean_ctor_get(x_17, 0);
x_26 = lean_ctor_get(x_17, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_17);
x_27 = lean_array_set(x_11, x_2, x_25);
x_28 = lean_nat_add(x_12, x_26);
lean_dec(x_26);
lean_dec(x_12);
x_29 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_29, 0, x_27);
lean_ctor_set(x_29, 1, x_28);
x_30 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_30;
x_5 = x_29;
goto _start;
}
}
else
{
lean_object* x_32; lean_object* x_33; uint8_t x_34; 
x_32 = lean_array_fget(x_11, x_2);
x_33 = l___private_StateReuseMeasure_0__observe(x_32);
x_34 = !lean_is_exclusive(x_33);
if (x_34 == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_35 = lean_ctor_get(x_33, 0);
x_36 = lean_ctor_get(x_33, 1);
x_37 = lean_array_set(x_11, x_2, x_35);
x_38 = lean_nat_add(x_12, x_36);
lean_dec(x_36);
lean_dec(x_12);
lean_ctor_set(x_33, 1, x_38);
lean_ctor_set(x_33, 0, x_37);
x_39 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_39;
x_5 = x_33;
goto _start;
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_41 = lean_ctor_get(x_33, 0);
x_42 = lean_ctor_get(x_33, 1);
lean_inc(x_42);
lean_inc(x_41);
lean_dec(x_33);
x_43 = lean_array_set(x_11, x_2, x_41);
x_44 = lean_nat_add(x_12, x_42);
lean_dec(x_42);
lean_dec(x_12);
x_45 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
x_46 = lean_nat_add(x_2, x_4);
lean_dec(x_2);
x_1 = x_10;
x_2 = x_46;
x_5 = x_45;
goto _start;
}
}
}
else
{
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
else
{
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__observe___lambda__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_3 = l_Lean_Syntax_getArgs(x_1);
x_4 = lean_array_get_size(x_3);
x_5 = lean_unsigned_to_nat(0u);
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_3);
lean_ctor_set(x_6, 1, x_5);
x_7 = lean_unsigned_to_nat(1u);
lean_inc(x_4);
x_8 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__observe___spec__1(x_4, x_5, x_4, x_7, x_6);
lean_dec(x_4);
if (lean_obj_tag(x_1) == 1)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_1);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_8, 0);
x_12 = lean_ctor_get(x_1, 2);
lean_dec(x_12);
lean_ctor_set(x_1, 2, x_11);
lean_ctor_set(x_8, 0, x_1);
return x_8;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_13 = lean_ctor_get(x_8, 0);
x_14 = lean_ctor_get(x_1, 0);
x_15 = lean_ctor_get(x_1, 1);
lean_inc(x_15);
lean_inc(x_14);
lean_dec(x_1);
x_16 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_16, 0, x_14);
lean_ctor_set(x_16, 1, x_15);
lean_ctor_set(x_16, 2, x_13);
lean_ctor_set(x_8, 0, x_16);
return x_8;
}
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_17 = lean_ctor_get(x_8, 0);
x_18 = lean_ctor_get(x_8, 1);
lean_inc(x_18);
lean_inc(x_17);
lean_dec(x_8);
x_19 = lean_ctor_get(x_1, 0);
lean_inc(x_19);
x_20 = lean_ctor_get(x_1, 1);
lean_inc(x_20);
if (lean_is_exclusive(x_1)) {
 lean_ctor_release(x_1, 0);
 lean_ctor_release(x_1, 1);
 lean_ctor_release(x_1, 2);
 x_21 = x_1;
} else {
 lean_dec_ref(x_1);
 x_21 = lean_box(0);
}
if (lean_is_scalar(x_21)) {
 x_22 = lean_alloc_ctor(1, 3, 0);
} else {
 x_22 = x_21;
}
lean_ctor_set(x_22, 0, x_19);
lean_ctor_set(x_22, 1, x_20);
lean_ctor_set(x_22, 2, x_17);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_18);
return x_23;
}
}
else
{
uint8_t x_24; 
x_24 = !lean_is_exclusive(x_8);
if (x_24 == 0)
{
lean_object* x_25; 
x_25 = lean_ctor_get(x_8, 0);
lean_dec(x_25);
lean_ctor_set(x_8, 0, x_1);
return x_8;
}
else
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_8, 1);
lean_inc(x_26);
lean_dec(x_8);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_1);
lean_ctor_set(x_27, 1, x_26);
return x_27;
}
}
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__observe(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; uint8_t x_4; 
lean_inc(x_1);
x_2 = l_Lean_Syntax_getKind(x_1);
x_3 = l___private_StateReuseMeasure_0__wrapSequence___closed__3;
x_4 = lean_name_eq(x_2, x_3);
lean_dec(x_2);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_box(0);
x_6 = l___private_StateReuseMeasure_0__observe___lambda__1(x_1, x_5);
return x_6;
}
else
{
lean_object* x_7; 
x_7 = l___private_StateReuseMeasure_0__wrapSequence(x_1);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__observe___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__observe___spec__1(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__observe___lambda__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l___private_StateReuseMeasure_0__observe___lambda__1(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l___private_StateReuseMeasure_0__emit(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = lean_get_stdout(x_2);
x_4 = lean_ctor_get(x_3, 0);
lean_inc(x_4);
x_5 = lean_ctor_get(x_3, 1);
lean_inc(x_5);
lean_dec(x_3);
x_6 = l_Lean_Json_compress(x_1);
lean_inc(x_4);
x_7 = l_IO_FS_Stream_putStrLn(x_4, x_6, x_5);
if (lean_obj_tag(x_7) == 0)
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_8 = lean_ctor_get(x_7, 1);
lean_inc(x_8);
lean_dec(x_7);
x_9 = lean_ctor_get(x_4, 0);
lean_inc(x_9);
lean_dec(x_4);
x_10 = lean_apply_1(x_9, x_8);
return x_10;
}
else
{
uint8_t x_11; 
lean_dec(x_4);
x_11 = !lean_is_exclusive(x_7);
if (x_11 == 0)
{
return x_7;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_12 = lean_ctor_get(x_7, 0);
x_13 = lean_ctor_get(x_7, 1);
lean_inc(x_13);
lean_inc(x_12);
lean_dec(x_7);
x_14 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_14, 0, x_12);
lean_ctor_set(x_14, 1, x_13);
return x_14;
}
}
}
}
LEAN_EXPORT lean_object* l_IO_ofExcept___at_main___spec__1(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_1);
if (x_3 == 0)
{
lean_object* x_4; 
lean_ctor_set_tag(x_1, 18);
x_4 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_1, 0);
lean_inc(x_5);
lean_dec(x_1);
x_6 = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(x_6, 0, x_5);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_2);
return x_7;
}
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
lean_dec(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_8);
lean_ctor_set(x_9, 1, x_2);
return x_9;
}
}
}
LEAN_EXPORT lean_object* l_IO_ofExcept___at_main___spec__2(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_1);
if (x_3 == 0)
{
lean_object* x_4; 
lean_ctor_set_tag(x_1, 18);
x_4 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_5 = lean_ctor_get(x_1, 0);
lean_inc(x_5);
lean_dec(x_1);
x_6 = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(x_6, 0, x_5);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_2);
return x_7;
}
}
else
{
lean_object* x_8; lean_object* x_9; 
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
lean_dec(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_8);
lean_ctor_set(x_9, 1, x_2);
return x_9;
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__3(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; 
x_7 = lean_usize_dec_lt(x_4, x_3);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_5);
lean_ctor_set(x_8, 1, x_6);
return x_8;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_array_uget(x_2, x_4);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_string_dec_eq(x_10, x_1);
lean_dec(x_10);
if (x_12 == 0)
{
size_t x_13; size_t x_14; 
lean_dec(x_11);
x_13 = 1;
x_14 = lean_usize_add(x_4, x_13);
x_4 = x_14;
goto _start;
}
else
{
lean_object* x_16; size_t x_17; size_t x_18; 
lean_dec(x_5);
x_16 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_16, 0, x_11);
x_17 = 1;
x_18 = lean_usize_add(x_4, x_17);
x_4 = x_18;
x_5 = x_16;
goto _start;
}
}
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("observe", 7);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_59; uint8_t x_60; 
x_59 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__2;
x_60 = lean_string_dec_eq(x_4, x_59);
if (x_60 == 0)
{
lean_object* x_61; 
x_61 = lean_unsigned_to_nat(0u);
x_10 = x_5;
x_11 = x_61;
goto block_58;
}
else
{
lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_62 = l___private_StateReuseMeasure_0__observe(x_5);
x_63 = lean_ctor_get(x_62, 0);
lean_inc(x_63);
x_64 = lean_ctor_get(x_62, 1);
lean_inc(x_64);
lean_dec(x_62);
x_10 = x_63;
x_11 = x_64;
goto block_58;
}
block_58:
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_12 = lean_nat_add(x_7, x_11);
lean_dec(x_11);
x_13 = lean_ctor_get(x_1, 0);
lean_inc(x_13);
x_14 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
lean_inc(x_1);
x_15 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_15, 0, x_6);
lean_ctor_set(x_15, 1, x_1);
lean_ctor_set(x_15, 2, x_13);
lean_ctor_set(x_15, 3, x_14);
x_16 = lean_st_mk_ref(x_15, x_9);
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_18 = lean_ctor_get(x_16, 0);
x_19 = lean_ctor_get(x_16, 1);
x_20 = l_Lean_Elab_Frontend_elabCommandAtFrontend(x_10, x_2, x_18, x_19);
if (lean_obj_tag(x_20) == 0)
{
lean_object* x_21; lean_object* x_22; uint8_t x_23; 
x_21 = lean_ctor_get(x_20, 1);
lean_inc(x_21);
lean_dec(x_20);
x_22 = lean_st_ref_get(x_18, x_21);
lean_dec(x_18);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_24 = lean_ctor_get(x_22, 0);
x_25 = lean_ctor_get(x_24, 0);
lean_inc(x_25);
lean_dec(x_24);
lean_ctor_set(x_16, 1, x_12);
lean_ctor_set(x_16, 0, x_1);
x_26 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_26, 0, x_3);
lean_ctor_set(x_26, 1, x_16);
x_27 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
x_28 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_22, 0, x_28);
return x_22;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_29 = lean_ctor_get(x_22, 0);
x_30 = lean_ctor_get(x_22, 1);
lean_inc(x_30);
lean_inc(x_29);
lean_dec(x_22);
x_31 = lean_ctor_get(x_29, 0);
lean_inc(x_31);
lean_dec(x_29);
lean_ctor_set(x_16, 1, x_12);
lean_ctor_set(x_16, 0, x_1);
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_3);
lean_ctor_set(x_32, 1, x_16);
x_33 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_33, 0, x_31);
lean_ctor_set(x_33, 1, x_32);
x_34 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_35, 0, x_34);
lean_ctor_set(x_35, 1, x_30);
return x_35;
}
}
else
{
uint8_t x_36; 
lean_free_object(x_16);
lean_dec(x_18);
lean_dec(x_12);
lean_dec(x_3);
lean_dec(x_1);
x_36 = !lean_is_exclusive(x_20);
if (x_36 == 0)
{
return x_20;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_37 = lean_ctor_get(x_20, 0);
x_38 = lean_ctor_get(x_20, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_20);
x_39 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
return x_39;
}
}
}
else
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; 
x_40 = lean_ctor_get(x_16, 0);
x_41 = lean_ctor_get(x_16, 1);
lean_inc(x_41);
lean_inc(x_40);
lean_dec(x_16);
x_42 = l_Lean_Elab_Frontend_elabCommandAtFrontend(x_10, x_2, x_40, x_41);
if (lean_obj_tag(x_42) == 0)
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; 
x_43 = lean_ctor_get(x_42, 1);
lean_inc(x_43);
lean_dec(x_42);
x_44 = lean_st_ref_get(x_40, x_43);
lean_dec(x_40);
x_45 = lean_ctor_get(x_44, 0);
lean_inc(x_45);
x_46 = lean_ctor_get(x_44, 1);
lean_inc(x_46);
if (lean_is_exclusive(x_44)) {
 lean_ctor_release(x_44, 0);
 lean_ctor_release(x_44, 1);
 x_47 = x_44;
} else {
 lean_dec_ref(x_44);
 x_47 = lean_box(0);
}
x_48 = lean_ctor_get(x_45, 0);
lean_inc(x_48);
lean_dec(x_45);
x_49 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_49, 0, x_1);
lean_ctor_set(x_49, 1, x_12);
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_3);
lean_ctor_set(x_50, 1, x_49);
x_51 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_51, 0, x_48);
lean_ctor_set(x_51, 1, x_50);
x_52 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_52, 0, x_51);
if (lean_is_scalar(x_47)) {
 x_53 = lean_alloc_ctor(0, 2, 0);
} else {
 x_53 = x_47;
}
lean_ctor_set(x_53, 0, x_52);
lean_ctor_set(x_53, 1, x_46);
return x_53;
}
else
{
lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; 
lean_dec(x_40);
lean_dec(x_12);
lean_dec(x_3);
lean_dec(x_1);
x_54 = lean_ctor_get(x_42, 0);
lean_inc(x_54);
x_55 = lean_ctor_get(x_42, 1);
lean_inc(x_55);
if (lean_is_exclusive(x_42)) {
 lean_ctor_release(x_42, 0);
 lean_ctor_release(x_42, 1);
 x_56 = x_42;
} else {
 lean_dec_ref(x_42);
 x_56 = lean_box(0);
}
if (lean_is_scalar(x_56)) {
 x_57 = lean_alloc_ctor(1, 2, 0);
} else {
 x_57 = x_56;
}
lean_ctor_set(x_57, 0, x_54);
lean_ctor_set(x_57, 1, x_55);
return x_57;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_5 = lean_ctor_get(x_3, 1);
lean_inc(x_5);
x_6 = lean_ctor_get(x_5, 1);
lean_inc(x_6);
x_7 = !lean_is_exclusive(x_3);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_8 = lean_ctor_get(x_3, 0);
x_9 = lean_ctor_get(x_3, 1);
lean_dec(x_9);
x_10 = lean_ctor_get(x_5, 0);
lean_inc(x_10);
lean_dec(x_5);
x_11 = !lean_is_exclusive(x_6);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; uint8_t x_23; 
x_12 = lean_ctor_get(x_6, 0);
x_13 = lean_ctor_get(x_6, 1);
x_14 = lean_ctor_get(x_8, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_8, 2);
lean_inc(x_15);
x_16 = l_Lean_Elab_Command_instInhabitedScope;
x_17 = l_List_head_x21___rarg(x_16, x_15);
lean_dec(x_15);
x_18 = lean_ctor_get(x_17, 1);
lean_inc(x_18);
x_19 = lean_ctor_get(x_17, 2);
lean_inc(x_19);
x_20 = lean_ctor_get(x_17, 3);
lean_inc(x_20);
lean_dec(x_17);
x_21 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_21, 0, x_14);
lean_ctor_set(x_21, 1, x_18);
lean_ctor_set(x_21, 2, x_19);
lean_ctor_set(x_21, 3, x_20);
lean_inc(x_2);
x_22 = l_Lean_Parser_parseCommand(x_2, x_21, x_12, x_10);
x_23 = !lean_is_exclusive(x_22);
if (x_23 == 0)
{
lean_object* x_24; uint8_t x_25; 
x_24 = lean_ctor_get(x_22, 1);
x_25 = !lean_is_exclusive(x_24);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; uint8_t x_29; 
x_26 = lean_ctor_get(x_22, 0);
x_27 = lean_ctor_get(x_24, 0);
x_28 = lean_ctor_get(x_24, 1);
lean_inc(x_26);
x_29 = l_Lean_Parser_isTerminalCommand(x_26);
if (x_29 == 0)
{
lean_object* x_30; lean_object* x_31; 
lean_free_object(x_24);
lean_free_object(x_22);
lean_free_object(x_6);
lean_free_object(x_3);
x_30 = lean_box(0);
x_31 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(x_27, x_2, x_28, x_1, x_26, x_8, x_13, x_30, x_4);
lean_dec(x_13);
if (lean_obj_tag(x_31) == 0)
{
lean_object* x_32; 
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
if (lean_obj_tag(x_32) == 0)
{
uint8_t x_33; 
lean_dec(x_2);
x_33 = !lean_is_exclusive(x_31);
if (x_33 == 0)
{
lean_object* x_34; lean_object* x_35; 
x_34 = lean_ctor_get(x_31, 0);
lean_dec(x_34);
x_35 = lean_ctor_get(x_32, 0);
lean_inc(x_35);
lean_dec(x_32);
lean_ctor_set(x_31, 0, x_35);
return x_31;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_36 = lean_ctor_get(x_31, 1);
lean_inc(x_36);
lean_dec(x_31);
x_37 = lean_ctor_get(x_32, 0);
lean_inc(x_37);
lean_dec(x_32);
x_38 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_38, 0, x_37);
lean_ctor_set(x_38, 1, x_36);
return x_38;
}
}
else
{
lean_object* x_39; lean_object* x_40; 
x_39 = lean_ctor_get(x_31, 1);
lean_inc(x_39);
lean_dec(x_31);
x_40 = lean_ctor_get(x_32, 0);
lean_inc(x_40);
lean_dec(x_32);
x_3 = x_40;
x_4 = x_39;
goto _start;
}
}
else
{
uint8_t x_42; 
lean_dec(x_2);
x_42 = !lean_is_exclusive(x_31);
if (x_42 == 0)
{
return x_31;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_31, 0);
x_44 = lean_ctor_get(x_31, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_31);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
return x_45;
}
}
}
else
{
lean_dec(x_26);
lean_dec(x_2);
lean_ctor_set(x_6, 0, x_27);
lean_ctor_set(x_3, 1, x_6);
lean_ctor_set(x_3, 0, x_28);
lean_ctor_set(x_24, 1, x_3);
lean_ctor_set(x_24, 0, x_8);
lean_ctor_set(x_22, 1, x_4);
lean_ctor_set(x_22, 0, x_24);
return x_22;
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; uint8_t x_49; 
x_46 = lean_ctor_get(x_22, 0);
x_47 = lean_ctor_get(x_24, 0);
x_48 = lean_ctor_get(x_24, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_24);
lean_inc(x_46);
x_49 = l_Lean_Parser_isTerminalCommand(x_46);
if (x_49 == 0)
{
lean_object* x_50; lean_object* x_51; 
lean_free_object(x_22);
lean_free_object(x_6);
lean_free_object(x_3);
x_50 = lean_box(0);
x_51 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(x_47, x_2, x_48, x_1, x_46, x_8, x_13, x_50, x_4);
lean_dec(x_13);
if (lean_obj_tag(x_51) == 0)
{
lean_object* x_52; 
x_52 = lean_ctor_get(x_51, 0);
lean_inc(x_52);
if (lean_obj_tag(x_52) == 0)
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
lean_dec(x_2);
x_53 = lean_ctor_get(x_51, 1);
lean_inc(x_53);
if (lean_is_exclusive(x_51)) {
 lean_ctor_release(x_51, 0);
 lean_ctor_release(x_51, 1);
 x_54 = x_51;
} else {
 lean_dec_ref(x_51);
 x_54 = lean_box(0);
}
x_55 = lean_ctor_get(x_52, 0);
lean_inc(x_55);
lean_dec(x_52);
if (lean_is_scalar(x_54)) {
 x_56 = lean_alloc_ctor(0, 2, 0);
} else {
 x_56 = x_54;
}
lean_ctor_set(x_56, 0, x_55);
lean_ctor_set(x_56, 1, x_53);
return x_56;
}
else
{
lean_object* x_57; lean_object* x_58; 
x_57 = lean_ctor_get(x_51, 1);
lean_inc(x_57);
lean_dec(x_51);
x_58 = lean_ctor_get(x_52, 0);
lean_inc(x_58);
lean_dec(x_52);
x_3 = x_58;
x_4 = x_57;
goto _start;
}
}
else
{
lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; 
lean_dec(x_2);
x_60 = lean_ctor_get(x_51, 0);
lean_inc(x_60);
x_61 = lean_ctor_get(x_51, 1);
lean_inc(x_61);
if (lean_is_exclusive(x_51)) {
 lean_ctor_release(x_51, 0);
 lean_ctor_release(x_51, 1);
 x_62 = x_51;
} else {
 lean_dec_ref(x_51);
 x_62 = lean_box(0);
}
if (lean_is_scalar(x_62)) {
 x_63 = lean_alloc_ctor(1, 2, 0);
} else {
 x_63 = x_62;
}
lean_ctor_set(x_63, 0, x_60);
lean_ctor_set(x_63, 1, x_61);
return x_63;
}
}
else
{
lean_object* x_64; 
lean_dec(x_46);
lean_dec(x_2);
lean_ctor_set(x_6, 0, x_47);
lean_ctor_set(x_3, 1, x_6);
lean_ctor_set(x_3, 0, x_48);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_8);
lean_ctor_set(x_64, 1, x_3);
lean_ctor_set(x_22, 1, x_4);
lean_ctor_set(x_22, 0, x_64);
return x_22;
}
}
}
else
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; uint8_t x_70; 
x_65 = lean_ctor_get(x_22, 1);
x_66 = lean_ctor_get(x_22, 0);
lean_inc(x_65);
lean_inc(x_66);
lean_dec(x_22);
x_67 = lean_ctor_get(x_65, 0);
lean_inc(x_67);
x_68 = lean_ctor_get(x_65, 1);
lean_inc(x_68);
if (lean_is_exclusive(x_65)) {
 lean_ctor_release(x_65, 0);
 lean_ctor_release(x_65, 1);
 x_69 = x_65;
} else {
 lean_dec_ref(x_65);
 x_69 = lean_box(0);
}
lean_inc(x_66);
x_70 = l_Lean_Parser_isTerminalCommand(x_66);
if (x_70 == 0)
{
lean_object* x_71; lean_object* x_72; 
lean_dec(x_69);
lean_free_object(x_6);
lean_free_object(x_3);
x_71 = lean_box(0);
x_72 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(x_67, x_2, x_68, x_1, x_66, x_8, x_13, x_71, x_4);
lean_dec(x_13);
if (lean_obj_tag(x_72) == 0)
{
lean_object* x_73; 
x_73 = lean_ctor_get(x_72, 0);
lean_inc(x_73);
if (lean_obj_tag(x_73) == 0)
{
lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; 
lean_dec(x_2);
x_74 = lean_ctor_get(x_72, 1);
lean_inc(x_74);
if (lean_is_exclusive(x_72)) {
 lean_ctor_release(x_72, 0);
 lean_ctor_release(x_72, 1);
 x_75 = x_72;
} else {
 lean_dec_ref(x_72);
 x_75 = lean_box(0);
}
x_76 = lean_ctor_get(x_73, 0);
lean_inc(x_76);
lean_dec(x_73);
if (lean_is_scalar(x_75)) {
 x_77 = lean_alloc_ctor(0, 2, 0);
} else {
 x_77 = x_75;
}
lean_ctor_set(x_77, 0, x_76);
lean_ctor_set(x_77, 1, x_74);
return x_77;
}
else
{
lean_object* x_78; lean_object* x_79; 
x_78 = lean_ctor_get(x_72, 1);
lean_inc(x_78);
lean_dec(x_72);
x_79 = lean_ctor_get(x_73, 0);
lean_inc(x_79);
lean_dec(x_73);
x_3 = x_79;
x_4 = x_78;
goto _start;
}
}
else
{
lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; 
lean_dec(x_2);
x_81 = lean_ctor_get(x_72, 0);
lean_inc(x_81);
x_82 = lean_ctor_get(x_72, 1);
lean_inc(x_82);
if (lean_is_exclusive(x_72)) {
 lean_ctor_release(x_72, 0);
 lean_ctor_release(x_72, 1);
 x_83 = x_72;
} else {
 lean_dec_ref(x_72);
 x_83 = lean_box(0);
}
if (lean_is_scalar(x_83)) {
 x_84 = lean_alloc_ctor(1, 2, 0);
} else {
 x_84 = x_83;
}
lean_ctor_set(x_84, 0, x_81);
lean_ctor_set(x_84, 1, x_82);
return x_84;
}
}
else
{
lean_object* x_85; lean_object* x_86; 
lean_dec(x_66);
lean_dec(x_2);
lean_ctor_set(x_6, 0, x_67);
lean_ctor_set(x_3, 1, x_6);
lean_ctor_set(x_3, 0, x_68);
if (lean_is_scalar(x_69)) {
 x_85 = lean_alloc_ctor(0, 2, 0);
} else {
 x_85 = x_69;
}
lean_ctor_set(x_85, 0, x_8);
lean_ctor_set(x_85, 1, x_3);
x_86 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_86, 0, x_85);
lean_ctor_set(x_86, 1, x_4);
return x_86;
}
}
}
else
{
lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; uint8_t x_104; 
x_87 = lean_ctor_get(x_6, 0);
x_88 = lean_ctor_get(x_6, 1);
lean_inc(x_88);
lean_inc(x_87);
lean_dec(x_6);
x_89 = lean_ctor_get(x_8, 0);
lean_inc(x_89);
x_90 = lean_ctor_get(x_8, 2);
lean_inc(x_90);
x_91 = l_Lean_Elab_Command_instInhabitedScope;
x_92 = l_List_head_x21___rarg(x_91, x_90);
lean_dec(x_90);
x_93 = lean_ctor_get(x_92, 1);
lean_inc(x_93);
x_94 = lean_ctor_get(x_92, 2);
lean_inc(x_94);
x_95 = lean_ctor_get(x_92, 3);
lean_inc(x_95);
lean_dec(x_92);
x_96 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_96, 0, x_89);
lean_ctor_set(x_96, 1, x_93);
lean_ctor_set(x_96, 2, x_94);
lean_ctor_set(x_96, 3, x_95);
lean_inc(x_2);
x_97 = l_Lean_Parser_parseCommand(x_2, x_96, x_87, x_10);
x_98 = lean_ctor_get(x_97, 1);
lean_inc(x_98);
x_99 = lean_ctor_get(x_97, 0);
lean_inc(x_99);
if (lean_is_exclusive(x_97)) {
 lean_ctor_release(x_97, 0);
 lean_ctor_release(x_97, 1);
 x_100 = x_97;
} else {
 lean_dec_ref(x_97);
 x_100 = lean_box(0);
}
x_101 = lean_ctor_get(x_98, 0);
lean_inc(x_101);
x_102 = lean_ctor_get(x_98, 1);
lean_inc(x_102);
if (lean_is_exclusive(x_98)) {
 lean_ctor_release(x_98, 0);
 lean_ctor_release(x_98, 1);
 x_103 = x_98;
} else {
 lean_dec_ref(x_98);
 x_103 = lean_box(0);
}
lean_inc(x_99);
x_104 = l_Lean_Parser_isTerminalCommand(x_99);
if (x_104 == 0)
{
lean_object* x_105; lean_object* x_106; 
lean_dec(x_103);
lean_dec(x_100);
lean_free_object(x_3);
x_105 = lean_box(0);
x_106 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(x_101, x_2, x_102, x_1, x_99, x_8, x_88, x_105, x_4);
lean_dec(x_88);
if (lean_obj_tag(x_106) == 0)
{
lean_object* x_107; 
x_107 = lean_ctor_get(x_106, 0);
lean_inc(x_107);
if (lean_obj_tag(x_107) == 0)
{
lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; 
lean_dec(x_2);
x_108 = lean_ctor_get(x_106, 1);
lean_inc(x_108);
if (lean_is_exclusive(x_106)) {
 lean_ctor_release(x_106, 0);
 lean_ctor_release(x_106, 1);
 x_109 = x_106;
} else {
 lean_dec_ref(x_106);
 x_109 = lean_box(0);
}
x_110 = lean_ctor_get(x_107, 0);
lean_inc(x_110);
lean_dec(x_107);
if (lean_is_scalar(x_109)) {
 x_111 = lean_alloc_ctor(0, 2, 0);
} else {
 x_111 = x_109;
}
lean_ctor_set(x_111, 0, x_110);
lean_ctor_set(x_111, 1, x_108);
return x_111;
}
else
{
lean_object* x_112; lean_object* x_113; 
x_112 = lean_ctor_get(x_106, 1);
lean_inc(x_112);
lean_dec(x_106);
x_113 = lean_ctor_get(x_107, 0);
lean_inc(x_113);
lean_dec(x_107);
x_3 = x_113;
x_4 = x_112;
goto _start;
}
}
else
{
lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; 
lean_dec(x_2);
x_115 = lean_ctor_get(x_106, 0);
lean_inc(x_115);
x_116 = lean_ctor_get(x_106, 1);
lean_inc(x_116);
if (lean_is_exclusive(x_106)) {
 lean_ctor_release(x_106, 0);
 lean_ctor_release(x_106, 1);
 x_117 = x_106;
} else {
 lean_dec_ref(x_106);
 x_117 = lean_box(0);
}
if (lean_is_scalar(x_117)) {
 x_118 = lean_alloc_ctor(1, 2, 0);
} else {
 x_118 = x_117;
}
lean_ctor_set(x_118, 0, x_115);
lean_ctor_set(x_118, 1, x_116);
return x_118;
}
}
else
{
lean_object* x_119; lean_object* x_120; lean_object* x_121; 
lean_dec(x_99);
lean_dec(x_2);
x_119 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_119, 0, x_101);
lean_ctor_set(x_119, 1, x_88);
lean_ctor_set(x_3, 1, x_119);
lean_ctor_set(x_3, 0, x_102);
if (lean_is_scalar(x_103)) {
 x_120 = lean_alloc_ctor(0, 2, 0);
} else {
 x_120 = x_103;
}
lean_ctor_set(x_120, 0, x_8);
lean_ctor_set(x_120, 1, x_3);
if (lean_is_scalar(x_100)) {
 x_121 = lean_alloc_ctor(0, 2, 0);
} else {
 x_121 = x_100;
}
lean_ctor_set(x_121, 0, x_120);
lean_ctor_set(x_121, 1, x_4);
return x_121;
}
}
}
else
{
lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; uint8_t x_142; 
x_122 = lean_ctor_get(x_3, 0);
lean_inc(x_122);
lean_dec(x_3);
x_123 = lean_ctor_get(x_5, 0);
lean_inc(x_123);
lean_dec(x_5);
x_124 = lean_ctor_get(x_6, 0);
lean_inc(x_124);
x_125 = lean_ctor_get(x_6, 1);
lean_inc(x_125);
if (lean_is_exclusive(x_6)) {
 lean_ctor_release(x_6, 0);
 lean_ctor_release(x_6, 1);
 x_126 = x_6;
} else {
 lean_dec_ref(x_6);
 x_126 = lean_box(0);
}
x_127 = lean_ctor_get(x_122, 0);
lean_inc(x_127);
x_128 = lean_ctor_get(x_122, 2);
lean_inc(x_128);
x_129 = l_Lean_Elab_Command_instInhabitedScope;
x_130 = l_List_head_x21___rarg(x_129, x_128);
lean_dec(x_128);
x_131 = lean_ctor_get(x_130, 1);
lean_inc(x_131);
x_132 = lean_ctor_get(x_130, 2);
lean_inc(x_132);
x_133 = lean_ctor_get(x_130, 3);
lean_inc(x_133);
lean_dec(x_130);
x_134 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_134, 0, x_127);
lean_ctor_set(x_134, 1, x_131);
lean_ctor_set(x_134, 2, x_132);
lean_ctor_set(x_134, 3, x_133);
lean_inc(x_2);
x_135 = l_Lean_Parser_parseCommand(x_2, x_134, x_124, x_123);
x_136 = lean_ctor_get(x_135, 1);
lean_inc(x_136);
x_137 = lean_ctor_get(x_135, 0);
lean_inc(x_137);
if (lean_is_exclusive(x_135)) {
 lean_ctor_release(x_135, 0);
 lean_ctor_release(x_135, 1);
 x_138 = x_135;
} else {
 lean_dec_ref(x_135);
 x_138 = lean_box(0);
}
x_139 = lean_ctor_get(x_136, 0);
lean_inc(x_139);
x_140 = lean_ctor_get(x_136, 1);
lean_inc(x_140);
if (lean_is_exclusive(x_136)) {
 lean_ctor_release(x_136, 0);
 lean_ctor_release(x_136, 1);
 x_141 = x_136;
} else {
 lean_dec_ref(x_136);
 x_141 = lean_box(0);
}
lean_inc(x_137);
x_142 = l_Lean_Parser_isTerminalCommand(x_137);
if (x_142 == 0)
{
lean_object* x_143; lean_object* x_144; 
lean_dec(x_141);
lean_dec(x_138);
lean_dec(x_126);
x_143 = lean_box(0);
x_144 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(x_139, x_2, x_140, x_1, x_137, x_122, x_125, x_143, x_4);
lean_dec(x_125);
if (lean_obj_tag(x_144) == 0)
{
lean_object* x_145; 
x_145 = lean_ctor_get(x_144, 0);
lean_inc(x_145);
if (lean_obj_tag(x_145) == 0)
{
lean_object* x_146; lean_object* x_147; lean_object* x_148; lean_object* x_149; 
lean_dec(x_2);
x_146 = lean_ctor_get(x_144, 1);
lean_inc(x_146);
if (lean_is_exclusive(x_144)) {
 lean_ctor_release(x_144, 0);
 lean_ctor_release(x_144, 1);
 x_147 = x_144;
} else {
 lean_dec_ref(x_144);
 x_147 = lean_box(0);
}
x_148 = lean_ctor_get(x_145, 0);
lean_inc(x_148);
lean_dec(x_145);
if (lean_is_scalar(x_147)) {
 x_149 = lean_alloc_ctor(0, 2, 0);
} else {
 x_149 = x_147;
}
lean_ctor_set(x_149, 0, x_148);
lean_ctor_set(x_149, 1, x_146);
return x_149;
}
else
{
lean_object* x_150; lean_object* x_151; 
x_150 = lean_ctor_get(x_144, 1);
lean_inc(x_150);
lean_dec(x_144);
x_151 = lean_ctor_get(x_145, 0);
lean_inc(x_151);
lean_dec(x_145);
x_3 = x_151;
x_4 = x_150;
goto _start;
}
}
else
{
lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; 
lean_dec(x_2);
x_153 = lean_ctor_get(x_144, 0);
lean_inc(x_153);
x_154 = lean_ctor_get(x_144, 1);
lean_inc(x_154);
if (lean_is_exclusive(x_144)) {
 lean_ctor_release(x_144, 0);
 lean_ctor_release(x_144, 1);
 x_155 = x_144;
} else {
 lean_dec_ref(x_144);
 x_155 = lean_box(0);
}
if (lean_is_scalar(x_155)) {
 x_156 = lean_alloc_ctor(1, 2, 0);
} else {
 x_156 = x_155;
}
lean_ctor_set(x_156, 0, x_153);
lean_ctor_set(x_156, 1, x_154);
return x_156;
}
}
else
{
lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; 
lean_dec(x_137);
lean_dec(x_2);
if (lean_is_scalar(x_126)) {
 x_157 = lean_alloc_ctor(0, 2, 0);
} else {
 x_157 = x_126;
}
lean_ctor_set(x_157, 0, x_139);
lean_ctor_set(x_157, 1, x_125);
x_158 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_158, 0, x_140);
lean_ctor_set(x_158, 1, x_157);
if (lean_is_scalar(x_141)) {
 x_159 = lean_alloc_ctor(0, 2, 0);
} else {
 x_159 = x_141;
}
lean_ctor_set(x_159, 0, x_122);
lean_ctor_set(x_159, 1, x_158);
if (lean_is_scalar(x_138)) {
 x_160 = lean_alloc_ctor(0, 2, 0);
} else {
 x_160 = x_138;
}
lean_ctor_set(x_160, 0, x_159);
lean_ctor_set(x_160, 1, x_4);
return x_160;
}
}
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("text", 4);
return x_1;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("information", 11);
return x_1;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_List_forIn_loop___at_main___spec__5___closed__2;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("severity", 8);
return x_1;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_List_forIn_loop___at_main___spec__5___closed__4;
x_2 = l_List_forIn_loop___at_main___spec__5___closed__3;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("warning", 7);
return x_1;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_List_forIn_loop___at_main___spec__5___closed__6;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_List_forIn_loop___at_main___spec__5___closed__4;
x_2 = l_List_forIn_loop___at_main___spec__5___closed__7;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("error", 5);
return x_1;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_List_forIn_loop___at_main___spec__5___closed__9;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_List_forIn_loop___at_main___spec__5___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_List_forIn_loop___at_main___spec__5___closed__4;
x_2 = l_List_forIn_loop___at_main___spec__5___closed__10;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_List_forIn_loop___at_main___spec__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
if (lean_obj_tag(x_2) == 0)
{
lean_object* x_5; 
lean_dec(x_1);
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_3);
lean_ctor_set(x_5, 1, x_4);
return x_5;
}
else
{
uint8_t x_6; 
x_6 = !lean_is_exclusive(x_2);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; uint8_t x_9; lean_object* x_10; 
x_7 = lean_ctor_get(x_2, 0);
x_8 = lean_ctor_get(x_2, 1);
x_9 = 0;
lean_inc(x_7);
x_10 = l_Lean_Message_toString(x_7, x_9, x_4);
if (lean_obj_tag(x_10) == 0)
{
lean_object* x_11; lean_object* x_12; uint8_t x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_ctor_get_uint8(x_7, sizeof(void*)*5 + 1);
lean_dec(x_7);
x_14 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_14, 0, x_11);
x_15 = l_List_forIn_loop___at_main___spec__5___closed__1;
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_14);
lean_inc(x_1);
lean_ctor_set(x_2, 1, x_1);
lean_ctor_set(x_2, 0, x_16);
switch (x_13) {
case 0:
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_17 = l_List_forIn_loop___at_main___spec__5___closed__5;
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_2);
x_19 = l_Lean_Json_mkObj(x_18);
x_20 = lean_array_push(x_3, x_19);
x_2 = x_8;
x_3 = x_20;
x_4 = x_12;
goto _start;
}
case 1:
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_22 = l_List_forIn_loop___at_main___spec__5___closed__8;
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_2);
x_24 = l_Lean_Json_mkObj(x_23);
x_25 = lean_array_push(x_3, x_24);
x_2 = x_8;
x_3 = x_25;
x_4 = x_12;
goto _start;
}
default: 
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_27 = l_List_forIn_loop___at_main___spec__5___closed__11;
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_2);
x_29 = l_Lean_Json_mkObj(x_28);
x_30 = lean_array_push(x_3, x_29);
x_2 = x_8;
x_3 = x_30;
x_4 = x_12;
goto _start;
}
}
}
else
{
uint8_t x_32; 
lean_free_object(x_2);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_3);
lean_dec(x_1);
x_32 = !lean_is_exclusive(x_10);
if (x_32 == 0)
{
return x_10;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_33 = lean_ctor_get(x_10, 0);
x_34 = lean_ctor_get(x_10, 1);
lean_inc(x_34);
lean_inc(x_33);
lean_dec(x_10);
x_35 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_35, 0, x_33);
lean_ctor_set(x_35, 1, x_34);
return x_35;
}
}
}
else
{
lean_object* x_36; lean_object* x_37; uint8_t x_38; lean_object* x_39; 
x_36 = lean_ctor_get(x_2, 0);
x_37 = lean_ctor_get(x_2, 1);
lean_inc(x_37);
lean_inc(x_36);
lean_dec(x_2);
x_38 = 0;
lean_inc(x_36);
x_39 = l_Lean_Message_toString(x_36, x_38, x_4);
if (lean_obj_tag(x_39) == 0)
{
lean_object* x_40; lean_object* x_41; uint8_t x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_40 = lean_ctor_get(x_39, 0);
lean_inc(x_40);
x_41 = lean_ctor_get(x_39, 1);
lean_inc(x_41);
lean_dec(x_39);
x_42 = lean_ctor_get_uint8(x_36, sizeof(void*)*5 + 1);
lean_dec(x_36);
x_43 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_43, 0, x_40);
x_44 = l_List_forIn_loop___at_main___spec__5___closed__1;
x_45 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_45, 0, x_44);
lean_ctor_set(x_45, 1, x_43);
lean_inc(x_1);
x_46 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_46, 0, x_45);
lean_ctor_set(x_46, 1, x_1);
switch (x_42) {
case 0:
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; 
x_47 = l_List_forIn_loop___at_main___spec__5___closed__5;
x_48 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_48, 0, x_47);
lean_ctor_set(x_48, 1, x_46);
x_49 = l_Lean_Json_mkObj(x_48);
x_50 = lean_array_push(x_3, x_49);
x_2 = x_37;
x_3 = x_50;
x_4 = x_41;
goto _start;
}
case 1:
{
lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; 
x_52 = l_List_forIn_loop___at_main___spec__5___closed__8;
x_53 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_53, 0, x_52);
lean_ctor_set(x_53, 1, x_46);
x_54 = l_Lean_Json_mkObj(x_53);
x_55 = lean_array_push(x_3, x_54);
x_2 = x_37;
x_3 = x_55;
x_4 = x_41;
goto _start;
}
default: 
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; 
x_57 = l_List_forIn_loop___at_main___spec__5___closed__11;
x_58 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_58, 0, x_57);
lean_ctor_set(x_58, 1, x_46);
x_59 = l_Lean_Json_mkObj(x_58);
x_60 = lean_array_push(x_3, x_59);
x_2 = x_37;
x_3 = x_60;
x_4 = x_41;
goto _start;
}
}
}
else
{
lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; 
lean_dec(x_37);
lean_dec(x_36);
lean_dec(x_3);
lean_dec(x_1);
x_62 = lean_ctor_get(x_39, 0);
lean_inc(x_62);
x_63 = lean_ctor_get(x_39, 1);
lean_inc(x_63);
if (lean_is_exclusive(x_39)) {
 lean_ctor_release(x_39, 0);
 lean_ctor_release(x_39, 1);
 x_64 = x_39;
} else {
 lean_dec_ref(x_39);
 x_64 = lean_box(0);
}
if (lean_is_scalar(x_64)) {
 x_65 = lean_alloc_ctor(1, 2, 0);
} else {
 x_65 = x_64;
}
lean_ctor_set(x_65, 0, x_62);
lean_ctor_set(x_65, 1, x_63);
return x_65;
}
}
}
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("candidate_end", 13);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__1;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("event", 5);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__3;
x_2 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("wrapped_outer_units", 19);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("elapsed_ns", 10);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("diagnostics", 11);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__8() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 0;
x_2 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("proof_result_reused", 19);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__9;
x_2 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__8;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("native_error", 12);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__12() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 1;
x_2 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
x_2 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__12;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; lean_object* x_12; uint8_t x_13; 
lean_inc(x_2);
lean_inc(x_1);
x_11 = l_Lean_Elab_Command_mkState(x_9, x_1, x_2);
x_12 = lean_io_mono_nanos_now(x_10);
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_14 = lean_ctor_get(x_12, 0);
x_15 = lean_ctor_get(x_12, 1);
x_16 = lean_unsigned_to_nat(0u);
lean_ctor_set(x_12, 1, x_16);
lean_ctor_set(x_12, 0, x_3);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_1);
lean_ctor_set(x_17, 1, x_12);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_11);
lean_ctor_set(x_18, 1, x_17);
x_19 = l_Lean_Loop_forIn_loop___at_main___spec__4(x_4, x_5, x_18, x_15);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; 
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_20, 1);
lean_inc(x_21);
x_22 = lean_ctor_get(x_21, 1);
lean_inc(x_22);
x_23 = lean_ctor_get(x_19, 1);
lean_inc(x_23);
lean_dec(x_19);
x_24 = !lean_is_exclusive(x_20);
if (x_24 == 0)
{
lean_object* x_25; lean_object* x_26; uint8_t x_27; 
x_25 = lean_ctor_get(x_20, 0);
x_26 = lean_ctor_get(x_20, 1);
lean_dec(x_26);
x_27 = !lean_is_exclusive(x_21);
if (x_27 == 0)
{
lean_object* x_28; lean_object* x_29; uint8_t x_30; 
x_28 = lean_ctor_get(x_21, 0);
x_29 = lean_ctor_get(x_21, 1);
lean_dec(x_29);
x_30 = !lean_is_exclusive(x_22);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_31 = lean_ctor_get(x_22, 1);
x_32 = lean_ctor_get(x_22, 0);
lean_dec(x_32);
x_33 = lean_ctor_get(x_25, 1);
lean_inc(x_33);
lean_dec(x_25);
lean_inc(x_33);
lean_inc(x_28);
x_34 = l_Lean_MessageLog_append(x_28, x_33);
x_35 = l_Lean_MessageLog_toList(x_34);
x_36 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
lean_inc(x_2);
x_37 = l_List_forIn_loop___at_main___spec__5(x_2, x_35, x_36, x_23);
if (lean_obj_tag(x_37) == 0)
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; uint8_t x_41; 
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_io_mono_nanos_now(x_39);
x_41 = !lean_is_exclusive(x_40);
if (x_41 == 0)
{
lean_object* x_42; lean_object* x_43; uint8_t x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; 
x_42 = lean_ctor_get(x_40, 0);
x_43 = lean_ctor_get(x_40, 1);
x_44 = l_Lean_MessageLog_hasErrors(x_28);
x_45 = l_Lean_JsonNumber_fromNat(x_31);
x_46 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_46, 0, x_45);
x_47 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5;
lean_ctor_set(x_40, 1, x_46);
lean_ctor_set(x_40, 0, x_47);
x_48 = lean_nat_sub(x_42, x_14);
lean_dec(x_14);
lean_dec(x_42);
x_49 = l_Lean_JsonNumber_fromNat(x_48);
x_50 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_50, 0, x_49);
x_51 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6;
lean_ctor_set(x_22, 1, x_50);
lean_ctor_set(x_22, 0, x_51);
x_52 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_52, 0, x_38);
x_53 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7;
lean_ctor_set(x_21, 1, x_52);
lean_ctor_set(x_21, 0, x_53);
x_54 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10;
lean_ctor_set_tag(x_20, 1);
lean_ctor_set(x_20, 1, x_2);
lean_ctor_set(x_20, 0, x_54);
x_55 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_55, 0, x_21);
lean_ctor_set(x_55, 1, x_20);
x_56 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_56, 0, x_22);
lean_ctor_set(x_56, 1, x_55);
x_57 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_57, 0, x_40);
lean_ctor_set(x_57, 1, x_56);
if (x_44 == 0)
{
uint8_t x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; 
x_58 = l_Lean_MessageLog_hasErrors(x_33);
x_59 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_59, 0, x_58);
x_60 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
x_61 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_61, 0, x_60);
lean_ctor_set(x_61, 1, x_59);
x_62 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_62, 0, x_61);
lean_ctor_set(x_62, 1, x_57);
x_63 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_63, 0, x_6);
lean_ctor_set(x_63, 1, x_62);
x_64 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_64, 0, x_7);
lean_ctor_set(x_64, 1, x_63);
x_65 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_66 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_66, 0, x_65);
lean_ctor_set(x_66, 1, x_64);
x_67 = l_Lean_Json_mkObj(x_66);
x_68 = l___private_StateReuseMeasure_0__emit(x_67, x_43);
if (lean_obj_tag(x_68) == 0)
{
uint8_t x_69; 
x_69 = !lean_is_exclusive(x_68);
if (x_69 == 0)
{
lean_object* x_70; lean_object* x_71; 
x_70 = lean_ctor_get(x_68, 0);
lean_dec(x_70);
x_71 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_71, 0, x_8);
lean_ctor_set(x_68, 0, x_71);
return x_68;
}
else
{
lean_object* x_72; lean_object* x_73; lean_object* x_74; 
x_72 = lean_ctor_get(x_68, 1);
lean_inc(x_72);
lean_dec(x_68);
x_73 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_73, 0, x_8);
x_74 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_74, 0, x_73);
lean_ctor_set(x_74, 1, x_72);
return x_74;
}
}
else
{
uint8_t x_75; 
lean_dec(x_8);
x_75 = !lean_is_exclusive(x_68);
if (x_75 == 0)
{
return x_68;
}
else
{
lean_object* x_76; lean_object* x_77; lean_object* x_78; 
x_76 = lean_ctor_get(x_68, 0);
x_77 = lean_ctor_get(x_68, 1);
lean_inc(x_77);
lean_inc(x_76);
lean_dec(x_68);
x_78 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_78, 0, x_76);
lean_ctor_set(x_78, 1, x_77);
return x_78;
}
}
}
else
{
lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; 
lean_dec(x_33);
x_79 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13;
x_80 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_80, 0, x_79);
lean_ctor_set(x_80, 1, x_57);
x_81 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_81, 0, x_6);
lean_ctor_set(x_81, 1, x_80);
x_82 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_82, 0, x_7);
lean_ctor_set(x_82, 1, x_81);
x_83 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_84 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_84, 0, x_83);
lean_ctor_set(x_84, 1, x_82);
x_85 = l_Lean_Json_mkObj(x_84);
x_86 = l___private_StateReuseMeasure_0__emit(x_85, x_43);
if (lean_obj_tag(x_86) == 0)
{
uint8_t x_87; 
x_87 = !lean_is_exclusive(x_86);
if (x_87 == 0)
{
lean_object* x_88; lean_object* x_89; 
x_88 = lean_ctor_get(x_86, 0);
lean_dec(x_88);
x_89 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_89, 0, x_8);
lean_ctor_set(x_86, 0, x_89);
return x_86;
}
else
{
lean_object* x_90; lean_object* x_91; lean_object* x_92; 
x_90 = lean_ctor_get(x_86, 1);
lean_inc(x_90);
lean_dec(x_86);
x_91 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_91, 0, x_8);
x_92 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_92, 0, x_91);
lean_ctor_set(x_92, 1, x_90);
return x_92;
}
}
else
{
uint8_t x_93; 
lean_dec(x_8);
x_93 = !lean_is_exclusive(x_86);
if (x_93 == 0)
{
return x_86;
}
else
{
lean_object* x_94; lean_object* x_95; lean_object* x_96; 
x_94 = lean_ctor_get(x_86, 0);
x_95 = lean_ctor_get(x_86, 1);
lean_inc(x_95);
lean_inc(x_94);
lean_dec(x_86);
x_96 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_96, 0, x_94);
lean_ctor_set(x_96, 1, x_95);
return x_96;
}
}
}
}
else
{
lean_object* x_97; lean_object* x_98; uint8_t x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; 
x_97 = lean_ctor_get(x_40, 0);
x_98 = lean_ctor_get(x_40, 1);
lean_inc(x_98);
lean_inc(x_97);
lean_dec(x_40);
x_99 = l_Lean_MessageLog_hasErrors(x_28);
x_100 = l_Lean_JsonNumber_fromNat(x_31);
x_101 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_101, 0, x_100);
x_102 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5;
x_103 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_103, 0, x_102);
lean_ctor_set(x_103, 1, x_101);
x_104 = lean_nat_sub(x_97, x_14);
lean_dec(x_14);
lean_dec(x_97);
x_105 = l_Lean_JsonNumber_fromNat(x_104);
x_106 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_106, 0, x_105);
x_107 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6;
lean_ctor_set(x_22, 1, x_106);
lean_ctor_set(x_22, 0, x_107);
x_108 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_108, 0, x_38);
x_109 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7;
lean_ctor_set(x_21, 1, x_108);
lean_ctor_set(x_21, 0, x_109);
x_110 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10;
lean_ctor_set_tag(x_20, 1);
lean_ctor_set(x_20, 1, x_2);
lean_ctor_set(x_20, 0, x_110);
x_111 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_111, 0, x_21);
lean_ctor_set(x_111, 1, x_20);
x_112 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_112, 0, x_22);
lean_ctor_set(x_112, 1, x_111);
x_113 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_113, 0, x_103);
lean_ctor_set(x_113, 1, x_112);
if (x_99 == 0)
{
uint8_t x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; 
x_114 = l_Lean_MessageLog_hasErrors(x_33);
x_115 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_115, 0, x_114);
x_116 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
x_117 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_117, 0, x_116);
lean_ctor_set(x_117, 1, x_115);
x_118 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_118, 0, x_117);
lean_ctor_set(x_118, 1, x_113);
x_119 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_119, 0, x_6);
lean_ctor_set(x_119, 1, x_118);
x_120 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_120, 0, x_7);
lean_ctor_set(x_120, 1, x_119);
x_121 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_122 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_122, 0, x_121);
lean_ctor_set(x_122, 1, x_120);
x_123 = l_Lean_Json_mkObj(x_122);
x_124 = l___private_StateReuseMeasure_0__emit(x_123, x_98);
if (lean_obj_tag(x_124) == 0)
{
lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; 
x_125 = lean_ctor_get(x_124, 1);
lean_inc(x_125);
if (lean_is_exclusive(x_124)) {
 lean_ctor_release(x_124, 0);
 lean_ctor_release(x_124, 1);
 x_126 = x_124;
} else {
 lean_dec_ref(x_124);
 x_126 = lean_box(0);
}
x_127 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_127, 0, x_8);
if (lean_is_scalar(x_126)) {
 x_128 = lean_alloc_ctor(0, 2, 0);
} else {
 x_128 = x_126;
}
lean_ctor_set(x_128, 0, x_127);
lean_ctor_set(x_128, 1, x_125);
return x_128;
}
else
{
lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; 
lean_dec(x_8);
x_129 = lean_ctor_get(x_124, 0);
lean_inc(x_129);
x_130 = lean_ctor_get(x_124, 1);
lean_inc(x_130);
if (lean_is_exclusive(x_124)) {
 lean_ctor_release(x_124, 0);
 lean_ctor_release(x_124, 1);
 x_131 = x_124;
} else {
 lean_dec_ref(x_124);
 x_131 = lean_box(0);
}
if (lean_is_scalar(x_131)) {
 x_132 = lean_alloc_ctor(1, 2, 0);
} else {
 x_132 = x_131;
}
lean_ctor_set(x_132, 0, x_129);
lean_ctor_set(x_132, 1, x_130);
return x_132;
}
}
else
{
lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; 
lean_dec(x_33);
x_133 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13;
x_134 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_134, 0, x_133);
lean_ctor_set(x_134, 1, x_113);
x_135 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_135, 0, x_6);
lean_ctor_set(x_135, 1, x_134);
x_136 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_136, 0, x_7);
lean_ctor_set(x_136, 1, x_135);
x_137 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_138 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_138, 0, x_137);
lean_ctor_set(x_138, 1, x_136);
x_139 = l_Lean_Json_mkObj(x_138);
x_140 = l___private_StateReuseMeasure_0__emit(x_139, x_98);
if (lean_obj_tag(x_140) == 0)
{
lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; 
x_141 = lean_ctor_get(x_140, 1);
lean_inc(x_141);
if (lean_is_exclusive(x_140)) {
 lean_ctor_release(x_140, 0);
 lean_ctor_release(x_140, 1);
 x_142 = x_140;
} else {
 lean_dec_ref(x_140);
 x_142 = lean_box(0);
}
x_143 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_143, 0, x_8);
if (lean_is_scalar(x_142)) {
 x_144 = lean_alloc_ctor(0, 2, 0);
} else {
 x_144 = x_142;
}
lean_ctor_set(x_144, 0, x_143);
lean_ctor_set(x_144, 1, x_141);
return x_144;
}
else
{
lean_object* x_145; lean_object* x_146; lean_object* x_147; lean_object* x_148; 
lean_dec(x_8);
x_145 = lean_ctor_get(x_140, 0);
lean_inc(x_145);
x_146 = lean_ctor_get(x_140, 1);
lean_inc(x_146);
if (lean_is_exclusive(x_140)) {
 lean_ctor_release(x_140, 0);
 lean_ctor_release(x_140, 1);
 x_147 = x_140;
} else {
 lean_dec_ref(x_140);
 x_147 = lean_box(0);
}
if (lean_is_scalar(x_147)) {
 x_148 = lean_alloc_ctor(1, 2, 0);
} else {
 x_148 = x_147;
}
lean_ctor_set(x_148, 0, x_145);
lean_ctor_set(x_148, 1, x_146);
return x_148;
}
}
}
}
else
{
uint8_t x_149; 
lean_dec(x_33);
lean_free_object(x_22);
lean_dec(x_31);
lean_free_object(x_21);
lean_dec(x_28);
lean_free_object(x_20);
lean_dec(x_14);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_149 = !lean_is_exclusive(x_37);
if (x_149 == 0)
{
return x_37;
}
else
{
lean_object* x_150; lean_object* x_151; lean_object* x_152; 
x_150 = lean_ctor_get(x_37, 0);
x_151 = lean_ctor_get(x_37, 1);
lean_inc(x_151);
lean_inc(x_150);
lean_dec(x_37);
x_152 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_152, 0, x_150);
lean_ctor_set(x_152, 1, x_151);
return x_152;
}
}
}
else
{
lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; 
x_153 = lean_ctor_get(x_22, 1);
lean_inc(x_153);
lean_dec(x_22);
x_154 = lean_ctor_get(x_25, 1);
lean_inc(x_154);
lean_dec(x_25);
lean_inc(x_154);
lean_inc(x_28);
x_155 = l_Lean_MessageLog_append(x_28, x_154);
x_156 = l_Lean_MessageLog_toList(x_155);
x_157 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
lean_inc(x_2);
x_158 = l_List_forIn_loop___at_main___spec__5(x_2, x_156, x_157, x_23);
if (lean_obj_tag(x_158) == 0)
{
lean_object* x_159; lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; uint8_t x_165; lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; lean_object* x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; lean_object* x_175; lean_object* x_176; lean_object* x_177; lean_object* x_178; lean_object* x_179; lean_object* x_180; 
x_159 = lean_ctor_get(x_158, 0);
lean_inc(x_159);
x_160 = lean_ctor_get(x_158, 1);
lean_inc(x_160);
lean_dec(x_158);
x_161 = lean_io_mono_nanos_now(x_160);
x_162 = lean_ctor_get(x_161, 0);
lean_inc(x_162);
x_163 = lean_ctor_get(x_161, 1);
lean_inc(x_163);
if (lean_is_exclusive(x_161)) {
 lean_ctor_release(x_161, 0);
 lean_ctor_release(x_161, 1);
 x_164 = x_161;
} else {
 lean_dec_ref(x_161);
 x_164 = lean_box(0);
}
x_165 = l_Lean_MessageLog_hasErrors(x_28);
x_166 = l_Lean_JsonNumber_fromNat(x_153);
x_167 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_167, 0, x_166);
x_168 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5;
if (lean_is_scalar(x_164)) {
 x_169 = lean_alloc_ctor(0, 2, 0);
} else {
 x_169 = x_164;
}
lean_ctor_set(x_169, 0, x_168);
lean_ctor_set(x_169, 1, x_167);
x_170 = lean_nat_sub(x_162, x_14);
lean_dec(x_14);
lean_dec(x_162);
x_171 = l_Lean_JsonNumber_fromNat(x_170);
x_172 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_172, 0, x_171);
x_173 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6;
x_174 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_174, 0, x_173);
lean_ctor_set(x_174, 1, x_172);
x_175 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_175, 0, x_159);
x_176 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7;
lean_ctor_set(x_21, 1, x_175);
lean_ctor_set(x_21, 0, x_176);
x_177 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10;
lean_ctor_set_tag(x_20, 1);
lean_ctor_set(x_20, 1, x_2);
lean_ctor_set(x_20, 0, x_177);
x_178 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_178, 0, x_21);
lean_ctor_set(x_178, 1, x_20);
x_179 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_179, 0, x_174);
lean_ctor_set(x_179, 1, x_178);
x_180 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_180, 0, x_169);
lean_ctor_set(x_180, 1, x_179);
if (x_165 == 0)
{
uint8_t x_181; lean_object* x_182; lean_object* x_183; lean_object* x_184; lean_object* x_185; lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; lean_object* x_190; lean_object* x_191; 
x_181 = l_Lean_MessageLog_hasErrors(x_154);
x_182 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_182, 0, x_181);
x_183 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
x_184 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_184, 0, x_183);
lean_ctor_set(x_184, 1, x_182);
x_185 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_185, 0, x_184);
lean_ctor_set(x_185, 1, x_180);
x_186 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_186, 0, x_6);
lean_ctor_set(x_186, 1, x_185);
x_187 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_187, 0, x_7);
lean_ctor_set(x_187, 1, x_186);
x_188 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_189 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_189, 0, x_188);
lean_ctor_set(x_189, 1, x_187);
x_190 = l_Lean_Json_mkObj(x_189);
x_191 = l___private_StateReuseMeasure_0__emit(x_190, x_163);
if (lean_obj_tag(x_191) == 0)
{
lean_object* x_192; lean_object* x_193; lean_object* x_194; lean_object* x_195; 
x_192 = lean_ctor_get(x_191, 1);
lean_inc(x_192);
if (lean_is_exclusive(x_191)) {
 lean_ctor_release(x_191, 0);
 lean_ctor_release(x_191, 1);
 x_193 = x_191;
} else {
 lean_dec_ref(x_191);
 x_193 = lean_box(0);
}
x_194 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_194, 0, x_8);
if (lean_is_scalar(x_193)) {
 x_195 = lean_alloc_ctor(0, 2, 0);
} else {
 x_195 = x_193;
}
lean_ctor_set(x_195, 0, x_194);
lean_ctor_set(x_195, 1, x_192);
return x_195;
}
else
{
lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; 
lean_dec(x_8);
x_196 = lean_ctor_get(x_191, 0);
lean_inc(x_196);
x_197 = lean_ctor_get(x_191, 1);
lean_inc(x_197);
if (lean_is_exclusive(x_191)) {
 lean_ctor_release(x_191, 0);
 lean_ctor_release(x_191, 1);
 x_198 = x_191;
} else {
 lean_dec_ref(x_191);
 x_198 = lean_box(0);
}
if (lean_is_scalar(x_198)) {
 x_199 = lean_alloc_ctor(1, 2, 0);
} else {
 x_199 = x_198;
}
lean_ctor_set(x_199, 0, x_196);
lean_ctor_set(x_199, 1, x_197);
return x_199;
}
}
else
{
lean_object* x_200; lean_object* x_201; lean_object* x_202; lean_object* x_203; lean_object* x_204; lean_object* x_205; lean_object* x_206; lean_object* x_207; 
lean_dec(x_154);
x_200 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13;
x_201 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_201, 0, x_200);
lean_ctor_set(x_201, 1, x_180);
x_202 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_202, 0, x_6);
lean_ctor_set(x_202, 1, x_201);
x_203 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_203, 0, x_7);
lean_ctor_set(x_203, 1, x_202);
x_204 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_205 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_205, 0, x_204);
lean_ctor_set(x_205, 1, x_203);
x_206 = l_Lean_Json_mkObj(x_205);
x_207 = l___private_StateReuseMeasure_0__emit(x_206, x_163);
if (lean_obj_tag(x_207) == 0)
{
lean_object* x_208; lean_object* x_209; lean_object* x_210; lean_object* x_211; 
x_208 = lean_ctor_get(x_207, 1);
lean_inc(x_208);
if (lean_is_exclusive(x_207)) {
 lean_ctor_release(x_207, 0);
 lean_ctor_release(x_207, 1);
 x_209 = x_207;
} else {
 lean_dec_ref(x_207);
 x_209 = lean_box(0);
}
x_210 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_210, 0, x_8);
if (lean_is_scalar(x_209)) {
 x_211 = lean_alloc_ctor(0, 2, 0);
} else {
 x_211 = x_209;
}
lean_ctor_set(x_211, 0, x_210);
lean_ctor_set(x_211, 1, x_208);
return x_211;
}
else
{
lean_object* x_212; lean_object* x_213; lean_object* x_214; lean_object* x_215; 
lean_dec(x_8);
x_212 = lean_ctor_get(x_207, 0);
lean_inc(x_212);
x_213 = lean_ctor_get(x_207, 1);
lean_inc(x_213);
if (lean_is_exclusive(x_207)) {
 lean_ctor_release(x_207, 0);
 lean_ctor_release(x_207, 1);
 x_214 = x_207;
} else {
 lean_dec_ref(x_207);
 x_214 = lean_box(0);
}
if (lean_is_scalar(x_214)) {
 x_215 = lean_alloc_ctor(1, 2, 0);
} else {
 x_215 = x_214;
}
lean_ctor_set(x_215, 0, x_212);
lean_ctor_set(x_215, 1, x_213);
return x_215;
}
}
}
else
{
lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; 
lean_dec(x_154);
lean_dec(x_153);
lean_free_object(x_21);
lean_dec(x_28);
lean_free_object(x_20);
lean_dec(x_14);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_216 = lean_ctor_get(x_158, 0);
lean_inc(x_216);
x_217 = lean_ctor_get(x_158, 1);
lean_inc(x_217);
if (lean_is_exclusive(x_158)) {
 lean_ctor_release(x_158, 0);
 lean_ctor_release(x_158, 1);
 x_218 = x_158;
} else {
 lean_dec_ref(x_158);
 x_218 = lean_box(0);
}
if (lean_is_scalar(x_218)) {
 x_219 = lean_alloc_ctor(1, 2, 0);
} else {
 x_219 = x_218;
}
lean_ctor_set(x_219, 0, x_216);
lean_ctor_set(x_219, 1, x_217);
return x_219;
}
}
}
else
{
lean_object* x_220; lean_object* x_221; lean_object* x_222; lean_object* x_223; lean_object* x_224; lean_object* x_225; lean_object* x_226; lean_object* x_227; 
x_220 = lean_ctor_get(x_21, 0);
lean_inc(x_220);
lean_dec(x_21);
x_221 = lean_ctor_get(x_22, 1);
lean_inc(x_221);
if (lean_is_exclusive(x_22)) {
 lean_ctor_release(x_22, 0);
 lean_ctor_release(x_22, 1);
 x_222 = x_22;
} else {
 lean_dec_ref(x_22);
 x_222 = lean_box(0);
}
x_223 = lean_ctor_get(x_25, 1);
lean_inc(x_223);
lean_dec(x_25);
lean_inc(x_223);
lean_inc(x_220);
x_224 = l_Lean_MessageLog_append(x_220, x_223);
x_225 = l_Lean_MessageLog_toList(x_224);
x_226 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
lean_inc(x_2);
x_227 = l_List_forIn_loop___at_main___spec__5(x_2, x_225, x_226, x_23);
if (lean_obj_tag(x_227) == 0)
{
lean_object* x_228; lean_object* x_229; lean_object* x_230; lean_object* x_231; lean_object* x_232; lean_object* x_233; uint8_t x_234; lean_object* x_235; lean_object* x_236; lean_object* x_237; lean_object* x_238; lean_object* x_239; lean_object* x_240; lean_object* x_241; lean_object* x_242; lean_object* x_243; lean_object* x_244; lean_object* x_245; lean_object* x_246; lean_object* x_247; lean_object* x_248; lean_object* x_249; lean_object* x_250; 
x_228 = lean_ctor_get(x_227, 0);
lean_inc(x_228);
x_229 = lean_ctor_get(x_227, 1);
lean_inc(x_229);
lean_dec(x_227);
x_230 = lean_io_mono_nanos_now(x_229);
x_231 = lean_ctor_get(x_230, 0);
lean_inc(x_231);
x_232 = lean_ctor_get(x_230, 1);
lean_inc(x_232);
if (lean_is_exclusive(x_230)) {
 lean_ctor_release(x_230, 0);
 lean_ctor_release(x_230, 1);
 x_233 = x_230;
} else {
 lean_dec_ref(x_230);
 x_233 = lean_box(0);
}
x_234 = l_Lean_MessageLog_hasErrors(x_220);
x_235 = l_Lean_JsonNumber_fromNat(x_221);
x_236 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_236, 0, x_235);
x_237 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5;
if (lean_is_scalar(x_233)) {
 x_238 = lean_alloc_ctor(0, 2, 0);
} else {
 x_238 = x_233;
}
lean_ctor_set(x_238, 0, x_237);
lean_ctor_set(x_238, 1, x_236);
x_239 = lean_nat_sub(x_231, x_14);
lean_dec(x_14);
lean_dec(x_231);
x_240 = l_Lean_JsonNumber_fromNat(x_239);
x_241 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_241, 0, x_240);
x_242 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6;
if (lean_is_scalar(x_222)) {
 x_243 = lean_alloc_ctor(0, 2, 0);
} else {
 x_243 = x_222;
}
lean_ctor_set(x_243, 0, x_242);
lean_ctor_set(x_243, 1, x_241);
x_244 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_244, 0, x_228);
x_245 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7;
x_246 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_246, 0, x_245);
lean_ctor_set(x_246, 1, x_244);
x_247 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10;
lean_ctor_set_tag(x_20, 1);
lean_ctor_set(x_20, 1, x_2);
lean_ctor_set(x_20, 0, x_247);
x_248 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_248, 0, x_246);
lean_ctor_set(x_248, 1, x_20);
x_249 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_249, 0, x_243);
lean_ctor_set(x_249, 1, x_248);
x_250 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_250, 0, x_238);
lean_ctor_set(x_250, 1, x_249);
if (x_234 == 0)
{
uint8_t x_251; lean_object* x_252; lean_object* x_253; lean_object* x_254; lean_object* x_255; lean_object* x_256; lean_object* x_257; lean_object* x_258; lean_object* x_259; lean_object* x_260; lean_object* x_261; 
x_251 = l_Lean_MessageLog_hasErrors(x_223);
x_252 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_252, 0, x_251);
x_253 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
x_254 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_254, 0, x_253);
lean_ctor_set(x_254, 1, x_252);
x_255 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_255, 0, x_254);
lean_ctor_set(x_255, 1, x_250);
x_256 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_256, 0, x_6);
lean_ctor_set(x_256, 1, x_255);
x_257 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_257, 0, x_7);
lean_ctor_set(x_257, 1, x_256);
x_258 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_259 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_259, 0, x_258);
lean_ctor_set(x_259, 1, x_257);
x_260 = l_Lean_Json_mkObj(x_259);
x_261 = l___private_StateReuseMeasure_0__emit(x_260, x_232);
if (lean_obj_tag(x_261) == 0)
{
lean_object* x_262; lean_object* x_263; lean_object* x_264; lean_object* x_265; 
x_262 = lean_ctor_get(x_261, 1);
lean_inc(x_262);
if (lean_is_exclusive(x_261)) {
 lean_ctor_release(x_261, 0);
 lean_ctor_release(x_261, 1);
 x_263 = x_261;
} else {
 lean_dec_ref(x_261);
 x_263 = lean_box(0);
}
x_264 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_264, 0, x_8);
if (lean_is_scalar(x_263)) {
 x_265 = lean_alloc_ctor(0, 2, 0);
} else {
 x_265 = x_263;
}
lean_ctor_set(x_265, 0, x_264);
lean_ctor_set(x_265, 1, x_262);
return x_265;
}
else
{
lean_object* x_266; lean_object* x_267; lean_object* x_268; lean_object* x_269; 
lean_dec(x_8);
x_266 = lean_ctor_get(x_261, 0);
lean_inc(x_266);
x_267 = lean_ctor_get(x_261, 1);
lean_inc(x_267);
if (lean_is_exclusive(x_261)) {
 lean_ctor_release(x_261, 0);
 lean_ctor_release(x_261, 1);
 x_268 = x_261;
} else {
 lean_dec_ref(x_261);
 x_268 = lean_box(0);
}
if (lean_is_scalar(x_268)) {
 x_269 = lean_alloc_ctor(1, 2, 0);
} else {
 x_269 = x_268;
}
lean_ctor_set(x_269, 0, x_266);
lean_ctor_set(x_269, 1, x_267);
return x_269;
}
}
else
{
lean_object* x_270; lean_object* x_271; lean_object* x_272; lean_object* x_273; lean_object* x_274; lean_object* x_275; lean_object* x_276; lean_object* x_277; 
lean_dec(x_223);
x_270 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13;
x_271 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_271, 0, x_270);
lean_ctor_set(x_271, 1, x_250);
x_272 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_272, 0, x_6);
lean_ctor_set(x_272, 1, x_271);
x_273 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_273, 0, x_7);
lean_ctor_set(x_273, 1, x_272);
x_274 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_275 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_275, 0, x_274);
lean_ctor_set(x_275, 1, x_273);
x_276 = l_Lean_Json_mkObj(x_275);
x_277 = l___private_StateReuseMeasure_0__emit(x_276, x_232);
if (lean_obj_tag(x_277) == 0)
{
lean_object* x_278; lean_object* x_279; lean_object* x_280; lean_object* x_281; 
x_278 = lean_ctor_get(x_277, 1);
lean_inc(x_278);
if (lean_is_exclusive(x_277)) {
 lean_ctor_release(x_277, 0);
 lean_ctor_release(x_277, 1);
 x_279 = x_277;
} else {
 lean_dec_ref(x_277);
 x_279 = lean_box(0);
}
x_280 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_280, 0, x_8);
if (lean_is_scalar(x_279)) {
 x_281 = lean_alloc_ctor(0, 2, 0);
} else {
 x_281 = x_279;
}
lean_ctor_set(x_281, 0, x_280);
lean_ctor_set(x_281, 1, x_278);
return x_281;
}
else
{
lean_object* x_282; lean_object* x_283; lean_object* x_284; lean_object* x_285; 
lean_dec(x_8);
x_282 = lean_ctor_get(x_277, 0);
lean_inc(x_282);
x_283 = lean_ctor_get(x_277, 1);
lean_inc(x_283);
if (lean_is_exclusive(x_277)) {
 lean_ctor_release(x_277, 0);
 lean_ctor_release(x_277, 1);
 x_284 = x_277;
} else {
 lean_dec_ref(x_277);
 x_284 = lean_box(0);
}
if (lean_is_scalar(x_284)) {
 x_285 = lean_alloc_ctor(1, 2, 0);
} else {
 x_285 = x_284;
}
lean_ctor_set(x_285, 0, x_282);
lean_ctor_set(x_285, 1, x_283);
return x_285;
}
}
}
else
{
lean_object* x_286; lean_object* x_287; lean_object* x_288; lean_object* x_289; 
lean_dec(x_223);
lean_dec(x_222);
lean_dec(x_221);
lean_dec(x_220);
lean_free_object(x_20);
lean_dec(x_14);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_286 = lean_ctor_get(x_227, 0);
lean_inc(x_286);
x_287 = lean_ctor_get(x_227, 1);
lean_inc(x_287);
if (lean_is_exclusive(x_227)) {
 lean_ctor_release(x_227, 0);
 lean_ctor_release(x_227, 1);
 x_288 = x_227;
} else {
 lean_dec_ref(x_227);
 x_288 = lean_box(0);
}
if (lean_is_scalar(x_288)) {
 x_289 = lean_alloc_ctor(1, 2, 0);
} else {
 x_289 = x_288;
}
lean_ctor_set(x_289, 0, x_286);
lean_ctor_set(x_289, 1, x_287);
return x_289;
}
}
}
else
{
lean_object* x_290; lean_object* x_291; lean_object* x_292; lean_object* x_293; lean_object* x_294; lean_object* x_295; lean_object* x_296; lean_object* x_297; lean_object* x_298; lean_object* x_299; 
x_290 = lean_ctor_get(x_20, 0);
lean_inc(x_290);
lean_dec(x_20);
x_291 = lean_ctor_get(x_21, 0);
lean_inc(x_291);
if (lean_is_exclusive(x_21)) {
 lean_ctor_release(x_21, 0);
 lean_ctor_release(x_21, 1);
 x_292 = x_21;
} else {
 lean_dec_ref(x_21);
 x_292 = lean_box(0);
}
x_293 = lean_ctor_get(x_22, 1);
lean_inc(x_293);
if (lean_is_exclusive(x_22)) {
 lean_ctor_release(x_22, 0);
 lean_ctor_release(x_22, 1);
 x_294 = x_22;
} else {
 lean_dec_ref(x_22);
 x_294 = lean_box(0);
}
x_295 = lean_ctor_get(x_290, 1);
lean_inc(x_295);
lean_dec(x_290);
lean_inc(x_295);
lean_inc(x_291);
x_296 = l_Lean_MessageLog_append(x_291, x_295);
x_297 = l_Lean_MessageLog_toList(x_296);
x_298 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
lean_inc(x_2);
x_299 = l_List_forIn_loop___at_main___spec__5(x_2, x_297, x_298, x_23);
if (lean_obj_tag(x_299) == 0)
{
lean_object* x_300; lean_object* x_301; lean_object* x_302; lean_object* x_303; lean_object* x_304; lean_object* x_305; uint8_t x_306; lean_object* x_307; lean_object* x_308; lean_object* x_309; lean_object* x_310; lean_object* x_311; lean_object* x_312; lean_object* x_313; lean_object* x_314; lean_object* x_315; lean_object* x_316; lean_object* x_317; lean_object* x_318; lean_object* x_319; lean_object* x_320; lean_object* x_321; lean_object* x_322; lean_object* x_323; 
x_300 = lean_ctor_get(x_299, 0);
lean_inc(x_300);
x_301 = lean_ctor_get(x_299, 1);
lean_inc(x_301);
lean_dec(x_299);
x_302 = lean_io_mono_nanos_now(x_301);
x_303 = lean_ctor_get(x_302, 0);
lean_inc(x_303);
x_304 = lean_ctor_get(x_302, 1);
lean_inc(x_304);
if (lean_is_exclusive(x_302)) {
 lean_ctor_release(x_302, 0);
 lean_ctor_release(x_302, 1);
 x_305 = x_302;
} else {
 lean_dec_ref(x_302);
 x_305 = lean_box(0);
}
x_306 = l_Lean_MessageLog_hasErrors(x_291);
x_307 = l_Lean_JsonNumber_fromNat(x_293);
x_308 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_308, 0, x_307);
x_309 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5;
if (lean_is_scalar(x_305)) {
 x_310 = lean_alloc_ctor(0, 2, 0);
} else {
 x_310 = x_305;
}
lean_ctor_set(x_310, 0, x_309);
lean_ctor_set(x_310, 1, x_308);
x_311 = lean_nat_sub(x_303, x_14);
lean_dec(x_14);
lean_dec(x_303);
x_312 = l_Lean_JsonNumber_fromNat(x_311);
x_313 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_313, 0, x_312);
x_314 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6;
if (lean_is_scalar(x_294)) {
 x_315 = lean_alloc_ctor(0, 2, 0);
} else {
 x_315 = x_294;
}
lean_ctor_set(x_315, 0, x_314);
lean_ctor_set(x_315, 1, x_313);
x_316 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_316, 0, x_300);
x_317 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7;
if (lean_is_scalar(x_292)) {
 x_318 = lean_alloc_ctor(0, 2, 0);
} else {
 x_318 = x_292;
}
lean_ctor_set(x_318, 0, x_317);
lean_ctor_set(x_318, 1, x_316);
x_319 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10;
x_320 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_320, 0, x_319);
lean_ctor_set(x_320, 1, x_2);
x_321 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_321, 0, x_318);
lean_ctor_set(x_321, 1, x_320);
x_322 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_322, 0, x_315);
lean_ctor_set(x_322, 1, x_321);
x_323 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_323, 0, x_310);
lean_ctor_set(x_323, 1, x_322);
if (x_306 == 0)
{
uint8_t x_324; lean_object* x_325; lean_object* x_326; lean_object* x_327; lean_object* x_328; lean_object* x_329; lean_object* x_330; lean_object* x_331; lean_object* x_332; lean_object* x_333; lean_object* x_334; 
x_324 = l_Lean_MessageLog_hasErrors(x_295);
x_325 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_325, 0, x_324);
x_326 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
x_327 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_327, 0, x_326);
lean_ctor_set(x_327, 1, x_325);
x_328 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_328, 0, x_327);
lean_ctor_set(x_328, 1, x_323);
x_329 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_329, 0, x_6);
lean_ctor_set(x_329, 1, x_328);
x_330 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_330, 0, x_7);
lean_ctor_set(x_330, 1, x_329);
x_331 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_332 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_332, 0, x_331);
lean_ctor_set(x_332, 1, x_330);
x_333 = l_Lean_Json_mkObj(x_332);
x_334 = l___private_StateReuseMeasure_0__emit(x_333, x_304);
if (lean_obj_tag(x_334) == 0)
{
lean_object* x_335; lean_object* x_336; lean_object* x_337; lean_object* x_338; 
x_335 = lean_ctor_get(x_334, 1);
lean_inc(x_335);
if (lean_is_exclusive(x_334)) {
 lean_ctor_release(x_334, 0);
 lean_ctor_release(x_334, 1);
 x_336 = x_334;
} else {
 lean_dec_ref(x_334);
 x_336 = lean_box(0);
}
x_337 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_337, 0, x_8);
if (lean_is_scalar(x_336)) {
 x_338 = lean_alloc_ctor(0, 2, 0);
} else {
 x_338 = x_336;
}
lean_ctor_set(x_338, 0, x_337);
lean_ctor_set(x_338, 1, x_335);
return x_338;
}
else
{
lean_object* x_339; lean_object* x_340; lean_object* x_341; lean_object* x_342; 
lean_dec(x_8);
x_339 = lean_ctor_get(x_334, 0);
lean_inc(x_339);
x_340 = lean_ctor_get(x_334, 1);
lean_inc(x_340);
if (lean_is_exclusive(x_334)) {
 lean_ctor_release(x_334, 0);
 lean_ctor_release(x_334, 1);
 x_341 = x_334;
} else {
 lean_dec_ref(x_334);
 x_341 = lean_box(0);
}
if (lean_is_scalar(x_341)) {
 x_342 = lean_alloc_ctor(1, 2, 0);
} else {
 x_342 = x_341;
}
lean_ctor_set(x_342, 0, x_339);
lean_ctor_set(x_342, 1, x_340);
return x_342;
}
}
else
{
lean_object* x_343; lean_object* x_344; lean_object* x_345; lean_object* x_346; lean_object* x_347; lean_object* x_348; lean_object* x_349; lean_object* x_350; 
lean_dec(x_295);
x_343 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13;
x_344 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_344, 0, x_343);
lean_ctor_set(x_344, 1, x_323);
x_345 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_345, 0, x_6);
lean_ctor_set(x_345, 1, x_344);
x_346 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_346, 0, x_7);
lean_ctor_set(x_346, 1, x_345);
x_347 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_348 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_348, 0, x_347);
lean_ctor_set(x_348, 1, x_346);
x_349 = l_Lean_Json_mkObj(x_348);
x_350 = l___private_StateReuseMeasure_0__emit(x_349, x_304);
if (lean_obj_tag(x_350) == 0)
{
lean_object* x_351; lean_object* x_352; lean_object* x_353; lean_object* x_354; 
x_351 = lean_ctor_get(x_350, 1);
lean_inc(x_351);
if (lean_is_exclusive(x_350)) {
 lean_ctor_release(x_350, 0);
 lean_ctor_release(x_350, 1);
 x_352 = x_350;
} else {
 lean_dec_ref(x_350);
 x_352 = lean_box(0);
}
x_353 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_353, 0, x_8);
if (lean_is_scalar(x_352)) {
 x_354 = lean_alloc_ctor(0, 2, 0);
} else {
 x_354 = x_352;
}
lean_ctor_set(x_354, 0, x_353);
lean_ctor_set(x_354, 1, x_351);
return x_354;
}
else
{
lean_object* x_355; lean_object* x_356; lean_object* x_357; lean_object* x_358; 
lean_dec(x_8);
x_355 = lean_ctor_get(x_350, 0);
lean_inc(x_355);
x_356 = lean_ctor_get(x_350, 1);
lean_inc(x_356);
if (lean_is_exclusive(x_350)) {
 lean_ctor_release(x_350, 0);
 lean_ctor_release(x_350, 1);
 x_357 = x_350;
} else {
 lean_dec_ref(x_350);
 x_357 = lean_box(0);
}
if (lean_is_scalar(x_357)) {
 x_358 = lean_alloc_ctor(1, 2, 0);
} else {
 x_358 = x_357;
}
lean_ctor_set(x_358, 0, x_355);
lean_ctor_set(x_358, 1, x_356);
return x_358;
}
}
}
else
{
lean_object* x_359; lean_object* x_360; lean_object* x_361; lean_object* x_362; 
lean_dec(x_295);
lean_dec(x_294);
lean_dec(x_293);
lean_dec(x_292);
lean_dec(x_291);
lean_dec(x_14);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_359 = lean_ctor_get(x_299, 0);
lean_inc(x_359);
x_360 = lean_ctor_get(x_299, 1);
lean_inc(x_360);
if (lean_is_exclusive(x_299)) {
 lean_ctor_release(x_299, 0);
 lean_ctor_release(x_299, 1);
 x_361 = x_299;
} else {
 lean_dec_ref(x_299);
 x_361 = lean_box(0);
}
if (lean_is_scalar(x_361)) {
 x_362 = lean_alloc_ctor(1, 2, 0);
} else {
 x_362 = x_361;
}
lean_ctor_set(x_362, 0, x_359);
lean_ctor_set(x_362, 1, x_360);
return x_362;
}
}
}
else
{
uint8_t x_363; 
lean_dec(x_14);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_363 = !lean_is_exclusive(x_19);
if (x_363 == 0)
{
return x_19;
}
else
{
lean_object* x_364; lean_object* x_365; lean_object* x_366; 
x_364 = lean_ctor_get(x_19, 0);
x_365 = lean_ctor_get(x_19, 1);
lean_inc(x_365);
lean_inc(x_364);
lean_dec(x_19);
x_366 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_366, 0, x_364);
lean_ctor_set(x_366, 1, x_365);
return x_366;
}
}
}
else
{
lean_object* x_367; lean_object* x_368; lean_object* x_369; lean_object* x_370; lean_object* x_371; lean_object* x_372; lean_object* x_373; 
x_367 = lean_ctor_get(x_12, 0);
x_368 = lean_ctor_get(x_12, 1);
lean_inc(x_368);
lean_inc(x_367);
lean_dec(x_12);
x_369 = lean_unsigned_to_nat(0u);
x_370 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_370, 0, x_3);
lean_ctor_set(x_370, 1, x_369);
x_371 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_371, 0, x_1);
lean_ctor_set(x_371, 1, x_370);
x_372 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_372, 0, x_11);
lean_ctor_set(x_372, 1, x_371);
x_373 = l_Lean_Loop_forIn_loop___at_main___spec__4(x_4, x_5, x_372, x_368);
if (lean_obj_tag(x_373) == 0)
{
lean_object* x_374; lean_object* x_375; lean_object* x_376; lean_object* x_377; lean_object* x_378; lean_object* x_379; lean_object* x_380; lean_object* x_381; lean_object* x_382; lean_object* x_383; lean_object* x_384; lean_object* x_385; lean_object* x_386; lean_object* x_387; lean_object* x_388; 
x_374 = lean_ctor_get(x_373, 0);
lean_inc(x_374);
x_375 = lean_ctor_get(x_374, 1);
lean_inc(x_375);
x_376 = lean_ctor_get(x_375, 1);
lean_inc(x_376);
x_377 = lean_ctor_get(x_373, 1);
lean_inc(x_377);
lean_dec(x_373);
x_378 = lean_ctor_get(x_374, 0);
lean_inc(x_378);
if (lean_is_exclusive(x_374)) {
 lean_ctor_release(x_374, 0);
 lean_ctor_release(x_374, 1);
 x_379 = x_374;
} else {
 lean_dec_ref(x_374);
 x_379 = lean_box(0);
}
x_380 = lean_ctor_get(x_375, 0);
lean_inc(x_380);
if (lean_is_exclusive(x_375)) {
 lean_ctor_release(x_375, 0);
 lean_ctor_release(x_375, 1);
 x_381 = x_375;
} else {
 lean_dec_ref(x_375);
 x_381 = lean_box(0);
}
x_382 = lean_ctor_get(x_376, 1);
lean_inc(x_382);
if (lean_is_exclusive(x_376)) {
 lean_ctor_release(x_376, 0);
 lean_ctor_release(x_376, 1);
 x_383 = x_376;
} else {
 lean_dec_ref(x_376);
 x_383 = lean_box(0);
}
x_384 = lean_ctor_get(x_378, 1);
lean_inc(x_384);
lean_dec(x_378);
lean_inc(x_384);
lean_inc(x_380);
x_385 = l_Lean_MessageLog_append(x_380, x_384);
x_386 = l_Lean_MessageLog_toList(x_385);
x_387 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
lean_inc(x_2);
x_388 = l_List_forIn_loop___at_main___spec__5(x_2, x_386, x_387, x_377);
if (lean_obj_tag(x_388) == 0)
{
lean_object* x_389; lean_object* x_390; lean_object* x_391; lean_object* x_392; lean_object* x_393; lean_object* x_394; uint8_t x_395; lean_object* x_396; lean_object* x_397; lean_object* x_398; lean_object* x_399; lean_object* x_400; lean_object* x_401; lean_object* x_402; lean_object* x_403; lean_object* x_404; lean_object* x_405; lean_object* x_406; lean_object* x_407; lean_object* x_408; lean_object* x_409; lean_object* x_410; lean_object* x_411; lean_object* x_412; 
x_389 = lean_ctor_get(x_388, 0);
lean_inc(x_389);
x_390 = lean_ctor_get(x_388, 1);
lean_inc(x_390);
lean_dec(x_388);
x_391 = lean_io_mono_nanos_now(x_390);
x_392 = lean_ctor_get(x_391, 0);
lean_inc(x_392);
x_393 = lean_ctor_get(x_391, 1);
lean_inc(x_393);
if (lean_is_exclusive(x_391)) {
 lean_ctor_release(x_391, 0);
 lean_ctor_release(x_391, 1);
 x_394 = x_391;
} else {
 lean_dec_ref(x_391);
 x_394 = lean_box(0);
}
x_395 = l_Lean_MessageLog_hasErrors(x_380);
x_396 = l_Lean_JsonNumber_fromNat(x_382);
x_397 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_397, 0, x_396);
x_398 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5;
if (lean_is_scalar(x_394)) {
 x_399 = lean_alloc_ctor(0, 2, 0);
} else {
 x_399 = x_394;
}
lean_ctor_set(x_399, 0, x_398);
lean_ctor_set(x_399, 1, x_397);
x_400 = lean_nat_sub(x_392, x_367);
lean_dec(x_367);
lean_dec(x_392);
x_401 = l_Lean_JsonNumber_fromNat(x_400);
x_402 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_402, 0, x_401);
x_403 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6;
if (lean_is_scalar(x_383)) {
 x_404 = lean_alloc_ctor(0, 2, 0);
} else {
 x_404 = x_383;
}
lean_ctor_set(x_404, 0, x_403);
lean_ctor_set(x_404, 1, x_402);
x_405 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_405, 0, x_389);
x_406 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7;
if (lean_is_scalar(x_381)) {
 x_407 = lean_alloc_ctor(0, 2, 0);
} else {
 x_407 = x_381;
}
lean_ctor_set(x_407, 0, x_406);
lean_ctor_set(x_407, 1, x_405);
x_408 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10;
if (lean_is_scalar(x_379)) {
 x_409 = lean_alloc_ctor(1, 2, 0);
} else {
 x_409 = x_379;
 lean_ctor_set_tag(x_409, 1);
}
lean_ctor_set(x_409, 0, x_408);
lean_ctor_set(x_409, 1, x_2);
x_410 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_410, 0, x_407);
lean_ctor_set(x_410, 1, x_409);
x_411 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_411, 0, x_404);
lean_ctor_set(x_411, 1, x_410);
x_412 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_412, 0, x_399);
lean_ctor_set(x_412, 1, x_411);
if (x_395 == 0)
{
uint8_t x_413; lean_object* x_414; lean_object* x_415; lean_object* x_416; lean_object* x_417; lean_object* x_418; lean_object* x_419; lean_object* x_420; lean_object* x_421; lean_object* x_422; lean_object* x_423; 
x_413 = l_Lean_MessageLog_hasErrors(x_384);
x_414 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_414, 0, x_413);
x_415 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11;
x_416 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_416, 0, x_415);
lean_ctor_set(x_416, 1, x_414);
x_417 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_417, 0, x_416);
lean_ctor_set(x_417, 1, x_412);
x_418 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_418, 0, x_6);
lean_ctor_set(x_418, 1, x_417);
x_419 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_419, 0, x_7);
lean_ctor_set(x_419, 1, x_418);
x_420 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_421 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_421, 0, x_420);
lean_ctor_set(x_421, 1, x_419);
x_422 = l_Lean_Json_mkObj(x_421);
x_423 = l___private_StateReuseMeasure_0__emit(x_422, x_393);
if (lean_obj_tag(x_423) == 0)
{
lean_object* x_424; lean_object* x_425; lean_object* x_426; lean_object* x_427; 
x_424 = lean_ctor_get(x_423, 1);
lean_inc(x_424);
if (lean_is_exclusive(x_423)) {
 lean_ctor_release(x_423, 0);
 lean_ctor_release(x_423, 1);
 x_425 = x_423;
} else {
 lean_dec_ref(x_423);
 x_425 = lean_box(0);
}
x_426 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_426, 0, x_8);
if (lean_is_scalar(x_425)) {
 x_427 = lean_alloc_ctor(0, 2, 0);
} else {
 x_427 = x_425;
}
lean_ctor_set(x_427, 0, x_426);
lean_ctor_set(x_427, 1, x_424);
return x_427;
}
else
{
lean_object* x_428; lean_object* x_429; lean_object* x_430; lean_object* x_431; 
lean_dec(x_8);
x_428 = lean_ctor_get(x_423, 0);
lean_inc(x_428);
x_429 = lean_ctor_get(x_423, 1);
lean_inc(x_429);
if (lean_is_exclusive(x_423)) {
 lean_ctor_release(x_423, 0);
 lean_ctor_release(x_423, 1);
 x_430 = x_423;
} else {
 lean_dec_ref(x_423);
 x_430 = lean_box(0);
}
if (lean_is_scalar(x_430)) {
 x_431 = lean_alloc_ctor(1, 2, 0);
} else {
 x_431 = x_430;
}
lean_ctor_set(x_431, 0, x_428);
lean_ctor_set(x_431, 1, x_429);
return x_431;
}
}
else
{
lean_object* x_432; lean_object* x_433; lean_object* x_434; lean_object* x_435; lean_object* x_436; lean_object* x_437; lean_object* x_438; lean_object* x_439; 
lean_dec(x_384);
x_432 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13;
x_433 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_433, 0, x_432);
lean_ctor_set(x_433, 1, x_412);
x_434 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_434, 0, x_6);
lean_ctor_set(x_434, 1, x_433);
x_435 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_435, 0, x_7);
lean_ctor_set(x_435, 1, x_434);
x_436 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4;
x_437 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_437, 0, x_436);
lean_ctor_set(x_437, 1, x_435);
x_438 = l_Lean_Json_mkObj(x_437);
x_439 = l___private_StateReuseMeasure_0__emit(x_438, x_393);
if (lean_obj_tag(x_439) == 0)
{
lean_object* x_440; lean_object* x_441; lean_object* x_442; lean_object* x_443; 
x_440 = lean_ctor_get(x_439, 1);
lean_inc(x_440);
if (lean_is_exclusive(x_439)) {
 lean_ctor_release(x_439, 0);
 lean_ctor_release(x_439, 1);
 x_441 = x_439;
} else {
 lean_dec_ref(x_439);
 x_441 = lean_box(0);
}
x_442 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_442, 0, x_8);
if (lean_is_scalar(x_441)) {
 x_443 = lean_alloc_ctor(0, 2, 0);
} else {
 x_443 = x_441;
}
lean_ctor_set(x_443, 0, x_442);
lean_ctor_set(x_443, 1, x_440);
return x_443;
}
else
{
lean_object* x_444; lean_object* x_445; lean_object* x_446; lean_object* x_447; 
lean_dec(x_8);
x_444 = lean_ctor_get(x_439, 0);
lean_inc(x_444);
x_445 = lean_ctor_get(x_439, 1);
lean_inc(x_445);
if (lean_is_exclusive(x_439)) {
 lean_ctor_release(x_439, 0);
 lean_ctor_release(x_439, 1);
 x_446 = x_439;
} else {
 lean_dec_ref(x_439);
 x_446 = lean_box(0);
}
if (lean_is_scalar(x_446)) {
 x_447 = lean_alloc_ctor(1, 2, 0);
} else {
 x_447 = x_446;
}
lean_ctor_set(x_447, 0, x_444);
lean_ctor_set(x_447, 1, x_445);
return x_447;
}
}
}
else
{
lean_object* x_448; lean_object* x_449; lean_object* x_450; lean_object* x_451; 
lean_dec(x_384);
lean_dec(x_383);
lean_dec(x_382);
lean_dec(x_381);
lean_dec(x_380);
lean_dec(x_379);
lean_dec(x_367);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_448 = lean_ctor_get(x_388, 0);
lean_inc(x_448);
x_449 = lean_ctor_get(x_388, 1);
lean_inc(x_449);
if (lean_is_exclusive(x_388)) {
 lean_ctor_release(x_388, 0);
 lean_ctor_release(x_388, 1);
 x_450 = x_388;
} else {
 lean_dec_ref(x_388);
 x_450 = lean_box(0);
}
if (lean_is_scalar(x_450)) {
 x_451 = lean_alloc_ctor(1, 2, 0);
} else {
 x_451 = x_450;
}
lean_ctor_set(x_451, 0, x_448);
lean_ctor_set(x_451, 1, x_449);
return x_451;
}
}
else
{
lean_object* x_452; lean_object* x_453; lean_object* x_454; lean_object* x_455; 
lean_dec(x_367);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_2);
x_452 = lean_ctor_get(x_373, 0);
lean_inc(x_452);
x_453 = lean_ctor_get(x_373, 1);
lean_inc(x_453);
if (lean_is_exclusive(x_373)) {
 lean_ctor_release(x_373, 0);
 lean_ctor_release(x_373, 1);
 x_454 = x_373;
} else {
 lean_dec_ref(x_373);
 x_454 = lean_box(0);
}
if (lean_is_scalar(x_454)) {
 x_455 = lean_alloc_ctor(1, 2, 0);
} else {
 x_455 = x_454;
}
lean_ctor_set(x_455, 0, x_452);
lean_ctor_set(x_455, 1, x_453);
return x_455;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; 
lean_inc(x_2);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_1);
lean_ctor_set(x_7, 1, x_2);
x_8 = lean_array_push(x_4, x_7);
x_9 = lean_apply_3(x_3, x_8, x_2, x_6);
return x_9;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("id", 2);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("code", 4);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("mode", 4);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("candidate_begin", 15);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__4;
x_2 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__3;
x_2 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__5;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("<input>", 7);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("original", 8);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("<native-imports>", 16);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("native setup import error", 25);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__10;
x_2 = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("\nimport StateReuseProfile\n", 26);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("", 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_4 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__1;
lean_inc(x_1);
x_5 = l_Lean_Json_getObjValAs_x3f___at___private_Lean_Message_0__Lean_fromJsonBaseMessage____x40_Lean_Message___hyg_2442____spec__1(x_1, x_4);
x_6 = l_IO_ofExcept___at_main___spec__2(x_5, x_3);
if (lean_obj_tag(x_6) == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
x_8 = lean_ctor_get(x_6, 1);
lean_inc(x_8);
lean_dec(x_6);
x_9 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__2;
lean_inc(x_1);
x_10 = l_Lean_Json_getObjValAs_x3f___at___private_Lean_Message_0__Lean_fromJsonBaseMessage____x40_Lean_Message___hyg_2442____spec__1(x_1, x_9);
x_11 = l_IO_ofExcept___at_main___spec__2(x_10, x_8);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_12 = lean_ctor_get(x_11, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_11, 1);
lean_inc(x_13);
lean_dec(x_11);
x_14 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__3;
x_15 = l_Lean_Json_getObjValAs_x3f___at___private_Lean_Message_0__Lean_fromJsonBaseMessage____x40_Lean_Message___hyg_2442____spec__1(x_1, x_14);
x_16 = l_IO_ofExcept___at_main___spec__2(x_15, x_13);
if (lean_obj_tag(x_16) == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_19, 0, x_7);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_4);
lean_ctor_set(x_20, 1, x_19);
lean_inc(x_17);
x_21 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_21, 0, x_17);
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_14);
lean_ctor_set(x_22, 1, x_21);
x_23 = lean_box(0);
lean_inc(x_22);
x_24 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_24, 0, x_22);
lean_ctor_set(x_24, 1, x_23);
lean_inc(x_20);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_20);
lean_ctor_set(x_25, 1, x_24);
x_26 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__6;
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_26);
lean_ctor_set(x_27, 1, x_25);
x_28 = l_Lean_Json_mkObj(x_27);
x_29 = l___private_StateReuseMeasure_0__emit(x_28, x_18);
if (lean_obj_tag(x_29) == 0)
{
lean_object* x_30; lean_object* x_31; uint8_t x_32; lean_object* x_33; lean_object* x_34; 
x_30 = lean_ctor_get(x_29, 1);
lean_inc(x_30);
lean_dec(x_29);
x_31 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__7;
x_32 = 0;
lean_inc(x_12);
x_33 = l_Lean_Parser_mkInputContext(x_12, x_31, x_32);
lean_inc(x_33);
x_34 = l_Lean_Parser_parseHeader(x_33, x_30);
if (lean_obj_tag(x_34) == 0)
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; uint8_t x_44; lean_object* x_45; lean_object* x_46; size_t x_47; size_t x_48; lean_object* x_49; 
x_35 = lean_ctor_get(x_34, 0);
lean_inc(x_35);
x_36 = lean_ctor_get(x_35, 1);
lean_inc(x_36);
lean_dec(x_35);
x_37 = lean_ctor_get(x_34, 1);
lean_inc(x_37);
lean_dec(x_34);
x_38 = lean_ctor_get(x_36, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_36, 1);
lean_inc(x_39);
lean_dec(x_36);
x_40 = lean_ctor_get(x_38, 0);
lean_inc(x_40);
x_41 = lean_unsigned_to_nat(0u);
x_42 = lean_string_utf8_extract(x_12, x_41, x_40);
lean_dec(x_40);
lean_dec(x_12);
x_43 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__8;
x_44 = lean_string_dec_eq(x_17, x_43);
x_45 = lean_box(0);
x_46 = lean_array_get_size(x_2);
x_47 = lean_usize_of_nat(x_46);
lean_dec(x_46);
x_48 = 0;
if (x_44 == 0)
{
lean_object* x_96; 
x_96 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__12;
x_49 = x_96;
goto block_95;
}
else
{
lean_object* x_97; 
x_97 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__13;
x_49 = x_97;
goto block_95;
}
block_95:
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; 
x_50 = lean_string_append(x_42, x_49);
lean_dec(x_49);
x_51 = l_Array_forInUnsafe_loop___at_main___spec__3(x_50, x_2, x_47, x_48, x_45, x_37);
x_52 = lean_ctor_get(x_51, 0);
lean_inc(x_52);
if (lean_obj_tag(x_52) == 0)
{
lean_object* x_53; lean_object* x_54; lean_object* x_55; uint8_t x_56; lean_object* x_57; lean_object* x_58; 
x_53 = lean_ctor_get(x_51, 1);
lean_inc(x_53);
lean_dec(x_51);
x_54 = lean_alloc_closure((void*)(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___boxed), 10, 7);
lean_closure_set(x_54, 0, x_39);
lean_closure_set(x_54, 1, x_23);
lean_closure_set(x_54, 2, x_38);
lean_closure_set(x_54, 3, x_17);
lean_closure_set(x_54, 4, x_33);
lean_closure_set(x_54, 5, x_22);
lean_closure_set(x_54, 6, x_20);
x_55 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__9;
x_56 = 1;
lean_inc(x_50);
x_57 = l_Lean_Parser_mkInputContext(x_50, x_55, x_56);
lean_inc(x_57);
x_58 = l_Lean_Parser_parseHeader(x_57, x_53);
if (lean_obj_tag(x_58) == 0)
{
lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; uint32_t x_64; lean_object* x_65; 
x_59 = lean_ctor_get(x_58, 0);
lean_inc(x_59);
x_60 = lean_ctor_get(x_59, 1);
lean_inc(x_60);
x_61 = lean_ctor_get(x_58, 1);
lean_inc(x_61);
lean_dec(x_58);
x_62 = lean_ctor_get(x_59, 0);
lean_inc(x_62);
lean_dec(x_59);
x_63 = lean_ctor_get(x_60, 1);
lean_inc(x_63);
lean_dec(x_60);
x_64 = 0;
x_65 = l_Lean_Elab_processHeader(x_62, x_23, x_63, x_57, x_64, x_32, x_61);
lean_dec(x_62);
if (lean_obj_tag(x_65) == 0)
{
uint8_t x_66; 
x_66 = !lean_is_exclusive(x_65);
if (x_66 == 0)
{
lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; uint8_t x_71; 
x_67 = lean_ctor_get(x_65, 0);
x_68 = lean_ctor_get(x_65, 1);
x_69 = lean_ctor_get(x_67, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_67, 1);
lean_inc(x_70);
lean_dec(x_67);
x_71 = l_Lean_MessageLog_hasErrors(x_70);
if (x_71 == 0)
{
lean_object* x_72; lean_object* x_73; 
lean_free_object(x_65);
x_72 = lean_box(0);
x_73 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__2(x_50, x_69, x_54, x_2, x_72, x_68);
return x_73;
}
else
{
lean_object* x_74; 
lean_dec(x_69);
lean_dec(x_54);
lean_dec(x_50);
lean_dec(x_2);
x_74 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__11;
lean_ctor_set_tag(x_65, 1);
lean_ctor_set(x_65, 0, x_74);
return x_65;
}
}
else
{
lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; uint8_t x_79; 
x_75 = lean_ctor_get(x_65, 0);
x_76 = lean_ctor_get(x_65, 1);
lean_inc(x_76);
lean_inc(x_75);
lean_dec(x_65);
x_77 = lean_ctor_get(x_75, 0);
lean_inc(x_77);
x_78 = lean_ctor_get(x_75, 1);
lean_inc(x_78);
lean_dec(x_75);
x_79 = l_Lean_MessageLog_hasErrors(x_78);
if (x_79 == 0)
{
lean_object* x_80; lean_object* x_81; 
x_80 = lean_box(0);
x_81 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__2(x_50, x_77, x_54, x_2, x_80, x_76);
return x_81;
}
else
{
lean_object* x_82; lean_object* x_83; 
lean_dec(x_77);
lean_dec(x_54);
lean_dec(x_50);
lean_dec(x_2);
x_82 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__11;
x_83 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_83, 0, x_82);
lean_ctor_set(x_83, 1, x_76);
return x_83;
}
}
}
else
{
uint8_t x_84; 
lean_dec(x_54);
lean_dec(x_50);
lean_dec(x_2);
x_84 = !lean_is_exclusive(x_65);
if (x_84 == 0)
{
return x_65;
}
else
{
lean_object* x_85; lean_object* x_86; lean_object* x_87; 
x_85 = lean_ctor_get(x_65, 0);
x_86 = lean_ctor_get(x_65, 1);
lean_inc(x_86);
lean_inc(x_85);
lean_dec(x_65);
x_87 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_87, 0, x_85);
lean_ctor_set(x_87, 1, x_86);
return x_87;
}
}
}
else
{
uint8_t x_88; 
lean_dec(x_57);
lean_dec(x_54);
lean_dec(x_50);
lean_dec(x_2);
x_88 = !lean_is_exclusive(x_58);
if (x_88 == 0)
{
return x_58;
}
else
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; 
x_89 = lean_ctor_get(x_58, 0);
x_90 = lean_ctor_get(x_58, 1);
lean_inc(x_90);
lean_inc(x_89);
lean_dec(x_58);
x_91 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_91, 0, x_89);
lean_ctor_set(x_91, 1, x_90);
return x_91;
}
}
}
else
{
lean_object* x_92; lean_object* x_93; lean_object* x_94; 
lean_dec(x_50);
x_92 = lean_ctor_get(x_51, 1);
lean_inc(x_92);
lean_dec(x_51);
x_93 = lean_ctor_get(x_52, 0);
lean_inc(x_93);
lean_dec(x_52);
x_94 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1(x_39, x_23, x_38, x_17, x_33, x_22, x_20, x_2, x_93, x_92);
lean_dec(x_17);
return x_94;
}
}
}
else
{
uint8_t x_98; 
lean_dec(x_33);
lean_dec(x_22);
lean_dec(x_20);
lean_dec(x_17);
lean_dec(x_12);
lean_dec(x_2);
x_98 = !lean_is_exclusive(x_34);
if (x_98 == 0)
{
return x_34;
}
else
{
lean_object* x_99; lean_object* x_100; lean_object* x_101; 
x_99 = lean_ctor_get(x_34, 0);
x_100 = lean_ctor_get(x_34, 1);
lean_inc(x_100);
lean_inc(x_99);
lean_dec(x_34);
x_101 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_101, 0, x_99);
lean_ctor_set(x_101, 1, x_100);
return x_101;
}
}
}
else
{
uint8_t x_102; 
lean_dec(x_22);
lean_dec(x_20);
lean_dec(x_17);
lean_dec(x_12);
lean_dec(x_2);
x_102 = !lean_is_exclusive(x_29);
if (x_102 == 0)
{
return x_29;
}
else
{
lean_object* x_103; lean_object* x_104; lean_object* x_105; 
x_103 = lean_ctor_get(x_29, 0);
x_104 = lean_ctor_get(x_29, 1);
lean_inc(x_104);
lean_inc(x_103);
lean_dec(x_29);
x_105 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_105, 0, x_103);
lean_ctor_set(x_105, 1, x_104);
return x_105;
}
}
}
else
{
uint8_t x_106; 
lean_dec(x_12);
lean_dec(x_7);
lean_dec(x_2);
x_106 = !lean_is_exclusive(x_16);
if (x_106 == 0)
{
return x_16;
}
else
{
lean_object* x_107; lean_object* x_108; lean_object* x_109; 
x_107 = lean_ctor_get(x_16, 0);
x_108 = lean_ctor_get(x_16, 1);
lean_inc(x_108);
lean_inc(x_107);
lean_dec(x_16);
x_109 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_109, 0, x_107);
lean_ctor_set(x_109, 1, x_108);
return x_109;
}
}
}
else
{
uint8_t x_110; 
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_110 = !lean_is_exclusive(x_11);
if (x_110 == 0)
{
return x_11;
}
else
{
lean_object* x_111; lean_object* x_112; lean_object* x_113; 
x_111 = lean_ctor_get(x_11, 0);
x_112 = lean_ctor_get(x_11, 1);
lean_inc(x_112);
lean_inc(x_111);
lean_dec(x_11);
x_113 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_113, 0, x_111);
lean_ctor_set(x_113, 1, x_112);
return x_113;
}
}
}
else
{
uint8_t x_114; 
lean_dec(x_2);
lean_dec(x_1);
x_114 = !lean_is_exclusive(x_6);
if (x_114 == 0)
{
return x_6;
}
else
{
lean_object* x_115; lean_object* x_116; lean_object* x_117; 
x_115 = lean_ctor_get(x_6, 0);
x_116 = lean_ctor_get(x_6, 1);
lean_inc(x_116);
lean_inc(x_115);
lean_dec(x_6);
x_117 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_117, 0, x_115);
lean_ctor_set(x_117, 1, x_116);
return x_117;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__4(lean_object* x_1, size_t x_2, lean_object* x_3, size_t x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
if (lean_obj_tag(x_5) == 0)
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
lean_dec(x_3);
x_7 = lean_ctor_get(x_5, 0);
lean_inc(x_7);
lean_dec(x_5);
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
lean_dec(x_1);
x_9 = lean_ctor_get(x_8, 1);
lean_inc(x_9);
lean_dec(x_8);
x_10 = lean_apply_3(x_9, lean_box(0), x_7, x_6);
return x_10;
}
else
{
lean_object* x_11; size_t x_12; size_t x_13; lean_object* x_14; 
x_11 = lean_ctor_get(x_5, 0);
lean_inc(x_11);
lean_dec(x_5);
x_12 = 1;
x_13 = lean_usize_add(x_2, x_12);
x_14 = l_Array_forInUnsafe_loop___at_main___spec__6(x_1, x_3, x_4, x_13, x_11, x_6);
return x_14;
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; 
x_7 = lean_usize_dec_lt(x_4, x_3);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; 
lean_dec(x_2);
x_8 = lean_ctor_get(x_1, 0);
lean_inc(x_8);
lean_dec(x_1);
x_9 = lean_ctor_get(x_8, 1);
lean_inc(x_9);
lean_dec(x_8);
x_10 = lean_apply_3(x_9, lean_box(0), x_5, x_6);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_11 = lean_array_uget(x_2, x_4);
x_12 = lean_ctor_get(x_1, 1);
lean_inc(x_12);
x_13 = lean_alloc_closure((void*)(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3), 3, 2);
lean_closure_set(x_13, 0, x_11);
lean_closure_set(x_13, 1, x_5);
x_14 = lean_box_usize(x_4);
x_15 = lean_box_usize(x_3);
x_16 = lean_alloc_closure((void*)(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__4___boxed), 6, 4);
lean_closure_set(x_16, 0, x_1);
lean_closure_set(x_16, 1, x_14);
lean_closure_set(x_16, 2, x_2);
lean_closure_set(x_16, 3, x_15);
x_17 = lean_apply_5(x_12, lean_box(0), lean_box(0), x_13, x_16, x_6);
return x_17;
}
}
}
static lean_object* _init_l_main___lambda__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("expected JSON array, got '", 26);
return x_1;
}
}
static lean_object* _init_l_main___lambda__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("'", 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_main___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_IO_FS_readFile(x_1, x_4);
if (lean_obj_tag(x_5) == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_32; 
x_6 = lean_ctor_get(x_5, 0);
lean_inc(x_6);
x_7 = lean_ctor_get(x_5, 1);
lean_inc(x_7);
lean_dec(x_5);
x_32 = l_Lean_Json_parse(x_6);
if (lean_obj_tag(x_32) == 0)
{
uint8_t x_33; 
x_33 = !lean_is_exclusive(x_32);
if (x_33 == 0)
{
x_8 = x_32;
goto block_31;
}
else
{
lean_object* x_34; lean_object* x_35; 
x_34 = lean_ctor_get(x_32, 0);
lean_inc(x_34);
lean_dec(x_32);
x_35 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_35, 0, x_34);
x_8 = x_35;
goto block_31;
}
}
else
{
uint8_t x_36; 
x_36 = !lean_is_exclusive(x_32);
if (x_36 == 0)
{
lean_object* x_37; 
x_37 = lean_ctor_get(x_32, 0);
if (lean_obj_tag(x_37) == 4)
{
lean_object* x_38; lean_object* x_39; size_t x_40; size_t x_41; lean_object* x_42; 
lean_free_object(x_32);
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
lean_dec(x_37);
x_39 = lean_array_get_size(x_38);
x_40 = lean_usize_of_nat(x_39);
lean_dec(x_39);
x_41 = 0;
x_42 = l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__3(x_40, x_41, x_38);
x_8 = x_42;
goto block_31;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_43 = lean_unsigned_to_nat(80u);
x_44 = l_Lean_Json_pretty(x_37, x_43);
x_45 = l_main___lambda__1___closed__1;
x_46 = lean_string_append(x_45, x_44);
lean_dec(x_44);
x_47 = l_main___lambda__1___closed__2;
x_48 = lean_string_append(x_46, x_47);
lean_ctor_set_tag(x_32, 0);
lean_ctor_set(x_32, 0, x_48);
x_8 = x_32;
goto block_31;
}
}
else
{
lean_object* x_49; 
x_49 = lean_ctor_get(x_32, 0);
lean_inc(x_49);
lean_dec(x_32);
if (lean_obj_tag(x_49) == 4)
{
lean_object* x_50; lean_object* x_51; size_t x_52; size_t x_53; lean_object* x_54; 
x_50 = lean_ctor_get(x_49, 0);
lean_inc(x_50);
lean_dec(x_49);
x_51 = lean_array_get_size(x_50);
x_52 = lean_usize_of_nat(x_51);
lean_dec(x_51);
x_53 = 0;
x_54 = l_Array_mapMUnsafe_map___at_Lean_Server_instRpcEncodableArray___spec__3(x_52, x_53, x_50);
x_8 = x_54;
goto block_31;
}
else
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
x_55 = lean_unsigned_to_nat(80u);
x_56 = l_Lean_Json_pretty(x_49, x_55);
x_57 = l_main___lambda__1___closed__1;
x_58 = lean_string_append(x_57, x_56);
lean_dec(x_56);
x_59 = l_main___lambda__1___closed__2;
x_60 = lean_string_append(x_58, x_59);
x_61 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_61, 0, x_60);
x_8 = x_61;
goto block_31;
}
}
}
block_31:
{
lean_object* x_9; 
x_9 = l_IO_ofExcept___at_main___spec__1(x_8, x_7);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; size_t x_13; size_t x_14; lean_object* x_15; lean_object* x_16; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_array_get_size(x_10);
x_13 = lean_usize_of_nat(x_12);
lean_dec(x_12);
x_14 = 0;
x_15 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1;
x_16 = l_Array_forInUnsafe_loop___at_main___spec__6(x_2, x_10, x_13, x_14, x_15, x_11);
if (lean_obj_tag(x_16) == 0)
{
uint8_t x_17; 
x_17 = !lean_is_exclusive(x_16);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; 
x_18 = lean_ctor_get(x_16, 0);
lean_dec(x_18);
x_19 = lean_box(0);
lean_ctor_set(x_16, 0, x_19);
return x_16;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_20 = lean_ctor_get(x_16, 1);
lean_inc(x_20);
lean_dec(x_16);
x_21 = lean_box(0);
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_22, 1, x_20);
return x_22;
}
}
else
{
uint8_t x_23; 
x_23 = !lean_is_exclusive(x_16);
if (x_23 == 0)
{
return x_16;
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_24 = lean_ctor_get(x_16, 0);
x_25 = lean_ctor_get(x_16, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_16);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
return x_26;
}
}
}
else
{
uint8_t x_27; 
lean_dec(x_2);
x_27 = !lean_is_exclusive(x_9);
if (x_27 == 0)
{
return x_9;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_28 = lean_ctor_get(x_9, 0);
x_29 = lean_ctor_get(x_9, 1);
lean_inc(x_29);
lean_inc(x_28);
lean_dec(x_9);
x_30 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_30, 0, x_28);
lean_ctor_set(x_30, 1, x_29);
return x_30;
}
}
}
}
else
{
uint8_t x_62; 
lean_dec(x_2);
x_62 = !lean_is_exclusive(x_5);
if (x_62 == 0)
{
return x_5;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; 
x_63 = lean_ctor_get(x_5, 0);
x_64 = lean_ctor_get(x_5, 1);
lean_inc(x_64);
lean_inc(x_63);
lean_dec(x_5);
x_65 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_65, 0, x_63);
lean_ctor_set(x_65, 1, x_64);
return x_65;
}
}
}
}
static lean_object* _init_l_main___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("usage: StateReuseMeasure INPUT", 30);
return x_1;
}
}
static lean_object* _init_l_main___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_main___closed__1;
x_2 = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_main___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = l_EStateM_instMonad(lean_box(0), lean_box(0));
return x_1;
}
}
static lean_object* _init_l_main___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("lean", 4);
return x_1;
}
}
static lean_object* _init_l_main___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_from_bytes("LEAN_SERVER_NATIVE_DYNLIB", 25);
return x_1;
}
}
LEAN_EXPORT lean_object* _lean_main(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; lean_object* x_4; 
x_3 = l_main___closed__2;
x_4 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
else
{
lean_object* x_5; 
x_5 = lean_ctor_get(x_1, 1);
lean_inc(x_5);
if (lean_obj_tag(x_5) == 0)
{
lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_6 = lean_ctor_get(x_1, 0);
lean_inc(x_6);
lean_dec(x_1);
x_7 = l_main___closed__4;
x_8 = l_Lean_findSysroot(x_7, x_2);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = lean_box(0);
x_12 = l_Lean_initSearchPath(x_9, x_11, x_10);
if (lean_obj_tag(x_12) == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_13 = lean_ctor_get(x_12, 1);
lean_inc(x_13);
lean_dec(x_12);
x_14 = lean_enable_initializer_execution(x_13);
x_15 = lean_ctor_get(x_14, 1);
lean_inc(x_15);
lean_dec(x_14);
x_16 = l_main___closed__5;
x_17 = lean_io_getenv(x_16, x_15);
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
if (lean_obj_tag(x_18) == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_19 = lean_ctor_get(x_17, 1);
lean_inc(x_19);
lean_dec(x_17);
x_20 = l_main___closed__3;
x_21 = lean_box(0);
x_22 = l_main___lambda__1(x_6, x_20, x_21, x_19);
lean_dec(x_6);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_23 = lean_ctor_get(x_17, 1);
lean_inc(x_23);
lean_dec(x_17);
x_24 = lean_ctor_get(x_18, 0);
lean_inc(x_24);
lean_dec(x_18);
x_25 = lean_load_dynlib(x_24, x_23);
lean_dec(x_24);
if (lean_obj_tag(x_25) == 0)
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_26 = lean_ctor_get(x_25, 0);
lean_inc(x_26);
x_27 = lean_ctor_get(x_25, 1);
lean_inc(x_27);
lean_dec(x_25);
x_28 = l_main___closed__3;
x_29 = l_main___lambda__1(x_6, x_28, x_26, x_27);
lean_dec(x_26);
lean_dec(x_6);
return x_29;
}
else
{
uint8_t x_30; 
lean_dec(x_6);
x_30 = !lean_is_exclusive(x_25);
if (x_30 == 0)
{
return x_25;
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_31 = lean_ctor_get(x_25, 0);
x_32 = lean_ctor_get(x_25, 1);
lean_inc(x_32);
lean_inc(x_31);
lean_dec(x_25);
x_33 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_33, 0, x_31);
lean_ctor_set(x_33, 1, x_32);
return x_33;
}
}
}
}
else
{
uint8_t x_34; 
lean_dec(x_6);
x_34 = !lean_is_exclusive(x_12);
if (x_34 == 0)
{
return x_12;
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_35 = lean_ctor_get(x_12, 0);
x_36 = lean_ctor_get(x_12, 1);
lean_inc(x_36);
lean_inc(x_35);
lean_dec(x_12);
x_37 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_37, 0, x_35);
lean_ctor_set(x_37, 1, x_36);
return x_37;
}
}
}
else
{
uint8_t x_38; 
lean_dec(x_6);
x_38 = !lean_is_exclusive(x_8);
if (x_38 == 0)
{
return x_8;
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_39 = lean_ctor_get(x_8, 0);
x_40 = lean_ctor_get(x_8, 1);
lean_inc(x_40);
lean_inc(x_39);
lean_dec(x_8);
x_41 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_41, 0, x_39);
lean_ctor_set(x_41, 1, x_40);
return x_41;
}
}
}
else
{
uint8_t x_42; 
lean_dec(x_1);
x_42 = !lean_is_exclusive(x_5);
if (x_42 == 0)
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_5, 1);
lean_dec(x_43);
x_44 = lean_ctor_get(x_5, 0);
lean_dec(x_44);
x_45 = l_main___closed__2;
lean_ctor_set(x_5, 1, x_2);
lean_ctor_set(x_5, 0, x_45);
return x_5;
}
else
{
lean_object* x_46; lean_object* x_47; 
lean_dec(x_5);
x_46 = l_main___closed__2;
x_47 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_47, 0, x_46);
lean_ctor_set(x_47, 1, x_2);
return x_47;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_9 = l_Array_forInUnsafe_loop___at_main___spec__3(x_1, x_2, x_7, x_8, x_5, x_6);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_4);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_Loop_forIn_loop___at_main___spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Lean_Loop_forIn_loop___at_main___spec__4(x_1, x_2, x_3, x_4);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_4);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__2(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___lambda__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_8 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_9 = l_Array_forInUnsafe_loop___at_main___spec__6___lambda__4(x_1, x_7, x_3, x_8, x_5, x_6);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_main___spec__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_8 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_9 = l_Array_forInUnsafe_loop___at_main___spec__6(x_1, x_2, x_7, x_8, x_5, x_6);
return x_9;
}
}
LEAN_EXPORT lean_object* l_main___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_main___lambda__1(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_1);
return x_5;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_StateReuseProfile(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_Import(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Parser_Module(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Elab_Frontend(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_StateReuseMeasure(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_StateReuseProfile(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_Import(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Parser_Module(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Elab_Frontend(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l___private_StateReuseMeasure_0__expensive___closed__1 = _init_l___private_StateReuseMeasure_0__expensive___closed__1();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__1);
l___private_StateReuseMeasure_0__expensive___closed__2 = _init_l___private_StateReuseMeasure_0__expensive___closed__2();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__2);
l___private_StateReuseMeasure_0__expensive___closed__3 = _init_l___private_StateReuseMeasure_0__expensive___closed__3();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__3);
l___private_StateReuseMeasure_0__expensive___closed__4 = _init_l___private_StateReuseMeasure_0__expensive___closed__4();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__4);
l___private_StateReuseMeasure_0__expensive___closed__5 = _init_l___private_StateReuseMeasure_0__expensive___closed__5();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__5);
l___private_StateReuseMeasure_0__expensive___closed__6 = _init_l___private_StateReuseMeasure_0__expensive___closed__6();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__6);
l___private_StateReuseMeasure_0__expensive___closed__7 = _init_l___private_StateReuseMeasure_0__expensive___closed__7();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__7);
l___private_StateReuseMeasure_0__expensive___closed__8 = _init_l___private_StateReuseMeasure_0__expensive___closed__8();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__8);
l___private_StateReuseMeasure_0__expensive___closed__9 = _init_l___private_StateReuseMeasure_0__expensive___closed__9();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__9);
l___private_StateReuseMeasure_0__expensive___closed__10 = _init_l___private_StateReuseMeasure_0__expensive___closed__10();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__10);
l___private_StateReuseMeasure_0__expensive___closed__11 = _init_l___private_StateReuseMeasure_0__expensive___closed__11();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__11);
l___private_StateReuseMeasure_0__expensive___closed__12 = _init_l___private_StateReuseMeasure_0__expensive___closed__12();
lean_mark_persistent(l___private_StateReuseMeasure_0__expensive___closed__12);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__1 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__1();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__1);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__2 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__2();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__2);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__3 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__3();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__3);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__4);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__5 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__5();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__5);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__6 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__6();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__6);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__7 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__7();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__7);
l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8 = _init_l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8();
lean_mark_persistent(l_Std_Range_forIn_loop___at___private_StateReuseMeasure_0__wrapSequence___spec__1___closed__8);
l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__1 = _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__1();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__1);
l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__2 = _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__2();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___lambda__2___closed__2);
l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__1 = _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__1();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__1);
l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__2 = _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__2();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__2);
l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__3 = _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__3();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__3);
l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__4 = _init_l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__4();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___lambda__3___closed__4);
l___private_StateReuseMeasure_0__wrapSequence___closed__1 = _init_l___private_StateReuseMeasure_0__wrapSequence___closed__1();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___closed__1);
l___private_StateReuseMeasure_0__wrapSequence___closed__2 = _init_l___private_StateReuseMeasure_0__wrapSequence___closed__2();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___closed__2);
l___private_StateReuseMeasure_0__wrapSequence___closed__3 = _init_l___private_StateReuseMeasure_0__wrapSequence___closed__3();
lean_mark_persistent(l___private_StateReuseMeasure_0__wrapSequence___closed__3);
l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1 = _init_l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__1);
l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__2 = _init_l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__2();
lean_mark_persistent(l_Lean_Loop_forIn_loop___at_main___spec__4___lambda__1___closed__2);
l_List_forIn_loop___at_main___spec__5___closed__1 = _init_l_List_forIn_loop___at_main___spec__5___closed__1();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__1);
l_List_forIn_loop___at_main___spec__5___closed__2 = _init_l_List_forIn_loop___at_main___spec__5___closed__2();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__2);
l_List_forIn_loop___at_main___spec__5___closed__3 = _init_l_List_forIn_loop___at_main___spec__5___closed__3();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__3);
l_List_forIn_loop___at_main___spec__5___closed__4 = _init_l_List_forIn_loop___at_main___spec__5___closed__4();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__4);
l_List_forIn_loop___at_main___spec__5___closed__5 = _init_l_List_forIn_loop___at_main___spec__5___closed__5();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__5);
l_List_forIn_loop___at_main___spec__5___closed__6 = _init_l_List_forIn_loop___at_main___spec__5___closed__6();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__6);
l_List_forIn_loop___at_main___spec__5___closed__7 = _init_l_List_forIn_loop___at_main___spec__5___closed__7();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__7);
l_List_forIn_loop___at_main___spec__5___closed__8 = _init_l_List_forIn_loop___at_main___spec__5___closed__8();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__8);
l_List_forIn_loop___at_main___spec__5___closed__9 = _init_l_List_forIn_loop___at_main___spec__5___closed__9();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__9);
l_List_forIn_loop___at_main___spec__5___closed__10 = _init_l_List_forIn_loop___at_main___spec__5___closed__10();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__10);
l_List_forIn_loop___at_main___spec__5___closed__11 = _init_l_List_forIn_loop___at_main___spec__5___closed__11();
lean_mark_persistent(l_List_forIn_loop___at_main___spec__5___closed__11);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__1 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__1();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__1);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__2 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__2();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__2);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__3 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__3();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__3);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__4);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__5);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__6);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__7);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__8 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__8();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__8);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__9 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__9();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__9);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__10);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__11);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__12 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__12();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__12);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__1___closed__13);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__1 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__1();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__1);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__2 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__2();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__2);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__3 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__3();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__3);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__4 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__4();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__4);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__5 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__5();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__5);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__6 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__6();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__6);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__7 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__7();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__7);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__8 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__8();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__8);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__9 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__9();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__9);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__10 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__10();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__10);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__11 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__11();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__11);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__12 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__12();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__12);
l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__13 = _init_l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__13();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_main___spec__6___lambda__3___closed__13);
l_main___lambda__1___closed__1 = _init_l_main___lambda__1___closed__1();
lean_mark_persistent(l_main___lambda__1___closed__1);
l_main___lambda__1___closed__2 = _init_l_main___lambda__1___closed__2();
lean_mark_persistent(l_main___lambda__1___closed__2);
l_main___closed__1 = _init_l_main___closed__1();
lean_mark_persistent(l_main___closed__1);
l_main___closed__2 = _init_l_main___closed__2();
lean_mark_persistent(l_main___closed__2);
l_main___closed__3 = _init_l_main___closed__3();
lean_mark_persistent(l_main___closed__3);
l_main___closed__4 = _init_l_main___closed__4();
lean_mark_persistent(l_main___closed__4);
l_main___closed__5 = _init_l_main___closed__5();
lean_mark_persistent(l_main___closed__5);
return lean_io_result_mk_ok(lean_box(0));
}
void lean_initialize();

  #if defined(WIN32) || defined(_WIN32)
  #include <windows.h>
  #endif

  int main(int argc, char ** argv) {
  #if defined(WIN32) || defined(_WIN32)
  SetErrorMode(SEM_FAILCRITICALERRORS);
  #endif
  lean_object* in; lean_object* res;
lean_initialize();
lean_set_panic_messages(false);
res = initialize_StateReuseMeasure(1 /* builtin */, lean_io_mk_world());
lean_set_panic_messages(true);
lean_io_mark_end_initialization();
if (lean_io_result_is_ok(res)) {
lean_dec_ref(res);
lean_init_task_manager();
in = lean_box(0);
int i = argc;
while (i > 1) {
 lean_object* n;
 i--;
 n = lean_alloc_ctor(1,2,0); lean_ctor_set(n, 0, lean_mk_string(argv[i])); lean_ctor_set(n, 1, in);
 in = n;
}
res = _lean_main(in, lean_io_mk_world());
}
lean_finalize_task_manager();
if (lean_io_result_is_ok(res)) {
  int ret = 0;
  lean_dec_ref(res);
  return ret;
} else {
  lean_io_result_show_error(res);
  lean_dec_ref(res);
  return 1;
}
}
#ifdef __cplusplus
}
#endif
