## Current frontier

The complete own arithmetic counterexample-screening pair on7,808original
miniF2Fcandidates has exact accepted/status parity but requires8.8563%more
elapsed than native before additional preparation. Exact refutations occur
in29ordinary-error candidates and remove no83timeouts. This is a small
supporting component, not the missing systems contribution.
[Complete final result](../artifacts/arithmetic-counterexample-2026-10-23/native-gpu-full-layout-fixed-20261024T1650/result-review.md)
retains all42resourcefailures and missing cold-controller-clock limitations.

The user explicitly stops expanding thisGPUcomparison and requests actual
tactic/phase attribution on the native slowest10%FAILED cohort:480sources,
including83timeouts/355Leanerrors/42resourcefailures. Its original83/old78
timeout mapping, unchanged source inputs, native runtime profiling boundary
and preflight are documented in the [measurement plan](../artifacts/lean-failure-profile-2026-10-25/plan.md).
The C-only24source qualification is complete and the solefull480capture
is running; neither qualification nor a partial profile is a hotspot conclusion.
The CPUoracle remains frozen. The latest user decision removes the
performance condition, deadline and short-paper closure and directs continuous
work on three axes: reliable earlyfailure/timeout detection,32candidate
first-success scheduling, and public Lean code-verification workloads.
During the sole live capture, advance offline scheduling analysis,
implementation and workload preparation rather than empty waiting.
No external-system reproductions, narrow-kernel revival or newGPUgrid.

The Initial Narrative, allfourRQs, Lean/SMTscope and OSDI-quality objective
remain unchanged, open and unfrozen. Rootalone implements and reviews,
with no independent audit. The only current paper is [docs/paper](paper/main.tex).
Source/runtime adaptations and complete results do not prove novelty or
submission readiness. Historical datedfrontiers remain linked in step reports.

