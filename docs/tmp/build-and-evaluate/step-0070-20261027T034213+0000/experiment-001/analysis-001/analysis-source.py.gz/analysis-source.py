from pathlib import Path
import collections,datetime,gzip,json,math,runpy,sys,time
import numpy as np
sys.dont_write_bytecode=True
r=Path('/workspaces/repository')
out=r/'artifacts/engine-resource-profile-2026-10-25/source-memory-crossfit-20261027'
out.mkdir(exist_ok=False)
started=time.monotonic()
path=r/'artifacts/engine-resource-pair-2026-10-25/full7808-20261026T004621Z/native/capture.json.gz'
data=json.loads(gzip.decompress(path.read_bytes()))
candidates=data['batch']['candidates'];results=data['results']
assert len(candidates)==len(results)==7808 and all(c['id']==v['id']for c,v in zip(candidates,results))
assert not any(v['cached']or v['coalesced']for v in results)
F=runpy.run_path(str(r/'bench/lean-candidate-scheduling/features.py'))
X=np.array([F['vector'](c['code'])for c in candidates],dtype=float)
peaks=np.array([max((a['peak_rss_bytes']for a in row['attempts']),default=0)for row in results],dtype=float)
known=peaks>0
tasks=sorted({c['task_id']for c in candidates});assert len(tasks)==244
assert all(sum(c['task_id']==t for c in candidates)==32 for t in tasks)
taskfold={t:i%5 for i,t in enumerate(tasks)}
folds=np.array([taskfold[c['task_id']]for c in candidates])
log_target=np.full(len(peaks),np.nan);log_target[known]=np.log(peaks[known])
pred=np.full(len(peaks),np.nan);base=np.full_like(pred,np.nan);models=[]
for fold in range(5):
 train=(folds!=fold)&known;test=(folds==fold)&known
 mean=X[train].mean(axis=0);scale=X[train].std(axis=0);scale[scale==0]=1
 A=np.column_stack([np.ones(train.sum()),(X[train]-mean)/scale])
 B=np.column_stack([np.ones(test.sum()),(X[test]-mean)/scale])
 penalty=np.eye(A.shape[1]);penalty[0,0]=0
 beta=np.linalg.solve(A.T@A+penalty,A.T@log_target[train])
 pred[test]=np.exp(B@beta);constant=float(np.median(peaks[train]));base[test]=constant
 models.append({'fold':fold,'train_tasks':len([t for t in tasks if taskfold[t]!=fold]),'held_out_task_ids':[t for t in tasks if taskfold[t]==fold],
  'train_known_sources':int(train.sum()),'test_known_sources':int(test.sum()),'means':mean.tolist(),'scales':scale.tolist(),
  'logrss_coefficients':beta.tolist(),'training_peak_median_bytes':constant})
assert np.isfinite(X).all()and np.isfinite(pred[known]).all()and(pred[known]>0).all()
statuses=np.array([v['outcome']['status']for v in results])
had_preemption=np.array([any(a['status']=='preempted'for a in v['attempts'])for v in results])
def metrics(values,mask):
 mask=mask&known;y=peaks[mask];p=values[mask];abs_error=np.abs(p-y)
 if len(y)==0:return {'known_sources':0}
 return {'known_sources':int(len(y)),'mean_absolute_error_GiB':float(abs_error.mean()/1024**3),
  'median_absolute_error_GiB':float(np.median(abs_error)/1024**3),'p90_absolute_error_GiB':float(np.quantile(abs_error,.9)/1024**3),
  'median_absolute_log2_error':float(np.median(np.abs(np.log2(p/y)))),
  'underpredict_more_than_2x_sources':int(np.sum(p*2<y)),
  'sum_positive_byte_shortfall_GiB':float(np.maximum(0,y-p).sum()/1024**3),
  'sum_positive_byte_overprediction_GiB':float(np.maximum(0,p-y).sum()/1024**3),
  'forecasts_over_48GiB':int(np.sum(p>48*1024**3))}
strata={'all_observed':np.ones(len(peaks),dtype=bool),'accepted':statuses=='accepted','ordinary_rejected':statuses=='rejected',
 'timeout':statuses=='timeout','resource_exhausted':statuses=='resource_exhausted','backend_error':statuses=='backend_error',
 'had_preemption':had_preemption,'completed_without_preemption':np.isin(statuses,['accepted','rejected','incomplete'])&~had_preemption}
summary={name:{'source_ridge':metrics(pred,mask),'training_median_constant':metrics(base,mask)}for name,mask in strata.items()}
preemptions=[{'id':v['id'],'task_id':c['task_id'],'attempt_index':ai,'elapsed_seconds':a['elapsed_seconds'],
 'peak_observed_rss_bytes':a['peak_rss_bytes'],'aggregate_preemption_rss_bytes':a['preemption_rss_bytes'],'final_status':v['outcome']['status']}
 for c,v in zip(candidates,results)for ai,a in enumerate(v['attempts'])if a['status']=='preempted']
predictions=[{'id':c['id'],'task_id':c['task_id'],'held_out_fold':int(folds[i]),'status':v['outcome']['status'],'had_preemption':bool(had_preemption[i]),
 'observed_peak_bytes':int(peaks[i])if known[i]else None,'source_ridge_bytes':float(pred[i])if known[i]else None,
 'training_median_bytes':float(base[i])if known[i]else None,'peak_censoring':'resource-exhausted lower-bound observation'if statuses[i]=='resource_exhausted'else'timeout-limited observation'if statuses[i]=='timeout'else'finite attempt observation'}
 for i,(c,v)in enumerate(zip(candidates,results))]
result={'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input':str(path.relative_to(r)),'sources':len(results),'tasks':len(tasks),
 'features':F['NAMES'],'folds':'sorted task IDs modulo5,32siblings together','L2_penalty':1,'unpenalized_intercept':True,
 'known_peak_sources':int(known.sum()),'unknown_peak_ids':[c['id']for i,c in enumerate(candidates)if not known[i]],
 'target':'maximum reported observed attempt peak per candidate; finite-resource observation,not uncensored intrinsic source demand',
 'metrics':summary,'preempted_attempts':len(preemptions),'preempted_sources':int(had_preemption.sum()),
 'preempted_attempt_elapsed_sum_seconds':sum(x['elapsed_seconds']for x in preemptions),
 'all_attempt_elapsed_sum_seconds':sum(a['elapsed_seconds']for v in results for a in v['attempts']),
 'analysis_seconds':time.monotonic()-started,'native_candidate_executions':0,'actual_admission_or_runtime_speedup':None,
 'limitations':['all metrics are on existing finite-resource observations','fold-training median is a predictive constant,not exact causal engine replay',
 'test task outcomes/peaks never enter fitting/standardization','censored high-demand observations may understate demand',
 'no admission simulation,changed resource policy,rejection decision or runtime benefit','concurrent discarded-work sums are not removable wall']}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'models.json.gz').write_bytes(gzip.compress((json.dumps({'features':F['NAMES'],'models':models},indent=2)+'\n').encode(),mtime=0))
(out/'predictions.jsonl.gz').write_bytes(gzip.compress(''.join(json.dumps(x)+'\n'for x in predictions).encode(),mtime=0))
(out/'preemptions.json.gz').write_bytes(gzip.compress((json.dumps(preemptions,indent=2)+'\n').encode(),mtime=0))
for name in ['features.py','analyze.py']:
 raw=(r/'bench/lean-candidate-scheduling'/name).read_bytes();(out/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
print(json.dumps(result),flush=True)
