import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let a,b,c be non-negative real numbers with sum 2. Prove that: $ 24(a^2+b^2+c^2)+(a^2+b^2+c^2)^2 \le 48+8(a^3+b^3+c^3)$ -/
theorem lean_workbook_10895 (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (habc : a + b + c = 2) : 24 * (a ^ 2 + b ^ 2 + c ^ 2) + (a ^ 2 + b ^ 2 + c ^ 2) ^ 2 ≤ 48 + 8 * (a ^ 3 + b ^ 3 + c ^ 3)  := by
  /-
  Given non-negative real numbers \(a\), \(b\), and \(c\) with sum 2, we need to prove that:
  \[ 24(a^2 + b^2 + c^2) + (a^2 + b^2 + c^2)^2 \leq 48 + 8(a^3 + b^3 + c^3) \]
  To prove this inequality, we use the non-linear arithmetic (nlinarith) tactic, which automatically handles inequalities involving polynomials. We provide several non-negative expressions to ensure the tactic can correctly deduce the inequality.
  -/
  -- Use non-linear arithmetic to handle the inequality involving polynomials.
  -- We provide several non-negative expressions to ensure the tactic can correctly deduce the inequality.
  nlinarith [sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha,
    sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
