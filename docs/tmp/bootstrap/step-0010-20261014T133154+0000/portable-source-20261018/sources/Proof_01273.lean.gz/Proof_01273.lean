import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that: $4 + 15abc + (a - b)(b - c)(c - a) \geq 5(a^2b + b^2c + c^2a) + 12(ab + bc + ca)$ given $a;b;c \geq 0$ and $a + b + c = 1$. -/
theorem lean_workbook_15342 (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hab : a + b + c = 1) : 4 + 15 * a * b * c + (a - b) * (b - c) * (c - a) ≥ 5 * (a^2 * b + b^2 * c + c^2 * a) + 12 * (a * b + b * c + c * a)  := by
  /-
  Given \(a, b, c \geq 0\) and \(a + b + c = 1\), we need to prove that:
  \[ 4 + 15abc + (a - b)(b - c)(c - a) \geq 5(a^2b + b^2c + c^2a) + 12(ab + bc + ca) \]
  We will consider different cases based on the relationships between \(a, b,\) and \(c\). By analyzing each case and using the properties of non-negative numbers and algebraic manipulations, we can show that the inequality holds in all cases.
  -/
  -- Consider different cases based on the relationships between a, b, and c.
  cases' le_total a b with h h <;>
  cases' le_total b c with h' h' <;>
  cases' le_total c a with h'' h'' <;>
  -- Use nlinarith to handle the non-negative constraints and algebraic manipulations.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha,
    mul_self_nonneg (a - b + c), mul_self_nonneg (b - c + a), mul_self_nonneg (c - a + b)]
