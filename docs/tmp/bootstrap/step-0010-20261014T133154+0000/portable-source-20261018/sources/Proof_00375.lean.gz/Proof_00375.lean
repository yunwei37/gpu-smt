import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that: $a^2 b^2 c^2 + a^2 + b^2 + c^2 + 2 \ge 2\left( {ab + bc + ca} \right),\forall a,b,c \in \left[ {0, + \infty } \right)$ -/
theorem lean_workbook_11522 : ∀ a b c : ℝ, a ∈ Set.Ici 0 ∧ b ∈ Set.Ici 0 ∧ c ∈ Set.Ici 0 → a^2 * b^2 * c^2 + a^2 + b^2 + c^2 + 2 ≥ 2 * (a * b + b * c + c * a)  := by
  /-
  We need to prove that for all \(a, b, c \in [0, +\infty)\), the inequality \(a^2 b^2 c^2 + a^2 + b^2 + c^2 + 2 \ge 2(ab + bc + ca)\) holds. This can be shown using non-linear arithmetic (nlinarith) by considering the non-negativity of squares. Specifically, we use the fact that the square of any real number is non-negative to establish the inequality.
  -/
  -- Introduce the variables a, b, c and the hypothesis habc that a, b, c are in the interval [0, +∞)
  intro a b c habc
  -- Use non-linear arithmetic to prove the inequality
  -- We provide lemmas about the non-negativity of squares to help nlinarith
  nlinarith [sq_nonneg (a * b * c - 1), sq_nonneg (a * b - 1), sq_nonneg (b * c - 1), sq_nonneg (c * a - 1),
    sq_nonneg (a * b * c), sq_nonneg (a * b), sq_nonneg (b * c), sq_nonneg (c * a), sq_nonneg (a * b * c - a),
    sq_nonneg (a * b * c - b), sq_nonneg (a * b * c - c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
