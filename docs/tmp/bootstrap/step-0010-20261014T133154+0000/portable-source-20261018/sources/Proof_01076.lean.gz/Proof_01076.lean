import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c> 0$ and $a+b+c=ab+bc+ca .$ Prove that \n $$a^3+b^3+c^3\geq 3$$ -/
theorem lean_workbook_14536 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = a * b + b * c + c * a) : a ^ 3 + b ^ 3 + c ^ 3 ≥ 3  := by
  /-
  Given \(a, b, c > 0\) and \(a + b + c = ab + bc + ca\), we need to prove that \(a^3 + b^3 + c^3 \geq 3\).
  First, we simplify the given equation \(a + b + c = ab + bc + ca\). We can rewrite this as:
  \[ a + b + c - ab - bc - ca = 0 \]
  Next, we use the fact that \(a, b, c > 0\) and apply algebraic manipulations to show that \(a^3 + b^3 + c^3 \geq 3\). We consider the non-negativity of squares and use the non-linear arithmetic to derive the desired inequality.
  -/
  -- Normalize the expression in the hypothesis and the goal
  ring_nf at habc ⊢
  -- Use non-linear arithmetic to prove the inequality
  -- We use the non-negativity of squares of differences to derive the inequality
  nlinarith [sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    mul_pos ha hb, mul_pos hb hc, mul_pos hc ha, habc, sq_nonneg (a - b), sq_nonneg (b - c),
    sq_nonneg (c - a)]
