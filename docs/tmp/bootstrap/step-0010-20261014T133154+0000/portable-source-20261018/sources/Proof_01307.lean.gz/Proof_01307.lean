import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- The following inequality is also true Let $a,b,c$ be positive real numbers satisfying $a^2+b^2+c^2=12.$ Prove that $7(a+b+c)+18>a^3+b^3+c^3.$ -/
theorem lean_workbook_155 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hab : a^2 + b^2 + c^2 = 12) : 7 * (a + b + c) + 18 > a^3 + b^3 + c^3  := by
  /-
  Given positive real numbers \(a\), \(b\), and \(c\) such that \(a^2 + b^2 + c^2 = 12\), we need to prove that \(7(a + b + c) + 18 > a^3 + b^3 + c^3\).
  To prove this, we use the non-linear arithmetic (nlinarith) tactic, which is capable of handling inequalities involving squares and cubes. Specifically, we use the fact that the square of any real number is non-negative, which helps in establishing the desired inequality.
  -/
  -- Use non-linear arithmetic to handle the inequality.
  -- We provide lemmas about the non-negativity of squares to help nlinarith.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a - 3), sq_nonneg (b - 3), sq_nonneg (c - 3)]
