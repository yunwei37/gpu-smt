import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c \in \mathbb{R^{+}}$ such that $a+b+c=3$ .Prove the inequality $a^2b+b^2c+c^2a+abc\le 4.$ -/
theorem lean_workbook_12355 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = 3) : a^2 * b + b^2 * c + c^2 * a + a * b * c ≤ 4  := by
  /-
  Given \(a, b, c \in \mathbb{R}^+\) such that \(a + b + c = 3\), we need to prove the inequality \(a^2b + b^2c + c^2a + abc \leq 4\).
  1. **Case Analysis**: We perform a case analysis on the relationships between \(a, b,\) and \(c\).
  2. **Nonlinear Arithmetic**: Using non-linear arithmetic, we derive the necessary inequalities to satisfy the given conditions.
  -/
  -- Perform case analysis on the relationships between a, b, and c.
  cases' le_total a b with h h <;>
  cases' le_total b c with h' h' <;>
  cases' le_total c a with h'' h'' <;>
  -- Use non-linear arithmetic to derive the necessary inequalities.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
