import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Given the conditions $a+b+c = 1$ and $a, b, c \in \mathbb{R^+}$, prove that $(1+a)(1+b)(1+c) \geq 8(1-a)(1-b)(1-c)$. -/
theorem lean_workbook_11890 (a b c : ℝ) (habc : a + b + c = 1) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :  (1 + a) * (1 + b) * (1 + c) ≥ 8 * (1 - a) * (1 - b) * (1 - c)  := by
  /-
  Given the conditions \(a + b + c = 1\) and \(a, b, c \in \mathbb{R}^+\), we need to prove that \((1 + a)(1 + b)(1 + c) \geq 8(1 - a)(1 - b)(1 - c)\).
  1. Since \(a, b, c > 0\) and \(a + b + c = 1\), we can use the fact that the product of positive numbers is non-negative.
  2. We use the non-negativity of squares and the properties of real numbers to establish the inequality.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- We provide the non-negativity of various expressions involving a, b, and c.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a - 1 / 2), sq_nonneg (b - 1 / 2), sq_nonneg (c - 1 / 2), sq_nonneg (a + 1 / 2), sq_nonneg (b + 1 / 2), sq_nonneg (c + 1 / 2)]
