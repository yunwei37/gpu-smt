import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that for all positive real a, b and c, we have $abc+2(4+a^2+b^2+c^2)\ge 5(a+b+c)$ -/
theorem lean_workbook_16935 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : a * b * c + 2 * (4 + a ^ 2 + b ^ 2 + c ^ 2) ≥ 5 * (a + b + c)  := by
  /-
  We need to prove that for all positive real numbers \(a\), \(b\), and \(c\), the inequality \(abc + 2(4 + a^2 + b^2 + c^2) \geq 5(a + b + c)\) holds. This can be shown using non-linear arithmetic by considering the non-negativity of squares of differences and sums of \(a\), \(b\), and \(c\).
  -/
  -- Use non-linear arithmetic to prove the inequality by considering the non-negativity of squares of differences and sums of a, b, and c.
  nlinarith [sq_nonneg (a + b + c - 3), sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    mul_self_nonneg (a - b), mul_self_nonneg (b - c), mul_self_nonneg (c - a),
    mul_nonneg ha.le hb.le, mul_nonneg hb.le hc.le, mul_nonneg hc.le ha.le,
    mul_self_nonneg (a * b - 1), mul_self_nonneg (b * c - 1), mul_self_nonneg (c * a - 1)]
