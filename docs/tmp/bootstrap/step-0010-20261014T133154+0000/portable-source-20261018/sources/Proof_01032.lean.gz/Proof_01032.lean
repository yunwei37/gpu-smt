import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $x, y, z \in \mathbb{R}^+ $ such that $ x^2+y^2+z^2+xyz=4$ . Prove that $x+y+z \geq xyz+2$ . -/
theorem lean_workbook_14313 (x y z : ℝ) (hx : 0 < x) (hy : 0 < y) (hz : 0 < z) (h : x^2 + y^2 + z^2 + x * y * z = 4) : x + y + z ≥ x * y * z + 2  := by
  /-
  Given \( x, y, z \in \mathbb{R}^+ \) such that \( x^2 + y^2 + z^2 + xyz = 4 \), we need to prove that \( x + y + z \geq xyz + 2 \).
  To prove this, we use the non-linear arithmetic (nlinarith) tactic, which automatically handles inequalities involving polynomials. We provide several non-negative expressions to help nlinarith derive the desired inequality. Specifically, we use the non-negativity of squares and other polynomial expressions to establish the required inequality.
  -/
  -- Use non-linear arithmetic to handle the inequality involving polynomials.
  -- We provide several non-negative expressions to help nlinarith derive the desired inequality.
  nlinarith [sq_nonneg (x + y + z), sq_nonneg (x - y), sq_nonneg (x - z), sq_nonneg (y - z),
    sq_nonneg (x + y - 2), sq_nonneg (x + z - 2), sq_nonneg (y + z - 2)]
