import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c$ be positive real numbers with $a+b+c=1.$ Show that \n $a^2+b^2+c^2+7abc\geq 2(a+b)(b+c)(c+a).$ -/
theorem lean_workbook_13367 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = 1) : a^2 + b^2 + c^2 + 7 * a * b * c ≥ 2 * (a + b) * (b + c) * (c + a)  := by
  /-
  Given positive real numbers \(a\), \(b\), and \(c\) such that \(a + b + c = 1\), we need to show that:
  \[ a^2 + b^2 + c^2 + 7abc \geq 2(a + b)(b + c)(c + a). \]
  To prove this inequality, we use the non-linear arithmetic (nlinarith) tactic, which is capable of handling inequalities involving squares and products of real numbers. Specifically, we provide the non-negativity of various expressions to help nlinarith derive the desired inequality.
  -/
  -- Use non-linear arithmetic to handle the inequality.
  -- We provide the non-negativity of various expressions to help nlinarith derive the desired inequality.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - 1 / 2), sq_nonneg (b - 1 / 2), sq_nonneg (c - 1 / 2),
    mul_nonneg ha.le hb.le, mul_nonneg hb.le hc.le, mul_nonneg hc.le ha.le,
    mul_self_nonneg (a + b + c - 1)]
