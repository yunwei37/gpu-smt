import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For $\max $ : By AM-GM $\frac{9abc}{2}\le \frac{(a+b+c)(ab+bc+ca)}{2}=\frac{ab+bc+ca}{2}$ We have $a+b+c=1\implies 0\le a,b,c\le 1\implies a^2\le a,\,\ b^2\le b,\,\ c^2\le c\implies a^2+b^2+c^2\le a+b+c=1$ Thus $P=a^2+b^2+c^2+\frac{9}{2}abc\le a^2+b^2+c^2+\frac{ab+bc+ca}{2}=\frac{3}{4}(a^2+b^2+c^2)+\frac{(a+b+c)^2}{4}\le \frac{3}{4}+\frac{1}{4}=1$ Equality holds if $a=1,\,\ b=c=0$ and its permutation -/
theorem lean_workbook_14521  (a b c : ℝ)
  (h₀ : a + b + c = 1)
  (h₁ : 0 ≤ a ∧ 0 ≤ b ∧ 0 ≤ c) :
  a^2 + b^2 + c^2 + 9 / 2 * a * b * c ≤ 1  := by
  /-
  We aim to prove that for non-negative real numbers \(a\), \(b\), and \(c\) such that \(a + b + c = 1\), the inequality \(a^2 + b^2 + c^2 + \frac{9}{2}abc \leq 1\) holds. We will use the non-negativity of squares and some algebraic manipulations to derive this result.
  -/
  -- Use non-linear arithmetic to handle the inequality.
  -- We provide the non-negativity of various expressions involving a, b, and c.
  nlinarith [sq_nonneg (a - 1 / 2), sq_nonneg (b - 1 / 2), sq_nonneg (c - 1 / 2),
    sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b + c)]
