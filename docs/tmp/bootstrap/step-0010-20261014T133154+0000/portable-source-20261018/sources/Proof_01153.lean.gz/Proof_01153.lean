import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $a^2+b^2+c^2+\frac{9}{a+b+c}\ge 2(a+b+c)$ given $a,b,c>0$ and $abc=1$. -/
theorem lean_workbook_14824 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) : a ^ 2 + b ^ 2 + c ^ 2 + 9 / (a + b + c) ≥ 2 * (a + b + c)  := by
  /-
  Given \( a, b, c > 0 \) and \( abc = 1 \), we need to prove that \( a^2 + b^2 + c^2 + \frac{9}{a + b + c} \geq 2(a + b + c) \).
  First, we note that since \( a, b, c > 0 \), the expression \( a + b + c \) is positive. We then simplify the inequality by clearing the denominator using this fact.
  Next, we use the fact that \( abc = 1 \) and apply algebraic manipulations and inequalities to show that the left-hand side of the inequality is always greater than or equal to the right-hand side. Specifically, we use the non-negativity of squares and linear arithmetic to establish the desired inequality.
  -/
  -- Establish that the sum a + b + c is positive.
  have h : 0 < a + b + c := by linarith
  -- Clear the denominator by multiplying both sides by a + b + c.
  field_simp [h]
  -- Use the division inequality to rewrite the inequality in a form suitable for nlinarith.
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    nlinarith [sq_nonneg (a + b + c - 3), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    ha, hb, hc, habc, sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
  -- Further simplify and prove the inequality.
  try nlinarith [sq_nonneg (a + b + c - 3), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    ha, hb, hc, habc, sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
