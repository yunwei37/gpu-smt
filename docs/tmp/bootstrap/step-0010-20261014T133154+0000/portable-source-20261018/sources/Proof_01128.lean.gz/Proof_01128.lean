import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For $ a,b,c >0, ab+bc+ca+abc=4 $, to prove that: \n $ a^3+b^3+c^3+9abc\geq\ 12 $ -/
theorem lean_workbook_14712 (a b c : ℝ) (h : a > 0 ∧ b > 0 ∧ c > 0 ∧ a * b + b * c + c * a + a * b * c = 4) :  a ^ 3 + b ^ 3 + c ^ 3 + 9 * a * b * c ≥ 12  := by
  /-
  Given \( a, b, c > 0 \) and \( ab + bc + ca + abc = 4 \), we need to prove that:
  \[ a^3 + b^3 + c^3 + 9abc \geq 12 \]
  To prove this inequality, we can use the non-linear arithmetic (nlinarith) tactic, which automatically handles inequalities involving polynomials. We provide several non-negative expressions to help nlinarith derive the desired inequality.
  -/
  -- Use non-linear arithmetic to handle the inequality.
  -- We provide several non-negative expressions to help nlinarith derive the desired inequality.
  nlinarith [sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    mul_nonneg h.1.le h.2.1.le, mul_nonneg h.2.1.le h.2.2.1.le, mul_nonneg h.2.2.1.le h.1.le,
    sq_nonneg (a + b + c - 3), sq_nonneg (a - b + c), sq_nonneg (b - c + a), sq_nonneg (c - a + b)]
