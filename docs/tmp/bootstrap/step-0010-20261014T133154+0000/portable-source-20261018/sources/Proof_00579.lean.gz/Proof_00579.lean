import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Determine if the inequality $2a^{2} + 2b^{2} + 2c^{2} + 9abc \geq 4a + 4b + 4c + ab + bc + ca$ holds true for all $a, b, c$ such that $abc = 1$. -/
theorem lean_workbook_12435 : ∀ a b c : ℝ, a * b * c = 1 → 2 * a ^ 2 + 2 * b ^ 2 + 2 * c ^ 2 + 9 * a * b * c ≥ 4 * a + 4 * b + 4 * c + a * b + b * c + c * a  := by
  /-
  We need to determine if the inequality \(2a^2 + 2b^2 + 2c^2 + 9abc \geq 4a + 4b + 4c + ab + bc + ca\) holds for all \(a, b, c\) such that \(abc = 1\). We will use the non-linear arithmetic (nlinarith) tactic to verify this inequality. The tactic will check the inequality by considering the non-negativity of various squared terms involving \(a, b, c\) and their products.
  -/
  -- Introduce the variables a, b, c and the hypothesis h that abc = 1.
  intro a b c h
  -- Use nlinarith to verify the inequality by considering the non-negativity of various squared terms.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a + 1), sq_nonneg (b + 1), sq_nonneg (c + 1)]
