import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $a,b,c\ge 0$, $a^2 +b^2+c^2+2abc=5$, prove that $abc+a+b+c+ab+bc+ca\le 7$. -/
theorem lean_workbook_12233 (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hab : 0 ≤ a + b) (hbc : 0 ≤ b + c) (hca : 0 ≤ a + c) (habc : 0 ≤ a + b + c) (h : a^2 + b^2 + c^2 + 2 * a * b * c = 5) :
  a * b * c + a + b + c + a * b + b * c + c * a ≤ 7  := by
  /-
  Given \(a, b, c \ge 0\) and \(a^2 + b^2 + c^2 + 2abc = 5\), we need to prove that \(abc + a + b + c + ab + bc + ca \le 7\).
  First, we use the given equation \(a^2 + b^2 + c^2 + 2abc = 5\). We will use non-linear arithmetic to show that the expression \(abc + a + b + c + ab + bc + ca\) is bounded above by 7.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  nlinarith [sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1), mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha,
    mul_self_nonneg (a - b), mul_self_nonneg (b - c), mul_self_nonneg (c - a)]
