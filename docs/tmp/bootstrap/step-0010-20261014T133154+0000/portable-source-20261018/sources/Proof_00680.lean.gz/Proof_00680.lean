import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ x$ , $ y$ , $ z$ be real numbers satisfying $ x^2+y^2+z^2+9=4(x+y+z)$ . Prove that \n $ x^4+y^4+z^4+16(x^2+y^2+z^2) \ge 8(x^3+y^3+z^3)+27$ \nand determine when equality holds. -/
theorem lean_workbook_12842 (x y z : ℝ) (h1 : x^2 + y^2 + z^2 + 9 = 4 * (x + y + z)) : x^4 + y^4 + z^4 + 16 * (x^2 + y^2 + z^2) ≥ 8 * (x^3 + y^3 + z^3) + 27  := by
  /-
  Given real numbers \( x \), \( y \), and \( z \) satisfying the equation \( x^2 + y^2 + z^2 + 9 = 4(x + y + z) \), we need to prove that:
  \[ x^4 + y^4 + z^4 + 16(x^2 + y^2 + z^2) \ge 8(x^3 + y^3 + z^3) + 27 \]
  and determine when equality holds.
  First, we express the inequality in a simplified form by expanding and rearranging terms. We then use the non-negativity of squares to establish the inequality. Specifically, we consider the squares of various expressions involving \( x \), \( y \), and \( z \) and use these to derive the desired inequality.
  -/
  -- Simplify the given equation and the target inequality by expanding and rearranging terms.
  simp_all only [sq, add_assoc, add_left_comm, add_right_comm, mul_add, mul_comm, mul_left_comm,
    mul_right_comm]
  -- Use the non-negativity of squares to establish the inequality.
  nlinarith [sq_nonneg (x - 1), sq_nonneg (y - 1), sq_nonneg (z - 1),
    sq_nonneg (x - 2), sq_nonneg (y - 2), sq_nonneg (z - 2),
    sq_nonneg (x - 3), sq_nonneg (y - 3), sq_nonneg (z - 3),
    sq_nonneg (x - 4), sq_nonneg (y - 4), sq_nonneg (z - 4),
    sq_nonneg (x + y + z - 3), sq_nonneg (x + y + z - 4), sq_nonneg (x + y + z - 5)]
