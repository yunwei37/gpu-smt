import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ x, y, z \in [1, 3] $ such that $ x^2+y^2+z^2=14 $ . Find the minimum of \n $ (1-\frac{y}{x})(2+\frac{z}{x}) $ -/
theorem lean_workbook_1740 (x y z : ℝ) (hx : 1 ≤ x ∧ x ≤ 3) (hy : 1 ≤ y ∧ y ≤ 3) (hz : 1 ≤ z ∧ z ≤ 3) (h : x^2 + y^2 + z^2 = 14): (1 - y/x) * (2 + z/x) ≥ -10  := by
  /-
  Given \( x, y, z \in [1, 3] \) such that \( x^2 + y^2 + z^2 = 14 \), we need to find the minimum of \( (1 - \frac{y}{x})(2 + \frac{z}{x}) \).
  To prove that \( (1 - \frac{y}{x})(2 + \frac{z}{x}) \geq -10 \), we start by considering the given constraints on \( x, y, \) and \( z \). We know that \( 1 \leq x \leq 3 \), \( 1 \leq y \leq 3 \), and \( 1 \leq z \leq 3 \). Additionally, \( x^2 + y^2 + z^2 = 14 \).
  We will use these constraints to simplify the expression \( (1 - \frac{y}{x})(2 + \frac{z}{x}) \) and show that it is at least \(-10\).
  -/
  have hx' : x ≥ 1 := by linarith
  have hx'' : x ≤ 3 := by linarith
  have hy' : y ≥ 1 := by linarith
  have hy'' : y ≤ 3 := by linarith
  have hz' : z ≥ 1 := by linarith
  have hz'' : z ≤ 3 := by linarith
  have h1 : 0 < x := by linarith
  have h2 : 0 < y := by linarith
  have h3 : 0 < z := by linarith
  field_simp [h1, h2, h3]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    nlinarith [sq_nonneg (x + y + z), sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x)]
  try nlinarith
