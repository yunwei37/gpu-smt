import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Suppose that $a,b,c,d$ are positive real numbers such that $a+b+c+d=\dfrac1a+\dfrac1b+\dfrac1c+\dfrac1d$ . Show that $a+b+c+d\geq 4$ . When does equality occur? -/
theorem lean_workbook_130 (a b c d : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d) (habc : a * b * c = 1) (h : a + b + c + d = 1 / a + 1 / b + 1 / c + 1 / d) : a + b + c + d >= 4  := by
  /-
  Given positive real numbers \(a, b, c, d\) such that \(a + b + c + d = \frac{1}{a} + \frac{1}{b} + \frac{1}{c} + \frac{1}{d}\), we need to show that \(a + b + c + d \geq 4\).
  First, we simplify the given equation by clearing denominators using the fact that \(a \cdot b \cdot c = 1\). This allows us to rewrite the equation in a more manageable form. We then use algebraic manipulations and inequalities to show that the sum \(a + b + c + d\) is at least 4.
  -/
  -- Simplify the given equation by clearing denominators using the fact that a * b * c = 1.
  field_simp [ha, hb, hc, hd, habc] at h
  -- Normalize the expression by expanding and simplifying it.
  ring_nf at h
  -- Use non-linear arithmetic to show that the sum a + b + c + d is at least 4.
  nlinarith [mul_pos ha hb, mul_pos ha hc, mul_pos ha hd, mul_pos hb hc, mul_pos hb hd, mul_pos hc hd,
    sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d), sq_nonneg (b - c), sq_nonneg (b - d),
    sq_nonneg (c - d)]
