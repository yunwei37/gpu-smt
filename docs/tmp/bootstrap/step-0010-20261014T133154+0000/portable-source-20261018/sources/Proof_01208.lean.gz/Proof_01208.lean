import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that for $a, b, c > 0$ and $a + b + c = 1$, $a^2 + b^2 + c^2 + 3abc \geq \frac{4}{9}$ using AM-GM. -/
theorem lean_workbook_15098 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = 1) : a^2 + b^2 + c^2 + 3 * a * b * c ≥ 4 / 9  := by
  /-
  To prove that for \(a, b, c > 0\) and \(a + b + c = 1\), \(a^2 + b^2 + c^2 + 3abc \geq \frac{4}{9}\), we can use the AM-GM inequality. By AM-GM, for any non-negative real numbers \(x_1, x_2, \ldots, x_n\), we have:
  \[
  \frac{x_1 + x_2 + \cdots + x_n}{n} \geq \sqrt[n]{x_1 x_2 \cdots x_n}
  \]
  Applying this to our terms, we get:
  \[
  \frac{a + b + c}{3} \geq \sqrt[3]{abc}
  \]
  Given \(a + b + c = 1\), we have:
  \[
  \frac{1}{3} \geq \sqrt[3]{abc}
  \]
  Cubing both sides, we obtain:
  \[
  \left(\frac{1}{3}\right)^3 \geq abc
  \]
  Simplifying, we find:
  \[
  \frac{1}{27} \geq abc
  \]
  Multiplying both sides by 27, we get:
  \[
  1 \geq 27abc
  \]
  Dividing both sides by 27, we have:
  \[
  \frac{1}{27} \geq abc
  \]
  Now, we need to show that \(a^2 + b^2 + c^2 + 3abc \geq \frac{4}{9}\). Using the fact that \(a + b + c = 1\), we can rewrite the inequality as:
  \[
  a^2 + b^2 + c^2 + 3abc \geq \frac{4}{9}
  \]
  By AM-GM, we know:
  \[
  a^2 + b^2 + c^2 \geq 3 \sqrt[3]{a^2 b^2 c^2}
  \]
  Since \(a + b + c = 1\), we can use the fact that \(a^2 + b^2 + c^2 \geq 3 \sqrt[3]{a^2 b^2 c^2}\) to show that:
  \[
  a^2 + b^2 + c^2 + 3abc \geq \frac{4}{9}
  \]
  -/
  -- Use AM-GM inequality to show that the sum of squares and products is at least 4/9.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a - 1 / 3), sq_nonneg (b - 1 / 3), sq_nonneg (c - 1 / 3)]
