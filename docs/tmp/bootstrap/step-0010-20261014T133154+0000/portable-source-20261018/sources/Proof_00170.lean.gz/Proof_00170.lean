import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ x$ , $ y$ , and $ z$ be non-negative real numbers satisfying $ x + y + z = 1$ . Show that $ x^2 y + y^2 z + z^2 x +xyz\leq \frac {4}{27}$ -/
theorem lean_workbook_10718 (x y z : ℝ) (hx: x ≥ 0 ∧ y ≥ 0 ∧ z ≥ 0) (h : x + y + z = 1) : x^2*y + y^2*z + z^2*x + x*y*z ≤ 4/27  := by
  /-
  Given non-negative real numbers \( x \), \( y \), and \( z \) such that \( x + y + z = 1 \), we aim to show that \( x^2 y + y^2 z + z^2 x + xyz \leq \frac{4}{27} \).
  1. **Case Analysis**: We consider different cases based on the relationships between \( x \), \( y \), and \( z \). These cases are derived from the inequalities \( x \leq y \leq z \), \( x \leq z \leq y \), \( y \leq x \leq z \), \( y \leq z \leq x \), \( z \leq x \leq y \), and \( z \leq y \leq x \).
  2. **Non-negativity and Bounds**: Utilize the non-negativity of \( x \), \( y \), and \( z \) and the fact that their sum is 1 to apply algebraic manipulations and inequalities.
  3. **Inequality Application**: Apply the inequality \( x^2 y + y^2 z + z^2 x + xyz \leq \frac{4}{27} \) by leveraging the non-negativity of squares and the given sum constraints.
  -/
  -- Consider different cases based on the relationships between x, y, and z.
  cases' le_total x y with hxy hxy <;>
  cases' le_total y z with hyz hyz <;>
  cases' le_total z x with hzx hzx <;>
  -- Use non-negativity and bounds to apply algebraic inequalities.
  nlinarith [sq_nonneg (x + y + z), sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x),
    sq_nonneg (x - 1 / 3), sq_nonneg (y - 1 / 3), sq_nonneg (z - 1 / 3)]
