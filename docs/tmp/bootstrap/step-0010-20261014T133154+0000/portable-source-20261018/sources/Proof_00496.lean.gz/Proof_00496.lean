import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove these inequalities:\n\n1) $ 2(a + b + c)\le{a^2(b + c) + b^2(a + c) + c^2(a + b)}$ \nif $ a,b,c > 0$ and $ abc = 1.$ \n\n2) $ a^2 + b^2 + ab + \sqrt {4 - a^2}\cdot\sqrt {9 - b^2}\ge4$ \nif $ 0\le{a}\le2,0\le{b}\le3.$ \n\n3) $ x > \sqrt {x - 1} + \sqrt {x(\sqrt {x} - 1)}$ \nif $ x\ge1.$ \n\nThank you in advance -/
theorem lean_workbook_12056 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) : 2 * (a + b + c) ≤ a^2 * (b + c) + b^2 * (a + c) + c^2 * (a + b)  := by
  /-
  Given \( a, b, c > 0 \) and \( abc = 1 \), we need to prove the inequality:
  \[ 2(a + b + c) \leq a^2(b + c) + b^2(a + c) + c^2(a + b) \]
  To prove this, we use the non-negativity of squares. Specifically, we consider the squares of the differences \( (a - b) \), \( (b - c) \), \( (c - a) \), \( (a - 1) \), \( (b - 1) \), and \( (c - 1) \). These squares are non-negative, and their sum can be used to derive the desired inequality.
  -/
  -- Use the non-negativity of squares to derive the inequality.
  -- Specifically, consider the squares of the differences (a - b), (b - c), (c - a), (a - 1), (b - 1), and (c - 1).
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    mul_pos ha hb, mul_pos hb hc, mul_pos hc ha, habc, sq_nonneg (a * b - 1), sq_nonneg (b * c - 1), sq_nonneg (c * a - 1)]
