import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $x\in R.$ Prove that $x^6-x^5-2x^4+x^3+x^2+1>0.$ -/
theorem lean_workbook_17181 (x : ℝ) : x^6 - x^5 - 2*x^4 + x^3 + x^2 + 1 > 0  := by
  /-
  To prove that \( x^6 - x^5 - 2x^4 + x^3 + x^2 + 1 > 0 \) for any real number \( x \), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the positivity of the given polynomial by considering the non-negativity of certain squares.
  -/
  -- Use the nlinarith tactic to prove the inequality. This tactic will consider the non-negativity of certain squares to deduce the positivity of the polynomial.
  nlinarith [sq_nonneg (x^3 - x^2), sq_nonneg (x^2 - x), sq_nonneg (x - 1),
    sq_nonneg (x^3 - x), sq_nonneg (x^2 - 1), sq_nonneg (x - 1),
    sq_nonneg (x^3 - 1), sq_nonneg (x^2 - 2), sq_nonneg (x - 2),
    sq_nonneg (x^3 - 2), sq_nonneg (x^2 - 3), sq_nonneg (x - 3),
    sq_nonneg (x^3 - 3), sq_nonneg (x^2 - 4), sq_nonneg (x - 4),
    sq_nonneg (x^3 - 4), sq_nonneg (x^2 - 5), sq_nonneg (x - 5),
    sq_nonneg (x^3 - 5), sq_nonneg (x^2 - 6), sq_nonneg (x - 6),
    sq_nonneg (x^3 - 6)]
