import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c>0 $ and $abc=1.$ Prove that\n$$\frac{ (a + 1)(b+1)(c + 1)} {(a + b + c-1 )^2}\leq 2$$ -/
theorem lean_workbook_12648 (a b c : ℝ) (ha : a > 0) (hb : b > 0) (hc : c > 0) (habc : a * b * c = 1) :  (a + 1) * (b + 1) * (c + 1) / (a + b + c - 1) ^ 2 ≤ 2  := by
  /-
  Given \(a, b, c > 0\) and \(abc = 1\), we need to prove that:
  \[
  \frac{(a + 1)(b + 1)(c + 1)}{(a + b + c - 1)^2} \leq 2
  \]
  To prove this, we will use the fact that the expression simplifies and can be bounded by 2. We will also use algebraic manipulations and inequalities to show that the expression is indeed less than or equal to 2.
  -/
  have h₀ : 0 < a * b := by nlinarith
  have h₁ : 0 < a * c := by nlinarith
  have h₂ : 0 < b * c := by nlinarith
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
  nlinarith [sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (b - c),
    mul_self_nonneg (a - 1), mul_self_nonneg (b - 1), mul_self_nonneg (c - 1)]
