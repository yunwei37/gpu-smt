import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a^2+b^2+c^2=3$ and $a,b,c>0$ . Prove that: \n $\frac{a^3}{b}+\frac{b^3}{c}+\frac{c^3}{a} \geq 3$ . -/
theorem lean_workbook_1642 (a b c : ℝ) (h : a > 0 ∧ b > 0 ∧ c > 0) (hab : a + b + c = 3) (h : a^2 + b^2 + c^2 = 3) : a^3 / b + b^3 / c + c^3 / a ≥ 3  := by
  /-
  Given \(a^2 + b^2 + c^2 = 3\) and \(a, b, c > 0\), we need to prove that:
  \[
  \frac{a^3}{b} + \frac{b^3}{c} + \frac{c^3}{a} \geq 3.
  \]
  To prove this, we use the non-linear arithmetic (nlinarith) tactic, which automatically handles inequalities involving squares and sums. Specifically, we use the fact that the square of any real number is non-negative, which helps in proving the inequality.
  -/
  -- Use non-linear arithmetic to handle the inequality involving squares and sums.
  have h₁ : 0 < a := by linarith
  have h₂ : 0 < b := by linarith
  have h₃ : 0 < c := by linarith
  have h₄ : 0 < a * b := by positivity
  have h₅ : 0 < b * c := by positivity
  have h₆ : 0 < c * a := by positivity
  field_simp [h₁, h₂, h₃]
  (first | rw [div_le_div_iff₀] | rw [le_div_iff₀] | rw [div_le_iff₀] | skip) <;>
    nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a^2 - b^2), sq_nonneg (b^2 - c^2), sq_nonneg (c^2 - a^2),
    sq_nonneg (a^2 - 1), sq_nonneg (b^2 - 1), sq_nonneg (c^2 - 1)]
  try nlinarith [h₁, h₂, h₃]
