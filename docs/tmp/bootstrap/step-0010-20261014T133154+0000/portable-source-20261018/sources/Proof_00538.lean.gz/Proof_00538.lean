import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For $a,b,c,d \in \mathbb{R}$ such that $ a^2+b^2+c^2+d^2=1 $ Prove that $ a(1+d-a)+b(1+d-b)+c(1+d-c)-d-1 \leq 0 $ -/
theorem lean_workbook_12296 (a b c d : ℝ) (h : a^2 + b^2 + c^2 + d^2 = 1) :
  a * (1 + d - a) + b * (1 + d - b) + c * (1 + d - c) - d - 1 ≤ 0  := by
  /-
  Given \(a, b, c, d \in \mathbb{R}\) such that \(a^2 + b^2 + c^2 + d^2 = 1\), we need to prove that \(a(1 + d - a) + b(1 + d - b) + c(1 + d - c) - d - 1 \leq 0\).
  To prove this, we use the non-negative property of squares. Specifically, we consider the squares of the expressions involving \(a, b, c, d\) and use the fact that these squares are non-negative to derive the desired inequality.
  -/
  -- Use the non-negative property of squares to prove the inequality.
  -- Specifically, consider the squares of the expressions involving a, b, c, d.
  nlinarith [sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1), sq_nonneg (d - 1),
    sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), sq_nonneg (a + b - 1),
    sq_nonneg (b + c - 1), sq_nonneg (c + a - 1), sq_nonneg (d + 1 - 1)]
