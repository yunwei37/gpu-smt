import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let be given $a,b,c\geq 0$ . Prove that $2(a^2+b^2+c^2)+abc+8\geq 5(a+b+c)$ -/
theorem lean_workbook_10705 (a b c : ℝ) (ha : a ≥ 0) (hb : b ≥ 0) (hc : c ≥ 0) : 2 * (a ^ 2 + b ^ 2 + c ^ 2) + a * b * c + 8 ≥ 5 * (a + b + c)  := by
  /-
  We need to prove that for non-negative real numbers \(a\), \(b\), and \(c\), the inequality \(2(a^2 + b^2 + c^2) + abc + 8 \geq 5(a + b + c)\) holds. This can be shown using non-linear arithmetic (nlinarith) by considering the non-negativity of various squared terms and products.
  -/
  -- Use non-linear arithmetic to prove the inequality by considering the non-negativity of various squared terms and products.
  nlinarith [sq_nonneg (a + b + c - 3), sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg ha hc, sq_nonneg (a - b), sq_nonneg (b - c),
    sq_nonneg (c - a), sq_nonneg (a * b - 1), sq_nonneg (b * c - 1), sq_nonneg (c * a - 1)]
