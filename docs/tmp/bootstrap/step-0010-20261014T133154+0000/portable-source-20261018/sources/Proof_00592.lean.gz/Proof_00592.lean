import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $ab+ac+ad+bc+bd+cd-abc-abd-acd-bcd <= \frac{5}{16}$ given $a, b, c, d$ are positive real numbers such that $a + b + c + d = 1$. -/
theorem lean_workbook_12487 (a b c d : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d) (hab : a + b + c + d = 1) : a * b + a * c + a * d + b * c + b * d + c * d - a * b * c - a * b * d - a * c * d - b * c * d ≤ 5 / 16  := by
  /-
  Given positive real numbers \(a, b, c, d\) such that \(a + b + c + d = 1\), we need to prove that:
  \[ ab + ac + ad + bc + bd + cd - abc - abd - acd - bcd \leq \frac{5}{16} \]
  To prove this, we use the non-linear arithmetic (nlinarith) tactic, which simplifies the expression by considering the non-negativity of squares and other algebraic properties.
  -/
  -- Use non-linear arithmetic to simplify the expression by considering the non-negativity of squares and other algebraic properties.
  nlinarith [sq_nonneg (a - 1 / 4), sq_nonneg (b - 1 / 4), sq_nonneg (c - 1 / 4), sq_nonneg (d - 1 / 4),
    sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d), sq_nonneg (b - c), sq_nonneg (b - d),
    sq_nonneg (c - d)]
