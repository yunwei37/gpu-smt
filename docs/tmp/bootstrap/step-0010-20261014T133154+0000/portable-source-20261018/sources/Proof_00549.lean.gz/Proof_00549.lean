import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If the positive real numbers $w,x,y,z$ satisfy $w+x+y+z=6$ and $w^2+x^2+y^2+z^2=12$ . Prove that $w^3+x^3+y^3+z^3\leq 30$. -/
theorem lean_workbook_12328 (w x y z : ℝ) (hw : w > 0) (hx : x > 0) (hy : y > 0) (hz : z > 0) (hwxyz : w + x + y + z = 6) (hw2x2y2z2 : w^2 + x^2 + y^2 + z^2 = 12) : w^3 + x^3 + y^3 + z^3 ≤ 30  := by
  /-
  Given positive real numbers \( w, x, y, z \) such that \( w + x + y + z = 6 \) and \( w^2 + x^2 + y^2 + z^2 = 12 \), we need to prove that \( w^3 + x^3 + y^3 + z^3 \leq 30 \).
  To prove this, we use the non-linear arithmetic (nlinarith) tactic, which can handle inequalities involving squares and sums. Specifically, we use the fact that the square of any real number is non-negative, which helps in bounding the sum of cubes.
  -/
  -- Use non-linear arithmetic to handle the inequalities involving squares and sums.
  -- The `sq_nonneg` lemmas ensure that the squares of the differences are non-negative, which helps in bounding the sum of cubes.
  nlinarith [sq_nonneg (w - 1), sq_nonneg (x - 1), sq_nonneg (y - 1), sq_nonneg (z - 1),
    sq_nonneg (w - 2), sq_nonneg (x - 2), sq_nonneg (y - 2), sq_nonneg (z - 2),
    sq_nonneg (w - 3), sq_nonneg (x - 3), sq_nonneg (y - 3), sq_nonneg (z - 3)]
