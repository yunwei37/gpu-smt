import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a,b,c>0$ . Prove that : \n $ 2(a^2+1)(b^2+1)(c^2+1) \geq (a+1)(b+1)(c+1)(abc+1)$ -/
theorem lean_workbook_15668 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) : 2 * (a^2 + 1) * (b^2 + 1) * (c^2 + 1) ≥ (a + 1) * (b + 1) * (c + 1) * (a * b * c + 1)  := by
  /-
  We need to prove that for positive real numbers \(a\), \(b\), and \(c\), the inequality \(2(a^2 + 1)(b^2 + 1)(c^2 + 1) \geq (a + 1)(b + 1)(c + 1)(abc + 1)\) holds. This can be shown using non-linear arithmetic by considering the non-negativity of various squared terms involving \(a\), \(b\), and \(c\).
  -/
  -- Use non-linear arithmetic to prove the inequality by considering the non-negativity of various squared terms.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    sq_nonneg (a * b - 1), sq_nonneg (b * c - 1), sq_nonneg (c * a - 1),
    sq_nonneg (a * b - a), sq_nonneg (b * c - b), sq_nonneg (c * a - c)]
