import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- If $0<a,b,c<2$ such that $ab+bc+ca=3$ then \n $\frac{a}{2-a} + \frac{b}{2-b} + \frac{c}{2-c}\geq 3$ (Proposed by Pham Quoc Sang) -/
theorem lean_workbook_12597 (a b c : ℝ) (ha : 0 < a ∧ a < 2) (hb : 0 < b ∧ b < 2) (hc : 0 < c ∧ c < 2) (hab : a * b + b * c + c * a = 3) : a / (2 - a) + b / (2 - b) + c / (2 - c) ≥ 3  := by
  /-
  Given \(0 < a, b, c < 2\) such that \(ab + bc + ca = 3\), we need to show that:
  \[
  \frac{a}{2 - a} + \frac{b}{2 - b} + \frac{c}{2 - c} \geq 3
  \]
  To prove this, we will use the fact that each term \(\frac{a}{2 - a}\), \(\frac{b}{2 - b}\), and \(\frac{c}{2 - c}\) is non-negative and that their sum is at least 3.
  -/
  have h₁ : 0 < 2 - a := by linarith
  have h₂ : 0 < 2 - b := by linarith
  have h₃ : 0 < 2 - c := by linarith
  have h₄ : 0 < a * b := by nlinarith
  have h₅ : 0 < b * c := by nlinarith
  have h₆ : 0 < c * a := by nlinarith
  have h₇ : 0 < (2 - a) * (2 - b) := by nlinarith
  have h₈ : 0 < (2 - b) * (2 - c) := by nlinarith
  have h₉ : 0 < (2 - c) * (2 - a) := by nlinarith
  have h₁₀ : 0 < a * b * c := by nlinarith
  field_simp [h₁, h₂, h₃]
  (try rw [le_div_iff₀ (by positivity)])
  try rw [← sub_nonneg]
  ring_nf
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
