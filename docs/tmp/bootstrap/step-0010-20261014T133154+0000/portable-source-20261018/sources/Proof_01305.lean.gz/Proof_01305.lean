import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c\geq 0$. If $a+b+c=3$, prove that: $a^2b+b^2c+c^2a+abc\leq 4$ -/
theorem lean_workbook_15489 (a b c : ℝ) (ha : a ≥ 0 ∧ b ≥ 0 ∧ c ≥ 0) (hab : a + b + c = 3) : a^2 * b + b^2 * c + c^2 * a + a * b * c ≤ 4  := by
  /-
  Given \(a, b, c \geq 0\) and \(a + b + c = 3\), we need to prove that \(a^2b + b^2c + c^2a + abc \leq 4\).
  1. **Case Analysis**: We analyze different cases based on the relationships between \(a, b,\) and \(c\).
  2. **Nonlinear Arithmetic**: For each case, we use nonlinear arithmetic to verify the inequality.
  -/
  -- We need to prove that a^2 * b + b^2 * c + c^2 * a + a * b * c ≤ 4 given a + b + c = 3.
  have h₀ : a^2 * b + b^2 * c + c^2 * a + a * b * c ≤ 4 := by
    -- Consider different cases for the relationships between a, b, and c.
    cases' le_total a b with hab hab <;>
    cases' le_total b c with hbc hbc <;>
    cases' le_total c a with hac hac <;>
    -- Use nonlinear arithmetic to verify the inequality for each case.
    nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
      mul_self_nonneg (a - 1), mul_self_nonneg (b - 1), mul_self_nonneg (c - 1)]
  -- The result follows from the nonlinear arithmetic verification.
  exact h₀
