import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- The inequality can be proved in the following way: $ \large\begin{array}{rcl} \frac{2}{(2+a)^3}+\frac{1}{\left (2+\frac{1}{a^2}\right )^3}&\ge &\frac{1}{9}\qquad\Leftrightarrow\\ & & \\\frac{a^9+6a^8+12a^7+24a^6+24a^4+12a^2+2}{(2+a)^3(2a^2+1)^3}&\ge &\frac{1}{9}\qquad\Leftrightarrow\\ & & \\\9\left (a^9+6a^8+12a^7+24a^6+24a^4+12a^2+2\right )-(2+a)^3(2a^2+1)^3&\ge &0\qquad\Leftrightarrow\\ & & \\\a^9+6a^8+80a^6-150a^5+84a^4-73a^3+54a^2-12a+10&\ge &0\qquad\Leftrightarrow\\ & & \\\(a-1)^2\cdot (a^7+8a^6+15a^5+102a^4+39a^3+60a^2+8a+10)&\ge &0. \end{array}$ But this is true for all $ a>0$ . -/
theorem lean_workbook_14369  (a : ℝ)
  (h₀ : 0 < a) :
  (a - 1)^2 * (a^7 + 8 * a^6 + 15 * a^5 + 102 * a^4 + 39 * a^3 + 60 * a^2 + 8 * a + 10) ≥ 0  := by
  /-
  The inequality can be proved in the following way:
  \[
  \frac{2}{(2+a)^3} + \frac{1}{(2 + \frac{1}{a^2})^3} \ge \frac{1}{9}
  \]
  This is equivalent to:
  \[
  \frac{a^9 + 6a^8 + 12a^7 + 24a^6 + 24a^4 + 12a^2 + 2}{(2+a)^3(2a^2+1)^3} \ge \frac{1}{9}
  \]
  Which simplifies to:
  \[
  9 \left( a^9 + 6a^8 + 12a^7 + 24a^6 + 24a^4 + 12a^2 + 2 \right) - (2+a)^3 (2a^2+1)^3 \ge 0
  \]
  Further simplifying to:
  \[
  a^9 + 6a^8 + 80a^6 - 150a^5 + 84a^4 - 73a^3 + 54a^2 - 12a + 10 \ge 0
  \]
  Finally, we prove that:
  \[
  (a - 1)^2 \cdot (a^7 + 8a^6 + 15a^5 + 102a^4 + 39a^3 + 60a^2 + 8a + 10) \ge 0
  \]
  This is true for all \( a > 0 \).
  -/
  -- Apply the product of non-negative numbers is non-negative.
  apply mul_nonneg
  -- The square of any real number is non-negative.
  apply pow_two_nonneg
  -- Use linear arithmetic to prove the non-negativity of the polynomial.
  nlinarith [sq_nonneg (a - 1), sq_nonneg (a + 1), sq_nonneg (a^2 - 1), sq_nonneg (a^2 + 1), sq_nonneg (a^3 - 1), sq_nonneg (a^3 + 1), sq_nonneg (a^4 - 1), sq_nonneg (a^4 + 1), sq_nonneg (a^5 - 1), sq_nonneg (a^5 + 1), sq_nonneg (a^6 - 1), sq_nonneg (a^6 + 1), sq_nonneg (a^7 - 1), sq_nonneg (a^7 + 1), sq_nonneg (a^8 - 1), sq_nonneg (a^8 + 1), sq_nonneg (a^9 - 1), sq_nonneg (a^9 + 1)]
