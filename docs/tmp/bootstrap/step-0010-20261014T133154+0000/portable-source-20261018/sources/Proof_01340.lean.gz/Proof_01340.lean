import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let a,b,c $\geq$ 0 such that a+b+c=6. Prove that: $ a^2 + 2b^2 + 3c^2 + abc \geq 24$ -/
theorem lean_workbook_15632 (a b c : ℝ) (ha : a ≥ 0) (hb : b ≥ 0) (hc : c ≥ 0) (habc : a + b + c = 6) : a^2 + 2 * b^2 + 3 * c^2 + a * b * c ≥ 24  := by
  /-
  We need to prove that for non-negative real numbers \(a\), \(b\), and \(c\) such that \(a + b + c = 6\), the inequality \(a^2 + 2b^2 + 3c^2 + abc \geq 24\) holds. This can be shown using non-linear arithmetic by considering the non-negativity of squares and other non-negative terms.
  -/
  -- Use non-linear arithmetic to handle the inequality, considering the non-negativity of squares and other non-negative terms.
  nlinarith [sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha, sq_nonneg (a - 2 * b), sq_nonneg (b - 2 * c),
    sq_nonneg (c - 2 * a), sq_nonneg (a + b - 2), sq_nonneg (b + c - 2), sq_nonneg (c + a - 2)]
