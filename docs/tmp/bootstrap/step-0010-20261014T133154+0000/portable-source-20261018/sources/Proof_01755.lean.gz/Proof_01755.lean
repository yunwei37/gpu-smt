import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For $x,y,z\ge 0$ satisfied $x+y+z=3$ . Prove that: $(x^2+2)(y^2+2)(z^2+5)\ge \frac{729}{16}$ -/
theorem lean_workbook_17360 (x y z : ℝ) (hx : x ≥ 0) (hy : y ≥ 0) (hz : z ≥ 0) (h : x + y + z = 3) :(x^2 + 2) * (y^2 + 2) * (z^2 + 5) ≥ 729 / 16  := by
  /-
  We need to prove that for non-negative real numbers \( x, y, z \) such that \( x + y + z = 3 \), the inequality \( (x^2 + 2)(y^2 + 2)(z^2 + 5) \geq \frac{729}{16} \) holds.
  To do this, we will use the non-linear arithmetic (nlinarith) tactic, which automatically verifies inequalities involving polynomials. We will provide specific non-negativity conditions to ensure that the terms involved are valid for the given constraints.
  -/
  -- Use nlinarith to verify the inequality. We provide non-negativity conditions for the squares and products.
  nlinarith [sq_nonneg (x - 1 / 2), sq_nonneg (y - 1 / 2), sq_nonneg (z - 1 / 2),
    sq_nonneg (x * y - 1 / 4), sq_nonneg (y * z - 1 / 4), sq_nonneg (z * x - 1 / 4),
    sq_nonneg (x * y * z - 1 / 8), hx, hy, hz, h, sq_nonneg (x - y), sq_nonneg (y - z),
    sq_nonneg (z - x)]
