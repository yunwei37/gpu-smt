import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that: $x^2y+y^2z+z^2x\leq \frac{4}{27}$ given $x, y, z \geq 0$ and $x+y+z=1$. -/
theorem lean_workbook_11347 (x y z : ℝ) (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z) (h : x + y + z = 1) : x^2*y + y^2*z + z^2*x ≤ 4 / 27  := by
  /-
  Given \( x, y, z \geq 0 \) and \( x + y + z = 1 \), we need to prove that \( x^2 y + y^2 z + z^2 x \leq \frac{4}{27} \).
  1. **Case Analysis**: We consider different cases based on the relationships between \( x, y, \) and \( z \).
  2. **Nonlinear Arithmetic**: For each case, we use nonlinear arithmetic to derive the desired inequality.
  -/
  -- Consider different cases based on the relationships between x, y, and z.
  cases' le_total x y with hxy hxy <;>
  cases' le_total y z with hyz hyz <;>
  cases' le_total z x with hzx hzx <;>
  -- Use nonlinear arithmetic to derive the inequality for each case.
  nlinarith [sq_nonneg (x - 1 / 3), sq_nonneg (y - 1 / 3), sq_nonneg (z - 1 / 3),
    sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x)]
