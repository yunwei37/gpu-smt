import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove true for all $x\in\Re$ in the following equation - \n $ x^6-6x+5\geq 0 $ -/
theorem lean_workbook_11293 (x : ℝ) : x^6-6*x+5 ≥ 0  := by
  /-
  To prove that \( x^6 - 6x + 5 \geq 0 \) for all \( x \in \mathbb{R} \), we can use the non-linear arithmetic (nlinarith) tactic in Lean4. This tactic is designed to handle inequalities involving polynomials and can automatically deduce the non-negativity of the given expression by considering the non-negativity of certain squares. Specifically, we will use the fact that the square of any real number is non-negative, and combine these facts to establish the desired inequality.
  -/
  -- Use the nlinarith tactic to prove the inequality.
  -- The nlinarith tactic will consider the non-negativity of certain squares to deduce the result.
  nlinarith [sq_nonneg (x^2 - 1), sq_nonneg (x^3 - 1), sq_nonneg (x^2 - 2), sq_nonneg (x - 1),
    sq_nonneg (x + 1), sq_nonneg (x^3 - 2), sq_nonneg (x^2 - 3), sq_nonneg (x - 2),
    sq_nonneg (x + 2), sq_nonneg (x^3 - 3), sq_nonneg (x^2 - 4), sq_nonneg (x - 3),
    sq_nonneg (x + 3), sq_nonneg (x^3 - 4), sq_nonneg (x^2 - 5), sq_nonneg (x - 4),
    sq_nonneg (x + 4), sq_nonneg (x^3 - 5), sq_nonneg (x^2 - 6), sq_nonneg (x - 5),
    sq_nonneg (x + 5), sq_nonneg (x^3 - 6), sq_nonneg (x^2 - 7), sq_nonneg (x - 6),
    sq_nonneg (x + 6), sq_nonneg (x^3 - 7), sq_nonneg (x^2 - 8), sq_nonneg (x - 7),
    sq_nonneg (x + 7), sq_nonneg (x^3 - 8), sq_nonneg (x^2 - 9), sq_nonneg (x - 8),
    sq_nonneg (x + 8), sq_nonneg (x^3 - 9), sq_nonneg (x^2 - 10), sq_nonneg (x - 9),
    sq_nonneg (x + 9), sq_nonneg (x^3 - 10)]
