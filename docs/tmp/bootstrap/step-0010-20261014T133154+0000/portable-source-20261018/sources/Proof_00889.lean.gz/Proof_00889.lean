import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c,d>0$ and $a+b+c+d=1$ . Then, \n $16(a^4+b^4+c^4+d^4)+8(a^3+b^3+c^3+d^3)-3(a^2+b^2+c^2+d^2)\ge 0$ . -/
theorem lean_workbook_13751 (a b c d : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d) (habc : a + b + c + d = 1) :(16 * (a ^ 4 + b ^ 4 + c ^ 4 + d ^ 4) + 8 * (a ^ 3 + b ^ 3 + c ^ 3 + d ^ 3) - 3 * (a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2)) ≥ 0  := by
  /-
  Given \(a, b, c, d > 0\) and \(a + b + c + d = 1\), we need to show that:
  \[ 16(a^4 + b^4 + c^4 + d^4) + 8(a^3 + b^3 + c^3 + d^3) - 3(a^2 + b^2 + c^2 + d^2) \ge 0 \]
  To prove this, we use the non-negativity of squares and some algebraic manipulations. Specifically, we consider the non-negativity of various expressions involving \(a, b, c,\) and \(d\). By leveraging the fact that the square of any real number is non-negative, we can establish the desired inequality.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- We use the non-negativity of squares of various expressions involving a, b, c, and d.
  nlinarith [sq_nonneg (a - 1 / 4), sq_nonneg (b - 1 / 4), sq_nonneg (c - 1 / 4), sq_nonneg (d - 1 / 4),
    sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - d), sq_nonneg (d - a),
    sq_nonneg (a + b + c + d - 1)]
