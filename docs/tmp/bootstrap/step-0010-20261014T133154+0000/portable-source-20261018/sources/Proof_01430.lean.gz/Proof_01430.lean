import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Given $a, b, c \geq 0$ and $a^2 + b^2 + c^2 = 3$. Prove that: $a^3b + b^3c + c^3a + abc(a + b + c) \leq 2(a + b + c)$ -/
theorem lean_workbook_16008 (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hab : a^2 + b^2 + c^2 = 3) : a^3 * b + b^3 * c + c^3 * a + a * b * c * (a + b + c) ≤ 2 * (a + b + c)  := by
  /-
  Given \(a, b, c \geq 0\) and \(a^2 + b^2 + c^2 = 3\), we need to prove that:
  \[ a^3b + b^3c + c^3a + abc(a + b + c) \leq 2(a + b + c) \]
  To prove this, we use the non-linear arithmetic (nlinarith) tactic, which automatically handles inequalities involving polynomials. We provide several non-negative terms to help the tactic derive the desired inequality. Specifically, we use the fact that the square of any real number is non-negative, and the product of non-negative numbers is also non-negative.
  -/
  -- Use non-linear arithmetic to handle the inequality involving polynomials.
  -- We provide several non-negative terms to help the tactic derive the desired inequality.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a), mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha,
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
