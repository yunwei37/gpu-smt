import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For $a,b,c\ge 0,a+b+c+ab+bc+ca=6$ prove that: $a^2+b^2+c^2+abc\ge 4$ -/
theorem lean_workbook_15278 (a b c : ℝ) (ha : a ≥ 0) (hb : b ≥ 0) (hc : c ≥ 0) (hab : a + b + c + a * b + b * c + a * c = 6) : a ^ 2 + b ^ 2 + c ^ 2 + a * b * c ≥ 4  := by
  /-
  Given \(a, b, c \ge 0\) such that \(a + b + c + ab + bc + ca = 6\), we need to prove that \(a^2 + b^2 + c^2 + abc \ge 4\). We will use the non-linear arithmetic (nlinarith) tactic to handle this proof. The tactic will consider the non-negativity of squares and other non-negative expressions to derive the desired inequality.
  -/
  -- Use the non-linear arithmetic tactic to handle the proof.
  -- This tactic will consider the non-negativity of squares and other non-negative expressions to derive the desired inequality.
  nlinarith [sq_nonneg (a + b + c), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha, hab, sq_nonneg (a - 1), sq_nonneg (b - 1),
    sq_nonneg (c - 1)]
