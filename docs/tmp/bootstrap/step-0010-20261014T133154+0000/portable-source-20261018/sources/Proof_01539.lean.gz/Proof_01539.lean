import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a, b, c \ge -1 $ satisfy $ : abc \ge a+b+c $ .We need prove : $a^2+b^2+c^2 \ge \sqrt{3}(a+b+c).$ -/
theorem lean_workbook_16434 (a b c : ℝ) (hab : a ≥ -1 ∧ b ≥ -1 ∧ c ≥ -1)(h : a * b * c ≥ a + b + c) : a ^ 2 + b ^ 2 + c ^ 2 ≥ Real.sqrt 3 * (a + b + c)  := by
  /-
  Given \( a, b, c \ge -1 \) such that \( abc \ge a + b + c \), we need to prove that \( a^2 + b^2 + c^2 \ge \sqrt{3}(a + b + c) \).
  1. Start by considering the given inequality \( abc \ge a + b + c \).
  2. Normalize the expression using algebraic manipulation.
  3. Use the fact that the square root of 3 is non-negative to apply algebraic inequalities.
  4. Combine these inequalities to derive the desired result.
  -/
  -- Normalize the expression using algebraic manipulation.
  ring_nf
  -- Use the fact that the square root of 3 is non-negative to apply algebraic inequalities.
  have h₀ : Real.sqrt 3 ≥ 0 := by apply Real.sqrt_nonneg
  -- Combine these inequalities to derive the desired result.
  nlinarith [sq_sqrt (show (0 : ℝ) ≤ 3 by norm_num),
    sq_nonneg (a - Real.sqrt 3 / 3),
    sq_nonneg (b - Real.sqrt 3 / 3),
    sq_nonneg (c - Real.sqrt 3 / 3),
    sq_nonneg (a - b),
    sq_nonneg (b - c),
    sq_nonneg (c - a)]
