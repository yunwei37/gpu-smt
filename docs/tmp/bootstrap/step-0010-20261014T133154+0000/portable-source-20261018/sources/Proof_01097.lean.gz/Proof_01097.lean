import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that for positive reals $a,b,c$ with sum 1 ,\n $\sqrt{a+\frac{(b-c)^2}{4}} + \sqrt{b}+\sqrt{c} \le \sqrt{3}$ -/
theorem lean_workbook_1460 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hab : a + b + c = 1) : √(a + (b - c) ^ 2 / 4) + √b + √c ≤ √3  := by
  /-
  To prove the inequality \( \sqrt{a + \frac{(b - c)^2}{4}} + \sqrt{b} + \sqrt{c} \le \sqrt{3} \) for positive reals \(a, b, c\) with sum 1, we proceed as follows:
  1. **Establish bounds for the terms**: We need to show that each term inside the square root is non-negative and less than or equal to 1.
  2. **Simplify the expression**: Use algebraic manipulation and properties of square roots to simplify the expression.
  3. **Apply numerical inequalities**: Use numerical methods to establish the desired inequality.
  -/
  -- We start by establishing that each term inside the square root is non-negative.
  have h₀ : 0 ≤ a + (b - c) ^ 2 / 4 := by
    -- Since a, b, c are positive, a is non-negative.
    nlinarith [ha, hb, hc, hab]
  have h₁ : 0 ≤ b := by nlinarith [ha, hb, hc, hab]
  have h₂ : 0 ≤ c := by nlinarith [ha, hb, hc, hab]
  -- We also establish that each term inside the square root is less than or equal to 1.
  have h₃ : a + (b - c) ^ 2 / 4 ≤ 1 := by
    nlinarith [ha, hb, hc, hab]
  have h₄ : b ≤ 1 := by nlinarith [ha, hb, hc, hab]
  have h₅ : c ≤ 1 := by nlinarith [ha, hb, hc, hab]
  -- We use the fact that the square root function is non-negative and apply numerical inequalities to establish the desired inequality.
  apply le_sqrt_of_sq_le
  nlinarith [sq_sqrt (show 0 ≤ a + (b - c) ^ 2 / 4 from h₀),
    sq_sqrt (show 0 ≤ b from h₁),
    sq_sqrt (show 0 ≤ c from h₂),
    sq_nonneg (√(a + (b - c) ^ 2 / 4) - √b),
    sq_nonneg (√b - √c),
    sq_nonneg (√c - √(a + (b - c) ^ 2 / 4))]
