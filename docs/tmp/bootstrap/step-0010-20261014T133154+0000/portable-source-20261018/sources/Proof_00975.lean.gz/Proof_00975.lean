import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c>0$ and $a+b^2+c=1.$ Prove that $(1-a^2)^2+(1-b^2)^2+(1-c^2)^2\geq \frac{7}{4}$ -/
theorem lean_workbook_14100 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = 1) : (1 - a ^ 2) ^ 2 + (1 - b ^ 2) ^ 2 + (1 - c ^ 2) ^ 2 ≥ 7 / 4  := by
  /-
  Given \( a, b, c > 0 \) and \( a + b^2 + c = 1 \), we need to prove that \( (1 - a^2)^2 + (1 - b^2)^2 + (1 - c^2)^2 \geq \frac{7}{4} \).
  To prove this, we use the non-negativity of squares and some algebraic manipulations. Specifically, we consider the expressions \( (a - b)^2 \), \( (b - c)^2 \), \( (c - a)^2 \), \( (a + b)^2 \), \( (b + c)^2 \), and \( (c + a)^2 \). These expressions are non-negative, and by summing them up, we can derive the desired inequality.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- We consider the non-negativity of several squared expressions involving a, b, and c.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a - 1 / 2), sq_nonneg (b - 1 / 2), sq_nonneg (c - 1 / 2)]
