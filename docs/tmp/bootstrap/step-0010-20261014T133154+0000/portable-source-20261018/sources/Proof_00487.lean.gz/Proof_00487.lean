import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c> 0$ and $a+b+c=ab+bc+ca .$ Prove that \n $$a(a^2+b^2)+b(b^2+c^2)+c(c^2+a^2) \geq 6$$ -/
theorem lean_workbook_12039 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hab : a + b + c = a * b + b * c + c * a) : a * (a ^ 2 + b ^ 2) + b * (b ^ 2 + c ^ 2) + c * (c ^ 2 + a ^ 2) ≥ 6  := by
  /-
  Given \(a, b, c > 0\) and \(a + b + c = ab + bc + ca\), we need to prove that:
  \[ a(a^2 + b^2) + b(b^2 + c^2) + c(c^2 + a^2) \geq 6 \]
  To prove this, we use the non-negativity of squares. Specifically, we consider the squares of the differences \(a - b\), \(b - c\), and \(c - a\). Since these squares are non-negative, we can derive the desired inequality by summing these expressions and simplifying.
  -/
  -- Use the non-negativity of squares to derive the inequality.
  -- Specifically, consider the squares of (a - b), (b - c), and (c - a).
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
