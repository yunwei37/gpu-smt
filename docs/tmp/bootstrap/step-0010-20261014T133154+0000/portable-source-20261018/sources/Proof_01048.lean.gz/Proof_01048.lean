import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let be given $a,b,c\geq 0$ . Prove that $2(a^2+b^2+c^2)+abc+8\geq 5(a+b+c)$ -/
theorem lean_workbook_14372 (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) : 2 * (a ^ 2 + b ^ 2 + c ^ 2) + a * b * c + 8 ≥ 5 * (a + b + c)  := by
  /-
  We need to prove that for non-negative real numbers \(a\), \(b\), and \(c\), the inequality \(2(a^2 + b^2 + c^2) + abc + 8 \geq 5(a + b + c)\) holds. This can be shown using non-linear arithmetic (nlinarith) by considering the non-negativity of the squares of the differences \(a + b + c - 3\), \(a - 1\), \(b - 1\), \(c - 1\), and the non-negativity of the expressions \(a + b - 2\), \(b + c - 2\), \(c + a - 2\), \(a + b + c - 4\), and \(a + b + c - 5\).
  -/
  -- Use non-linear arithmetic to handle the inequality by considering the non-negativity of various expressions.
  nlinarith [sq_nonneg (a + b + c - 3), sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    mul_nonneg ha hb, mul_nonneg hb hc, mul_nonneg hc ha,
    sq_nonneg (a + b - 2), sq_nonneg (b + c - 2), sq_nonneg (c + a - 2),
    sq_nonneg (a + b + c - 4), sq_nonneg (a + b + c - 5)]
