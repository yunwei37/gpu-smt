import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $ a,b,c \geq 0 $ with $ a+b+c=3 $ , \n $ (a^{2}+1)(b^{2}+1)(c^{2}+1)\geq (a+1)(b+1)(c+1) $ -/
theorem lean_workbook_17085 (a b c : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hab : a + b + c = 3) : (a^2 + 1) * (b^2 + 1) * (c^2 + 1) ≥ (a + 1) * (b + 1) * (c + 1)  := by
  /-
  Given \( a, b, c \geq 0 \) with \( a + b + c = 3 \), we need to show that \( (a^2 + 1)(b^2 + 1)(c^2 + 1) \geq (a + 1)(b + 1)(c + 1) \).
  To prove this inequality, we can use the non-linear arithmetic (nlinarith) tactic, which automatically handles inequalities involving polynomials. Specifically, we will use the fact that the square of any real number is non-negative, which will help in proving the inequality.
  -/
  -- Use nlinarith to handle the inequality, providing non-negativity lemmas for squares.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1),
    sq_nonneg (a * b - 1), sq_nonneg (b * c - 1), sq_nonneg (c * a - 1),
    sq_nonneg (a * b * c - 1)]
