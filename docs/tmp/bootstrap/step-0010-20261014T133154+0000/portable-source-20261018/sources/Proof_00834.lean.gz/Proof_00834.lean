import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Suppose $ a,b,c,d,e \in \mathbb{R}, a + b + c + d + e = 5, a^2 + b^2 + c^2 + d^2 + e^2 = 10$ \nFind the range of $ e$ . -/
theorem lean_workbook_13498 (a b c d e : ℝ) (h₁ : a + b + c + d + e = 5) (h₂ : a^2 + b^2 + c^2 + d^2 + e^2 = 10) : -1 ≤ e ∧ e ≤ 3  := by
  /-
  Given \( a, b, c, d, e \in \mathbb{R} \) with the conditions \( a + b + c + d + e = 5 \) and \( a^2 + b^2 + c^2 + d^2 + e^2 = 10 \), we need to find the range of \( e \).
  First, we use the given conditions to derive bounds for \( e \). We know that the sum of the squares of \( a, b, c, d \) and \( e \) is 10, and their sum is 5. We can use these conditions to establish the bounds for \( e \).
  By the Cauchy-Schwarz inequality, we have:
  \[ (a + b + c + d + e)^2 \leq 5(a^2 + b^2 + c^2 + d^2 + e^2) \]
  Substituting the given values:
  \[ 5^2 \leq 5 \cdot 10 \]
  \[ 25 \leq 50 \]
  This inequality holds, and it helps us to understand the constraints on \( e \).
  Next, we use the fact that the sum of the squares of \( a, b, c, d \) and \( e \) is 10, and their sum is 5. We can use these conditions to establish the bounds for \( e \).
  By the AM-GM inequality, we have:
  \[ \frac{a + b + c + d + e}{5} \geq \sqrt[5]{a b c d e} \]
  Substituting the given values:
  \[ \frac{5}{5} \geq \sqrt[5]{a b c d e} \]
  \[ 1 \geq \sqrt[5]{a b c d e} \]
  This inequality also holds, and it helps us to understand the constraints on \( e \).
  Combining these results, we find that \( -1 \leq e \leq 3 \).
  -/
  constructor
  -- We need to prove both -1 ≤ e and e ≤ 3.
  all_goals
    -- Use the given conditions and the Cauchy-Schwarz inequality to derive bounds for e.
    nlinarith [sq_nonneg (a + b + c + d), h₁, h₂, sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d),
      sq_nonneg (b - c), sq_nonneg (b - d), sq_nonneg (c - d)]
