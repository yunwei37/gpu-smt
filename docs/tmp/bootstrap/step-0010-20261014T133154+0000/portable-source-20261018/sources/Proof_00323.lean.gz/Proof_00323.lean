import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- a,b,c>0; \ \ \ a^2+b^2+c^2=3 . Prove that $ a^4+b^4+c^4+(a+b)(b+c)(c+a)\ge 4abc+ 7 $ -/
theorem lean_workbook_11332 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a * b * c = 1) (h : a^2 + b^2 + c^2 = 3) : a^4 + b^4 + c^4 + (a + b) * (b + c) * (c + a) ≥ 4 * a * b * c + 7  := by
  /-
  Given \(a, b, c > 0\) and \(a^2 + b^2 + c^2 = 3\), we need to prove that:
  \[ a^4 + b^4 + c^4 + (a + b)(b + c)(c + a) \ge 4abc + 7 \]
  To prove this, we use the non-negativity of squares and some algebraic manipulations. Specifically, we consider the non-negativity of various expressions involving \(a, b,\) and \(c\). By leveraging the properties of non-negative numbers and the given conditions, we can establish the desired inequality.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- We consider the non-negativity of various squares and other expressions.
  nlinarith [sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a),
    sq_nonneg (a + b), sq_nonneg (b + c), sq_nonneg (c + a),
    sq_nonneg (a - 1), sq_nonneg (b - 1), sq_nonneg (c - 1)]
