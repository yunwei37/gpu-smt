import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that: $ \sqrt{a-a^{2}}+\sqrt{b-b^{2}}+\sqrt{c-c^{2}}\le\sqrt 2. $ where $ a,b,c $ are positive real numbers and $ a+b+c = 1. $ -/
theorem lean_workbook_13646 (a b c : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (habc : a + b + c = 1) : (Real.sqrt (a - a^2) + Real.sqrt (b - b^2) + Real.sqrt (c - c^2)) ≤ Real.sqrt 2  := by
  /-
  To prove the inequality \( \sqrt{a-a^{2}}+\sqrt{b-b^{2}}+\sqrt{c-c^{2}}\le\sqrt 2 \) where \( a, b, c \) are positive real numbers and \( a + b + c = 1 \), we can use the properties of square roots and the fact that the sum of non-negative numbers is bounded by a certain value. Specifically, we will use the fact that the square root function is increasing and that the sum of non-negative numbers is non-negative.
  -/
  -- Apply the lemma that if the difference of two expressions is non-negative, then the first expression is less than or equal to the second.
  apply le_sqrt_of_sq_le
  -- Use non-linear arithmetic to prove the inequality.
  nlinarith [sq_sqrt (show 0 ≤ a - a^2 by nlinarith), sq_sqrt (show 0 ≤ b - b^2 by nlinarith), sq_sqrt (show 0 ≤ c - c^2 by nlinarith),
    sq_nonneg (Real.sqrt (a - a^2) - Real.sqrt (b - b^2)), sq_nonneg (Real.sqrt (b - b^2) - Real.sqrt (c - c^2)),
    sq_nonneg (Real.sqrt (c - c^2) - Real.sqrt (a - a^2)), sq_nonneg (a - b), sq_nonneg (b - c), sq_nonneg (c - a)]
