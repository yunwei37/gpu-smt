import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that if $a,b,c,d>0$ and $abcd=2$ , then $a^2+b^2+c^2+d^2+ab+ac+ad+bc+bd+cd>14$ . -/
theorem lean_workbook_11626 (a b c d : ℝ) (hab : a > 0 ∧ b > 0 ∧ c > 0 ∧ d > 0 ∧ a * b * c * d = 2) : a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 + a * b + a * c + a * d + b * c + b * d + c * d > 14  := by
  /-
  Given \(a, b, c, d > 0\) and \(abcd = 2\), we need to prove that:
  \[ a^2 + b^2 + c^2 + d^2 + ab + ac + ad + bc + bd + cd > 14 \]
  To prove this, we use the non-negativity of squares and the fact that all terms are positive. By considering the squares of the differences between each pair of variables, we can derive the desired inequality.
  -/
  -- Use non-linear arithmetic to prove the inequality.
  -- We use the non-negativity of squares of differences between each pair of variables.
  nlinarith [sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d), sq_nonneg (b - c), sq_nonneg (b - d), sq_nonneg (c - d),
    mul_pos hab.1 hab.2.1, mul_pos hab.1 hab.2.2.1, mul_pos hab.1 hab.2.2.2.1, mul_pos hab.2.1 hab.2.2.1, mul_pos hab.2.1 hab.2.2.2.1,
    mul_pos hab.2.2.1 hab.2.2.2.1]
