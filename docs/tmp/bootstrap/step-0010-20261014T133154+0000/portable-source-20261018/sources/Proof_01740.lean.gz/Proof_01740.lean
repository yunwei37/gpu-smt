import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $a,b,c,d$ are positive numbers, such that $ 2(a+b+c+d) \ge abcd $ . Prove that $ a^2+b^2+c^2+d^2 \ge abcd $ -/
theorem lean_workbook_17310 (a b c d : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d) (habc : a * b * c * d ≤ 2 * (a + b + c + d)) : a^2 + b^2 + c^2 + d^2 ≥ a * b * c * d  := by
  /-
  Given positive numbers \(a, b, c, d\) such that \(2(a + b + c + d) \ge abcd\), we need to prove that \(a^2 + b^2 + c^2 + d^2 \ge abcd\).
  To prove this, we use the non-negativity of squares. Specifically, we consider the squares of the differences \(a - b\), \(a - c\), \(a - d\), \(b - c\), \(b - d\), \(c - d\), and the non-negativity of the products \((a - b)^2\), \((a - c)^2\), \((a - d)^2\), \((b - c)^2\), \((b - d)^2\), and \((c - d)^2\). These non-negative terms, when combined appropriately, will lead to the desired inequality.
  -/
  -- Use the non-negativity of squares to establish the inequality.
  -- Specifically, consider the squares of the differences and their non-negativity.
  nlinarith [sq_nonneg (a - b), sq_nonneg (a - c), sq_nonneg (a - d), sq_nonneg (b - c), sq_nonneg (b - d), sq_nonneg (c - d),
    mul_nonneg (sub_nonneg.mpr ha.le) (sub_nonneg.mpr hb.le),
    mul_nonneg (sub_nonneg.mpr ha.le) (sub_nonneg.mpr hc.le),
    mul_nonneg (sub_nonneg.mpr ha.le) (sub_nonneg.mpr hd.le),
    mul_nonneg (sub_nonneg.mpr hb.le) (sub_nonneg.mpr hc.le),
    mul_nonneg (sub_nonneg.mpr hb.le) (sub_nonneg.mpr hd.le),
    mul_nonneg (sub_nonneg.mpr hc.le) (sub_nonneg.mpr hd.le)]
