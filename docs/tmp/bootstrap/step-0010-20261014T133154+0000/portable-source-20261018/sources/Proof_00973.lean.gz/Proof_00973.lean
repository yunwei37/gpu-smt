import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- For $a,b,c,d,e\in[0,1]$ prove: $(1+a+b+c+d+e)^2 \geq 4(a^2+b^2+c^2+d^2+e^2)$ -/
theorem lean_workbook_14097 (a b c d e : ℝ) (ha : a ∈ Set.Icc 0 1) (hb : b ∈ Set.Icc 0 1) (hc : c ∈ Set.Icc 0 1) (hd : d ∈ Set.Icc 0 1) (he : e ∈ Set.Icc 0 1) : (1 + a + b + c + d + e) ^ 2 ≥ 4 * (a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2 + e ^ 2)  := by
  /-
  To prove the inequality \((1 + a + b + c + d + e)^2 \geq 4(a^2 + b^2 + c^2 + d^2 + e^2)\) for \(a, b, c, d, e \in [0, 1]\), we can use the fact that each of \(a, b, c, d, e\) is between 0 and 1. This allows us to apply non-linear arithmetic to verify the inequality. Specifically, we can use the constraints on \(a, b, c, d, e\) to ensure that the terms \(a^2, b^2, c^2, d^2, e^2\) are non-negative and bounded by the squares of the respective values within the interval \([0, 1]\).
  -/
  -- Extract the bounds for a, b, c, d, e from the given conditions.
  rcases ha with ⟨ha_left, ha_right⟩
  rcases hb with ⟨hb_left, hb_right⟩
  rcases hc with ⟨hc_left, hc_right⟩
  rcases hd with ⟨hd_left, hd_right⟩
  rcases he with ⟨he_left, he_right⟩
  -- Use non-linear arithmetic to verify the inequality.
  nlinarith [sq_nonneg (a + b + c + d + e - 1),
    sq_nonneg (a - 1 / 2), sq_nonneg (b - 1 / 2), sq_nonneg (c - 1 / 2),
    sq_nonneg (d - 1 / 2), sq_nonneg (e - 1 / 2)]
