import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Alternative version. For any three reals $x$ , $y$ , $z$ satisfying $x^{2}+y^{2}+z^{2}=9$ , show that $2\left(x+y+z\right)-xyz\leq 10$ . -/
theorem lean_workbook_15019 (x y z : ℝ) (h : x ^ 2 + y ^ 2 + z ^ 2 = 9) :
  2 * (x + y + z) - x * y * z ≤ 10  := by
  /-
  Given three real numbers \( x \), \( y \), and \( z \) such that \( x^2 + y^2 + z^2 = 9 \), we need to show that \( 2(x + y + z) - xyz \leq 10 \).
  To prove this, we use the non-negativity of squares. Specifically, we consider the squares of various expressions involving \( x \), \( y \), and \( z \). By noting that the square of any real number is non-negative, we can derive inequalities that, when combined with the given condition, lead to the desired result.
  -/
  -- Use the non-negativity of squares to derive useful inequalities.
  nlinarith [sq_nonneg (x + y + z - 3), sq_nonneg (x - 2), sq_nonneg (y - 2), sq_nonneg (z - 2),
    sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x), sq_nonneg (x + y - 2),
    sq_nonneg (y + z - 2), sq_nonneg (z + x - 2)]
