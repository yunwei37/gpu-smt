import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Prove that $x^2y+y^2z+z^2x \leq \frac{4}{27}$ given $0 \leq x,y,z\in R$ and $x+y+z=1$. -/
theorem lean_workbook_15916 (x y z : ℝ) (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z) (h : x + y + z = 1) : x ^ 2 * y + y ^ 2 * z + z ^ 2 * x ≤ 4 / 27  := by
  /-
  Given \(0 \leq x, y, z \in \mathbb{R}\) and \(x + y + z = 1\), we need to prove that \(x^2y + y^2z + z^2x \leq \frac{4}{27}\).
  1. **Case Analysis**: We consider different cases based on the relationships between \(x, y, z\) and their sum.
  2. **Non-linear Arithmetic**: Using non-linear arithmetic, we derive the inequalities that bound the expression \(x^2y + y^2z + z^2x\).
  -/
  -- We start by considering different cases based on the relationships between x, y, z and their sum.
  cases' le_total x y with hxy hxy <;>
  cases' le_total y z with hyz hyz <;>
  cases' le_total z x with hzx hzx <;>
  -- Use non-linear arithmetic to derive the inequalities that bound the expression.
  nlinarith [sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x),
    sq_nonneg (x + y + z), sq_nonneg (x + y - 2 * z), sq_nonneg (y + z - 2 * x),
    sq_nonneg (z + x - 2 * y)]
