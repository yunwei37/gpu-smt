import Mathlib
import Aesop
import GpuArithmetic.IntegerPowerOracle

set_option maxHeartbeats 0

open BigOperators Real Nat Topology Rat

/- Let $x,y,z>0 $ ; $ x+y+z=6$ Prove that: $x^{2}+y^{2}+z^{2}-xy-yz-zx+xyz\geq 8$ -/
theorem lean_workbook_15726 (x y z : ℝ) (hx : 0 < x) (hy : 0 < y) (hz : 0 < z) (h : x + y + z = 6) :x^2 + y^2 + z^2 - x*y - y*z - z*x + x*y*z ≥ 8  := by
  /-
  We need to prove that for \( x, y, z > 0 \) with \( x + y + z = 6 \), the inequality \( x^2 + y^2 + z^2 - xy - yz - zx + xyz \geq 8 \) holds.
  1. **Case Analysis**: We consider different cases based on the relationships between \( x, y, \) and \( z \).
  2. **Non-negativity of Squares**: Utilize the fact that the square of any real number is non-negative.
  3. **Inequality Manipulation**: Apply non-linear arithmetic to derive the desired inequality.
  -/
  -- Consider different cases based on the relationships between x, y, and z
  cases' le_total x y with hxy hxy <;>
  cases' le_total y z with hyz hyz <;>
  cases' le_total z x with hzx hzx <;>
  -- Use non-negativity of squares and non-linear arithmetic to derive the inequality
  nlinarith [sq_nonneg (x - y), sq_nonneg (y - z), sq_nonneg (z - x),
    mul_nonneg hx.le hy.le, mul_nonneg hy.le hz.le, mul_nonneg hz.le hx.le,
    sq_nonneg (x - 1), sq_nonneg (y - 1), sq_nonneg (z - 1)]
