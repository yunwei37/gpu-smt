// Run-owned Z3 4.12.5 retained native prefix parent. Never executed at build stage.
#include <iostream>
#include <sstream>
#include <fstream>
#include <filesystem>
#include <map>
#include <vector>
#include <sys/syscall.h>
#include <chrono>
#include <cstdint>
#include <cerrno>
#include <cstring>
#include <csignal>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <ext/stdio_filebuf.h>
#include "util/gparams.h"
#include <poll.h>
#include <unistd.h>
#include "util/memory_manager.h"
#include "util/env_params.h"
#include "util/timeout.h"
#include "util/error_codes.h"
#include "util/z3_exception.h"
#include "parsers/smt2/smt2parser.h"
#include "muz/fp/dl_cmds.h"
#include "cmd_context/extra_cmds/dbg_cmds.h"
#include "cmd_context/extra_cmds/proof_cmds.h"
#include "opt/opt_cmds.h"
#include "cmd_context/extra_cmds/polynomial_cmds.h"
#include "cmd_context/extra_cmds/subpaving_cmds.h"
#include "smt/smt2_extra_cmds.h"
#include "smt/smt_solver.h"

// Protocol is only finite run-owned invocation/FD transport, not research control.
struct request { uint64_t tag; uint32_t kind; uint32_t reserved; };
struct reply { uint64_t tag; int32_t kind; int32_t value; double wall; double cpu; };
static_assert(sizeof(request)==16 && sizeof(reply)==32);
static unsigned tasks() { unsigned n=0; for(auto const& e:std::filesystem::directory_iterator("/proc/self/task")){(void)e; ++n;}return n; }
static void timeout_exit(){_Exit(0);}
static void STD_CALL interrupted(int){signal(SIGINT,SIG_DFL);raise(SIGINT);}
static bool send_reply(int fd, reply const& r){return send(fd,&r,sizeof(r),MSG_NOSIGNAL)==sizeof(r);}
struct state {
    // Prefix stream outlives the parser, including its retained scanner pointer.
    std::string literal;
    std::istringstream input;
    std::ostringstream output,diagnostic;
    cmd_context ctx;
    smt2::parser* parser=nullptr;
    explicit state(std::string bytes):literal(std::move(bytes)),input(literal){
        ctx.set_solver_factory(mk_smt_strategic_solver_factory());
        install_dl_cmds(ctx);install_dbg_cmds(ctx);install_polynomial_cmds(ctx);
        install_subpaving_cmds(ctx);install_opt_cmds(ctx);install_smt2_extra_cmds(ctx);install_proof_cmds(ctx);
        ctx.set_regular_stream(output);ctx.set_diagnostic_stream(diagnostic);
    }
    ~state(){if(parser)smt2::free_parser(parser);}
    bool prepare(){return parse_smt2_commands_with_parser(parser,ctx,input,true);}
    unsigned suffix(std::istream& is=std::cin,std::ostream& os=std::cout,std::ostream& es=std::cerr){
        ctx.set_regular_stream(os);ctx.set_diagnostic_stream(es);
        os<<output.str();es<<diagnostic.str();
        return parse_smt2_commands_with_parser(parser,ctx,is,true)?0:1;
    }
};
static unsigned serve(int control,char const* prefix_path,bool logical){
    auto started=std::chrono::steady_clock::now();
    std::ifstream in(prefix_path,std::ios::binary);if(!in)return 3;
    std::ostringstream bytes;bytes<<in.rdbuf();in.close();
    // Prefix eligibility is checked online by the coordinator before any native
    // preparation. Each parent has its own native globals, manager and parser.
    auto native=new state(bytes.str());
    bool prepared=native->prepare();
    unsigned task_count=tasks();
    bool supported=prepared && (logical || task_count==1) && native->output.str().empty() && native->diagnostic.str().empty();
    double prep_wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
    rusage self{};getrusage(RUSAGE_SELF,&self);
    double prep_cpu=self.ru_utime.tv_sec+self.ru_utime.tv_usec/1e6+self.ru_stime.tv_sec+self.ru_stime.tv_usec/1e6;
    if(!send_reply(control,{0,supported?0:-1,static_cast<int32_t>(task_count),prep_wall,prep_cpu})){delete native;return 3;}
    if(!supported){std::cerr<<native->output.str()<<native->diagnostic.str();delete native;return 4;}
    struct child_record {uint64_t tag; std::chrono::steady_clock::time_point started; int pidfd;};
    std::map<pid_t,child_record> children;
    bool live=true;
    while(live || !children.empty()){
        std::vector<pollfd> watched{{live?control:-1,POLLIN,0}};
        for(auto const& [pid,item]:children){(void)pid;watched.push_back({item.pidfd,POLLIN,0});}
        int polling=poll(watched.data(),watched.size(),-1);
        if(polling<0 && errno!=EINTR)live=false;
        if(live && polling>0 && (watched[0].revents&(POLLIN|POLLHUP|POLLERR))){
            request req{};char ancillary[CMSG_SPACE(3*sizeof(int))]{};
            iovec iov{&req,sizeof(req)};msghdr msg{};msg.msg_iov=&iov;msg.msg_iovlen=1;msg.msg_control=ancillary;msg.msg_controllen=sizeof(ancillary);
            auto received=recvmsg(control,&msg,MSG_CMSG_CLOEXEC);
            if(received!=sizeof(req))live=false;
            else if(req.kind==2){
                for(auto const& [pid,item]:children)if(item.tag==req.tag)kill(-pid,SIGKILL);
            }else if(req.kind==1){
                int fds[3]{-1,-1,-1};auto header=CMSG_FIRSTHDR(&msg);
                bool valid=header && !(msg.msg_flags&(MSG_TRUNC|MSG_CTRUNC)) && header->cmsg_level==SOL_SOCKET && header->cmsg_type==SCM_RIGHTS && header->cmsg_len==CMSG_LEN(sizeof(fds));
                if(valid)std::memcpy(fds,CMSG_DATA(header),sizeof(fds));
                if(!valid || (!logical && tasks()!=1)){
                    for(int fd:fds)if(fd>=0)close(fd);
                    send_reply(control,{req.tag,-1,0,0,0});continue;
                }
                if(logical){
                    auto job_start=std::chrono::steady_clock::now();rusage before{};getrusage(RUSAGE_SELF,&before);
                    state* candidate=nullptr;unsigned rc=3;
                    try{
                        // Independent native lazy target manager; replay all
                        // namespace/option setup and charge it, instead of
                        // pretending solver translation copies a command context.
                        // In this Z3 version reset() frees region-backed module keys but
                        // retains their registered maps. Recreate the global
                        // parameter registry before replaying this candidate.
                        // Logical requests are serialized by their parent.
                        gparams::finalize();gparams::init();env_params::updt_params();
                        candidate=new state(native->literal);
                        bool ready=candidate->prepare() && candidate->output.str().empty() && candidate->diagnostic.str().empty();
                        auto source=native->ctx.get_solver();
                        ready=ready && source && candidate->ctx.has_manager();
                        solver_ref translated;
                        if(ready){
                            translated=source->translate(candidate->ctx.m(),source->get_params());
                            auto const& asserted=candidate->ctx.assertions();
                            ready=translated && translated->get_num_assertions()==asserted.size();
                            // Native translated assertion graphs must resolve to
                            // the independently reparsed target namespace. Any
                            // mismatch refuses before consuming candidate suffix.
                            for(unsigned i=0;ready && i<asserted.size();++i)
                                ready=translated->get_assertion(i)==asserted[i];
                        }
                        if(!ready){translated.reset();delete candidate;for(int fd:fds)close(fd);send_reply(control,{req.tag,-1,0,0,0});continue;}
                        candidate->ctx.set_solver(translated.get());
                        // Context now owns the solver. Release this extra ref
                        // while its target AST manager is still alive.
                        translated.reset();
                        if(!send_reply(control,{req.tag,1,static_cast<int32_t>(getpid()),0,0})){delete candidate;for(int fd:fds)close(fd);live=false;continue;}
                        __gnu_cxx::stdio_filebuf<char> ib(fds[0],std::ios::in),ob(fds[1],std::ios::out),eb(fds[2],std::ios::out);
                        std::istream stream_in(&ib);std::ostream stream_out(&ob),stream_error(&eb);
                        fds[0]=fds[1]=fds[2]=-1;
                        try{rc=candidate->suffix(stream_in,stream_out,stream_error);}
                        catch(z3_exception const& ex){stream_error<<"ERROR: "<<ex.msg()<<'\n';rc=ex.has_error_code()?ex.error_code():ERR_INTERNAL_FATAL;}
                        catch(std::exception const& ex){stream_error<<ex.what()<<'\n';rc=3;}
                        stream_out.flush();stream_error.flush();delete candidate;candidate=nullptr;
                    }catch(z3_exception const&){delete candidate;for(int fd:fds)if(fd>=0)close(fd);send_reply(control,{req.tag,-1,0,0,0});continue;}
                    catch(std::exception const&){delete candidate;for(int fd:fds)if(fd>=0)close(fd);send_reply(control,{req.tag,-1,0,0,0});continue;}
                    rusage after{};getrusage(RUSAGE_SELF,&after);
                    double cpu=(after.ru_utime.tv_sec-before.ru_utime.tv_sec)+(after.ru_utime.tv_usec-before.ru_utime.tv_usec)/1e6+(after.ru_stime.tv_sec-before.ru_stime.tv_sec)+(after.ru_stime.tv_usec-before.ru_stime.tv_usec)/1e6;
                    double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-job_start).count();
                    send_reply(control,{req.tag,2,static_cast<int32_t>(rc<<8),wall,cpu});continue;
                }
                std::cout.flush();std::cerr.flush();auto begin=std::chrono::steady_clock::now();pid_t parent=getpid();pid_t pid=fork();
                if(pid==0){
                    setpgid(0,0);prctl(PR_SET_PDEATHSIG,SIGKILL);
                    if(getppid()!=parent)_exit(3);
                    for(int i=0;i<3;++i)if(dup2(fds[i],i)<0)_exit(3);
                    for(int fd:fds)if(fd>2)close(fd);close(control);
                    unsigned rc=3;
                    try{rc=native->suffix();}
                    catch(z3_exception const& ex){std::cerr<<"ERROR: "<<ex.msg()<<'\n';rc=ex.has_error_code()?ex.error_code():ERR_INTERNAL_FATAL;}
                    catch(std::exception const& ex){std::cerr<<ex.what()<<'\n';}
                    std::cout.flush();std::cerr.flush();
                    // Native object destruction/finalization occurs in the owned
                    // branch, before terminal wait receipt; no inherited reset.
                    delete native;disable_timeout();memory::finalize();_exit(rc);
                }
                for(int fd:fds)close(fd);
                if(pid<0){send_reply(control,{req.tag,-1,errno,0,0});continue;}
                setpgid(pid,pid);
                int pidfd=static_cast<int>(syscall(SYS_pidfd_open,pid,0));
                if(pidfd<0){
                    kill(-pid,SIGKILL);int stopped=0;while(waitpid(pid,&stopped,0)<0 && errno==EINTR){}
                    send_reply(control,{req.tag,-1,0,0,0});continue;
                }
                children.emplace(pid,child_record{req.tag,begin,pidfd});
                send_reply(control,{req.tag,1,static_cast<int32_t>(pid),0,0});
            }else live=false;
        }
        if(!live)for(auto const& [pid,item]:children){(void)item;kill(-pid,SIGKILL);}
        for(auto it=children.begin();it!=children.end();){
            int status=0;rusage use{};pid_t done=wait4(it->first,&status,WNOHANG,&use);
            if(done==it->first){
                double wall=std::chrono::duration<double>(std::chrono::steady_clock::now()-it->second.started).count();
                double cpu=use.ru_utime.tv_sec+use.ru_utime.tv_usec/1e6+use.ru_stime.tv_sec+use.ru_stime.tv_usec/1e6;
                send_reply(control,{it->second.tag,2,status,wall,cpu});close(it->second.pidfd);it=children.erase(it);
            }else if(done<0 && errno!=EINTR){send_reply(control,{it->second.tag,-2,errno,0,0});close(it->second.pidfd);it=children.erase(it);}
            else ++it;
        }
        
    }
    delete native;return 0;
}
int STD_CALL main(int argc,char** argv){
    if(argc!=4 || (strcmp(argv[3],"branch") && strcmp(argv[3],"logical")))return 2;
    try{
        memory::initialize(0);memory::exit_when_out_of_memory(true,"ERROR: out of memory");env_params::updt_params();memory::exit_when_out_of_memory(true,"(error \"out of memory\")");
        register_on_timeout_proc(timeout_exit);signal(SIGINT,interrupted);
        unsigned result=serve(std::stoi(argv[1]),argv[2],!strcmp(argv[3],"logical"));disable_timeout();memory::finalize();return result;
    }catch(z3_exception const& ex){std::cerr<<ex.msg()<<'\n';return ex.has_error_code()?ex.error_code():ERR_INTERNAL_FATAL;}
    catch(std::exception const& ex){std::cerr<<ex.what()<<'\n';return 3;}
}
