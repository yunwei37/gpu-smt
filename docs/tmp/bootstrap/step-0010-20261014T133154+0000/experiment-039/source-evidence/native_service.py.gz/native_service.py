#!/usr/bin/env python3
"""Finite benchmark-owned retained native prefix service. Not run at build stage.

Online history is only received earlier different-source literal bytes. No trace
labels, outcomes or future preloading. Parent misses/evictions/branches and
terminal native CPU/wait are recorded. Process placement limits are mandatory.
"""
import argparse
import bisect
import array
import hashlib
import gzip
import json
import os
from pathlib import Path
import select
import signal
import socket
import socketserver
import struct
import subprocess
import threading
import time
from service_common import receive_exact, receive_json, send_json, eligible

REQ = struct.Struct('=QII')
REP = struct.Struct('=Qiidd')


class Parent:
    def __init__(self, prefix, owner):
        self.digest = hashlib.sha256(prefix).hexdigest()
        self.method = owner.method
        self.logical_lock = threading.Lock()
        self.closed = False
        self.prefix_path = owner.scratch / ('prefix-'+self.digest+'.smt2')
        if not self.prefix_path.exists():
            self.prefix_path.write_bytes(prefix)
        preserved = owner.out / ('prefix-'+self.digest+'.smt2.gz')
        if not preserved.exists():
            with gzip.open(preserved,'wb') as target:
                target.write(prefix)
        self.started = time.monotonic()
        self.control, peer = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        self.log = (owner.out / ('parent-'+self.digest+'.stderr')).open('ab')
        self.proc = subprocess.Popen([owner.native_parent, str(peer.fileno()), str(self.prefix_path), self.method],
                                     pass_fds=(peer.fileno(),), stdin=subprocess.DEVNULL,
                                     stdout=subprocess.DEVNULL, stderr=self.log)
        peer.close()
        initial = self.control.recv(REP.size)
        if len(initial) != REP.size:
            self.control.close()
            self.proc.wait()
            self.log.close()
            raise RuntimeError('native parent closed before readiness')
        tag, kind, task_count, wall, cpu = REP.unpack(initial)
        self.ready = kind == 0 and tag == 0 and (self.method == 'logical' or task_count == 1)
        self.last_used = self.started
        self.pending = {}
        self.lock = threading.Lock()
        self.send_lock = threading.Lock()
        owner.emit(dict(kind='parent-preparation', prefix_sha256=self.digest,
                        bytes=len(prefix), pid=self.proc.pid, supported=self.ready,
                        observed_tasks=task_count, native_wall_s=wall, native_cpu_s=cpu,
                        launch_ready_wall_s=time.monotonic()-self.started))
        if not self.ready:
            self.control.close()
            self.proc.wait()
            self.log.close()
            raise RuntimeError('native prefix boundary refused')
        self.reader = threading.Thread(target=self.read, daemon=True)
        self.reader.start()

    def read(self):
        try:
            while True:
                data = self.control.recv(REP.size)
                if len(data) != REP.size:
                    raise EOFError('native parent terminal')
                tag, kind, value, wall, cpu = REP.unpack(data)
                with self.lock:
                    row = self.pending.get(tag)
                    if row is None:
                        continue
                    if kind == 1:
                        row['pid'] = value
                        row['accepted'].set()
                    else:
                        row.update(kind=kind, value=value, wall_s=wall, cpu_s=cpu)
                        row['accepted'].set()
                        row['done'].set()
        except (OSError, EOFError) as exc:
            with self.lock:
                for row in self.pending.values():
                    if not row['done'].is_set():
                        row.update(kind=-2, value=str(exc), wall_s=None, cpu_s=None)
                        row['accepted'].set()
                        row['done'].set()

    def branch(self, tag, fds):
        if self.method == 'logical':
            self.logical_lock.acquire()
        row = dict(accepted=threading.Event(), done=threading.Event(), pid=None)
        with self.lock:
            self.pending[tag] = row
            self.last_used = time.monotonic()
        try:
            with self.send_lock:
                self.control.sendmsg([REQ.pack(tag, 1, 0)], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array('i', fds))])
        except OSError:
            with self.lock:
                self.pending.pop(tag, None)
            if self.method == 'logical':
                self.logical_lock.release()
            raise
        row['accepted'].wait()
        return row

    def cancel(self, tag):
        if self.method == 'logical':
            # Killing the exact logical worker disposes the active candidate and
            # its retained prefix; next lookup rebuilds, with that miss charged.
            self.proc.terminate()
            return
        with self.send_lock:
            self.control.send(REQ.pack(tag, 2, 0))

    def idle(self):
        with self.lock:
            return not self.pending

    def close(self):
        if self.closed:
            return
        self.closed = True
        # Control EOF instructs this exact parent to kill/reap its owned branches.
        try:
            self.control.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.control.close()
        self.proc.wait()
        self.reader.join()
        self.log.close()


class Owner:
    def __init__(self, args):
        self.out = args.out.resolve()
        self.out.mkdir(parents=True, exist_ok=False)
        self.scratch = args.scratch.resolve()
        self.scratch.mkdir(parents=True, exist_ok=False)
        self.native_parent = str(args.native_parent.resolve())
        self.method = args.method
        self.max_parents = args.max_parents
        self.history_size = args.history_size
        self.history = []
        self.prefix_index = []
        self.entries = {}
        self.parents = {}
        self.order = threading.Condition()
        self.next_sequence = 1
        self.skipped = set()
        self.receipt_lock = threading.Lock()
        self.receipts = (self.out / 'service.jsonl').open('a')
        self.emit(dict(kind='service-start', argv=os.sys.argv, pid=os.getpid(),
                       native_parent=self.native_parent, affinity=sorted(os.sched_getaffinity(0)),
                       max_parents=self.max_parents, history_size=self.history_size, history_unlimited_within_finite_block=self.history_size==0, method=self.method,
                       no_preloaded_history=True))

    def emit(self, record):
        record['monotonic_s'] = time.monotonic()
        with self.receipt_lock:
            self.receipts.write(json.dumps(record)+'\n')
            self.receipts.flush()

    def select(self, sequence, metadata, initial):
        with self.order:
            while sequence != self.next_sequence:
                self.order.wait()
            try:
                try:
                    ends = eligible(initial)
                except ValueError as exc:
                    self.emit(dict(kind='online-lookup',sequence=sequence,source_sha256=metadata['source_sha256'],
                                   route='stock-unsupported-boundary-framing',error=repr(exc)))
                    return None,0,'stock-unsupported-boundary-framing'
                current = initial[:ends[-1]] if ends else b''
                best = b''
                witness = None
                position = bisect.bisect_left(self.prefix_index, (current, -1))
                neighbors = []
                for index, direction in [(position-1,-1),(position,1)]:
                    while 0 <= index < len(self.prefix_index):
                        previous = self.entries[self.prefix_index[index][1]]
                        if previous['source_sha256'] != metadata['source_sha256']:
                            neighbors.append(previous)
                            break
                        index += direction
                # Eligible lexicographic neighbors maximize literal byte LCP.
                # The sorted index changes lookup cost, never arrival eligibility.
                for previous in neighbors:
                    older = previous['prefix']
                    low, high = 0, min(len(older),len(current))
                    while low < high:
                        middle = (low+high+1)//2
                        if older[:middle] == current[:middle]:
                            low = middle
                        else:
                            high = middle-1
                    common = low
                    intersection = set(previous['ends'])
                    shared = [end for end in ends if end <= common and end in intersection]
                    if shared and shared[-1] > len(best):
                        best = current[:shared[-1]]
                        witness = previous['sequence']
                # Store only currently arrived source bytes after the earlier-only
                # query. No other candidate's result or future capture is accessed.
                if current:
                    entry=dict(sequence=sequence, source_sha256=metadata['source_sha256'],prefix=current, ends=ends)
                    self.history.append(entry)
                    self.entries[sequence]=entry
                    bisect.insort(self.prefix_index,(current,sequence))
                    if self.history_size>0 and len(self.history)>self.history_size:
                        removed=self.history.pop(0)
                        self.entries.pop(removed['sequence'])
                        key=(removed['prefix'],removed['sequence'])
                        self.prefix_index.pop(bisect.bisect_left(self.prefix_index,key))
                record = dict(kind='online-lookup', sequence=sequence,
                              source_sha256=metadata['source_sha256'], initial_bytes=len(initial),
                              eligible_bytes=len(current), prefix_bytes=len(best), earlier_witness=witness)
                if not best:
                    record['route'] = 'stock-no-earlier-prefix'
                    self.emit(record)
                    return None, 0, record['route']
                digest = hashlib.sha256(best).hexdigest()
                parent = self.parents.get(digest)
                if parent is not None and parent.proc.poll() is not None:
                    parent.close()
                    self.parents.pop(digest)
                    self.emit(dict(kind='parent-departed', pid=parent.proc.pid, returncode=parent.proc.returncode, prefix_sha256=digest))
                    parent = None
                if parent is None:
                    if len(self.parents) >= self.max_parents:
                        idle = [p for p in self.parents.values() if p.idle()]
                        if not idle:
                            record['route'] = 'stock-parent-capacity-busy'
                            self.emit(record)
                            return None, 0, record['route']
                        old = min(idle, key=lambda p: p.last_used)
                        old.close()
                        self.parents.pop(old.digest)
                        self.emit(dict(kind='parent-eviction', prefix_sha256=old.digest,
                                       pid=old.proc.pid, terminal_returncode=old.proc.returncode))
                    try:
                        parent = Parent(best, self)
                    except (OSError, RuntimeError) as exc:
                        record.update(route='stock-native-boundary-refused', error=repr(exc))
                        self.emit(record)
                        return None, 0, record['route']
                    self.parents[digest] = parent
                    record['parent_miss'] = True
                else:
                    record['parent_miss'] = False
                record.update(route='retained-native-branch', prefix_sha256=digest, parent_pid=parent.proc.pid)
                self.emit(record)
                return parent, len(best), record['route']
            finally:
                self.next_sequence += 1
                while self.next_sequence in self.skipped:
                    self.skipped.remove(self.next_sequence)
                    self.next_sequence += 1
                self.order.notify_all()

    def close(self):
        for parent in self.parents.values():
            parent.close()
            self.emit(dict(kind='parent-terminal', pid=parent.proc.pid,
                           returncode=parent.proc.returncode, prefix_sha256=parent.digest))
        self.emit(dict(kind='service-terminal', pid=os.getpid()))
        self.receipts.close()


class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        sequence = self.server.sequences.pop(self.request.fileno())
        fds = []
        parent = None
        row = None
        try:
            header, ancillary, flags, _ = self.request.recvmsg(16, socket.CMSG_SPACE(3*array.array('i').itemsize))
            header += receive_exact(self.request, 16-len(header))
            if flags & socket.MSG_CTRUNC:
                raise ValueError('truncated descriptors')
            for level, kind, data in ancillary:
                if level == socket.SOL_SOCKET and kind == socket.SCM_RIGHTS:
                    arr = array.array('i')
                    arr.frombytes(data)
                    fds.extend(arr)
            meta_bytes, initial_bytes = struct.unpack('!QQ', header)
            metadata = json.loads(receive_exact(self.request, meta_bytes))
            initial = receive_exact(self.request, initial_bytes)
            if len(fds) != 3 or metadata.get('argv') != ['-smt2', '-in'] or metadata.get('method') != self.server.owner.method or not isinstance(metadata.get('source_sha256'), str) or len(metadata['source_sha256']) != 64:
                raise ValueError('unsupported caller metadata/descriptors')
            parent, prefix_bytes, route = self.server.owner.select(sequence, metadata, initial)
            if parent is None:
                send_json(self.request, dict(route='stock', reason=route, sequence=sequence))
                return
            row = parent.branch(sequence, fds)
            if row['pid'] is None:
                send_json(self.request, dict(route='stock', reason='native-branch-refused', sequence=sequence))
                return
            send_json(self.request, dict(route='branch', sequence=sequence,
                                        prefix_bytes=prefix_bytes, parent_pid=parent.proc.pid,
                                        child_pid=row['pid'], prefix_sha256=parent.digest))
            cancelled = False
            while not row['done'].wait(.1):
                readable, _, _ = select.select([self.request], [], [], 0)
                if readable:
                    if not self.request.recv(1, socket.MSG_PEEK):
                        parent.cancel(sequence)
                        cancelled = True
                        row['done'].wait()
                        break
            terminal = dict(sequence=sequence, route='branch', child_pid=row['pid'],
                            cancelled_caller_disconnect=cancelled, wait_status=row.get('value'),
                            native_terminal_kind=row.get('kind'), native_wall_s=row.get('wall_s'),
                            native_cpu_s=row.get('cpu_s'))
            self.server.owner.emit(dict(kind='branch-terminal', **terminal))
            if not cancelled:
                send_json(self.request, terminal)
        except (EOFError, OSError, ValueError) as exc:
            self.server.owner.emit(dict(kind='caller-error', sequence=sequence, error=repr(exc)))
            if parent is not None and row is not None and row['pid'] is not None:
                try:
                    parent.cancel(sequence)
                    row['done'].wait()
                except OSError:
                    pass
            # Advance malformed arrivals so subsequent legitimate calls cannot
            # wait forever for a skipped sequence; do not create native state.
            with self.server.owner.order:
                if sequence >= self.server.owner.next_sequence:
                    self.server.owner.skipped.add(sequence)
                    while self.server.owner.next_sequence in self.server.owner.skipped:
                        self.server.owner.skipped.remove(self.server.owner.next_sequence)
                        self.server.owner.next_sequence += 1
                    self.server.owner.order.notify_all()
        finally:
            for fd in fds:
                os.close(fd)
            if parent is not None and row is not None:
                with parent.lock:
                    parent.pending.pop(sequence, None)
                if parent.method == 'logical':
                    parent.logical_lock.release()


class Server(socketserver.ThreadingUnixStreamServer):
    daemon_threads = False
    def __init__(self, address, owner):
        self.owner = owner
        self.sequence = 0
        self.sequences = {}
        super().__init__(address, Handler)
    def get_request(self):
        client, address = super().get_request()
        self.sequence += 1
        self.sequences[client.fileno()] = self.sequence
        return client, address


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--socket', type=Path, required=True)
    p.add_argument('--native-parent', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--scratch', type=Path, required=True)
    p.add_argument('--method', choices=['branch','logical'], required=True)
    p.add_argument('--max-parents', type=int, required=True)
    p.add_argument('--history-size', type=int, required=True)
    a = p.parse_args()
    if a.max_parents<1 or a.history_size<0 or a.socket.exists():
        p.error('positive parent placement, nonnegative history size (0=all earlier finite-block arrivals), and a new owned socket required')
    owner = Owner(a)
    server = Server(str(a.socket), owner)
    os.chmod(a.socket, 0o600)
    def stop(signum, frame):
        threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        server.serve_forever()
    finally:
        # Cancel owned native children before waiting for caller handlers, so a
        # long solve cannot hold server shutdown indefinitely.
        for parent in list(owner.parents.values()):
            with parent.lock:
                tags = list(parent.pending)
            for tag in tags:
                try:
                    parent.cancel(tag)
                except OSError:
                    pass
        server.server_close()
        owner.close()
        a.socket.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
