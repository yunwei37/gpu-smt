## Current work: arithmetic counterexamples

Our method proposes numeric counterexamples on RTX 5090, checks them exactly
on CPU, and fails only the current false arithmetic tactic. Unsupported
contexts or no exact witness retain native execution and enclosing proof
alternatives. Existing SHRED, Kimina and Farkas comparisons are retained;
no further reproduction or integration is planned.

The complete original **7,808-source miniF2F observation is still running**.
Full false-goal/timeout coverage, native off/on acceptance consistency and
end-to-end benefit remain open. The initial off/observation check on 32 sources
preserves 28 complete and four rejected outcomes.

A fixed partial snapshot finds **13 exact witnesses in 11 of 1,758 observed
candidates**. All 11 end in ordinary Lean errors, none in a timeout. This
does not establish the full false-goal fraction or saved wall time.
The known witnesses refute current proof obligations rather than their
original theorem statements; the11sources cover5underlying tasks.
[Original-source interpretation](artifacts/arithmetic-counterexample-2026-10-23/witness-origins-20261024T0715/result-review.md).
Three separate 300-second timeout examples contain nine captured arithmetic
goals that hold on their complete feasible integer domain. The current hook
cannot refute those goals. [Costly-case applicability analysis](artifacts/arithmetic-counterexample-2026-10-23/timeout-factorization-20261024T0805/result-review.md)
does not establish a whole-population or GPU impossibility bound.


[Coverage and cost limits](artifacts/arithmetic-counterexample-2026-10-23/coverage-snapshot-20261024T0543/result-review.md).

Actual RTX 5090 qualification processes 474 retained goals with the same two
CPU-exact witnesses and no invalid returned points. A subsequent persistent
worker check handles 84 closed goals on CPU and 390 device requests, with both
workers/provider exiting with code 0 and the owned Job gone. These are **functional
checks, not end-to-end proof acceleration or actual candidate batching**.
[Device qualification](artifacts/arithmetic-counterexample-2026-10-23/gpu-point-qualification-1/result-review.md),
[worker-stream qualification and retained failure](artifacts/arithmetic-counterexample-2026-10-23/gpu-worker-stream-qualification-2/result-review.md).

[Current plan](artifacts/arithmetic-counterexample-2026-10-23/plan.md),
[Lean qualification](artifacts/arithmetic-counterexample-2026-10-23/qualification-review.md),
[implementation and commands](bench/lean-counterexample/README.md).
