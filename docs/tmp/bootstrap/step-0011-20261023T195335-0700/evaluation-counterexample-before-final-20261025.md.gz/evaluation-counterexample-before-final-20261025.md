## Current user-directed arithmetic counterexample measurement

Further external-method reproduction/integration is stopped by userdecision.
[Ownmethod plan](../artifacts/arithmetic-counterexample-2026-10-23/plan.md)
tests GPUproposed/CPUexactchecked refutation of intermediate arithmeticgoals,
nativefallback and untouched-original outcome parity. Failure is not falsity;
a refuted branch is not a false originaltheorem. All4RQ remainopen.

The untouched native7808baseline iscomplete:3014SDKvalid/4669Leanerrors/
83timeouts/42resourcefailures, whole21693.761299439s, same2actualREPLs/
24GiBeach/48GiBaggregate/CPUs8–11. Keep allresourcefailures andtimeoutcosts.
[Originalfullattempt/native and failedGPUraw](../artifacts/arithmetic-counterexample-2026-10-23/native-gpu-full-20261024T0913/failure-result-review.md)
retains2214GPUresponses beforethe demonstrated control-transport cleanup
failure. Detached single-client observation repair isqualified;
[actual24/replay/cleanup](../artifacts/arithmetic-counterexample-2026-10-23/native-gpu24-detached-repair2-20261024T1640/result-review.md).

A later actualcomparison finds109nativeaccepted sources rejected byold
source-wrapperparsererrors. Oldcensus/timeoutpartition numbers therefore
describe thatinstrumentedversion, not finaloriginalsourcecoverage.
Currentpaper withdraws provisionalpopulationconclusions; raw andhistory
remain. [Original109losses, layoutrepair and realqualification](../artifacts/arithmetic-counterexample-2026-10-23/layout-regression-20261024T1644/result-review.md)
preserves them, the intentionallycancelled invalidrerun and allcleanupreceipts.

Repairedpreparation preservesLeanlayout, reparseswithnativeparser and falls
back toexactoriginalsource. Full7808preparation wraps4272sources/8578tactics;
13transformedparsefailures retainoriginals. Real24 usesuntouchedoff:
19valid/5errorsboth, threeactuallyregressedpositives restored,
18deviceRPCs/2exactwitnesses,0fallbackerrors, allchildren/provider/Jobretired.
These are qualificationfacts, not completespeedup or independentaudit.

Next is the corrected completeGPUrun fromzero against retaineduntouched
nativebaseline. No partial GPUsplicing, oldobserverdenominator, algorithm/
resourcevariation or extrapolated performanceclaim. Charge own preparation/
reparse/device/queue/exact/fallback/cancellation/cleanup, and report native-
ranked tails, failedrequests, timeout and every outcomechange.
[Priorcounterexample chronology](tmp/bootstrap/step-0011-20261023T195335-0700/evaluation-counterexample-history-20261024T1650.md.gz)
is retainedasdatedhistory, not freshlyvalidated currentstate.
