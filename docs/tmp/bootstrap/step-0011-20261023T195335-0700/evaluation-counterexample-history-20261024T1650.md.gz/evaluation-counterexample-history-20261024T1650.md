## Current user-directed arithmetic counterexample measurement
Furtherexternal-methodreproduction/integration is stopped byuserdecision.
Existingcomparisonsremain. [Own-method plan](../artifacts/arithmetic-counterexample-2026-10-23/plan.md)
tests GPUproposed/CPUexactchecked counterexamples at actualarithmeticgoals,
with nativefallback and all48GiBresourceconstraints. ExistingfullminiF2F
census4793non-complete/7808sources consumes87.660953%of cumulativeHTTPenvelopes,
not wholewall.51of71timeouts mentionarithmetic;2024printactual linarithfailure.
These are notfalse-goalcounts. [All-source costs and limits](../artifacts/arithmetic-counterexample-2026-10-23/failure-cost-review.md).
The completed own extraction below separates exactwitness/no-witness/
unsupported while retaining native candidate/tacticalternative behavior.


## Complete own7808 arithmetic-goal census,2026-10-24UTC
[Closed census and self-review](../artifacts/arithmetic-counterexample-2026-10-23/full-coverage-analysis-20261024T0907/result-review.md)
reports15372entries/3701sources;8407supportedentries/1485sources.
Fixed4096-point seed0 proposals plus exact checks refute30intermediate goals
in25sources, allLeanerrors, out of4903failed requests. Their current overlapping
HTTPsums33.435316s/35613.993576s (0.093883%) do not establish savedwalltime.
Zero of78timeouts and zero observation-ranked slowest1% have a witness.
No-witness/unsupported/unobserved remain unknown. All7808returned:
2905SDKvalid/4782Leanerror/78timeout/43resourcefailure.
Whole20903.803838s including input preparation; peak46.648457GiB/max2,
0watchdogerrors/kills, allchildrenretired; source24GiBeach/48total/CPUs8–11.
This census challenges first-recipe applicability to expensive failures,
not globalGPUimpossibility. Existingnative24 and fullownoff/on remain next.


[Actualnative/GPU24preflight](../artifacts/arithmetic-counterexample-2026-10-23/native-gpu24-20261024T0915/result-review.md)
returns19valid/5Leanerrors inbothcells,17actual5090requests,2exactwitnesses,
0fallbackerrors/acceptancechanges, completechild/device/Jobretirement.
All17batches are singletons. Smallwarm4.342/4.220s clocks are not a speedup
result. The fulloriginal7808native/off versus GPU/on pair is admitted next.


[Fulltimeoutapplicability](../artifacts/arithmetic-counterexample-2026-10-23/timeout-population-analysis-20261024T0918/result-review.md)
groups78timeoutsinto26tasks. All39supportedentries from17Natfactorization
timeouts admit no counterexample over their complete retaineddomain.
945closedentries fromoneothertimeout consistof944falsecontexts/1truegoal.
984of1020supportedtimeoutentries arethereforeinapplicable to refutation;
thisentrycountisdominatedbyonecandidate, not awalltimebound. Theother36
variableentries andmissing/unsupportedcontexts remainunknown.


The firstfullownscreeningpair suffered a control-lifecycle failure:
nativeoff7808complete/21693.761299439s; GPUonly2214sources returned
beforeproviderRSSconnectionreset. No fullratio isadmissible.
[Failure/raw/cleanup and repair route](../artifacts/arithmetic-counterexample-2026-10-23/native-gpu-full-20261024T0913/failure-result-review.md).
Keepnativebaseline; repairobserver-loss handling before completeGPUrerun.


### Current qualification correction: original-source layout
The completed untouched nativebaseline reveals109previouslyaccepted sources
rejected by old wrapperparsererrors. Earlier24off/on bothrewroteinputs and
masked this defect. Oldcensus/timeoutpopulation counts above describe that
instrumentedversion, not proven original-source parity or finalcoverage.
[Actual109regressions and diagnosis](../artifacts/arithmetic-counterexample-2026-10-23/layout-regression-20261024T1644/diagnosis.json).
Currentpaper removes provisionalpopulationconclusions; allraw/failedrecords
remain. Freshlayoutpreservation/native-reparsefallback and untouched-original
offqualification precede a corrected completeGPUrun; nativebaseline isretained.
