## Current frontier

The user's current experiment is our own exact-checked arithmetic
counterexample screen within RQ4. Existing external-system comparisons are
retained and are not being extended. The original Initial Narrative, four
RQs and Lean/SMT/OSDI-quality objective remain open and unfrozen. No surviving
new systems contribution or useful additional GPU effect is established.

The original7,808source typed-goal observation is active on its frozen
source/worker, with the current48GiBaggregate/max2REPLs/24GiBeach resource
contract. The completed RTX5090 offline474entry qualification finds the same
two exact witnesses as CPU and retires its provider/context/Job. It is
functional hardware evidence, not nativeproof equivalence or acceleration.
The larger immutable prefix finds13witness entries in11sources, all ordinary
Lean errors. Of19currently returned timeouts,13have no arithmetic entry,
five have unsupported entries and one has supported entries. The main
uncertainty is cost coverage of false goals, not point-kernel throughput.
[Actual data and current interpretation](evaluation.md#current-own-method-frontier).

A separate alias build is compiled for future native qualification, and the
future worker evaluates supported closed arithmetic once onCPU. Native24and
complete same-candidate off/on measurement remain pending. The current
observer and raw/failed data are preserved. Root alone implements and reviews;
no independent audit is claimed. The sole current manuscript is
[docs/paper](paper/main.tex). The
[12-round writing self-review](tmp/bootstrap/step-0011-20261023T195335-0700/iter-refine-writing-20261024T0615/round-11-meaning-preservation.md)
preserves every numerical value, allfourRQ and missingresultslots. Scientific
evidence and submission readiness are not supplied by writing.

The next decisive action is to collect the existing full observation at
actual completion, qualify our native24device path, and measure whole
off/on failure/timeout/tail costs. Do not restart healthy acquisition or
extend oldcompetitors/narrowkernels to create activity. The complete dated
frontier that preceded this condensation is retained
[verbatim](tmp/bootstrap/step-0011-20261023T195335-0700/idea-frontier-through-20261024T0630.md.gz);
its pending statements describe their original dates, not current live state.

